################################################################################
#
# Copyright 2020 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: Adithya Avvaru (adithya.avvaru@teradata.com)
# Secondary Owner: Gouri.Patwardhan (gouri.patwardhan@teradata.com)
#
# This file has the following implementations for enabling tdplyr integration with the
# Script Table Operator:
#   1.  Constructor for Script operator.
#   2.  Setup test environment module for the operator.
#   3.  Test module for the operator.
#   4.  Set data module which helps in recreating ScriptTableOperator object.
#   5.  Execute script function to run user script in Vantage.
#
################################################################################

#' Set data
#'
#' This function enables the user to set data and data related arguments without having to
#' re-create any object. The object is of class "ScriptTableOperator".\cr
#' Note: All data related arguments that are not specified in this function are reset to
#' default values.
#'
#' @param object Required Argument.\cr
#'               Specifies the ScriptTableOperator object containing the details.
#' @param ... Any additional arguments, if required.
#' @export
td_set_data <- function(object, ...) {
  UseMethod("td_set_data")
}

#' Test user script
#'
#' This function enables the user to run script in docker container environment outside Vantage.
#' Input data for user script is read from file or Vantage.
#'
#' @param object Required Argument.\cr
#'               Specifies the ScriptTableOperator object containing the details that are needed
#'              for testing user script.
#' @param ... Any additional arguments, if required.
#' @export
td_test_script <- function(object, ...) {
  UseMethod("td_test_script")
}

#' Execute user script
#'
#' This function enables the user to execute script on Teradata Vantage.\cr
#'
#' @param object Required Argument.\cr
#'               Specifies the ScriptTableOperator object containing the details that are needed
#'               for executing the user script.
#' @param ... Any additional arguments, if required.
#' @export
td_execute_script <- function(object, ...) {
  UseMethod("td_execute_script")
}

#' Creates and initializes an object of "ScriptTableOperator" class.
#'
#' This function constructs a ScriptTableOperator object, that can be used to execute a
#' user-installed script or any Linux command inside database on Teradata Vantage.
#'
#' @param script.command Required Argument.\cr
#'                       Specifies the command/script to run.\cr
#'                       Types: character
#' @param returns Required Argument.\cr
#'                Specifies the output column definition. It contains a named list of key-value
#'                pairs where key contains the column name and value contains the Teradata
#'                SQL data type.\cr
#'                Types: named list of characters
#' @param data Optional Argument.\cr
#'             Specifies the tbl_teradata containing the input for the script.\cr
#'             Default Value: NULL\cr
#'             Types: tbl_teradata
#' @param data.hash.column Optional Argument.\cr
#'                         Specifies the input tbl_teradata column to be used for hashing.\cr
#'                         The rows in the data are redistributed to AMPs based on the hash
#'                         value of the column specified. The user-installed script file then
#'                         runs once on each AMP.\cr
#'                         Note: This argument cannot be specified along with the arguments
#'                         "data.partition.column" and "data.order.column".\cr
#'                         Default Value: NULL\cr
#'                         Types: character
#' @param data.partition.column Optional Argument.\cr
#'                              Specifies Partition By columns for "data".\cr
#'                              Values to this argument can be provided as a vector, if multiple
#'                              columns are used for partition.\cr
#'                              Note:
#'                              \enumerate{
#'                              \item This argument cannot be specified along with
#'                              "data.hash.column" argument.
#'                              \item This argument cannot be specified when the argument
#'                              "is.local.order" is set to TRUE.
#'                              \item If this argument is not specified, then the entire result
#'                              set, delivered by the function, constitutes a single group or
#'                              partition.
#'                              }
#'                              Permitted Values: "ANY" OR one or more columns in "data"
#'                              tbl_teradata.\cr
#'                              Default Value: NULL\cr
#'                              Types: character OR vector of characters
#' @param data.order.column Optional Argument.\cr
#'                          Specifies Order By columns for "data".\cr
#'                          Values to this argument can be provided as a vector, if multiple
#'                          columns are used for ordering.\cr
#'                          This column(s) mentioned in the argument is/are used in ordering
#'                          irrespective of whether the argument "is.local.order" is set to
#'                          TRUE or not.\cr
#'                          Note: This argument cannot be specified along with the argument
#'                          "data.hash.column".\cr
#'                          Default Value: NULL\cr
#'                          Types: character OR vector of characters
#' @param is.local.order Optional Argument.\cr
#'                       Specifies whether the input data is to be ordered locally or not.
#'                       When set to TRUE, the data is ordered locally.\cr
#'                       Order by (Vs) Local Order by:\cr
#'                       \itemize{
#'                       \item Order by: Specifies the order in which the values in a group, or
#'                       partition, are sorted.
#'                       \item Local Order by: Orders qualified rows on each AMP in preparation
#'                       to be input to a table function.
#'                       }
#'                       Note:
#'                       \enumerate{
#'                       \item This argument is ignored if the argument "data.order.column" is not
#'                       specified or NULL.
#'                       \item When this argument is specified, the argument "data.order.column"
#'                       should be specified and the column(s) specified in "data.order.column"
#'                       is/are used for local ordering.
#'                       }
#'                       Default Value: FALSE\cr
#'                       Types: logical
#' @param sort.ascending Optional Argument.\cr
#'                       Specfies whether to sort the result set in ascending or descending order
#'                       using columns specified in "data.order.column" argument.\cr
#'                       The sorting is ascending when this argument is set to TRUE,
#'                       descending otherwise.\cr
#'                       Note: This argument is ignored if the argument "data.order.column" is
#'                       not specified.\cr
#'                       Default Value: TRUE\cr
#'                       Types: logical
#' @param nulls.first Optional Argument.\cr
#'                    Specifies whether the result set containing NULL values are to be listed
#'                    first during ordering.\cr
#'                    NULLs are listed first when this argument is set to TRUE, otherwise NULLs
#'                    are listed last.\cr
#'                    Default Value: TRUE\cr
#'                    Types: logical
#' @param delimiter Optional Argument.\cr
#'                  Specifies the delimiter to use when reading the columns from a row and
#'                  writing result columns.\cr
#'                  Note:
#'                  \enumerate{
#'                    \item This argument cannot be same as "delimiter" argument.
#'                    \item This argument cannot be a NEWLINE character i.e., '\\n'.
#'                  }
#'                  Default Value: "\\t"\cr
#'                  Types: character of length 1
#' @param auth Optional Argument.\cr
#'             Specifies an authorization to use when running the script which binds
#'             an operating system user to the script via authorization objects.\cr
#'             Use this argument to specify the fully qualified name of an authorization object
#'             in single quotes.\cr
#'             If the database name is not provided, the name is fully qualified using the
#'             current user or database.\cr
#'             The database user executing the script query must have the following EXECUTE
#'             privileges:
#'             \enumerate{
#'             \item EXECUTE privilege on the authorization object specified.
#'             \item EXECUTE FUNCTION on td_sysfnlib.script.
#'             }
#'             Default Value: NULL\cr
#'             Types: character
#' @param charset Optional Argument.\cr
#'                Specifies the character encoding for all of the data passed to and from the
#'                user-installed script.\cr
#'                Note: Teradata recommends to use UTF16, when using CHAR or VARCHAR
#'                with CHARACTER SET UNICODE.\cr
#'                Permitted Values: "UTF-16", "LATIN"\cr
#'                Default Value: "LATIN"\cr
#'                Types: character
#' @param quotechar Optional Argument.\cr
#'                  Specifies a character that forces all input and output of the script to be
#'                  quoted using this specified character.\cr
#'                  Using this argument enables the Advanced SQL Engine to distinguish between NULL
#'                  fields and empty VARCHARs. A VARCHAR with length zero is quoted, while NULL
#'                  fields are not.\cr
#'                  If this character is found in the data, it will be escaped by a
#'                  second quote character.\cr
#'                  Note:
#'                  \enumerate{
#'                    \item This argument cannot be same as "delimiter" argument.
#'                    \item This argument cannot be a NEWLINE character i.e., '\\n'.
#'                  }
#'                  Default Value: NULL\cr
#'                  Types: character of length 1
#' @seealso td_setup_test_env, td_test_script
#' @return A named list of "ScriptTableOperator" class.
#' @examples
#' \donttest{
#' # Replace "<schema_name>" with the name of the schema to search the file for.
#' schema_name <- "<schema_name>"
#'
#' script_command <- gettextf("Rscript ./%s/mapper.R", schema_name)
#'
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#'
#' # Load example data.
#' loadExampleData("script_example", "barrier")
#'
#' # Create object(s) of class "tbl_teradata".
#' barrier <- tbl(con, "barrier")
#'
#' # Create a ScriptTableOperator object that allows us to execute user script in Vantage.
#' script_obj <- Script(data = barrier %>% select(Name),
#'                      script.command = script_command,
#'                      returns = list("word"= "VARCHAR(15)", "count_input"= "VARCHAR(2)")
#'                      )
#' }
#'
#' @export
Script <- function(script.command = NULL,
                   returns = NULL,
                   data = NULL,
                   data.hash.column = NULL,
                   data.partition.column = NULL,
                   data.order.column = NULL,
                   is.local.order = FALSE,
                   sort.ascending = TRUE,
                   nulls.first = TRUE,
                   delimiter = "\t",
                   auth = NULL,
                   charset = "LATIN",
                   quotechar = NULL) {

  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("script.command", script.command, FALSE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("returns", returns, FALSE, c("character", "list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, TRUE, c("ta.data.frame", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.hash.column", data.hash.column, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.partition.column", data.partition.column, TRUE, c("character", "list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("is.local.order", is.local.order, TRUE, c("logical", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("sort.ascending", sort.ascending, TRUE, c("logical", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("nulls.first", nulls.first, TRUE, c("logical", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("delimiter", delimiter, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("auth", auth, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("charset", charset, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("quotechar", quotechar, TRUE, c("character", NA)))

  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")

  # Make sure that a non-NULL value has been supplied for all mandatory arguments.
  .validateMissingRequiredArguments(argInfoMatrix)

  # Make sure that a non-NULL value has been supplied correct type of argument.
  # Skipping type check for the argument "returns" which will be handled later.
  .validateArgumentTypes(argInfoMatrix[-2,])

  # Create the "ScriptTableOperator" object.
  object <- list(script.command = script.command,
                 returns = returns,
                 data = data,
                 data.hash.column = data.hash.column,
                 data.partition.column = data.partition.column,
                 data.order.column = data.order.column,
                 is.local.order = is.local.order,
                 sort.ascending = sort.ascending,
                 nulls.first = nulls.first,
                 delimiter = delimiter,
                 auth = auth,
                 charset = charset,
                 quotechar = quotechar)

  # Validate arguments.
  .validateScriptArgs(object)

  # Set the class name of the named list.
  class(object) <- "ScriptTableOperator"

  return(object)
}

#' Set data
#'
#' This function enables the user to set data and data related arguments without having to
#' re-create ScriptTableOperator object.\cr
#' Note: All data related arguments that are not specified in this function are reset to
#' default values.
#'
#' @param object Required Argument.\cr
#'               Specifies the ScriptTableOperator object containing the details.
#' @param data Required Argument.\cr
#'             Specifies the tbl_teradata containing the input for the script.\cr
#'             Default Value: NULL\cr
#'             Types: tbl_teradata
#' @param data.hash.column Optional Argument.\cr
#'                         Specifies the input tbl_teradata column to be used for hashing.\cr
#'                         The rows in the data are redistributed to AMPs based on the hash
#'                         value of the column specified. The user-installed script file then
#'                         runs once on each AMP.\cr
#'                         Note: This argument cannot be specified along with the arguments
#'                         "data.partition.column" and "data.order.column".\cr
#'                         Default Value: NULL\cr
#'                         Types: character
#' @param data.partition.column Optional Argument.\cr
#'                              Specifies Partition By columns for "data".\cr
#'                              Values to this argument can be provided as a vector, if multiple
#'                              columns are used for partition.\cr
#'                              Note:
#'                              \enumerate{
#'                              \item This argument cannot be specified along with
#'                              "data.hash.column" argument.
#'                              \item This argument cannot be specified when the argument
#'                              "is.local.order" is set to TRUE.
#'                              \item If this argument is not specified, then the entire result
#'                              set, delivered by the function, constitutes a single group or
#'                              partition.
#'                              }
#'                              Permitted Values: "ANY" OR one or more columns in "data"
#'                              tbl_teradata.\cr
#'                              Default Value: NULL\cr
#'                              Types: character OR vector of characters
#' @param data.order.column Optional Argument.\cr
#'                          Specifies Order By columns for "data".\cr
#'                          Values to this argument can be provided as a vector, if multiple
#'                          columns are used for ordering.\cr
#'                          The column(s) mentioned in the argument is/are used in ordering
#'                          irrespective of whether the argument "is.local.order" is set to
#'                          TRUE or not.\cr
#'                          Note: This argument cannot be specified along with the argument
#'                          "data.hash.column".\cr
#'                          Default Value: NULL\cr
#'                          Types: character OR vector of characters
#' @param is.local.order Optional Argument.\cr
#'                       Specifies whether the input data is to be ordered locally or not.
#'                       When set to TRUE, the data is ordered locally.\cr
#'                       Order by (Vs) Local Order by:\cr
#'                       \itemize{
#'                       \item Order by: Specifies the order in which the values in a group, or
#'                       partition, are sorted.
#'                       \item Local Order by: Orders qualified rows on each AMP in preparation
#'                       to be input to a table function.
#'                       }
#'                       Note:
#'                       \enumerate{
#'                       \item This argument is ignored if the argument "data.order.column" is not
#'                       specified or NULL.
#'                       \item When this argument is specified, the argument "data.order.column"
#'                       should be specified and the column(s) specified in "data.order.column"
#'                       is/are used for local ordering.
#'                       }
#'                       Default Value: FALSE\cr
#'                       Types: logical
#' @param sort.ascending Optional Argument.\cr
#'                       Specfies whether to sort the result set in ascending or descending order
#'                       using columns specified in "data.order.column" argument.\cr
#'                       The sorting is ascending when this argument is set to TRUE,
#'                       descending otherwise.\cr
#'                       Note: This argument is ignored if the argument "data.order.column" is
#'                       not specified.\cr
#'                       Default Value: TRUE\cr
#'                       Types: logical
#' @param nulls.first Optional Argument.\cr
#'                    Specifies whether the result set containing NULL values are to be listed
#'                    first during ordering.\cr
#'                    NULLs are listed first when this argument is set to TRUE, otherwise NULLs
#'                    are listed last.\cr
#'                    Default Value: TRUE\cr
#'                    Types: logical
#' @param ... Any other optional arguments, if required.
#' @seealso td_setup_test_env, td_test_script, td_execute_script
#' @return A named list of "ScriptTableOperator" class.
#' @examples
#' \donttest{
#' # Note - Refer to Teradata R User Guide for setting search path and required permissions.
#'
#' # Replace "<tdplyr_install_location>" with the absolute path of the install location of the
#' # tdplyr library. One can get this location using '.libPaths()'.
#' # Make sure to include 'tdplyr' in the path. For example, <r_pkg_install_location>/tdplyr.
#' tdplyr_install_location <- "<tdplyr_install_location>"
#'
#' # Replace "<schema_name>" with the name of the schema to search the file for.
#' schema_name <- "<schema_name>"
#'
#' script_command <- gettextf("Rscript ./%s/mapper.R", schema_name)
#'
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#'
#' # Load example data.
#' loadExampleData("script_example", "barrier")
#'
#' # Create object(s) of class "tbl_teradata".
#' barrier <- tbl(con, "barrier")
#'
#' # Create a ScriptTableOperator object that allows us to execute user script in Vantage.
#' script_obj <- Script(script.command = script_command,
#'                      charset = "LATIN",
#'                      returns = list("word"= "VARCHAR(15)", "count_input"= "VARCHAR(2)")
#'                      )
#'
#' # Test user script mentioned in the argument "script.name" using the data provided in the
#' # argument "input.data.file".
#' td_test_script(object = script_obj,
#'                script.name = "mapper.R",
#'                files.local.path = file.path(tdplyr_install_location, "scripts"),
#'                input.data.file = "barrier.csv"
#'                )
#'
#' # Now in order to test/run script using actual data on Vantage user can set data and related
#' # arguments without recreating ScriptTableOperator object.
#' script_obj <- td_set_data(object = script_obj,
#'                           data = barrier %>% select(Name)
#'                           )
#'
#' # Run the td_execute_script() function to execute the script on Vantage or td_test_script()
#' # to test the script in the sandbox.
#' }
#'
#' @export
td_set_data.ScriptTableOperator <- function(object = NULL, data = NULL, data.hash.column = NULL,
                                            data.partition.column = NULL,
                                            data.order.column = NULL,
                                            is.local.order = FALSE,
                                            sort.ascending = TRUE,
                                            nulls.first = TRUE, ...) {
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("object", object, FALSE, c("named list", "character")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.hash.column", data.hash.column, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.partition.column", data.partition.column, TRUE, c("character", "list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("is.local.order", is.local.order, TRUE, c("logical", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("sort.ascending", sort.ascending, TRUE, c("logical", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("nulls.first", nulls.first, TRUE, c("logical", NA)))

  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")

  # Make sure that a non-NULL value has been supplied for all mandatory arguments.
  .validateMissingRequiredArguments(argInfoMatrix)

  # Make sure that a non-NULL value has been supplied correct type of argument.
  .validateArgumentTypes(argInfoMatrix)

  object <- list(script.command = object$script.command,
                 returns = object$returns,
                 data = data,
                 data.hash.column = data.hash.column,
                 data.partition.column = data.partition.column,
                 data.order.column = data.order.column,
                 is.local.order = is.local.order,
                 sort.ascending = sort.ascending,
                 nulls.first = nulls.first,
                 delimiter = object$delimiter,
                 auth = object$auth,
                 charset = object$charset,
                 quotechar = object$quotechar)

  # Validate arguments.
  .validateScriptArgs(object)

  # Set the class name of the named list.
  class(object) <- "ScriptTableOperator"

  return(object)
}

#'  Setup test environment
#'
#' This function enables the user to load the sandbox image that is downloaded from Teradata site.
#' This sets up the environment for the user to run the script within docker container using data
#' from csv file, which enables the user to fix script issues outside Teradata Vantage.\cr
#' Note: Refer to Teradata R User Guide to get the location of the downloadable docker image.\cr
#'
#' @param docker.image.location Required Argument.\cr
#'                              Specifies the location of the downloaded image on user's
#'                              system.\cr
#'                              Types: character
#' @seealso Script, td_test_script
#' @return Nothing. Loads the docker image if successful.
#' @examples
#' \donttest{
#' # Replace "<path_to_docker_image>" with the local path to the downloaded docker image file.
#' docker_image_location <- "<path_to_docker_image>"
#'
#' # Setup the environment by providing the docker image location.
#' td_setup_test_env(docker.image.location = docker_image_location)
#'
#' }
#'
#' @export
td_setup_test_env <- function(docker.image.location = NULL) {

  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("docker.image.location", docker.image.location, FALSE, c("character", NA)))

  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")

  # Make sure that a non-NULL value has been supplied for all mandatory arguments.
  .validateMissingRequiredArguments(argInfoMatrix)

  # Make sure that a non-NULL value has been supplied correct type of argument.
  .validateArgumentTypes(argInfoMatrix)

  .validateInputColumnsNotEmpty(docker.image.location)

  if (!file.exists(docker.image.location)) {
    .ta.stop("TDR_E5001", docker.image.location, "'docker.image.location'")
  }

  # Check if docker is installed or not.
  cmd_opt <- system2("docker", c("--version"), stdout = TRUE, stderr = FALSE)
  if (!grepl(pattern = "docker", x = tolower(as.character(cmd_opt)))) {
    .ta.stop("TDR_E5007")
  }

  cat(paste0("Loading image from '", docker.image.location, "'. It may take few minutes.\n"))
  status <- 0
  tryCatch({
    status <- system2("docker", c("load", "-i", docker.image.location))
  }, error = function(e) {
    .ta.stop(e)
  })
  if (status == 0) {
    cat("Image loaded successfully.\n")
  } else {
    cat("Image loading failed.\n")
  }
}

#' Test user script
#'
#' This function enables the user to run script in docker container environment outside Vantage.
#' Input data for user script is read from file or Vantage.
#'
#' @param object Required Argument.\cr
#'               Specifies the ScriptTableOperator object containing the details that
#'               are needed for testing user script.
#' @param files.local.path Required Argument.\cr
#'                         Specifies the absolute local path where user script (specified in
#'                         the argument "script.name"), all supporting files like model files
#'                         (specified in the argument "supporting.files"), and input data file
#'                         (specified in the argument "input.data.file") reside.\cr
#'                         Types: character
#' @param script.name Required Argument.\cr
#'                    Specifies the name of the user script.\cr
#'                    It should have a path relative to the location specified in
#'                    "files.local.path" argument.\cr
#'                    Types: character
#' @param input.data.file Optional Argument.\cr
#'                        Specifies the name of the input data file.\cr
#'                        It should have a path relative to the location specified in
#'                        "files.local.path" argument.\cr
#'                        If this argument is not provided, data is read from AMP in the
#'                        database. The data is taken from the "data" argument of
#'                        ScriptTableOperator object.\cr
#'                        Default Value: NULL\cr
#'                        Types: character
#' @param supporting.files Optional Arguument.\cr
#'                         Specifies one or more supporting files like model files to be
#'                         copied to the container. These files should have a path relative to
#'                         the location specified in "files.local.path" argument.\cr
#'                         Default Value: NULL\cr
#'                         Types: character OR vector of characters
#' @param script.args Optional Argument.\cr
#'                    Specifies command line arguments required by the user script.\cr
#'                    Default Value: NULL\cr
#'                    Types: character
#' @param ... Specifies the arguments used for reading data from all AMPs.\cr
#'            The following are the valid argument names:
#'            \enumerate{
#'            \item data.row.limit: Specifies the number of rows to be taken from all AMPs
#'            when reading from a table or view on Vantage.\cr
#'            Default Value: 1000\cr
#'            Types: integer
#'            \item password: Specifies the password to connect to Vantage where the data
#'            resides.\cr
#'            Types: character
#'            }
#'            Any other arguments, if provided, are ignored.
#' @seealso td_setup_test_env, Script
#' @return A R data.frame containing the output of user script.
#' @examples
#' \donttest{
#' # Replace "<tdplyr_install_location>" with the absolute path of the install location of the
#' # tdplyr library. One can get this location using '.libPaths()'.
#' # Make sure to include 'tdplyr' in the path. For example, <r_pkg_install_location>/tdplyr.
#' tdplyr_install_location <- "<tdplyr_install_location>"
#'
#' # Replace "<schema_name>" with the name of the schema to search the file for.
#' schema_name <- "<schema_name>"
#'
#' # Replace "<path_to_docker_image>" with the local path to the downloaded docker image file.
#' docker_image_location <- "<path_to_docker_image>"
#'
#' # Replace "<password>" with the password of the user to fetch data from Vantage.
#' password <- "<password>"
#'
#' script_command <- gettextf("Rscript ./%s/mapper.R", schema_name)
#'
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#'
#' # Load example data.
#' loadExampleData("script_example", "barrier")
#'
#' # Create object(s) of class "tbl_teradata".
#' barrier <- tbl(con, "barrier")
#'
#' # Create a ScriptTableOperator object that allows us to execute user script in Vantage.
#' script_obj <- Script(data = barrier %>% select(Name),
#'                      script.command = script_command,
#'                      returns = list("word"= "VARCHAR(15)", "count_input"= "VARCHAR(2)")
#'                      )
#'
#' ## Run the user script locally within docker container using data from csv file.
#'
#' # Setup the environment by providing path to the docker image file.
#' td_setup_test_env(docker.image.location = docker_image_location)
#'
#'
#' # Example 1: Test user script mentioned in the argument "script.name" using the data
#' # provided in the argument "input.data.file".
#' td_test_script(object = script_obj,
#'                files.local.path = file.path(tdplyr_install_location, "scripts"),
#'                script.name = "mapper.R",
#'                input.data.file = "barrier.csv"
#'                )
#'
#' # Example 2: Test user script mentioned in the argument "script.name" using the data
#' # from AMPs in the database.
#' td_test_script(object = script_obj,
#'                files.local.path = file.path(tdplyr_install_location, "scripts"),
#'                script.name = "mapper.R",
#'                password = password
#'                )
#'
#' }
#'
#' @export
#' @importFrom bit64 as.integer64
td_test_script.ScriptTableOperator <- function(object = NULL, files.local.path = NULL, script.name = NULL,
                                               input.data.file = NULL, supporting.files = NULL,
                                               script.args = NULL, ...) {

  dots <- list(...)
  # Default value of data.row.limit is 1000.
  data.row.limit <- 1000
  if ("data.row.limit" %in% names(dots)) {
    data.row.limit <- dots[["data.row.limit"]]
  }
  password <- NULL
  if ("password" %in% names(dots)) {
    password <- dots[["password"]]
  }

  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("object", object, FALSE, c("named list", "character")))
  argInfoMatrix <- rbind(argInfoMatrix, list("files.local.path", files.local.path, FALSE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("script.name", script.name, FALSE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("input.data.file", input.data.file, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("supporting.files", supporting.files, TRUE, c("character", "list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("script.args", script.args, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.row.limit", data.row.limit, TRUE, c("integer", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("password", password, TRUE, c("character", NA)))

  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")

  # Make sure that a non-NULL value has been supplied for all mandatory arguments.
  .validateMissingRequiredArguments(argInfoMatrix)

  # Make sure that a non-NULL value has been supplied correct type of argument.
  .validateArgumentTypes(argInfoMatrix)

  .validateInputColumnsNotEmpty(files.local.path)
  .validateInputColumnsNotEmpty(script.name)
  .validateInputColumnsNotEmpty(input.data.file)
  .validateInputColumnsNotEmpty(supporting.files)
  .validateInputColumnsNotEmpty(script.args)
  .validateInputColumnsNotEmpty(password)


  if (data.row.limit == as.integer(data.row.limit) && data.row.limit <= 0) {
    .ta.stop("TDR_E3104", "argument", "data.row.limit", "positive integers greater than 0")
  }

  # Either input.data.file or (data and password) should be provided.
  if (!(!is.null(input.data.file) || (!is.null(object$data) && !is.null(password)))) {
    .ta.stop("TDR_E3009", "'input.data.file'", "(Script's 'data' argument and 'password')")
  }

  docker_image_name <- getOption("docker.image.name")
  docker_image_tag <- getOption("docker.image.tag")
  docker_image_name_with_tag <- paste0(docker_image_name, ":", docker_image_tag)

  # The command that is run here is "docker image ls rstosandbox --quiet".
  image_ls_cmd_args <- c("image", "ls", docker_image_name, "--quiet")
  error_msg <- paste0("Failed to get list of docker image ",docker_image_name ,".")
  image_ls_cmd_opt <- .exec_docker_command(image_ls_cmd_args, TRUE, error_msg)

  # No image named "rstosandbox".
  if (identical(image_ls_cmd_opt, character(0))) {
    .ta.stop("TDR_E5004", "STO sandbox", "td_setup_test_env")
  }

  # Create and start the container.
  # The command that is run here is "docker run --detach --interactive --tty rstosandbox:1.0".
  container_create_cmd_args <- c("run", "--detach", "--interactive", "--tty", docker_image_name_with_tag)
  error_msg <- paste0("Failed to create the container using image '", docker_image_name ,"'.")
  success_msg <- paste0("Created container using image '", docker_image_name, "' successfully.")
  container_id <- .exec_docker_command(container_create_cmd_args, TRUE, error_msg, success_msg)

  # The files are copied to the location "/home/tdatuser" in the container.
  path_in_docker_container <- "/home/tdatuser"

  ## Gather all the files to be copied to the container:
  # script to be run in the container, all supporting files and the input data file.
  files_to_copy_to_container <- c(trimws(script.name), trimws(supporting.files), trimws(input.data.file))

  copy_fail_msg <- "Failed to copy file '%s' to container."
  copy_success_msg <- "File '%s' copied to container successfully."
  # Copy files to docker container.
  for (file in files_to_copy_to_container) {
    # Get the full path by appending "files.local.path" to the individual files.
    file_loc <- file.path(files.local.path, file)

    # Check if file exists in local client.
    if (!file.exists(file_loc)) {
      .ta.stop("TDR_E5001", file_loc, "'files.local.path' and the file name")
    }

    # Copying the files to docker container.
    # Command that is run: "docker cp <files.local.path/<file> <container_id>:/home/tdatuser/<file>.
    file_path_in_container <- file.path(path_in_docker_container, file)
    cp_container_args <- c("cp", file_loc, paste0(container_id,":", file_path_in_container))
    success_msg <- paste0("File '", file_loc, "' copied to container successfully.")
    .exec_docker_command(cp_container_args, FALSE, gettextf(copy_fail_msg, file_loc),
                         gettextf(copy_success_msg, file_loc))
  }

  ## Generate the command to execute the user script in docker,
  ## based on the availability of the argument "input.data.file".

  # Get the command to run script_executor.R.
  exec_cmd_args <- c("Rscript", "script_executor.R", script.name)
  if (!is.null(input.data.file)) {
    # Process using input data file if provided.
    exec_cmd_args <- c(exec_cmd_args, "-d", input.data.file)
  } else {
    # Check on the number of rows of the tbl_teradata.
    if (td_nrow(object$data) > as.integer64(data.row.limit)) {
      .ta.stop("TDR_E5006", data.row.limit, "data.row.limit", "object$data", data.row.limit)
    }

    # If input data file is not provided, get data from Vantage (table is present in argument
    # "data" of ScriptTableOperator object.
    con <- .taConnection()
    host <- .get_servername(con)
    user_name <- .get_username(con)
    temp_db <- .get_dbname(con)

    table_name <- remote_name(object$data)
    # table_name will be NULL if object$data is a lazy query.
    # Class of table_name will be SQL if object$data is tbl_teradata on top of query.
    # Create a view for queries.
    if (is.null(table_name) || inherits(table_name, "sql")) {
      # We are here means tbl_teradata is created using select SQL query.
      view_name <- .teradataGenerateTempTableName(prefix = "view_", use.default.database = TRUE,
                                                  table.type = "view", gc.onQuit = TRUE)
      table_name <- .create.view(con, remote_query(object$data), view_name)
    }

    # Extract table name for full name as schema name will also be passed as arguments.
    table_name <- .extractTableNameQuoted(table_name)

    exec_cmd_args <- c(exec_cmd_args, "--db-host", host, "--user", user_name, "--passwd", password,
                       "--table", table_name, "--db-name", temp_db)
  }


  # Use the script arguments provided by the user.
  if (!is.null(script.args)) {
    script.args <- c("--script-args", paste0("\"", script.args, "\""))
  }
  # Use the default delimiter or the delimiter provided by the user.
  delimiter.args <- c("--delimiter", paste0("\"", object$delimiter, "\""))

  # Generate and run the docker execute command.
  exec_cmd_args <- c("container", "exec", "-w", path_in_docker_container, container_id,
                     exec_cmd_args, script.args, delimiter.args)
  error_msg <- paste0("Failed to test the script '", script.name, "'.")
  success_msg <- paste0("The script '", script.name, "' is tested successfully.")
  command_opt <- .exec_docker_command(exec_cmd_args, TRUE, error_msg, success_msg, c("container", "rm", "-f", container_id))

  # Remove the containers at the end.
  .exec_docker_command(c("container", "rm", "-f", container_id), TRUE)

  expected_number_of_cols <- length(names(object[["returns"]]))
  opt_df <- list()
  for (row in command_opt) {
    row_val <- strsplit(row, split = object[["delimiter"]])[[1]]
    if (length(row_val) < expected_number_of_cols) {
      .ta.stop("TDR_E5008", "less than", expected_number_of_cols, paste0("(", toString(row_val), ")"))
    } else if (length(row_val) > expected_number_of_cols) {
      .ta.stop("TDR_E5008", "greater than", expected_number_of_cols, paste0("(", toString(row_val), ")"))
    }
    opt_df <- rbind(opt_df, row_val)
  }
  colnames(opt_df) <- names(object[["returns"]])
  opt_df <- as.data.frame(opt_df, row.names = FALSE)
  rownames(opt_df) <- NULL

  return(opt_df)
}

#' Execute script using Script Table Operator
#'
#' This function enables the user to execute script using Script Table Operator on Teradata Vantage.
#'
#' @param object Required Argument.\cr
#'               Specifies the ScriptTableOperator object.
#' @param ... Any other optional arguments, if required.
#' @seealso Script, td_test_script
#' @return Named list containing tbl_teradata which can be referenced directly with
#' the "$" operator using name: result.
#' @examples
#' \donttest{
#' # Note - Refer to Teradata R User Guide for setting search path and required permissions.
#'
#' # Replace "<tdplyr_install_location>" with the absolute path of the install location of the
#' # tdplyr library. One can get this location using '.libPaths()'.
#' # Make sure to include 'tdplyr' in the path. For example, <r_pkg_install_location>/tdplyr.
#' tdplyr_install_location <- "<tdplyr_install_location>"
#'
#' # Replace "<schema_name>" with the name of the schema to search the file for.
#' schema_name <- "<schema_name>"
#'
#' set_session <- gettextf('SET SESSION SEARCHUIFDBPATH = "%s";', schema_name)
#' script_command <- gettextf("Rscript ./%s/mapper.R", schema_name)
#'
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#'
#' # Set Search path, which is necessary for runninng td_execute_script() function.
#' dbExecute(con, dplyr::sql(set_session))
#'
#' # Load example data.
#' loadExampleData("script_example", "barrier")
#'
#' # Create object(s) of class "tbl_teradata".
#' barrier <- tbl(con, "barrier")
#'
#' # Create a ScriptTableOperator object that allows us to execute user script in Vantage.
#' script_obj <- Script(data = barrier %>% select(Name),
#'                      script.command = script_command,
#'                      returns = list("word"= "VARCHAR(15)", "count_input"= "VARCHAR(2)")
#'                      )
#'
#' # Install the file 'mapper.R' found in the 'scripts' directory of tdplyr installation location.
#' td_install_file(file.path.loc = file.path(tdplyr_install_location, "scripts", "mapper.R"),
#'                 file.identifier = 'mapper')
#'
#' # Execute user script on vantage.
#' td_execute_script(script_obj)
#'
#' }
#'
#' @export
td_execute_script.ScriptTableOperator <- function(object, ...) {
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("object", object, FALSE, c("named list", "character")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")

  # Make sure that a non-NULL value has been supplied for all mandatory arguments.
  .validateMissingRequiredArguments(argInfoMatrix)

  # Make sure that a non-NULL value has been supplied correct type of argument.
  .validateArgumentTypes(argInfoMatrix)

  # Form and execute Table Operator query
  .executeTblOpQuery(object = object)
}

# An internal function to generate the Table Operator queries.
# The function defines variables and list of arguments required to form the query.
.executeTblOpQuery <- function(object = NULL) {
  script.command <- object[["script.command"]]
  returns <- object[["returns"]]
  data <- object[["data"]]
  data.hash.column <- object[["data.hash.column"]]
  data.partition.column <- object[["data.partition.column"]]
  data.order.column <- object[["data.order.column"]]
  is.local.order <- object[["is.local.order"]]
  sort.ascending <- object[["sort.ascending"]]
  nulls.first <- object[["nulls.first"]]
  delimiter <- object[["delimiter"]]
  auth <- object[["auth"]]
  charset <- object[["charset"]]
  quotechar <- object[["quotechar"]]

  funcOutputArgs <- NA
  funcOutputArgSqlNames <- c()

  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()

  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SCRIPT_COMMAND")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(script.command, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")

  if (!is.null(delimiter)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "DELIMITER")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(delimiter, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }

  # Generate returns clause
  returns_clause <- paste(names(returns), returns, sep = " ")

  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "RETURNS")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(returns_clause, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")

  if (!is.null(auth)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AUTH")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(auth, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }

  if (!is.null(charset)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CHARSET")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(charset, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }

  if (!is.null(quotechar)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "QUOTECHAR")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(quotechar, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }

  # Create a named vector for other arguments of function
  names(funcOtherArgs) <- funcOtherArgSqlNames
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }

  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  funcInputOrderByType <- NULL
  funcInputSortAscending <- sort.ascending
  funcInputNullsFirst <- NULL

  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType,
                               funcInputDistribution, funcInputPartitionByCols,
                               funcInputOrderByCols, funcInputArgSqlNames)

  if (!is.null(data)) {
    data.distribution <- "FACT"
    if (!is.null(data.hash.column)) {
      data.distribution <- "HASH"
      data.partition.column <- data.hash.column
    } else if (isTRUE(is.local.order)) {
      data.distribution <- NULL
      funcInputOrderByType <- "LOCAL"
    }
    if (!is.null(data.order.column)) {
      funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
    } else {
      funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
    }
    if (!is.null(data.partition.column)) {
      funcInputPartitionByCols <- c(funcInputPartitionByCols, .teradataCollapseArgVector(data.partition.column, "\""))
    } else {
      funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    }
    if (!is.null(data.distribution)) {
      funcInputDistribution <- c(funcInputDistribution, data.distribution)
    } else {
      funcInputDistribution <- c(funcInputDistribution, "NA_character_")
    }

    tableRef <- .teradataOnClauseFromDataFrame(data)
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputNullsFirst <- nulls.first

    # create inputMatrix which will be used by .TeradataTbpOpQueryGenerator$new
    funcInputPartitionByCols <- type.convert(funcInputPartitionByCols,
                                             na.strings = "NA_character_",
                                             as.is = TRUE)
    funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
    inputTableRefMatrix <- cbind(funcInputTableViewQuery,
                                 funcInputDataframeType,
                                 funcInputDistribution,
                                 funcInputPartitionByCols,
                                 funcInputOrderByCols,
                                 funcInputArgSqlNames)
    # Add column names to the matrix
    colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
                                       "column_order", "alias")
  }

  tblOpObject <- .TeradataTblOpQueryGenerator$new(sqlmrFuncName = "Script",
                                                  sqlmrFuncArgs = funcOtherArgs,
                                                  sqlmrOutputTabArgs = funcOutputArgs,
                                                  inputTableRefMatrix = inputTableRefMatrix,
                                                  funcInputOrderByType = funcInputOrderByType,
                                                  funcInputNullsFirst = funcInputNullsFirst,
                                                  funcInputSortAscending = funcInputSortAscending,
                                                  sqlmrEngine = .getEngineName("ENGINE_SQL")
  )
  tblOpQuery <- tblOpObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(tblOpQuery)

  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)

  # Execute Table Operator query
  result <- list()
  result[["result"]] <- .createDataSetObject(tblOpQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  return(result)
}

# An internal function to run docker command using the argument "args", which accepts docker
# command arguments as character or character vector.
# Parameters:
#   args    Required Argument.
#           Specifies the docker command arguments.
#           Types: character or vector of characters.
#   stdout.val    Optional Argument.
#                 Specifies whether to capture the console output of the command execution.
#                 Default Value: TRUE
#                 Types: logical
#   error.msg   Optional Argument.
#               Specifies the message to print, if the command execution fails.
#               Default Value: ""
#               Type: character
#   success.msg   Optional Argument.
#                 Specifies the message to be printed if the command execution succeeds and
#                 the option "td.debug.enable" is set to TRUE.
#                 Default Value: NULL
#                 Types: character
#   drop.container.args   Optional Argument.
#                         Specifies the argument required to drop the container if command
#                         execution fails.
#                         Default Value: NULL
#                         Types: vector of characters
.exec_docker_command <- function(args, stdout.val = TRUE, error.msg = "", success.msg = NULL, drop.container.args = NULL) {
  cmd_opt <- NULL
  tryCatch({
    cmd_opt <- system2("docker", args = args, stdout = stdout.val)
    if (isTRUE(getOption("td.debug.enable")) && !is.null(success.msg)) {
      .ta.print(success.msg)
    }
  }, error = function(e) {
    if (!is.null(drop.container.args)) {
      .exec_docker_command(drop.container.args, TRUE)
    }
    .ta.stop("TDR_E5005", error.msg, e)
  })
  return(cmd_opt)
}

# Validate arguments
# This is an internal function to validate Table Operator Function arguments, including argument
# value validations.
#   object  Required Argument.
#           Specifies the ScriptTableOperator object.
#           Types: named list of class "ScriptTableOperator".
.validateScriptArgs <- function(object) {

  script.command <- object$script.command
  returns <- object$returns
  data <- object$data
  data.hash.column <- object$data.hash.column
  data.partition.column <- object$data.partition.column
  data.order.column <- object$data.order.column
  is.local.order <- object$is.local.order
  sort.ascending <- object$sort.ascending
  nulls.first <- object$nulls.first
  delimiter <- object$delimiter
  auth <- object$auth
  charset <- object$charset
  quotechar <- object$quotechar

  # Validate the type of the argument "returns".
  # Checks for the argument 'returns' type. It is a special case with named list.
  if (is.null(names(returns)) || "" %in% names(returns)) {
    .ta.stop("TDR_E3104", "argument", "returns", "Named list of characters")
  }

  # Type check of each value of the named list "returns".
  error_msgs <- c()
  msg <- paste0("Each value in named list argument 'returns' must be 'character' datatype. ",
                "Multiple values are not allowed. Found: ")
  for (return_val in names(returns)) {
    # Check for type and multiple values.
    val <- NULL
    if (!class(returns[[return_val]]) == "character") {
      val <- paste0("", toString(returns[[return_val]]), "")
    } else if (length(returns[[return_val]]) > 1) {
      val <- paste0("(", toString(returns[[return_val]]), ")")
    }

    if (!is.null(val)) {
      error_msgs <- c(error_msgs, val)
    }
  }
  if (length(error_msgs) > 0) {
    .ta.stop("TDR_E3005", paste0(msg, paste0(error_msgs, collapse = ", ")))
  }

  .validateInputTableDataType(data)

  .validateInputColumnsNotEmpty(script.command)
  .validateInputColumnsNotEmpty(auth)

  .validateInputColumnsNotEmpty(data.hash.column)
  .validateTblHasArgumentColumns(data.hash.column, "data.hash.column", data, "data")

  .validateInputColumnsNotEmpty(data.partition.column)

  if (!is.null(data.partition.column) && data.partition.column != "ANY") {
    .validateTblHasArgumentColumns(data.partition.column, "data.partition.column", data, "data")
  }

  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")

  # Validate permitted values for the argument 'charset'.
  charset_permitted_values <- list("LATIN", "UTF-16")
  .validatePermittedValues(charset, charset_permitted_values)

  # Check for length of the arguments "delimiter" and "quotechar".
  .validateArgValueLength(delimiter, 1, "EQ")
  .validateArgValueLength(quotechar, 1, "EQ")

  # The arguments 'quotechar' and 'delimiter' cannot take newline character.
  if (identical(delimiter, "\n")) {
    .ta.stop("TDR_E5003", "NEWLINE character", "delimiter")
  }
  if (identical(quotechar, "\n")) {
    .ta.stop("TDR_E5003", "NEWLINE character", "quotechar")
  }

  # Both "delimiter" and "quotechar" cannot be same.
  if (!is.null(delimiter) && !is.null(quotechar) && identical(delimiter, quotechar)) {
    .ta.stop("TDR_E3408", "delimiter", "quotechar", "same")
  }

  # Provide either data.hash.column or data.partition.column but not both.
  if (!is.null(data.hash.column) && !is.null(data.partition.column)) {
    .ta.stop("TDR_E3009", "'data.hash.column'", "'data.partition.column' but not both")
  }

  # Provide either data.hash.column or data.order.column but not both.
  if (!is.null(data.hash.column) && !is.null(data.order.column)) {
    .ta.stop("TDR_E3009", "'data.hash.column'", "'data.order.column' but not both")
  }

  # data.order.columns should be specified when is.local.order = TRUE.
  if (isTRUE(is.local.order) && is.null(data.order.column)) {
    .ta.stop("TDR_E3416", "data.order.column", "is.local.order", "set to TRUE")
  }

  # Provide either data.partition.column or set is.local.order to TRUE but not both.
  if (!is.null(data.partition.column) && isTRUE(is.local.order)) {
    .ta.stop("TDR_E3009", "'data.partition.column'", "set 'is.local.order' to TRUE but not both")
  }
}