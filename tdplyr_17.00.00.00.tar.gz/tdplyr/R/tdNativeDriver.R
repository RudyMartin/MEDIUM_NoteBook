# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

########################################################################
# Functionality specific to The Teradata Native driver (teradatasql) ###
########################################################################


############ Overridden S4 methods and classes #########
# This is an environment to store S4 class definitions
# We store all our custom S4 class defs here
class_cache <- new.env(parent = emptyenv())

.getClassCache <- function() {
  class_cache
}

#' Teradata Native Driver Class
#'
#' Creates a "NativeDriver" class which is inherited from "DBIDriver" class of DBI package.
#'
#' @export
#' @importClassesFrom DBI DBIDriver
#' @importFrom methods setClass
setClass("NativeDriver", contains = "DBIDriver")

#' Teradata Native Driver
#'
#' A Teradata Native Driver object to enable connectivity using the Teradata SQL driver for R.
#'
#' Returns an object of class "NativeDriver" to be used with the \code{dbConnect} function.
#' @importFrom methods new
#' @export
NativeDriver <- function() {
  .checkPkg("teradatasql")
   return(new("NativeDriver"))
}

#' Connect to Teradata Vantage using the Teradata SQL driver for R
#'
#' Use the \code{dbConnect(tdplyr::NativeDriver(), ...)} function to establish a connection to
#' Teradata Vantage using the Teradata SQL driver for R (also called the native driver for R) and
#' initialize a context.\cr
#' \cr
#' Note:
#' \itemize{
#' \item If there is no previous context, then a new context is initialized.
#' \item If the context already exists, then
#'    \enumerate{
#'      \item the previous context is overwritten and all non-persistent work tables are removed if
#'      the connection parameters \code{host}, \code{uid} and \code{database} (i.e., default schema)
#'      of the new connection object are different than those of the connection object from the
#'      previous context.
#'      \item the previous context is NOT overwritten and all non-persistent work tables remain in 
#'      the session if the connection parameters are same for both the new connection object and the
#'      connection object from the previous context.
#'    }
#' }
#'
#' @param drv Specifies a NativeDriver object obtained from \code{tdplyr::NativeDriver()}.
#' @param host Specifies the fully qualified domain name or IP address of a Teradata Vantage System. 
#' @param uid Specifies the username  to connect with.
#' @param pwd Specifies the password for the connecting user.
#' @param logmech Specifies the logon authentication method. Permitted values are TD2, LDAP, 
#'                TDNEGO, KRB5 for Kerberos, and JWT.
#' @param logdata Specifies additional data for the chosen logon authentication method. If 
#'                logmech = JWT, then JWT token should be provided with the key 'jwt.token' in the 
#'                named list of this argument.
#' @param temp.database Specifies the database name in which temporary database object (table/view),
#'                      for processing data, are created. Such objects are garbage collected at the 
#'                      end of the session.\cr
#'                      Make sure the user has privilege to create objects in this database, 
#'                      otherwise the functions that create temporary objects will fail.\cr
#'                      If this argument is not supplied, default database of the connection is 
#'                      used for temporary objects. To get the temporary database name, use 
#'                      function \code{td_get_context()}.
#' @param ... Additional arguments as supported by the native driver. Currently, none supported.
#' @return A "Teradata" connection object.
#' @seealso \code{td_remove_context}, \code{td_create_context}, \code{td_get_context},
#' \code{td_set_context}
#' @aliases dbConnect
#' @examples
#' \donttest{
#' # Establish a connection to Teradata Vantage using the dbConnect API and NativeDriver object.
#' # This will initialize the context based on the connection parameters, if the context does not
#' # exist.
#' con <- DBI::dbConnect(tdplyr::NativeDriver(), host = "<dbcname>", uid = "<tduser>",
#'                       pwd = "<tdpwd>")
#'
#' # Establish a connection to Teradata Vantage using the dbConnect API and teradatasql
#' # TeradataDriver object.
#' # This will NOT initialize the context and td_get_context() function returns NULL if there is no
#' # previous context. One has to use td_set_context() function to initialize the context on
#' # TeradataDriver object.
#' con <- DBI::dbConnect(teradatasql::TeradataDriver(),
#'                       '{"host":"<dbcname>","user":"<tduser>","password":"<tdpwd>"}')
#' }
#' @export
setMethod("dbConnect", "NativeDriver",

  function(drv, host, uid, pwd = NULL, logmech = NULL, logdata = NULL, temp.database = NULL, ...) {
    # Validate arguments.
    argInfoMatrix <- list()
    argInfoMatrix <- rbind(argInfoMatrix, list("host", host, FALSE, c("character", NA)))
    argInfoMatrix <- rbind(argInfoMatrix, list("uid", uid, TRUE, c("character", NA)))
    argInfoMatrix <- rbind(argInfoMatrix, list("pwd", pwd, TRUE, c("character", NA)))
    argInfoMatrix <- rbind(argInfoMatrix, list("logmech", logmech, TRUE, c("character", NA)))
    argInfoMatrix <- rbind(argInfoMatrix, list("logdata", logdata, TRUE, c("list", NA)))
    argInfoMatrix <- rbind(argInfoMatrix, list("temp.database", temp.database, TRUE, c("character", NA)))
  
    colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
    # Make sure that a non-NULL value has been supplied for all mandatory arguments.
    .validateMissingRequiredArguments(argInfoMatrix)
  
    # Check for permitted values
    logmech_permittedValues <- .ta.ValidLogonMechanims()
    .validatePermittedValues(logmech, logmech_permittedValues)
  
    # Make sure that a non-NULL value has been supplied correct type of argument.
    .validateArgumentTypes(argInfoMatrix)

    if (is.null(host)) {
    .ta.stop("TDR_E1007", "host", showFunctionCall = FALSE)
    }
    # Validate if the given logon mechanism is supported or not.
    if (!is.null(logmech) && is.vector(logmech) && length(logmech) > 1) {
      .ta.stop("TDR_E3002", "logmech", "character/string")
    }

    .validate_logmech_logdata_arguments(logmech = logmech, logdata = logdata)
    
    logdata_value <- NULL
    if ("jwt.token" %in% names(logdata)) {
      logdata_value <- paste("token=", logdata$jwt.token)
    }
    if (is.null(logmech))
      jsonStr <- do.call(".getJSONObject", list(host = host, user = uid, password = pwd))
    else {
      jsonStr <- do.call(".getJSONObject", list(host = host, user = uid, password = pwd, 
                                                logmech = logmech, logdata = logdata_value))
    }
    if (getOption("td.debug.enable"))
      .ta.print("Invoking teradatasql driver with a json string: %s", jsonStr)
    con <- dbConnect(teradatasql::TeradataDriver(), jsonStr)

    # The argument "from.create.context" is passed when the connection request is from
    # "td_create_context", which is used to do GC when the connection is from "td_create_context".
    dots <- list(...)
    from.create.context <- FALSE
    if (!is.null(dots[["from.create.context"]])) {
      from.create.context <- dots[["from.create.context"]]
    }
    
    skipGC <- FALSE
    # If context already exists and connection is the same as this one, then skip garbage
    # collection if the call is not from create context.
    if(!from.create.context && .ta.contextExists() && 
      .ta.isIdenticalConnection(con, .taConnection())) {
      skipGC <- TRUE
    }
    
    # Currently the native driver does not add the Teradata subclass.
    # This check is present if in future they decide to add it.
    if (!inherits(con, "Teradata"))
      con <- .ta.AddTeradataS4Class(con)
    
    # If verification fails then we dont initialize the context
    .ta.verifyConnection(con)
    
    # Initialize the context and session and do any garbage collection if required
    .ta.initializeContext(con, temp.database, is.skip.gc = skipGC)
    
    # Assign vantage version using pm.versionInfo table.
    .ta.setVantageVersion(con)
    
    return(con)
})


######## S4 Class related helper methods #########

# Retrieve the class definitions from local cache
# Helper method to check if a class definition is present in a given
#' @importFrom methods isVirtualClass
#' @importFrom methods getClassDef
.ta.getClassDef <- function(name, where = .getClassCache(), inherits = FALSE) {
  classDef <- getClassDef(name, where = where, inherits = inherits)
  if (!is.null(classDef) && !isVirtualClass(classDef))
    return(classDef)
  return(NULL)
}

# This functions adds the Teradata S4 subclass for the connection object
# This is required because the native driver fails to add this sub class
.ta.AddTeradataS4Class <- function(con) {
  # Before adding S4 class check if ODBC was previously used
  # this is required to avoid S4 class collision
  # If we have used the NativODBC driver before this in the same session,
  # Then we try to cleanup the class
  .ta.removeODBCTeradataClassDef()

  # Second check if the Teradata class def is present in our package
  if (is.null(.ta.getClassDef("Teradata"))) {
    setClass("Teradata", contains = class(con)[[1]], where = .getClassCache())
  }
  
  new(.ta.getClassDef("Teradata"), con)
}

# If Teradata class already present from ODBC driver, removes it
# this is required to avod S4 class collision for the "Teradata" class name
# This is only required if both ODBC and Native drivers are used interchangeably in same session
.ta.removeODBCTeradataClassDef <- function() {
    if (!is.null(.ta.getODBCTeradataClassDef())) {
    # Use the folllowing to remove class from odbc
    try(suppressWarnings(removeClass("Teradata",
                                     where = get("class_cache", envir = asNamespace("odbc")))
                        ), silent = TRUE)
    # The following is required for dbExecute to work,
    # basically removes other interferring odbc classes such as OdbcResult, etc.
    try({library(odbc)
        detach("package:odbc", unload = TRUE)
        }, silent = TRUE)
  }
}

.ta.getODBCTeradataClassDef <- function() {
  tryCatch({.ta.getClassDef("Teradata",
                      where = get("class_cache", envir = asNamespace("odbc")))},
                    error = function(e){NULL})
}

# If Teradata class already present from Native driver, removes it
# this is required to avod S4 class collision for the "Teradata" class name
# This is only required if both ODBC and Native drivers are used interchangeably in same session
#' @importFrom methods removeClass
.ta.removeNativeTeradataClassDef <- function() {
  if (!is.null(.ta.getClassDef("Teradata"))) {
    # Use the folllowing commands to remove Teradata class for the native driver
    try(suppressWarnings(removeClass("Teradata", where = .getClassCache())), silent = TRUE)
    try(unloadNamespace("teradatasql"), silent = TRUE)
  }
}

# Overridden show method for the connection object, to support native driver
# This method also calls the super class show method for odbc
#' @importFrom methods callNextMethod
#' @importFrom methods getMethod
setMethod(
  "show", "Teradata",
  function(object) {
    cat(sep = "",
      if (inherits(object, "TeradataConnection")) { # this is native driver
        if (.ta.isConnectionValid(object, silent = TRUE)) {
          paste0("<Teradata Native Driver Connection>\n  ",.get_username(object),"@",
            .get_servername(object),"\n  Database: ",.get_dbname(object),
                 "\n  Teradata Version: ",.get_version(object),"\n")
        } else {
          paste0(str(
            .ta.getErrorObject("TDR_E10051", FALSE, FALSE, FALSE, list())),"\n")
        }
      })
    # Call the super class show method
    superClass <- "OdbcConnection"
    if (inherits(object, "TeradataConnection"))
      superClass <- "TeradataConnection"
    superShow <- try(getMethod("show", c(superClass)), silent = TRUE)
    if (!identical(class(superShow), "try-error"))
     superShow(object)
})

######## Other helper methods #########

# A generic function to construct a json object.
# Only JSON values with strings are supported.
.getJSONObject <- function(...) {
  arguments <- as.list(sys.call()[-1])
  jsonArgs <- c()
  for (argName in names(arguments)) {
    if (!is.null(arguments[[argName]]))
      jsonArgs <- c(jsonArgs, .getJSONArg(argName, arguments[[argName]]))
  }
  paste0("{", paste0(jsonArgs, collapse = ","), "}")
}

.getJSONArg <- function(name, value) {
  paste0(.teradataQuoteArg(name, '"', FALSE), ":", .teradataQuoteArg(value, '"', FALSE))
}

# Retrieve the class definitions from local cache
# Helper method to check if a class definition is present in local cache
#' @importFrom methods isVirtualClass
#' @importFrom methods getClassDef
.ta.getClassDef <- function(name, where = .getClassCache(), inherits = FALSE) {
  classDef <- getClassDef(name, where = where, inherits = inherits)
  if (!is.null(classDef) && !isVirtualClass(classDef))
    return(classDef)
  return(NULL)
}

# Function to validate logmech and logdata arguments. Returns TRUE if all validations are
# successful.
.validate_logmech_logdata_arguments <- function(logmech, logdata) {
  # This is a check to validate if logdata$jwt_token is null or not provided when logmech is used.
  if (!is.null(logmech) && logmech == 'JWT' && (is.null(logdata) ||
    !("jwt.token" %in% names(logdata)))) {
    .ta.stop("TDR_E1109", "'jwt.token'", "the named list of 'logdata'", "'logmech'","set to JWT")
  }
  # This is a check to validate the datatype of jwt.token
  if (!is.null(logmech) && logmech == 'JWT' && !inherits(logdata$jwt.token, "character")) {
    .ta.stop("TDR_E3005", "'jwt.token' of named list in the 'logdata' argument")
  }
  # This is a check to validate if logdata$jwt_token is empty string or not.
  if (any(grepl("^$", logdata$jwt.token), grepl("^\\s*$", logdata$jwt.token))) {
    .ta.stop("TDR_E1110", "'jwt.token' of named list", "logdata")
  }
  return(TRUE)
}