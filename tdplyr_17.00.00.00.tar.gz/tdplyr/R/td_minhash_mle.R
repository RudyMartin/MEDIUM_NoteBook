# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 2.10
# 
# ################################################################## 

# Description:
#   The MinHash function uses transaction history to cluster similar
#   items or users together. For example, the function can cluster items
#   that are frequently bought together or users that bought the same
#   items.
# 
# Args:
#   data -
#     Required Argument.\cr
#     Specifies the tbl_teradata containing the input data.\cr
#   
#   id.column -
#     Required Argument.\cr
#     Specifies the name of the column in "data" that contains the
#     values to be hashed into the same cluster.\cr
#     Typically these values are customer identifiers.\cr
#     Types: character
#   
#   items.column -
#     Required Argument.\cr
#     Specifies the name of the column in "data" that contains the
#     values to use for hashing.\cr
#     Types: character
#   
#   hash.num -
#     Required Argument.\cr
#     Specifies the number of hash functions to generate. This argument
#     determines the number and size of clusters generated.\cr
#     Types: integer
#   
#   key.groups -
#     Required Argument.\cr
#     Specifies the number of key groups to generate. The "key.groups" must
#     be a divisor of "hash.num". A large value in "key.groups" decreases
#     the probability that multiple users will be assigned to the same
#     cluster identifier.\cr
#     Types: integer
#   
#   seed.table -
#     Optional Argument.\cr
#     Specifies the tbl_teradata that contains the seeds to be used for
#     hashing. Typically, this is the "save.seed.to" tbl_teradata that was
#     created by an earlier call to \code{td_minhash_mle}.\cr
#     Note: When this argument is specified, the "save.seed.to" output
#           tbl_teradata is not created in the current call to
#           \code{td_minhash_mle}.
#   
#   input.format -
#     Optional Argument.\cr
#     Specifies the format of the values to be hashed (the values in 
#     items_column).\cr
#     Default Value: "integer"\cr
#     Permitted Values: bigint, integer, hex, string\cr
#     Types: character
#   
#   mincluster.size -
#     Optional Argument.\cr
#     Specifies the minimum cluster size.\cr
#     Default Value: 3\cr
#     Types: integer
#   
#   maxcluster.size -
#     Optional Argument.\cr
#     Specifies the maximum cluster size.\cr
#     Default Value: 5\cr
#     Types: integer
#   
#   delimiter -
#     Optional Argument.\cr
#     Specifies the delimiter used between hashed values (typically 
#     customer identifiers) in the output.\cr
#     Default Value: " "\cr
#     Types: character
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   seed.table.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "seed.table". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_minhash_mle" which is a named 
#   list containing objects of class "tbl_teradata".\cr
#   Named list members can be referenced directly with the "$" operator 
#   using the following names:\enumerate{\item output.table\item 
#   save.seed.to\item output}
# 
# 
#' @export
td_minhash_mle <- function(
  data = NULL,
  id.column = NULL,
  items.column = NULL,
  hash.num = NULL,
  key.groups = NULL,
  seed.table = NULL,
  input.format = "integer",
  mincluster.size = 3,
  maxcluster.size = 5,
  delimiter = " ",
  data.sequence.column = NULL,
  seed.table.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("id.column", id.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("items.column", items.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("hash.num", hash.num, FALSE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("key.groups", key.groups, FALSE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seed.table", seed.table, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("input.format", input.format, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("mincluster.size", mincluster.size, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("maxcluster.size", maxcluster.size, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("delimiter", delimiter, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("seed.table.sequence.column", seed.table.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  .validateInputTableDataType(seed.table, NULL)
  
  # Check for permitted values
  input.formatPermittedValues <- list("BIGINT", "INTEGER", "HEX", "STRING")
  .validatePermittedValues(input.format, input.formatPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(id.column)
  .validateTblHasArgumentColumns(id.column, "id.column", data, "data")
  
  .validateInputColumnsNotEmpty(items.column)
  .validateTblHasArgumentColumns(items.column, "items.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(seed.table.sequence.column)
  .validateTblHasArgumentColumns(seed.table.sequence.column, "seed.table.sequence.column", seed.table, "seed.table")
  
  # Generate temp table names for output table parameters if any.
  output.tableTempTableName <- .teradataGenerateTempTableName("td_minhash_mle0_", use.default.database=TRUE, gc.onQuit=TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_minhash_mle.internal)
  Call[["output.tableTempTableName"]] <- output.tableTempTableName
  # Manually adding this check. Since if seed.table is provided then
  # function fails when creating save.seed.to output table.
  if (is.null(seed.table)) {
    save.seed.toTempTableName <- .teradataGenerateTempTableName("td_minhash_mle1_", use.default.database=TRUE, gc.onQuit=TRUE)
    Call[["save.seed.toTempTableName"]] <- save.seed.toTempTableName
  }
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_minhash_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_minhash_mle.internal <- function(
  data = NULL,
  id.column = NULL,
  items.column = NULL,
  hash.num = NULL,
  key.groups = NULL,
  seed.table = NULL,
  input.format = "integer",
  mincluster.size = 3,
  maxcluster.size = 5,
  delimiter = " ",
  data.sequence.column = NULL,
  seed.table.sequence.column = NULL,
  output.tableTempTableName = NULL,
  save.seed.toTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("OutputTable")
  funcOutputArgs <- c(output.tableTempTableName)
  
  # manually added check to conditionally add SaveSeedTo table
  if (!missing(save.seed.toTempTableName) && !is.null(save.seed.toTempTableName)) {
    funcOutputArgsSqlNames <- c(funcOutputArgsSqlNames,"SaveSeedTo")
    funcOutputArgs <- c(funcOutputArgs, save.seed.toTempTableName)
  }
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "UserIDColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(id.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ItemIDColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(items.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "HashNum")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(hash.num, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "KeyGroups")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(key.groups, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  
  if (!is.null(input.format) && !missing(input.format)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "InputFormat")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(input.format, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(mincluster.size) && !missing(mincluster.size)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MinClusterSize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(mincluster.size, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(maxcluster.size) && !missing(maxcluster.size)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxClusterSize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(maxcluster.size, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(delimiter) && !missing(delimiter)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Delimiter")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(delimiter, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (!is.null(seed.table.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("SeedTable:", .teradataCollapseArgVector(seed.table.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # Process seed.table
  if (!is.null(seed.table)) {
    tableRef <- .teradataOnClauseFromDataFrame(seed.table)
    funcInputDistribution <- c(funcInputDistribution, "NONE")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "SeedTable")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
                                     "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "Minhash",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("Minhash", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data, seed.table)
  
  # Return output table data frames.
  result <- list()
  result[["output.table"]] <- .createDataSetObject(.extractTableName(output.tableTempTableName), sourceType = "table", .extractDatabaseName(output.tableTempTableName), is_dplyr_input)
  # manually added check to conditionally add SaveSeedTo table
  if (!missing(save.seed.toTempTableName) && !is.null(save.seed.toTempTableName))
    result[["save.seed.to"]] <- .createDataSetObject(.extractTableName(save.seed.toTempTableName), sourceType = "table", .extractDatabaseName(save.seed.toTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_minhash <- td_minhash_mle
