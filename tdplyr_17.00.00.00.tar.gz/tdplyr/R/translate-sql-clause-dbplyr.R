# Reusing the same code for some of the unexported functions of dbplyr.

# Generic function which builds SQL clauses.
sql_clause_generic <- function(clause, fields, con){
  if (length(fields) > 0L) {
    stopifnot(is.character(fields))
    build_sql(
      sql(clause), " ",
      escape(fields, collapse = ", ", con = con),
      con = con
    )
  }
}

#' @importFrom dbplyr sql_vector
sql_clause_where <- function(where, con){
  if (length(where) > 0L) {
    stopifnot(is.character(where))
    where_paren <- escape(where, parens = TRUE, con = con)
    build_sql(
      "WHERE ", sql_vector(where_paren, collapse = " AND ", con = con),
      con = con
    )
  }
}

sql_clause_from  <- function(from, con) sql_clause_generic("FROM", from, con)

sql_clause_group_by <- function(group_by, con) sql_clause_generic("GROUP BY", group_by, con)

sql_clause_having <- function(having, con) sql_clause_generic("HAVING", having, con)

sql_clause_order_by <- function(order_by, con) sql_clause_generic("ORDER BY", order_by, con)


# Reusing the same unexported code of dbplyr from 
# https://github.com/tidyverse/dbplyr/blob/master/R/partial-eval.R
partial_eval_dots <- function(dots, vars) {
  stopifnot(inherits(dots, "quosures"))
  
  lapply(dots, function(x) {
    new_quosure(
      partial_eval(get_expr(x), vars = vars, env = get_env(x)),
      get_env(x)
    )
  })
}

# Reusing the same unexported code of dbplyr from 
# https://github.com/tidyverse/dbplyr/blob/master/R/verb-summarise.R
# For each expression, check if it uses any newly created variables
check_summarise_vars <- function(dots) {
  for (i in seq_along(dots)) {
    used_vars <- all_names(get_expr(dots[[i]]))
    cur_vars <- names(dots)[seq_len(i - 1)]
    if (any(used_vars %in% cur_vars)) {
      stop(
        "`", names(dots)[[i]],
        "` refers to a variable created earlier in this summarise().\n",
        "Do you need an extra mutate() step?",
        call. = FALSE
      )
    }
  }
}

# Reusing the same unexported code of dbplyr from 
# https://github.com/tidyverse/dbplyr/blob/master/R/translate-sql.R
#' @importFrom rlang is_quosure
#' @importFrom rlang quo_get_expr
all_names <- function(x) {
  if (is.name(x)) return(as.character(x))
  if (is_quosure(x)) return(all_names(quo_get_expr(x)))
  if (!is.call(x)) return(NULL)
  
  unique(unlist(lapply(x[-1], all_names), use.names = FALSE))
}