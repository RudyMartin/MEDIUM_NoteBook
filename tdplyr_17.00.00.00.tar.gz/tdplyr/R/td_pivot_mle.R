# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.9
# 
# ################################################################## 

# Description:
#   The Pivot function pivots data that is stored in rows into columns. It
#   outputs a tbl_teradata whose columns are based on the individual
#   values from an input table column. The schema of the output 
#   tbl_teradata depends on the arguments to the function. The
#   function handles missing or NULL values automatically.
# 
# Args:
#   data -
#     Required Argument.
#     The tbl_teradata containing the data to be pivoted.
#   
#   data.partition.column -
#     Required Argument.
#     Specifies Partition By columns for data.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.
#     Types: character OR vector of Strings (character)
#   
#   data.order.column -
#     Optional Argument.
#     Specifies Order By columns for data.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   partition.columns -
#     Required Argument.
#     Specifies the same columns as the partition.columns clause (in any 
#     order).
#     Types: character OR vector of Strings (character)
#   
#   target.columns -
#     Required Argument.
#      Specifies the names of the input columns that contain the values to 
#     pivot.
#     Types: character OR vector of Strings (character)
#   
#   pivot.column -
#     Optional Argument.
#      Specifies the name of the column that contains the pivot keys. If 
#     the pivot column contains numeric values, then the function casts 
#     them to VARCHAR. If you omit the num.rows argument, then you must 
#     specify this argument. Note: If you specify the pivot.column 
#     argument, then you must order the input data; otherwise, the output 
#     tbl_teradata column content is nondeterministic.
#     Types: character
#   
#   pivot.keys -
#     Optional Argument.
#     If you specify the pivot.column argument, then this argument 
#     specifies the names of the pivot keys. Do not use this argument 
#     without the pivot.column argument. If pivot.column contains a value 
#     that is not specified as a pivot.key, then the function ignores the 
#     row containing that value. pivot.keys is required when pivot.columns 
#     is used.
#     Types: character OR vector of characters
#   
#   numeric.pivotkey -
#     Optional Argument.
#     indicates whether the pivot key values are numeric values.
#     Default Value: FALSE
#     Types: logical
#   
#   num.rows -
#     Optional Argument.
#     Specifies the maximum number of rows in any partition. If a partition 
#     has fewer than number_of_rows rows, then the function adds NULL 
#     values; if a partition has more than number_of_rows rows, then the 
#     function omits the extra rows. If you omit this argument, then you 
#     must specify the pivot.column argument. Note: With this argument, the 
#     ORDER BY clause is optional. If omitted, the order of values can 
#     vary. The function adds NULL values at the end.
#     Types: integer
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_pivot_mle" which is a named 
#   list containing Teradata tbl object.
#   Named list member can be referenced directly with the "$" operator 
#   using name: result.
# 
# 
#' @export
td_pivot_mle <- function(
  data = NULL,
  partition.columns = NULL,
  target.columns = NULL,
  pivot.column = NULL,
  pivot.keys = NULL,
  numeric.pivotkey = FALSE,
  num.rows = NULL,
  data.sequence.column = NULL,
  data.partition.column = NULL,
  data.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.partition.column", data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("partition.columns", partition.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("target.columns", target.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("pivot.column", pivot.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("pivot.keys", pivot.keys, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("numeric.pivotkey", numeric.pivotkey, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("num.rows", num.rows, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(partition.columns)
  .validateTblHasArgumentColumns(partition.columns, "partition.columns", data, "data")
  
  .validateInputColumnsNotEmpty(target.columns)
  .validateTblHasArgumentColumns(target.columns, "target.columns", data, "data")
  
  .validateInputColumnsNotEmpty(pivot.column)
  .validateTblHasArgumentColumns(pivot.column, "pivot.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.partition.column)
  .validateTblHasArgumentColumns(data.partition.column, "data.partition.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PartitionColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(partition.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(target.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(pivot.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PivotColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(pivot.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(num.rows)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NumberOfRows")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(num.rows, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(pivot.keys)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PivotKeys")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(pivot.keys, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(numeric.pivotkey) && !missing(numeric.pivotkey)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NumericPivotKey")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(numeric.pivotkey, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  data.partition.column <- .teradataCollapseArgVector(data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "Pivot",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("Pivot", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_pivot_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_pivot <- td_pivot_mle
