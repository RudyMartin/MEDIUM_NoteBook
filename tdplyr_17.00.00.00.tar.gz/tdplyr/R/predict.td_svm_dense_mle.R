# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' @export
predict.td_svm_dense_mle <- function(object = NULL,
                                     newdata = NULL,
                                     attribute.columns = NULL,
                                     sample.id.column = NULL,
                                     accumulate.label = NULL,
                                     output.class.num = NULL,
                                     output.response.probdist = TRUE,
                                     output.responses = NULL,
                                     newdata.sequence.column = NULL,
                                     object.sequence.column = NULL,
                                     newdata.order.column = NULL,
                                     object.order.column = NULL
                                    )
{
  Call <- match.call()
  Call[[1]] <- quote(tdplyr::td_svm_dense_predict_mle)
  eval.parent(Call)
}
