# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# Secondary Owner: Jeris Alan Jawahar (jeris.jawahar@teradata.com)
# 
# Version: 1.1
# Function Version: 1.0
# 
# ################################################################## 

# Description:
#   The Unpack function unpacks data from a single packed column into 
#   multiple columns. The packed column is composed of multiple virtual 
#   columns, which become the output columns. To determine the virtual 
#   columns, the function must have either the delimiter that separates 
#   them in the packed column or their lengths.
# 
# Args:
#   data -
#     Required Argument.\cr
#     The tbl_teradata containing the input attributes.\cr
#   
#   data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   input.column -
#     Required Argument.\cr
#      Specifies the name of the input column that contains the packed 
#     data.\cr
#     Types: character
#   
#   output.columns -
#     Required Argument.\cr
#     Specifies the names to give to the output columns, in the order in 
#     which the corresponding virtual columns appear in input_column.If you 
#     specify fewer output column names than there are virtual input 
#     columns, the function ignores the extra virtual input columns. That 
#     is, if the packed data contains x+y virtual columns and the 
#     OutputColumns argument specifies x output column names, the function 
#     assigns the names to the first x virtual columns and ignores the 
#     remaining y virtual columns. \cr
#     Types: character OR vector of characters
#   
#   output.datatypes -
#     Required Argument.\cr
#     Specifies the datatypes of the unpacked output columns.Supported 
#     output.datatypes are VARCHAR, integer, numeric, TIME, DATE, and 
#     TIMESTAMP.If output.datatypes specifies only one value and 
#     output.columns specifies multiple columns, then the specified value 
#     applies to every output_column. If output.datatypes specifies 
#     multiple values, then it must specify a value for each output_column. 
#     The nth datatype corresponds to the nth output_column.The function 
#     can output only 16 VARCHAR columns.\cr
#     Types: character OR vector of characters
#   
#   delimiter -
#     Optional Argument.\cr
#      Specifies the delimiter (a string) that separates the virtual 
#     columns in the packed data.The default delimiter is comma (,). If the 
#     virtual columns are separated by a delimiter, then specify the 
#     delimiter with this argument; otherwise, specify the column.length 
#     argument. Do not specify both this argument and the column.length 
#     argument.\cr
#     Default Value: ","\cr
#     Types: character
#   
#   column.length -
#     Optional Argument.\cr
#     Specifies the lengths of the virtual columns; therefore, to use this 
#     argument, you must know the length of each virtual column. If 
#     column.length specifies only one value and output.columns specifies 
#     multiple columns, then the specified value applies to every 
#     output_column. If column.length specifies multiple values, then it 
#     must specify a value for each output_column. The nth datatype 
#     corresponds to the nth output_column. However, the last column_name 
#     can be an asterisk (*), which represents a single virtual column that 
#     contains the remaining data. For example, if the first three virtual 
#     columns have the lengths 2, 1, and 3, and all remaining data belongs 
#     to the fourth virtual column, you can specify column.length ("2", 
#     "1", "3", *). If you specify this argument, you must omit the 
#     delimiter argument.\cr
#     Types: character OR vector of characters
#   
#   regex -
#     Optional Argument.\cr
#     Specifies a regular expression that describes a row of packed data, 
#     enabling the function to find the data values. A row of packed data 
#     contains one data value for each virtual column, but the row might 
#     also contain other information (such as the virtual column name). In 
#     the regular_expression, each data value is enclosed in parentheses. 
#     For example, suppose that the packed data has two virtual columns, 
#     age and sex, and that one row of packed data is: age:34,sex:male The 
#     regular_expression that describes the row is ".*:(.*)". The ".*:" 
#     matches the virtual column names, age and sex, and the "(.*)" matches 
#     the values, 34 and male. The default regular_expression is "(.*)" 
#     which matches the whole string (between delimiters, if any). When 
#     applied to the preceding sample row, the default regular_expression 
#     causes the function to return "age:34" and "sex:male" as data values. 
#     To represent multiple data groups in regular_expression, use multiple 
#     pairs of parentheses. By default, the last data group in 
#     regular_expression represents the data value (other data groups are 
#     assumed to be virtual column names or unwanted data). If a different 
#     data group represents the data value, specify its group number with 
#     the regex.set argument.\cr
#     Default Value: "(.*)"\cr
#     Types: character
#   
#   regex.set -
#     Optional Argument.\cr
#     Specifies the ordinal number of the data group in regular_expression 
#     that represents the data value in a virtual column. By default, the 
#     last data group in regular_expression represents the data value. For 
#     example, suppose that regular_expression is: "([a-zA-Z]*):(.*)" If 
#     group_number is "1", then "([a-zA-Z]*)" represents the data value. If 
#     group_number is "2", then "(.*)" represents the data value.\cr
#     Default Value: 1\cr
#     Types: integer
#   
#   exception -
#     Optional Argument.\cr
#     Specifies whether the function ignores rows that contain invalid 
#     data; that is, continues without outputting them. which causes the 
#     function to fail if it encounters a row with invalid data.\cr
#     Default Value: FALSE\cr
#     Types: logical
# 
# Returns:
#   Function returns an object of class "td_unpack_sqle" which is a named 
#   list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_unpack_sqle <- function(
  data = NULL,
  input.column = NULL,
  output.columns = NULL,
  output.datatypes = NULL,
  delimiter = ",",
  column.length = NULL,
  regex = "(.*)",
  regex.set = 1,
  exception = FALSE,
  data.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("input.column", input.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.columns", output.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.datatypes", output.datatypes, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("delimiter", delimiter, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("column.length", column.length, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("regex", regex, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("regex.set", regex.set, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("exception", exception, TRUE, c("logical",NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(input.column)
  .validateTblHasArgumentColumns(input.column, "input.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  # Validate that value passed to the output column argument is not empty.
  .validateInputColumnsNotEmpty(output.columns)
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(input.column, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.columns, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputDataTypes")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.datatypes, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  if (!is.null(delimiter) && !missing(delimiter)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Delimiter")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(delimiter, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(column.length)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ColumnLength")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(column.length, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(regex) && !missing(regex)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Regex")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(regex, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(regex.set) && !missing(regex.set)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "RegexSet")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(regex.set, ""))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(exception) && !missing(exception)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IgnoreInvalid")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(exception, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "ANY")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "Unpack",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_SQL")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("Unpack", engine = .getEngineName("ENGINE_SQL"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_unpack_sqle", engine = .getEngineName("ENGINE_SQL"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_unpack <- td_unpack_sqle
