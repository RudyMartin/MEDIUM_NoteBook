# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' @export
predict.td_lar_mle <- function(   object = NULL,
                              newdata = NULL,
                              mode = "STEP",
                              s = NULL,
                              target.col = NULL,
                              object.sequence.column = NULL,
                              newdata.sequence.column = NULL, 
                              newdata.order.column = NULL,
                              object.order.column = NULL) {
  td_lar_predict_mle(   object = object,
                    newdata = newdata,
                    mode = mode,
                    s = s,
                    target.col = target.col,
                    object.sequence.column = object.sequence.column,
                    newdata.sequence.column = newdata.sequence.column,
                    newdata.order.column = newdata.order.column,
                    object.order.column = object.order.column)
}
