# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 2.25
# 
# ################################################################## 

# Description:
#   The Forest Drive function uses a training data set to generate a 
#   predictive model. You can input the model to the Forest Predict 
#   function, which uses it to make predictions.
# 
# Args:
#   formula -
#     Required Argument.
#     An object of class "formula". Specifies the model to be fitted. Only 
#     basic formula of the (col1 ~ col2 + col3 +...) form are supported and 
#     all variables must be from the same tbl_teradata object. The 
#     response should be column of type numeric or logical.
#   
#   data -
#     Required Argument.
#     Specifies the tbl_teradata containing the input data set.
#   
#   maxnum.categorical -
#     Optional Argument.
#     Specifies the maximum number of distinct values for a single 
#     categorical variable. The max_cat_values must be a positive integer. 
#     A max_cat_values greater than 20 is not recommended.
#     Default Value: 20
#     Types: integer
#   
#   tree.type -
#     Optional Argument.
#     Specifies whether the analysis is a regression (continuous response 
#     variable) or a multiclass classification (predicting result from the 
#     number of classes). The default value is "regression" if the response 
#     variable is numeric and "classification" if the response variable is 
#     nonnumeric.
#     Types: character
#   
#   ntree -
#     Optional Argument.
#     Specifies the number of trees to grow in the forest model. When 
#     specified, number_of_trees must be greater than or equal to the 
#     number of vworkers.When not specified, the function builds the 
#     minimum number of trees that provides the input dataset with full 
#     coverage.
#     Types: integer
#   
#   tree.size -
#     Optional Argument.
#     Specifies the number of rows that each tree uses as its input data 
#     set. If not specified, the function builds a tree using either the 
#     number of rows on a vworker or the number of rows that fit into the 
#     vworker"s memory, whichever is less.
#     Types: integer
#   
#   nodesize -
#     Optional Argument.
#     Specifies a decision tree stopping criterion; the minimum size of any 
#     node within each decision tree 
#     Default Value: 1
#     Types: integer
#   
#   variance -
#     Optional Argument.
#     Specifies a decision tree stopping criterion. If the variance within 
#     any nodedips below this value, the algorithm stops looking for splits 
#     in the branch. The default value is 0.
#     Default Value: 0
#     Types: numeric
#   
#   max.depth -
#     Optional Argument.
#     Specifies a decision tree stopping criterion. If the tree reaches a 
#     depth pastthis value, the algorithm stops looking for splits. 
#     Decision trees can grow to (2(max_depth+1) - 1) nodes. This stopping 
#     criteria has the greatest effect on the performance of the function. 
#     Default Value: 12
#     Types: integer
#   
#   mtry -
#     Optional Argument.
#     Specifies the number of variables to randomly sample from each 
#     inputvalue. For example, if mtry is 3, then the function randomly 
#     samples 3variables from each input at each split. The mtry must be an 
#     integer.
#     Types: integer
#   
#   mtry.seed -
#     Optional Argument.
#     Specifies a numeric value to use in determining the random seed for 
#     mtry
#     Types: numeric
#   
#   seed -
#     Optional Argument.
#     Specifies a numeric value to use in determining the seed for the 
#     random number generator. If you specify this value, you can specify 
#     the same value in future calls to this function and the function will 
#     build the same tree.
#     Types: numeric
#   
#   outofbag -
#     Optional Argument.
#     Specifies whether to output the out-of-bag estimate of error rate.
#     Default Value: FALSE
#     Types: logical
#   
#   display.num.processed.rows -
#     Optional Argument.
#     Specifies whether to display the number of processed rows of input 
#     table. 
#     Default Value: FALSE
#     Types: logical
#   
#   categorical.encoding -
#     Optional Argument.
#     Specifies which encoding method is used for categorical variables.
#     Default Value: "graycode"
#     Permitted Values: graycode, hashing
#     Types: character
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_decision_forest_mle" which is 
#   a named list containing Teradata tbl objects.
#   Named list members can be referenced directly with the "$" operator 
#   using following names:\enumerate{\item predictive.model\item 
#   monitor.table\item output}
# 
# 
#' @export
td_decision_forest_mle <- function(
  formula = NULL,
  data = NULL,
  maxnum.categorical = 20,
  tree.type = NULL,
  ntree = NULL,
  tree.size = NULL,
  nodesize = 1,
  variance = 0,
  max.depth = 12,
  mtry = NULL,
  mtry.seed = NULL,
  seed = NULL,
  outofbag = FALSE,
  display.num.processed.rows = FALSE,
  categorical.encoding = "graycode",
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("formula", formula, FALSE, "formula"))
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("maxnum.categorical", maxnum.categorical, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("tree.type", tree.type, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("ntree", ntree, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("tree.size", tree.size, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("nodesize", nodesize, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("variance", variance, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("max.depth", max.depth, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("mtry", mtry, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("mtry.seed", mtry.seed, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seed", seed, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("outofbag", outofbag, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("display.num.processed.rows", display.num.processed.rows, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("categorical.encoding", categorical.encoding, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check for permitted values
  categorical.encodingPermittedValues <- list("GRAYCODE", "HASHING")
  .validatePermittedValues(categorical.encoding, categorical.encodingPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  # Generate temp table names for output table parameters if any.
  predictive.modelTempTableName <- .teradataGenerateTempTableName("td_decision_forest_mle0_", use.default.database = TRUE, gc.onQuit = TRUE)
  monitor.tableTempTableName <- .teradataGenerateTempTableName("td_decision_forest_mle1_", use.default.database = TRUE, gc.onQuit = TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_decision_forest_mle.internal)
  Call[["predictive.modelTempTableName"]] <- predictive.modelTempTableName
  Call[["monitor.tableTempTableName"]] <- monitor.tableTempTableName
  
  retval <- NULL
  tryCatch({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_decision_forest_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units = "secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval, data) 
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_decision_forest_mle.internal <- function(
  formula = NULL,
  data = NULL,
  maxnum.categorical = 20,
  tree.type = NULL,
  ntree = NULL,
  tree.size = NULL,
  nodesize = 1,
  variance = 0,
  max.depth = 12,
  mtry = NULL,
  mtry.seed = NULL,
  seed = NULL,
  outofbag = FALSE,
  display.num.processed.rows = FALSE,
  categorical.encoding = "graycode",
  data.sequence.column = NULL,
  predictive.modelTempTableName = NULL,
  monitor.tableTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("OutputTable", "MonitorTable")
  funcOutputArgs <- c(predictive.modelTempTableName, monitor.tableTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  if (!is.null(tree.type)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TreeType")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(tree.type, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(ntree)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NumTrees")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(ntree, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(tree.size)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TreeSize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(tree.size, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(nodesize) && !missing(nodesize)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MinNodeSize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(nodesize, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(variance) && !missing(variance)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Variance")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(variance, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(max.depth) && !missing(max.depth)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxDepth")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(max.depth, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(maxnum.categorical) && !missing(maxnum.categorical)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxNumCategoricalValues")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(maxnum.categorical, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(display.num.processed.rows) && !missing(display.num.processed.rows)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "DisplayNumProcessedRows")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(display.num.processed.rows, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(mtry)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Mtry")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(mtry, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(mtry.seed)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MtrySeed")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(mtry.seed, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "LONG")
  }
  
  if (!is.null(seed)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Seed")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(seed, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "LONG")
  }
  
  if (!is.null(outofbag) && !missing(outofbag)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutOfBag")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(outofbag, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(categorical.encoding) && !missing(categorical.encoding)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CategoricalEncoding")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(categorical.encoding, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Let's process formula argument
  formula.terms.matrix <- .ta.parse.formula(formula, data)
  # response variable
  response <- formula.terms.matrix[1,1]
  mc.target.column <- response
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ResponseColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(response,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  mc.sql.specific.attributes[["ResponseColumn"]] <- response
  
  # numerical input columns
  numerical_inputs <- .ta.getColumnsByType(formula.terms.matrix, data, "numerical")
  if (length(numerical_inputs) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NumericInputs")
    numericalColumnsList <- .teradataCollapseArgVector(.teradataQuoteArg(numerical_inputs,"\""), "'")
    funcOtherArgs <- c(funcOtherArgs, numericalColumnsList)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
    mc.sql.specific.attributes[["NumericInputs"]] <- numericalColumnsList
  }
  
  # categorical input columns
  categorical_inputs <- .ta.getColumnsByType(formula.terms.matrix, data, "categorical")
  if (length(categorical_inputs) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CategoricalInputs")
    categoricalColumnsList <- .teradataCollapseArgVector(.teradataQuoteArg(categorical_inputs,"\""), "'")
    funcOtherArgs <- c(funcOtherArgs, categoricalColumnsList)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
    mc.sql.specific.attributes[["CategoricalInputs"]] <- categoricalColumnsList
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "DecisionForest",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("DecisionForest", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database = TRUE, gc.onQuit = TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["predictive.model"]] <- .createDataSetObject(.extractTableName(predictive.modelTempTableName), sourceType = "table", .extractDatabaseName(predictive.modelTempTableName), is_dplyr_input)
  result[["monitor.table"]] <- .createDataSetObject(.extractTableName(monitor.tableTempTableName), sourceType = "table", .extractDatabaseName(monitor.tableTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_decision_forest <- td_decision_forest_mle
