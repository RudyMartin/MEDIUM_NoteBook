# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.7
# 
# ################################################################## 

# Description:
#   The PartitionScale function scales the sequences in each partition
#   independently, using the same formula as the function Scale.
# 
# Args:
#   data -
#     Required Argument.
#     The input dataset for scale function.
#   
#   data.partition.column -
#     Required Argument.
#     Specifies Partition By columns for data.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.
#     Types: character OR vector of Strings (character)
#   
#   data.order.column -
#     Optional Argument.
#     Specifies Order By columns for data.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   method -
#     Required Argument.
#     Specifies one or more statistical methods to use to scale the data 
#     set. For method values and descriptions. If you specify multiple 
#     methods, the output tbl_teradata includes the column scalemethod 
#     (which contains the method name) and a row for each input-row/method 
#     combination
#     Permitted Values: MEAN, SUM, USTD, STD, RANGE, MIDRANGE, MAXABS
#     Types: character OR vector of characters
#   
#   miss.value -
#     Optional Argument.
#     Specifies how the ta.partitionscale function is to process NULL 
#     values in input, as follows: KEEP (default): Keep NULL values, OMIT: 
#     Ignore any row that has a NULL value, ZERO: Replace each NULL value 
#     with zero, LOCATION: Replace each NULL value with its location value.
#     Default Value: "KEEP"
#     Permitted Values: KEEP, OMIT, ZERO, LOCATION
#     Types: character
#   
#   input.columns -
#     Required Argument.
#     Specifies the input tbl_teradata columns that contain the attribute 
#     values of the samples. The attribute values must be numeric values 
#     between -1e308 and 1e308. If a value is outside this range, the 
#     function treats it as infinity.
#     Types: character OR vector of Strings (character)
#   
#   global -
#     Optional Argument.
#      Specifies whether all input columns are scaled to the same location 
#     and scale. (each input column is scaled separately). 
#     Default Value: FALSE
#     Types: logical
#   
#   accumulate -
#     Optional Argument.
#     Specifies the input tbl_teradata columns to copy to the output table. 
#     By default, the function copies no input tbl_teradata columns to the 
#     output table. Tip: To identify the sequences in the output, specify 
#     the partition columns in this argument.
#     Types: character OR vector of Strings (character)
#   
#   multiplier -
#     Optional Argument.
#     Specifies one or more multiplying factors to apply to the input 
#     variables (multiplier in the following formula): X" = intercept + 
#     multiplier * (X - location)/scale If you specify only one multiplier, 
#     it applies to all columns specified by the input.columns argument. If 
#     you specify multiple multiplying factor, each multiplier applies to 
#     the corresponding input column. For example, the first multiplier 
#     applies to the first column specified by the InputColumns argument, 
#     the second multiplier applies to the second input column, and so on. 
#     The default multiplier is 1. 
#     Default Value: [1]
#     Types: numeric OR vector of numerics
#   
#   intercept -
#     Optional Argument.
#     Specifies one or more addition factors incrementing the scaled 
#     results-intercept in the following formula: X" = intercept + 
#     multiplier * (X - location)/scale If you specify only one intercept, 
#     it applies to all columns specified by the input.columns argument. If 
#     you specify multiple addition factors, each intercept applies to the 
#     corresponding input column. The syntax of intercept is: [-]{number | 
#     min | mean | max } where min, mean, and max are the global minimum, 
#     maximum, mean values in the corresponding columns. The function 
#     scales the values of min, mean, and max. For example, if intercept is 
#     "- min" and multiplier is 1, the scaled result is transformed to a 
#     nonnegative sequence according to this formula, where scaledmin is 
#     the scaled value: X" = -scaledmin + 1 * (X - location)/scale The 
#     default intercept is 0.
#     Default Value: "["0"]"
#     Types: character OR vector of characters
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_scale_by_partition_mle" which 
#   is a named list containing Teradata tbl object.
#   Named list member can be referenced directly with the "$" operator 
#   using name: result.
# 
# 
#' @export
td_scale_by_partition_mle <- function(
  data = NULL,
  method = NULL,
  miss.value = "KEEP",
  input.columns = NULL,
  global = FALSE,
  accumulate = NULL,
  multiplier = 1,
  intercept = "0",
  data.sequence.column = NULL,
  data.partition.column = NULL,
  data.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.partition.column", data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("method", method, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("miss.value", miss.value, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("input.columns", input.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("global", global, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("multiplier", multiplier, TRUE, c("numeric","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("intercept", intercept, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check for permitted values
  methodPermittedValues <- list("MEAN", "SUM", "USTD", "STD", "RANGE", "MIDRANGE", "MAXABS")
  .validatePermittedValues(method, methodPermittedValues)
  
  miss.valuePermittedValues <- list("KEEP", "OMIT", "ZERO", "LOCATION")
  .validatePermittedValues(miss.value, miss.valuePermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(input.columns)
  .validateTblHasArgumentColumns(input.columns, "input.columns", data, "data")
  
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.partition.column)
  .validateTblHasArgumentColumns(data.partition.column, "data.partition.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(input.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(accumulate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(accumulate,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ScaleMethod")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(method, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  if (!is.null(miss.value) && !missing(miss.value)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MissValue")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(miss.value, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(global) && !missing(global)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "GlobalScale")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(global, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(multiplier) && !missing(multiplier)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Multiplier")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(multiplier, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(intercept) && !missing(intercept)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Intercept")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(intercept, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  data.partition.column <- .teradataCollapseArgVector(data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "PartitionScale",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("PartitionScale", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_scale_by_partition_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_scale_by_partition <- td_scale_by_partition_mle
