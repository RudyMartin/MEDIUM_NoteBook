# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

# Helper functions for constructing sql mappings

# helper function for building regexp_* functions in Teradata
# Arguments:
#   position - value to use for the position parameter
#   occurrence - value to use for the occurrence parameter
#   return_opt  - value to use for the return_opt parameter
#   match - value to use for the match parameter
# Returns:
#   sql with the arg list
.td_regexp_options <- function(position, occurrence, match, return_opt = NULL){

  res <- build_sql(', ', position)
  res <- build_sql(res, ', ', occurrence)

  if (!is.null(return_opt))
    res <- build_sql(res, ', ', return_opt)

  res <- build_sql(res, ', ', match)

  res
}

# build a case when
sql_if <- function(cond, if_true, if_false = NULL) {
  build_sql(
    "CASE WHEN (", cond, ")", " THEN (", if_true, ")",
    if (!is.null(if_false))
      build_sql(" WHEN NOT(", cond, ") THEN (", if_false, ")"),
    " END"
  )
}

.build_sql_using_distinct_for_multiple_operations <- function(value.expression, use.distinct, operation) {
  if (use.distinct) {
    build_sql(sql(operation), "(", sql("DISTINCT"), " ", sql(value.expression), ")")
  } else {
    build_sql(sql(operation), "(", sql(value.expression), ")")
  }
}

win_distinct_not_supported <- function(f) {

  function(...) {
    .ta.stop(
      paste0('The DISTINCT clause is not permitted in window aggregate function ', f)
    )
  }
}


win_time_series_not_supported <- function(err_code, msg) {
  function(...) {
    .ta.stop(err_code, msg)
  }
}

win_aggregate_not_supported <- function(operation, msg) {
  function(...) {
    .ta.stop("TDR_E3301", operation, msg)
  }
}

# Helper function to build sql expression for bottom and top time series 
# aggregate functions.
.build.sql.expr.bottom.top <- function(sql_expression, value.expression, 
                                        number.of.values, with.ties) {
  build_sql(sql(sql_expression),
    if (with.ties) {
      build_sql(" WITH TIES")
    },
    build_sql("(", sql(number.of.values), ", ", sql(value.expression), ")")
  )
}

# Helper function to validate required arguments of ts.bottom and ts.top functions.
.validate_arguments_bottom_top <- function(value.expression, number.of.values, with.ties) {
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("value.expression", value.expression, FALSE, c("sql", "character")))
  argInfoMatrix <- rbind(argInfoMatrix, list("number.of.values", number.of.values, FALSE, c("numeric", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("with.ties", with.ties, TRUE, c("logical",NA)))
  
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  .validateArgInfoMatrix(argInfoMatrix)
  
  if (number.of.values %% 1 != 0) {
    # If fractional part exists
    .ta.stop("TDR_E3005", "Argument 'number.of.values' must be of 'integer' datatype.")
  }
}

# Function to validate ts.median arguments.
.validateMedianArgs <- function(value.expression, use.distinct) {
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("value.expression", value.expression, FALSE, c("sql", "character")))
  argInfoMatrix <- rbind(argInfoMatrix, list("use.distinct", use.distinct, TRUE, c("logical",NA)))
  
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  .validateArgInfoMatrix(argInfoMatrix)
}

# Function to validate only value.expression. Can be used for multiple TS aggregations.
.validateValueExpressionOnly <- function(value.expression) {
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("value.expression", value.expression, FALSE, c("sql", "character")))
  
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  .validateArgInfoMatrix(argInfoMatrix)
}

# This function validates the argInfoMatrix used in time series aggregates.
.validateArgInfoMatrix <- function(argInfoMatrix) {
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Check the argument types
  .validateArgumentTypes(argInfoMatrix)
}

# This function validates the arguments of the time series aggregate function 
# ts.mad()
.validateArgumentsForTsMad <- function(value.expression, multiplier) {
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("value.expression", value.expression, FALSE, c("sql", "character")))
  argInfoMatrix <- rbind(argInfoMatrix, list("multiplier", multiplier, TRUE, c("numeric", NA)))
  
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  .validateArgInfoMatrix(argInfoMatrix)
  
  # 'multiplier' doesn't take negative numerals
  if (!is.null(multiplier) && multiplier < 0) {
    .ta.stop("TDR_E3104","argument", "multipler", "non-negative numerals")
  }
}

# This function validates the arguments of the time series aggregate function 
# ts.percentile()
.validateArgumentsForTsPercentile <- function(value.expression, percentile, interpolation.type) {
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("value.expression", value.expression, FALSE, c("sql", "character")))
  argInfoMatrix <- rbind(argInfoMatrix, list("percentile", percentile, FALSE, c("numeric", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("interpolation.type", interpolation.type, TRUE, c("character", NA)))
  
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  .validateArgInfoMatrix(argInfoMatrix)
  
  # 'percentile' ranges from 0 - 100 (both inclusive)
  if (!.validate_integer_bounds(percentile, lbound = 0, ubound = 100)) { 
    .ta.stop("TDR_E3104","argument", "percentile", "0 - 100 (both inclusive)")
  }
  
  # Check for permitted values
  interpolation.typePermittedValues <- list("LINEAR", "LOW", "HIGH", "NEAREST", "MIDPOINT")
  .validatePermittedValues(interpolation.type, interpolation.typePermittedValues)
}