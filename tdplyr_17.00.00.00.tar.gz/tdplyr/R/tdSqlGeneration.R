# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: Jeris Alan Jawahar (jeris.jawahar@teradata.com)
# Secondary Owner:
#
# Internal functions to build sqls. 
#
###################################################################################

# This function builds create table query from R dataframe.
# Parameters:
#    data          : the R data frame
#    table.name    : name of table in database where data frame will be saved
#    table.type    : PI or NOPI
#    primary.index : Primary index for PI table
#    row.names     : TRUE - If user wants to insert row names in table
#    types         : Data types for the columns in data frame
#    temporary     : TRUE to create temporary(volatile) table
#    pti_clause    : Have PTI clause
#                    Eg - "TIMESTAMP(6), DATE '2012-01-01', HOURS(1), COLUMNS(buoyid), sequenced"
#    pti_type      : PTI Type - either SEQ or NON_SEQ; used only when pti_clause is not NULL
#    pti_name      : Name of the Primary Time Index.
#
# Returns:      
#    value         : Created table Query
#
#' @importFrom DBI dbQuoteIdentifier
.ta.constructCreateTableSQL <- function(con, data, table.name=NULL,
                                        table.type="nopi", primary.index = NULL, row.names=FALSE,
                                        types = NULL, temporary = FALSE, pti_clause = NULL, 
                                        pti_type = NULL, pti_name = NULL) {
  colNames <- names(data)
  
  num_cols_removed <- 0
  
  # Only when PTI clause is given.
  # Currently being used in LoadExampleData.
  if (!is.null(pti_clause)) {
    # If table is sequenced, it contains TD_TIMECODE and TD_SEQ columns as first 2 columns.
    # If table is nonsequenced, it contains TD_TIMECODE column as first column.
    # These shouldn't be given while table creation.
    if (pti_type == "SEQ") {
      colNames <- colNames[-c(1,2)]
      num_cols_removed <- 2
    } else if (pti_type == "NON_SEQ") {
      colNames <- colNames[-1]
      num_cols_removed <- 1
    }
  }
  
  # Check colTypes
  if (!is.null(types)) {
    if (class(types) != "list" && class(types) != "character") {
      .ta.stop("Unknown format of types")
    } else {
      # Follow colClasses in read.table() to replicate the types
      nmDataTypes <- names(types)
      
      # If types is not a named character vector, then replicate it to length of colNames
      if (is.null(nmDataTypes)) {
        types <- rep_len(types, length(colNames))
      } else {
        tmp <- rep_len(NA_character_, length(colNames))
        names(tmp) <- colNames
        i <- match(nmDataTypes, colNames, 0L)
        tmp[i[i > 0L]] <- types
        types <- tmp
      }
    }
  }
  
  #TODO: double check mapping for complex
  col_names_types <- .get_col_names_and_types(con, data, colNames, row.names, types, 
                                              num_cols_removed)
  colNameStr <- col_names_types[["names"]]
  colTypeStr <- col_names_types[["types"]]

  if (temporary)
    sql <- "CREATE MULTISET VOLATILE TABLE"
  else
    sql <- "CREATE MULTISET TABLE"
  
  sql <- gettextf("%s %s (%s)",sql, dbQuoteIdentifier(con, table.name),
                  paste0("\"", colNameStr, "\" ", colTypeStr, collapse = ", "))
  
  if (!is.null(pti_clause)) {
    # Append PTI clause after column names and types.
    sql <- gettextf("%s PRIMARY TIME INDEX", sql)
    if (!is.null(pti_name)) {
      sql <- gettextf("%s %s", sql, pti_name)
    }
    sql <- gettextf("%s (%s)", sql, pti_clause)
  } else if (tolower(table.type) == "pi" && !is.null(primary.index)) {
    # if table.type is PI add parimary index to create table syntax
    sql <- gettextf("%s PRIMARY INDEX (%s)", sql, paste0("\"", primary.index, "\"", collapse = ","))
  } else if (tolower(table.type) == "nopi") {
    sql <- gettextf("%s NO PRIMARY INDEX", sql)
  }
  if (temporary)
    sql <- gettextf("%s ON COMMIT PRESERVE ROWS", sql)
  
  return(sql)
}

# This function get the column names and types based on the argument 'row.names', column names and 
# types of the dataframe. 
# Parameters:
#    con           : The remote data source.
#    data          : The dataframe.
#    colNames      : The modified column names of the dataframe.
#    row.names     : TRUE - If user wants to insert row names in table.
#    types         : Data types for the columns in data frame.
#    temporary     : TRUE to create temporary(volatile) table
#    num_cols_removed : Has the number which tells how many columns are removed from the actual 
#                       columns of the dataframe. 
#                       It is
#                       - 0 when table to be create is regular table.
#                       - 1 when table to be create is non-sequenced PTI table.
#                       - 2 when table to be create is equenced PTI table.
#
# Returns:      
#    The list of column names and types.
.get_col_names_and_types <- function(con, data, colNames, row.names, types, num_cols_removed = 0){
  colNameStr <- c()
  colTypeStr <- c()
  
  if ( !is.null(row.names) && row.names ) {
    colNameStr <- c(colNameStr, "row_names")
    colTypeStr <- c(colTypeStr, .getSQLDataType(con, row.names(data)[[1]]))
  }

  for (i in 1:length(colNames)) {
    if (is.null(types) || i > length(types) || is.na(types[[i]])) {
      colType <- .getSQLDataType(con, data[[i + num_cols_removed]])
    }
    else {
      colType <- types[[i]]
    }
    colNameStr <- c(colNameStr, colNames[[i]])
    colTypeStr <- c(colTypeStr, colType)
  }

  return(list("names" = colNameStr, "types" = colTypeStr))
}