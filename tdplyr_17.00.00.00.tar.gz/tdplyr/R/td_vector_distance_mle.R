# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Adithya Avvaru (adithya.avvaru@teradata.com)
# 
# Version: 1.2
# Function Version: 1.3
# 
# ################################################################## 

# Description:
#   The VectorDistance function takes a tbl_teradata of target vectors 
#   and a tbl_teradata of reference vectors and returns a tbl_teradata 
#   that contains the distance between each target-reference pair.
# 
# Args:
#   target.data -
#     Required Argument.\cr
#     A tbl_teradata that specifies target vectors\cr
#   
#   target.data.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "target.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   target.data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "target.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   ref.data -
#     Required Argument.\cr
#     A tbl_teradata that specifies reference vectors\cr
#   
#   ref.data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "ref.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   target.id -
#     Required Argument.\cr
#     Specifies the names of the columns that comprise the target vector 
#     identifier. You must partition the target input tbl_teradata by these 
#     columns and specify them with this argument.\cr
#     Types: character OR vector of Strings (character)
#   
#   target.feature -
#     Required Argument.\cr
#     Specifies the name of the column that contains the target vector 
#     feature name (for example, the axis of a 3-D vector). Note: An entry 
#     with a NULL value in a feature_column is dropped.\cr
#     Types: character
#   
#   target.value -
#     Optional Argument.\cr
#     Specifies the name of the column that contains the value for the 
#     target vector feature. The default value is 1. Note: An entry with a 
#     NULL value in a value_column is dropped.\cr
#     Types: character
#   
#   ref.id -
#     Optional Argument.\cr
#     Specifies the names of the columns that comprise the reference vector 
#     identifier. The default value is the target.id argument value. \cr
#     Types: character OR vector of Strings (character)
#   
#   ref.feature -
#     Optional Argument.\cr
#     Specifies the name of the column that contains the reference vector 
#     feature name. The default value is the target.feature argument 
#     value.\cr
#     Types: character
#   
#   ref.value -
#     Optional Argument.\cr
#     Specifies the name of the column that contains the value for the 
#     reference vector feature. The default value is the TargetValueColumn 
#     argument value. Note: An entry with a NULL value in a value_column is 
#     dropped.\cr
#     Types: character
#   
#   reftable.size -
#     Optional Argument.\cr
#     Specifies the size of the reference table. Specify "LARGE" only if 
#     the reference tbl_teradata does not fit in memory. The default value, 
#     "SMALL", allows faster processing.\cr
#     Default Value: "small"\cr
#     Permitted Values: small, large\cr
#     Types: character
#   
#   distance.measure -
#     Optional Argument.\cr
#     Specifies the distance measures that the function uses.\cr
#     Default Value: "["cosine"]"\cr
#     Permitted Values: COSINE, EUCLIDEAN, MANHATTAN, BINARY\cr
#     Types: character OR vector of characters
#   
#   ignore.mismatch -
#     Optional Argument.\cr
#     Specifies whether to drop mismatched dimensions. If distance.measure 
#     is "cosine", then this argument is "false". If you specify "true", 
#     then two vectors with no common features become two empty vectors 
#     when only their common features are considered, and the function 
#     cannot measure the distance between them.\cr
#     Default Value: TRUE\cr
#     Types: logical
#   
#   replace.invalid -
#     Optional Argument.\cr
#     Specifies the value to return when the function encounters an 
#     infinite value or empty vectors. For custom, you can supply any 
#     numeric value. \cr
#     Default Value: "positiveinfinity"\cr
#     Types: character
#   
#   top.k -
#     Optional Argument.\cr
#     Specifies, for each target vector and for each measure, the maximum 
#     number of closest reference vectors to include in the output table. 
#     For k, you can supply any integer value. The default value is the 
#     maximum integer value (2,147,483,647).\cr
#     Default Value: 2147483647\cr
#     Types: integer
#   
#   max.distance -
#     Optional Argument.\cr
#     Specifies the maximum distance between a pair of target and reference 
#     vectors. If the distance exceeds the threshold, the pair does not 
#     appear in the output table. If the distance.measure argument 
#     specifies multiple measures, then the max.distance argument must 
#     specify a threshold for each measure. The ith threshold corresponds 
#     to the ith measure. Each threshold can be any numeric value. If you 
#     omit this argument, then the function returns all results.\cr
#     Types: numeric OR vector of numerics
#   
#   target.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "target.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   ref.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "ref.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_vector_distance_mle" which is 
#   a named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_vector_distance_mle <- function(
  target.data = NULL,
  ref.data = NULL,
  target.id = NULL,
  target.feature = NULL,
  target.value = NULL,
  ref.id = NULL,
  ref.feature = NULL,
  ref.value = NULL,
  reftable.size = "small",
  distance.measure = "cosine",
  ignore.mismatch = TRUE,
  replace.invalid = "positiveinfinity",
  top.k = 2147483647,
  max.distance = NULL,
  target.data.sequence.column = NULL,
  ref.data.sequence.column = NULL,
  target.data.partition.column = NULL,
  target.data.order.column = NULL,
  ref.data.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("target.data", target.data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("target.data.partition.column", target.data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("target.data.order.column", target.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("ref.data", ref.data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("ref.data.order.column", ref.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("target.id", target.id, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("target.feature", target.feature, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("target.value", target.value, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("ref.id", ref.id, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("ref.feature", ref.feature, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("ref.value", ref.value, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("reftable.size", reftable.size, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("distance.measure", distance.measure, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("ignore.mismatch", ignore.mismatch, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("replace.invalid", replace.invalid, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("top.k", top.k, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("max.distance", max.distance, TRUE, c("numeric","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("target.data.sequence.column", target.data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("ref.data.sequence.column", ref.data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(target.data, NULL)
  .validateInputTableDataType(ref.data, NULL)
  
  # Check for permitted values
  reftable.sizePermittedValues <- list("SMALL", "LARGE")
  .validatePermittedValues(reftable.size, reftable.sizePermittedValues)
  
  distance.measurePermittedValues <- list("COSINE", "EUCLIDEAN", "MANHATTAN", "BINARY")
  .validatePermittedValues(distance.measure, distance.measurePermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(target.id)
  .validateTblHasArgumentColumns(target.id, "target.id", target.data, "target.data")
  
  .validateInputColumnsNotEmpty(target.feature)
  .validateTblHasArgumentColumns(target.feature, "target.feature", target.data, "target.data")
  
  .validateInputColumnsNotEmpty(target.value)
  .validateTblHasArgumentColumns(target.value, "target.value", target.data, "target.data")
  
  .validateInputColumnsNotEmpty(ref.id)
  .validateTblHasArgumentColumns(ref.id, "ref.id", ref.data, "ref.data")
  
  .validateInputColumnsNotEmpty(ref.feature)
  .validateTblHasArgumentColumns(ref.feature, "ref.feature", ref.data, "ref.data")
  
  .validateInputColumnsNotEmpty(ref.value)
  .validateTblHasArgumentColumns(ref.value, "ref.value", ref.data, "ref.data")
  
  .validateInputColumnsNotEmpty(target.data.sequence.column)
  .validateTblHasArgumentColumns(target.data.sequence.column, "target.data.sequence.column", target.data, "target.data")
  
  .validateInputColumnsNotEmpty(ref.data.sequence.column)
  .validateTblHasArgumentColumns(ref.data.sequence.column, "ref.data.sequence.column", ref.data, "ref.data")
  
  .validateInputColumnsNotEmpty(target.data.partition.column)
  .validateTblHasArgumentColumns(target.data.partition.column, "target.data.partition.column", target.data, "target.data")
  
  .validateInputColumnsNotEmpty(target.data.order.column)
  .validateTblHasArgumentColumns(target.data.order.column, "target.data.order.column", target.data, "target.data")
  
  .validateInputColumnsNotEmpty(ref.data.order.column)
  .validateTblHasArgumentColumns(ref.data.order.column, "ref.data.order.column", ref.data, "ref.data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetIdColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(target.id,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetFeatureColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(target.feature,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(target.value)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetValueColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(target.value,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(ref.id)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "RefIdColumns")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(ref.id,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(ref.feature)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "RefFeatureColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(ref.feature,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(ref.value)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "RefValueColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(ref.value,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(replace.invalid) && !missing(replace.invalid)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ReplaceInvalid")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(replace.invalid, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(reftable.size) && !missing(reftable.size)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "RefTableSize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(reftable.size, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(distance.measure) && !missing(distance.measure)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "DistanceMeasure")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(distance.measure, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(max.distance)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxDistance")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(max.distance, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(ignore.mismatch) && !missing(ignore.mismatch)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IgnoreMismatch")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(ignore.mismatch, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(top.k) && !missing(top.k)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TopK")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(top.k, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(target.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("target:", .teradataCollapseArgVector(target.data.sequence.column, "")))
  }
  
  if (!is.null(ref.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("ref:", .teradataCollapseArgVector(ref.data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process target.data
  target.data.partition.column <- .teradataCollapseArgVector(target.data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(target.data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "target")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, target.data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(target.data.order.column, "\""))
  
  # Process ref.data
  tableRef <- .teradataOnClauseFromDataFrame(ref.data)
  funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "ref")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(ref.data.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "VectorDistance",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("VectorDistance", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(target.data, ref.data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_vector_distance_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_vector_distance <- td_vector_distance_mle
