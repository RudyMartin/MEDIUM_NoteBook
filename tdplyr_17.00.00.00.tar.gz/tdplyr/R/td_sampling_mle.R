# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Jeris Alan Jawahar (jeris.jawahar@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.5
# 
# ################################################################## 

# Description:
#   The Sample function draws rows randomly from the input table.
# 
# Args:
#   data -
#     Required Argument.\cr
#     The tbl_teradata containing the data to be sampled.\cr
#   
#   data.partition.column -
#     Optional Argument\cr
#     Specifies Partition By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Default Value: ANY\cr
#     Types: character OR vector of Strings (character)
#   
#   data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   summary.data -
#     Optional Argument.\cr
#     The summary input contains the stratum count information.\cr
#   
#   summary.data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "summary.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   stratum.column -
#     Optional Argument.\cr
#     Specifies the name of the column that contains the sample conditions. 
#     If the function has only one input tbl_teradata (the data table), 
#     then condition_column is in the data table. If the function has two 
#     input tables, data and summary, then condition_column is in the 
#     summary table.\cr
#     Types: character
#   
#   strata -
#     Optional Argument.\cr
#     Specifies the sample conditions that appear in the condition_column 
#     specified by stratum.column. If strata specifies a condition that 
#     does not appear in condition_column, then the function issues an 
#     error message.\cr
#     Types: character OR vector of characters
#   
#   sample.fraction -
#     Optional Argument.\cr
#     Specifies one or more fractions to use in sampling the data. (Syntax 
#     options that do not use sample.fraction require approx.sample.size.) 
#     If you specify only one fraction, then the function uses fraction for 
#     all strata defined by the sample conditions. If you specify more than 
#     one fraction, then the function uses each fraction for sampling a 
#     particular stratum defined by the condition arguments. Note: For 
#     conditional sampling with variable sample sizes, specify one fraction 
#     for each condition that you specify with the strata argument.\cr
#     Types: numeric OR vector of numerics
#   
#   approx.sample.size -
#     Optional Argument.\cr
#     Specifies one or more approximate sample sizes to use in sampling the 
#     data. (Syntax options that do not use approx.sample.size require 
#     sample.fraction.) Each sample size is approximate because the 
#     function maps the size to the sample fractions and then generates the 
#     sample data. If you specify only one size, then it represents the 
#     total sample size for the entire population. If you also specify the 
#     strata argument, then the function proportionally generates sample 
#     units for each stratum. If you specify more than one size, then each 
#     size corresponds to a stratum, and the function uses each size to 
#     generate sample units for the corresponding stratum. Note: For 
#     conditional sampling with variable approximate sample sizes, specify 
#     one size for each condition that you specify with the strata 
#     argument.\cr
#     Types: integer OR vector of integers
#   
#   seed -
#     Optional Argument.\cr
#     Specifies an integer to add to each task ID to create a real random 
#     seed for the task. The default value is 0.\cr
#     Default Value: 0\cr
#     Types: numeric
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   summary.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "summary.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_sampling_mle" which is a 
#   named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_sampling_mle <- function(
  data = NULL,
  data.partition.column = "ANY",
  data.order.column = NULL,
  summary.data = NULL,
  summary.data.order.column = NULL,
  stratum.column = NULL,
  strata = NULL,
  sample.fraction = NULL,
  approx.sample.size = NULL,
  seed = 0,
  data.sequence.column = NULL,
  summary.data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.partition.column", data.partition.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("summary.data", summary.data, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("summary.data.order.column", summary.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("stratum.column", stratum.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("strata", strata, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("sample.fraction", sample.fraction, TRUE, c("numeric","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("approx.sample.size", approx.sample.size, TRUE, c("integer","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("seed", seed, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("summary.data.sequence.column", summary.data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that either sample.fraction or approx.sample.size is provided
  if((is.null(sample.fraction) && is.null(approx.sample.size)) || (!is.null(sample.fraction) && !is.null(approx.sample.size))){
    .ta.stop("TDR_E3009", "sample.fraction", "approx.sample.size")
  }
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  .validateInputTableDataType(summary.data, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(stratum.column)
  .validateTblHasArgumentColumns(stratum.column, "stratum.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(summary.data.sequence.column)
  .validateTblHasArgumentColumns(summary.data.sequence.column, "summary.data.sequence.column", summary.data, "summary.data")
  
  .validateInputColumnsNotEmpty(data.partition.column)
  if (.isDefaultOrNot(data.partition.column, "ANY")) {
    .validateTblHasArgumentColumns(data.partition.column, "data.partition.column", data, "data")
  }
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  .validateInputColumnsNotEmpty(summary.data.order.column)
  .validateTblHasArgumentColumns(summary.data.order.column, "summary.data.order.column", summary.data, "summary.data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  if (!is.null(stratum.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StratumColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(stratum.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(sample.fraction)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SampleFraction")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(sample.fraction, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(approx.sample.size)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ApproxSampleSize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(approx.sample.size, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(strata)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Strata")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(strata, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(seed) && !missing(seed)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Seed")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(seed, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "LONG")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (!is.null(summary.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("summary:", .teradataCollapseArgVector(summary.data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  if (.isDefaultOrNot(data.partition.column, "ANY")) {
    data.partition.column <- .teradataCollapseArgVector(data.partition.column, "\"")
  }
  
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # Process summary.data
  if (!is.null(summary.data)) {
    tableRef <- .teradataOnClauseFromDataFrame(summary.data)
    funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "summary")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(summary.data.order.column, "\""))
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "Sampling",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("Sampling", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data, summary.data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_sampling_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_sampling <- td_sampling_mle
