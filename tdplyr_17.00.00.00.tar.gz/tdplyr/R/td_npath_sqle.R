# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.1
# 
# ################################################################## 

# Description:
#   The nPath function scans a set of rows, looking for patterns that you 
#   specify. For each set of input rows that matches the pattern, nPath 
#   produces a single output row. The function provides a flexible 
#   pattern-matching capability that lets you specify complex patterns in 
#   the input data and define the values that are output for each matched 
#   input set.
# 
# Args:
#   data1 -
#     Required Argument.\cr
#     Input table\cr
#   
#   data1.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "data1".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   data1.order.column -
#     Required Argument.\cr
#     Specifies Order By columns for "data1".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   mode -
#     Required Argument.\cr
#     Specifies the pattern-matching mode: 
#      OVERLAPPING: The function finds every occurrence of the pattern in 
#     the partition, regardless of  whether it is part of a previously 
#     found match. Therefore, one row can match multiple symbols in a  
#     given matched pattern. 
#      NONOVERLAPPING: The function begins the next pattern search at the 
#     row that follows the last  pattern match. This is the default 
#     behavior of many commonly used pattern matching utilities, including 
#     the UNIX grep utility.\cr
#     Permitted Values: OVERLAPPING, NONOVERLAPPING\cr
#     Types: character
#   
#   pattern -
#     Required Argument.\cr
#     Specifies the pattern for which the function searches. You compose 
#     pattern with the symbols that you define in the symbols argument, 
#     operators, and parentheses. tbl_teradata describes the simplest 
#     patterns, which you can combine to form more complex patterns. When 
#     patterns have multiple operators, the function applies them in order 
#     of precedence, and applies operators of equal precedence from left to 
#     right. tbl_teradata also shows operator precedence. To force the 
#     function to evaluate a subpattern first, enclose it in parentheses. 
#     To specify that a subpattern must appear a specific number of times, 
#     use the "Range-Matching Feature".
#     For pattern matching details, refer to "Pattern Matching".\cr
#     Types: character
#   
#   symbols -
#     Required Argument.\cr
#     Defines the symbols that appear in the values of the pattern and 
#     result arguments. The col_expr is an expression whose value is a 
#     column name, symbol is any valid identifier, and  symbol_predicate is 
#     a SQL predicate (often a column name).
#      For example, the Symbols argument for analyzing website visits might 
#     look like this: 
#     symbols 
#     (
#      pagetype = "homepage" AS H, 
#     pagetype <> "homepage" AND  pagetype <> "checkout" AS PP,
#      pagetype = "checkout" AS CO 
#     )
#      The symbol is case-insensitive; however, a symbol of one or two 
#     uppercase letters is easy to identify in patterns. 
#     If col_expr represents a column that appears in multiple input 
#     tables, then you must qualify the ambiguous column name with its 
#     tbl_teradata name. For example: 
#      Symbols 
#      ( 
#      weblog.pagetype = "homepage" AS H, 
#      weblog.pagetype = "thankyou" AS T, 
#      ads.adname = "xmaspromo" AS X, 
#      ads.adname = "realtorpromo" AS R 
#     ) 
#     For more information about symbols that appear in the Pattern 
#     argument value, refer to "symbols". For more information about 
#     symbols that appear in the Result argument value, refer to "result: 
#     Applying Aggregate Functions".\cr
#     Types: character OR vector of characters
#   
#   result -
#     Required Argument.\cr
#     Defines the output columns. The col_expr is an expression whose value 
#     is a column name; it specifies the values to retrieve from the 
#     matched rows. The function applies aggregate_function  to these 
#     values. For details, see "result: Applying Aggregate Functions". 
#     The function evaluates this argument once for every matched pattern 
#     in the partition (that is, it outputs one row for each pattern 
#     match).\cr
#     Types: character OR vector of characters
#   
#   filter -
#     Optional Argument.\cr
#     Specifies filters to impose on the matched rows. The function 
#     combines the filter expressions using the AND operator. 
#     The filter_expression syntax is: 
#     symbol_expression  comparison_operator symbol_expression 
#     The two symbol expressions must be type-compatible. The 
#     symbol_expression syntax is: 
#     { FIRST | LAST }(column_with_expression OF [ANY](symbol[,...])) 
#     The column_with_expression cannot contain the operator AND or OR, and 
#     all its columns must come from the same input. If the function has 
#     multiple inputs, then column_with_expression and symbol must come 
#     from the same input. 
#     The comparison_operator is either <, >, <=, >=, =, or <>.\cr
#     Types: character OR vector of characters
#   
#   data2 -
#     Optional Argument.\cr
#     Additional optional input table\cr
#   
#   data2.partition.column -
#     Optional Argument\cr
#     Specifies Partition By columns for "data2".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   data2.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "data2".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   data3 -
#     Optional Argument.\cr
#     Additional optional input table\cr
#   
#   data3.partition.column -
#     Optional Argument\cr
#     Specifies Partition By columns for "data3".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   data3.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "data3".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   

# 
# Returns:
#   Function returns an object of class "td_npath_sqle" which is a named 
#   list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_npath_sqle <- function(
  data1 = NULL,
  mode = NULL,
  pattern = NULL,
  symbols = NULL,
  result = NULL,
  filter = NULL,
  data2 = NULL,
  data3 = NULL,
  data1.partition.column = NULL,
  data2.partition.column = NULL,
  data3.partition.column = NULL,
  data1.order.column = NULL,
  data2.order.column = NULL,
  data3.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data1", data1, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data1.partition.column", data1.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data1.order.column", data1.order.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("mode", mode, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("pattern", pattern, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("symbols", symbols, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("result", result, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("filter", filter, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data2", data2, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data2.partition.column", data2.partition.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data2.order.column", data2.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data3", data3, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data3.partition.column", data3.partition.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data3.order.column", data3.order.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data1, NULL)
  .validateInputTableDataType(data2, NULL)
  .validateInputTableDataType(data3, NULL)
  
  # Check for permitted values
  modePermittedValues <- list("OVERLAPPING", "NONOVERLAPPING")
  .validatePermittedValues(mode, modePermittedValues)
  
  .validateInputColumnsNotEmpty(data1.partition.column)
  .validateTblHasArgumentColumns(data1.partition.column, "data1.partition.column", data1, "data1")
  
  .validateInputColumnsNotEmpty(data2.partition.column)
  .validateTblHasArgumentColumns(data2.partition.column, "data2.partition.column", data2, "data2")
  
  .validateInputColumnsNotEmpty(data3.partition.column)
  .validateTblHasArgumentColumns(data3.partition.column, "data3.partition.column", data3, "data3")
  
  .validateInputColumnsNotEmpty(data1.order.column)
  .validateTblHasArgumentColumns(data1.order.column, "data1.order.column", data1, "data1")
  
  .validateInputColumnsNotEmpty(data2.order.column)
  .validateTblHasArgumentColumns(data2.order.column, "data2.order.column", data2, "data2")
  
  .validateInputColumnsNotEmpty(data3.order.column)
  .validateTblHasArgumentColumns(data3.order.column, "data3.order.column", data3, "data3")
  
  # Validate that value passed to the output column argument is not empty.
  .validateInputColumnsNotEmpty(result)
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Mode")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(mode, ""))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Pattern")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(pattern, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Symbols")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(symbols, ""))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  if (!is.null(filter)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Filter")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(filter, ""))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Result")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(result, ""))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data1
  data1.partition.column <- .teradataCollapseArgVector(data1.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(data1)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input1")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, data1.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data1.order.column, "\""))
  
  # Process data2
  if (!is.null(data2)) {
    data2.distribution <- "DIMENSION"
    if (!is.null(data2.partition.column)) {
      data2.distribution <- "FACT"
      data2.partition.column <- .teradataCollapseArgVector(data2.partition.column, "\"")
    } else {
      data2.partition.column <- "NA_character_"
    }
    tableRef <- .teradataOnClauseFromDataFrame(data2)
    funcInputDistribution <- c(funcInputDistribution, data2.distribution)
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "input2")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, data2.partition.column)
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data2.order.column, "\""))
  }
  
  # Process data3
  if (!is.null(data3)) {
    data3.distribution <- "DIMENSION"
    if (!is.null(data3.partition.column)) {
      data3.distribution <- "FACT"
      data3.partition.column <- .teradataCollapseArgVector(data3.partition.column, "\"")
    } else {
      data3.partition.column <- "NA_character_"
    }
    tableRef <- .teradataOnClauseFromDataFrame(data3)
    funcInputDistribution <- c(funcInputDistribution, data3.distribution)
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "input3")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, data3.partition.column)
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data3.order.column, "\""))
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "nPath",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_SQL")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("nPath", engine = .getEngineName("ENGINE_SQL"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data1, data2, data3)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_npath_sqle", engine = .getEngineName("ENGINE_SQL"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_npath <- td_npath_sqle
