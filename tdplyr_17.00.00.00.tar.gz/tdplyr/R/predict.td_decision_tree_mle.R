# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' @export
predict.td_decision_tree_mle <- function(object = NULL,
                                     newdata = NULL,
                                     attr.table.groupby.columns = NULL,
                                     attr.table.pid.columns = NULL,
                                     attr.table.val.column = NULL,
                                     accumulate = NULL,
                                     output.response.probdist = FALSE,
                                     output.responses = NULL,
                                     newdata.partition.column = NULL,
                                     newdata.order.column = NULL,
                                     object.order.column = NULL) {
  td_decision_tree_predict_sqle(object = object,
                           newdata = newdata,
                           attr.table.groupby.columns = attr.table.groupby.columns,
                           attr.table.pid.columns = attr.table.pid.columns,
                           attr.table.val.column = attr.table.val.column,
                           accumulate = accumulate,
                           output.response.probdist = output.response.probdist,
                           output.responses = output.responses,
                           newdata.partition.column = newdata.partition.column,
                           newdata.order.column = newdata.order.column,
                           object.order.column = object.order.column)
}
