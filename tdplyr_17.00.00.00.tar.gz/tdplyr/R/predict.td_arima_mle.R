# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' @export
predict.td_arima_mle <- function( object = NULL,
                              residual.table = NULL,
                              n.ahead = 1,
                              partition.columns = NULL,
                              object.sequence.column = NULL,
                              residual.table.sequence.column = NULL,
                              object.partition.column = NULL,
                              residual.table.partition.column = NULL,
                              object.order.column = NULL,
                              residual.table.order.column = NULL) {
  td_arima_predict_mle( object = object,
                    residual.table = residual.table,
                    n.ahead = n.ahead,
                    partition.columns = partition.columns,
                    object.sequence.column = object.sequence.column,
                    residual.table.sequence.column = residual.table.sequence.column,
                    object.partition.column = object.partition.column,
                    residual.table.partition.column = residual.table.partition.column,
                    object.order.column = object.order.column,
                    residual.table.order.column = residual.table.order.column)
}
