# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

############################################################
# Common Internal functions for connectivity        #######
#
############################################################

# Internal function to validate a connection is active and working
# Arguments:
#  con: A teradata connection object
#  silent: Stop if invalid connection and silent is False
#  return:
#     True if connection is supported and valid
#' @importFrom DBI dbIsValid
#' @importFrom DBI dbGetQuery
.ta.isConnectionValid <- function(con, silent = TRUE) {

  # dbIsValid returns true even if it is active, so better try to run a query and see
  # Added tryCatch for native driver, default this to TRUE for now
  status <- tryCatch(dbIsValid(con), error = function(e){TRUE})
  # There seems to be an issue in odbc::dbIsValid that it returns true even if it is invalid
  # So try if a dbGetQuery succeeds
  if (status)
    status <- tryCatch({
          ifelse(nrow(dbGetQuery(con, "select user")) == 1L,
            TRUE,
            FALSE)},
          error = function(e){FALSE})

  if (!silent && !status) {
    # Error is Invalid connection object or inactive connection
    .ta.stop("TDR_E10051")
  }
  status
}

# Verify if the connection is valid and has the right subclass
# params:
#   con: connection object to be verified
.ta.verifyConnection <- function(con) {
  # The connection must have the Teradata sub class to be valid
  if (!inherits(con, "Teradata"))
    .ta.stop("TDR_E1102")

  .ta.isConnectionValid(con, silent = FALSE)
  # Add warning if detected the server is earlier than lowest version
  .ta.connection.DBMSVersion.checkServer(con = con,
                                         silent = FALSE)
}

# Function loads the libiodbc library only for APPLE OSX
# This is required to support DSN with the odbc package on MAC
# Returns TRUE if the library was loaded, FALSE otherwise
.loadIODBC <- function () {
  
  # Since loading this library is risku, only perform this when option is enabled
  if (is.null(getOption("td.load.IODBC")) ||
      identical(getOption("td.load.IODBC"), FALSE))
    return(FALSE)

  # check if we already loaded
  if (!is.null(.get(".is__iodbc__loaded")) &&
    .get(".is__iodbc__loaded") > 0)
    return(FALSE)

  # do not load if platform is windows or linux
  if(.ta.isPlatformWindows() || .ta.isPlatformLinux()) {
    .assign(".is__iodbc__loaded", 1L)
    return(FALSE)
  }

  lib <- getOption("td.lib.IODBC")
  # just warn and return if the option is null or NA or empty
  if (is.null(lib) || is.na(lib) || nchar(lib) == 0L) {
    .ta.warning("TDR_W1004", "NULL / NA / EMPTY", "Invalid value in option - td.lib.IODBC", showFunctionCall = FALSE)
    return(FALSE)
  }
  libpath <- .get("library__path__")
  cRes <- tryCatch({
    # This line throws error if the library load fails.
    library.dynam("tdplyr", "tdplyr", libpath);0L
  }, error = function(e) {
    # DO NOT throw a warning here because user might not have the tdplyr.so in the build intentionally
    # Alternatively, the presence of tdplyr.so on client machine can be checked using the command:
    #  system.file("libs/tdplyr.so", package = "tdplyr")
    # TODO: Add a wrapper function called .ta.debug to log debug messages.
    if (isTRUE(getOption("td.debug.enable")))
      .ta.print("TDR_W1004", "tdplyr.[so/dll]", e[["message"]],
        showFunctionCall = FALSE, showStackTrace = FALSE)
    return(1)
  })
  if (!identical(cRes, 0L)) {
    return(FALSE)
  }
  cRes <- tryCatch({
    retCode <- 0
    lib <- as.vector(lib)# optionally to cast
    # Specify the library name here instead of hardcoding in the C file
    # This gives the flexibility to call this function with a different name
    result <- .C("InitializeIODBC", lib, as.integer(retCode), PACKAGE = "tdplyr")
    as.integer(result[[2]])
  }, error = function(e) {
    # This shows a warning that DSN may not be supported and the reason,
    # And provides how to correctly set option
    .ta.warning("TDR_W1004", lib, e[["message"]],
        showFunctionCall = FALSE)
    return(1L)
  })

  if (identical(cRes, 0L)) {
    .assign(".is__iodbc__loaded", 2L)
    return(TRUE)
  }

  # This means the error block in the tryCatch above was not executed
  # so, show the warning that libiodbc was not found
  # The native code returns negative value if libiodbc not found
  if (!identical(cRes, 1L)) {
    .ta.warning("TDR_W1004", lib, "Cannot find libiodbc", showFunctionCall = FALSE)
  }
  return(FALSE)
}

# .ta.connection.DBMSVersion.checkServer() checks whether the server is supported.
.ta.connection.DBMSVersion.checkServer <- function(con, silent = TRUE) {
  dbVersion <- .get_version(con)
  # extract the first five digits
  dbVersion <- substr(dbVersion, 1,5)
  if (dbVersion < .get("lowestSupportedVersion")) {
    if (!silent)
      .ta.warning("TDR_W1003", dbVersion, showFunctionCall = FALSE)
    return(FALSE)
  }
  return(TRUE)
}


.ta.isIdenticalConnection <- function(con1, con2) {
  # if either of them is null then we return false,
  # so even if both are null we return false because then no point comparing
  if (is.null(con1) || is.null(con2))
    return(FALSE)
  # if they are literally the same objects then just return TRUE
  if (identical(con1, con2))
    return(TRUE)
  if (identical(.get_servername(con1), .get_servername(con2)) &&
      identical(.get_username(con1), .get_username(con2)) &&
      identical(.get_dbname(con1), .get_dbname(con2))) {
    return(TRUE)
  }
  return(FALSE)
}

# Returns all valid logon mechanims supported by tdplyr.
.ta.ValidLogonMechanims <- function() {
  list("TD2", "LDAP", "TDNEGO", "KRB5", "JWT")
}

# Get Vantage Version
#'@importFrom DBI dbGetQuery
.ta.getVantageVersion <- function(con) {
  tryCatch({
    # The table 'pm.versionInfo' doesn't exists for vantage 1.0
    if (! db_has_table(con, in_schema("pm", "versionInfo"))) {
      return("Vantage 1.0")
    } else {
      vantage_version_table <- DBI::dbGetQuery(con, "select InfoData from pm.versionInfo
                                               where InfoKey = 'RELEASE'  (NOT CASESPECIFIC)")
      
      # Get Vantage Version string from the tbl object
      # Sample output of table 'pm.versionInfo'
      #   InfoKey       InfoData            
      #   <chr>         <chr>               
      # 1 BUILD_VERSION 08.10.00.00-e84ce5f7
      # 2 RELEASE       Vantage 1.1 GA 
      
      vantage_version <- as.data.frame(vantage_version_table)[["InfoData"]]
      return(vantage_version)
    }
  },
  error = function(e) {
    # Message to the user that the package is using vantage version from option td.vantage.version.
    vVersion <- getOption("td.vantage.version")
    .ta.print("TDR_P1004", vVersion, vVersion)
    if (vVersion == "vantage1.0")
      return("Vantage 1.0")
    else
      # Default to Vantage 1.1.
      return("Vantage 1.1 GA")
  })
}

# Sets Vantage Version
.ta.setVantageVersion <- function(con) {
  vantageVersion <- .ta.getVantageVersion(con)
  
  if (grepl("Vantage 1.0", vantageVersion)) {
    options(td.vantage.version = "vantage1.0")
  } else if (grepl("Vantage 1.1", vantageVersion)) {
    # TODO: Update if to 'if-else if' in case we support for other vantage version is needed.
    options(td.vantage.version = "vantage1.1")
  }
}


