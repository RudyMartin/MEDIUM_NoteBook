# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

##############################################################################
# Internal Functions for context management
##############################################################################

# Checks whether the name exists as a package variable
# This will throw context not found error if not found
.validateContextVariable <- function(name, silent = FALSE) {
  val <- .get(name)
  if (!silent && is.null(val)) {
    # Using an error code because this is a very generic
    # Context not found error message
    .ta.stop("TDR_E1004", showFunctionCall = FALSE)
  }
  val
}

# Helper function to get the current temp database
.ta.getTempDatabase <- function(silent = FALSE) {
  .validateContextVariable(".temp__database__", silent = silent)
}

# Helper function to get the current default database
.ta.getDefaultDatabase <- function(silent = FALSE) {
  .get_dbname(.taConnection(silent = silent))
}

# Helper function to retrieve the global connection in the current context
.taConnection <- function(silent = FALSE) {
  .validateContextVariable(".ta__connection__", silent = silent)
}

# Sets the supplied database in a global variable.
# If it is null it sets the default database
# Args:
#    temp.database: The name of the temporary database (or database) where 
#       temporary tables will be created.
# Returns:
#   TRUE, if temp.database provided is not null / empty
#   FALSE, if default database is used
.ta.setTempDatabase <- function(con, temp.database) {
  # set the temp database if it is not present
  if (is.null(temp.database) || is.na(temp.database) || nchar(temp.database) == 0) {
    default.database <- .get_dbname(con)
    # Generic user facing message, display on debug
    if (identical(getOption("td.debug.enable"), TRUE))
      .ta.print("TDR_P1001", default.database)
    temp.database <- default.database
  } 
  # commenting this because databaseExists function is case sensitive and problematic
  # else if (!.ta.databaseExists(con, temp.database)) {
  #   default.database <- .get_dbname(con)
  #   # check if the temp.database exists or not -> because user might have had a typo
  #   # just throw a warning in this case and let her know she can use set context to change it.
  #   .ta.warning("TDR_W1007", temp.database, default.database, showFunctionCall = FALSE)
  #   temp.database <- default.database
  # }
  .assign(".temp__database__", toupper(temp.database))
}

# sets the connection object in the package variable
.ta.setConnection <- function(con) {
  # The connection always represents the context
  # So make sure we set this last of all context parameters
  .assign(".ta__connection__", con)
}

# Creates and initializes the context
# If context already exists it will be overwritten
# This will invoke garbage collection with the new context, but only if the
# previous context does not exist or it exists but is invalid
# Arguments:
#   con : A connection object of class Teradata
#   temp.database: The temporary database to be initialized during the context
#   is.skip.gc: if TRUE then the no gc is performed, useful when two con objects are same
# Return: None
.ta.initializeContext <- function(con, temp.database, is.skip.gc = FALSE) {

  isPrevContextValid <- .ta.contextExists() &&
   .ta.isConnectionValid(.taConnection(), silent= TRUE)

  # We remove context and do GC only if prev context valid
  # depending on whether it was created with set or create context as discussed below
  # user calls - set context followed by set context: No discon perform only GC only if con differs
  # create context followed by set context: discon con and do GC only if conn is diff
  # create context followed by create context: discon con and do GC
  # set context followed by create context: No discon con but GC is done
  # Key thing is we never disconnect in set context work flow but do GC
  if (isPrevContextValid && !is.skip.gc) {
    # Warn that connection already exists so temp objects will be cleaned
    .ta.warning("TDR_W1002",
                showFunctionCall = FALSE)
  
    .ta.removeContext()
  }

  # Start new session
  .ta.initSessionMetadata()

  .ta.setTempDatabase(con, temp.database)

  .ta.setConnection(con)

  # Do garbage collection with new connection again but force persist
  # only if no prev context because we dont want to persist file if nothing changes
  # Always do garbage collection with new connection just as a precaution
  # NOTE: whether this was called from set context or create context, we do GC
  if (!is.skip.gc)
    .ta.gcTempObjects(forcePersist = !isPrevContextValid, con = con)
}

# Internal function to removes the global context,
# Do garbage collection and dbDisconnect
# Param: is.disconnect: should we also disconnect the connection
#' @importFrom DBI dbDisconnect
#' @importFrom DBI dbIsValid
.ta.removeContext <- function (is.disconnect = TRUE) {
  con <- .taConnection(silent = TRUE)
  if (is.null(con))
    return(NULL)

  # First do garbage collection silently
  tryCatch({
    if (.ta.isConnectionValid(con, silent = TRUE))
      .ta.gcTempObjects(forcePersist = TRUE, con = con)
  }, error = function(emsg) {
      if (getOption("td.debug.enable")) {
        # The error can occur only if the user has no permissions to write the file
        # ALl DB errors are already handled in .ta.gcTempObjects
        .ta.print(emsg[["message"]], showFunctionCall = TRUE, showStackTrace = FALSE)
      }
  })
  if (is.disconnect) {
    host <- DBI::dbGetInfo(con)$host
    
    tryCatch({dbDisconnect(con)},
      error = function(emsg) {
        .ta.warning(emsg[["message"]], showStackTrace = FALSE)
    })
    # When connection is closed, R package should tell RStudio to update the pane
    .onConnectionClosed(host)
  }

  .rm(".ta__connection__")
  .rm(".temp__database__")
}

# Returns TRUE if the global context exists
.ta.contextExists <- function() {
  !is.null(.taConnection(silent = TRUE))
}

# Function checks if RStudio has connections Panel and updates it.
.onConnectionClosed <- function(host) {
  # Make sure we have an observer
  observer <- getOption("connectionObserver")
  if (!is.null(observer)){
    type <- "Teradata"
    observer$connectionClosed(type, host)
  }
}
