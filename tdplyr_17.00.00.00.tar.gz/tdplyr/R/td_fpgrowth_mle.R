# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Arun Kalyanasundaram (arun.kalyanasundaram@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.13
# 
# ################################################################## 

# Description:
#   The FPGrowth (frequent pattern growth) function uses an FP-growth
#   			algorithm to generate association rules from patterns in a data 
#   set, and then determines
#   			their interestingness.
# 
# Args:
#   data -
#     Required Argument.\cr
#     Specifies the name of the tbl_teradata that contains the data set\cr
#   
#   tran.item.columns -
#     Required Argument.\cr
#     Specifies the names of the columns that contain transaction items to 
#     analyze.\cr
#     Types: character OR vector of Strings (character)
#   
#   tran.id.columns -
#     Required Argument.\cr
#     Specifies the names of the columns that contain identifiers for the 
#     transaction items.\cr
#     Types: character OR vector of Strings (character)
#   
#   patterns.or.rules -
#     Optional Argument.\cr
#     Specifies whether the function outputs patterns, rules, or both. An 
#     example of a pattern is {onions, potatoes, hamburger}. \cr
#     Default Value: "both"\cr
#     Permitted Values: both, patterns, rules\cr
#     Types: character
#   
#   groupby.columns -
#     Optional Argument.\cr
#     Specifies the names of columns that define the partitions into which 
#     the function groups the input data and calculates output for it. At 
#     least one column must be usable as a distribution key. If you omit 
#     this argument, then the function considers all input data to be in a 
#     single partition. Note: Do not specify the same column in both this 
#     argument and the tran.id.column argument, because this causes 
#     incorrect counting in the partitions.\cr
#     Types: character OR vector of Strings (character)
#   
#   pattern.distribution.key.column -
#     Optional Argument.\cr
#     Specifies the name of the column to use as the distribution key for 
#     output.pattern.table. The default value is "pattern_targetcolumns".\cr
#     Types: character
#   
#   rule.distribution.key.column -
#     Optional Argument.\cr
#     Specifies the name of the column to use as the distribution key for 
#     output.rule.table. The default value is "antecedent_targetcolumns".\cr
#     Types: character
#   
#   compress -
#     Optional Argument.\cr
#     Specifies the compression level the output tables. Realized 
#     compression ratios depend on both this value and the data 
#     characteristics. These ratios typically range from 3x to 12x. \cr
#     Default Value: "nocompress"\cr
#     Permitted Values: low, medium, high, nocompress\cr
#     Types: character
#   
#   group.size -
#     Optional Argument.\cr
#     Specifies the number of transaction items to be assigned to each 
#     worker. This value must be an integer in the range from 1 to the 
#     number of distinct transaction items, inclusive. For a machine with 
#     limited RAM, use a relatively small value. \cr
#     Default Value: 4\cr
#     Types: integer
#   
#   min.support -
#     Optional Argument.\cr
#     Specifies the minimum support value of returned patterns (including 
#     the specified support value). This value must be a DECIMAL in the 
#     range [0, 1]. \cr
#     Default Value: 0.05\cr
#     Types: numeric
#   
#   min.confidence -
#     Optional Argument.\cr
#     Specifies the minimum confidence value of returned patterns 
#     (including the specified confidence value). This value must be a 
#     DECIMAL in the range [0, 1]. \cr
#     Default Value: 0.8\cr
#     Types: numeric
#   
#   max.pattern.length -
#     Optional Argument.\cr
#     Specifies the maximum length of returned patterns. The length of a 
#     pattern is the sum of the item numbers in the antecedent and 
#     consequence columns. This value must be an integer greater than 2. 
#     The default value is 10. max.pattern.length also limits the length of 
#     returned rules to this value.\cr
#     Default Value: "10"\cr
#     Types: character
#   
#   antecedent.count.range -
#     Optional Argument.\cr
#     Specifies the range for na, the number of items in the antecedent. 
#     The function returns only patterns for which na is in the range 
#     [lower_bound, upper_bound]. The lower_bound must be greater an 
#     integer greater than 0. The lower_bound and upper_bound can be equal. 
#     The default value is "1- infinite".\cr
#     Default Value: "1-INFINITE"\cr
#     Types: character
#   
#   consequence.count.range -
#     Optional Argument.\cr
#     Specifies the range for nc, the number of items in the consequence. 
#     The function returns only patterns for which nc is in the range 
#     [lower_bound, upper_bound]. The lower_bound must be greater an 
#     integer greater than 0. The lower_bound and upper_bound can be equal. 
#     The default value is "1-1".\cr
#     Default Value: "1-1"\cr
#     Types: character
#   
#   delimiter -
#     Optional Argument.\cr
#     Specifies the delimiter that separates items in the output. (that is, 
#     the default delimiter is comma).\cr
#     Default Value: ","\cr
#     Types: character
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_fpgrowth_mle" which is a 
#   named list containing objects of class "tbl_teradata".\cr
#   Named list members can be referenced directly with the "$" operator 
#   using the following names:\enumerate{\item output.pattern.table\item 
#   output.rule.table\item output}
# 
# 
#' @export
td_fpgrowth_mle <- function(
  data = NULL,
  tran.item.columns = NULL,
  tran.id.columns = NULL,
  patterns.or.rules = "both",
  groupby.columns = NULL,
  pattern.distribution.key.column = NULL,
  rule.distribution.key.column = NULL,
  compress = "nocompress",
  group.size = 4,
  min.support = 0.05,
  min.confidence = 0.8,
  max.pattern.length = "10",
  antecedent.count.range = "1-INFINITE",
  consequence.count.range = "1-1",
  delimiter = ",",
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("tran.item.columns", tran.item.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("tran.id.columns", tran.id.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("patterns.or.rules", patterns.or.rules, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("groupby.columns", groupby.columns, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("pattern.distribution.key.column", pattern.distribution.key.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("rule.distribution.key.column", rule.distribution.key.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("compress", compress, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("group.size", group.size, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("min.support", min.support, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("min.confidence", min.confidence, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("max.pattern.length", max.pattern.length, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("antecedent.count.range", antecedent.count.range, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("consequence.count.range", consequence.count.range, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("delimiter", delimiter, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check for permitted values
  patterns.or.rulesPermittedValues <- list("BOTH", "PATTERNS", "RULES")
  .validatePermittedValues(patterns.or.rules, patterns.or.rulesPermittedValues)
  
  compressPermittedValues <- list("LOW", "MEDIUM", "HIGH", "NOCOMPRESS")
  .validatePermittedValues(compress, compressPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(tran.item.columns)
  .validateTblHasArgumentColumns(tran.item.columns, "tran.item.columns", data, "data")
  
  .validateInputColumnsNotEmpty(tran.id.columns)
  .validateTblHasArgumentColumns(tran.id.columns, "tran.id.columns", data, "data")
  
  .validateInputColumnsNotEmpty(groupby.columns)
  .validateTblHasArgumentColumns(groupby.columns, "groupby.columns", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  # Validate that value passed to the output column argument is not empty.
  .validateInputColumnsNotEmpty(pattern.distribution.key.column)
  .validateInputColumnsNotEmpty(rule.distribution.key.column)
  # Generate temp table names for output table parameters if any.
  output.pattern.tableTempTableName <- .teradataGenerateTempTableName("td_fpgrowth0_", use.default.database = TRUE, gc.onQuit = TRUE)
  output.rule.tableTempTableName <- .teradataGenerateTempTableName("td_fpgrowth1_", use.default.database = TRUE, gc.onQuit = TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_fpgrowth_mle.internal)
  # Manually added condition to handle scenario when patterns.or.rules is not BOTH
  if (toupper(patterns.or.rules) != "RULES")
    Call[["output.pattern.tableTempTableName"]] <- output.pattern.tableTempTableName
  if (toupper(patterns.or.rules) != "PATTERNS")
    Call[["output.rule.tableTempTableName"]] <- output.rule.tableTempTableName
  
  retval <- NULL
  tryCatch({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_fpgrowth_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units = "secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_fpgrowth_mle.internal <- function(
  data = NULL,
  tran.item.columns = NULL,
  tran.id.columns = NULL,
  patterns.or.rules = "both",
  groupby.columns = NULL,
  pattern.distribution.key.column = NULL,
  rule.distribution.key.column = NULL,
  compress = "nocompress",
  group.size = 4,
  min.support = 0.05,
  min.confidence = 0.8,
  max.pattern.length = "10",
  antecedent.count.range = "1-INFINITE",
  consequence.count.range = "1-1",
  delimiter = ",",
  data.sequence.column = NULL,
  output.pattern.tableTempTableName = NULL,
  output.rule.tableTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- NULL
  funcOutputArgs <- NULL
  
  # Manually added condition to handle scenario when patterns.or.rules is not BOTH
  if (!missing(output.pattern.tableTempTableName) && !is.null(output.pattern.tableTempTableName)) {
    funcOutputArgsSqlNames <- "OutputPatternTable"
    funcOutputArgs <- output.pattern.tableTempTableName
  }
  
  if (!missing(output.rule.tableTempTableName) && !is.null(output.rule.tableTempTableName)) {
    funcOutputArgsSqlNames <- c(funcOutputArgsSqlNames, "OutputRuleTable")
    funcOutputArgs <- c(funcOutputArgs, output.rule.tableTempTableName)
  }
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(tran.item.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TransactionIDColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(tran.id.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  if (!is.null(groupby.columns)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PartitionColumns")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(groupby.columns,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(patterns.or.rules) && !missing(patterns.or.rules)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PatternsOrRules")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(patterns.or.rules, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(compress) && !missing(compress)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CompressionLevel")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(compress, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(group.size) && !missing(group.size)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "GroupSize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(group.size, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(min.support) && !missing(min.support)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MinSupport")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(min.support, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(min.confidence) && !missing(min.confidence)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MinConfidence")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(min.confidence, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(max.pattern.length) && !missing(max.pattern.length)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxPatternLength")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(max.pattern.length, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(antecedent.count.range) && !missing(antecedent.count.range)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AntecedentCountRange")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(antecedent.count.range, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(consequence.count.range) && !missing(consequence.count.range)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ConsequenceCountRange")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(consequence.count.range, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(delimiter) && !missing(delimiter)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Delimiter")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(delimiter, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(pattern.distribution.key.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PatternDistributionKeyColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(pattern.distribution.key.column, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(rule.distribution.key.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "RuleDistributionKeyColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(rule.distribution.key.column, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "FPGrowth",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("FPGrowth", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database = TRUE, gc.onQuit = TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  # Manually added condition to handle scenario when patterns.or.rules is not BOTH
  if (!missing(output.pattern.tableTempTableName) && !is.null(output.pattern.tableTempTableName))
    result[["output.pattern.table"]] <- .createDataSetObject(.extractTableName(output.pattern.tableTempTableName), sourceType = "table", .extractDatabaseName(output.pattern.tableTempTableName), is_dplyr_input)
  if (!missing(output.rule.tableTempTableName) && !is.null(output.rule.tableTempTableName))
    result[["output.rule.table"]] <- .createDataSetObject(.extractTableName(output.rule.tableTempTableName), sourceType = "table", .extractDatabaseName(output.rule.tableTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_fpgrowth <- td_fpgrowth_mle
