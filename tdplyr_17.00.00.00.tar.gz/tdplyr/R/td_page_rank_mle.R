# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.8
# 
# ################################################################## 

# Description:
#   The PageRank function computes the PageRank values for a directed 
#   graph, weighted or unweighted.
# 
# Args:
#   vertices.data -
#     Required Argument.\cr
#     Specifies the input tbl_teradata containing vertices in the graph.\cr
#   
#   vertices.data.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "vertices.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   vertices.data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "vertices.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   edges.data -
#     Required Argument.\cr
#     Specifies the input tbl_teradata containing edges in the graph.\cr
#   
#   edges.data.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "edges.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   edges.data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "edges.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   target.key -
#     Required Argument.\cr
#     Specifies the target key columns in the "edges.data".\cr
#     Types: character OR vector of Strings (character)
#   
#   weights -
#     Optional Argument.\cr
#     Specifies the column in "edges.data" that contains the edge weight,
#     which must be a positive value. By default, all edges have the same
#     weight (that is, the graph is unweighted).\cr
#     Types: character
#   
#   damping -
#     Optional Argument.\cr
#     Specifies the value to use in the PageRank formula. This argument must be
#     a numeric value between 0 and 1.\cr
#     Default Value: 0.85\cr
#     Types: numeric
#   
#   niter -
#     Optional Argument.\cr
#     Specifies the maximum number of iterations for which the algorithm runs
#     before the function completes. This argument be a positive integer value.\cr
#     Default Value: 1000\cr
#     Types: integer
#   
#   eps -
#     Optional Argument.\cr
#     Specifies the convergence criteria value.\cr
#     Default Value: 0.001\cr
#     Types: numeric
#   
#   accumulate -
#     Optional Argument.\cr
#     Specifies the names of columns in "vertices.data" to copy to the "result"
#     output tbl_teradata.\cr
#     Types: character OR vector of Strings (character)
#   
#   vertices.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "vertices.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   edges.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "edges.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_page_rank_mle" which is a 
#   named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_page_rank_mle <- function(
  vertices.data = NULL,
  edges.data = NULL,
  target.key = NULL,
  weights = NULL,
  damping = 0.85,
  niter = 1000,
  eps = 0.001,
  accumulate = NULL,
  vertices.data.sequence.column = NULL,
  edges.data.sequence.column = NULL,
  vertices.data.partition.column = NULL,
  edges.data.partition.column = NULL,
  vertices.data.order.column = NULL,
  edges.data.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("vertices.data", vertices.data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("vertices.data.partition.column", vertices.data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("vertices.data.order.column", vertices.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("edges.data", edges.data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("edges.data.partition.column", edges.data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("edges.data.order.column", edges.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("target.key", target.key, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("weights", weights, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("damping", damping, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("niter", niter, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("eps", eps, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("vertices.data.sequence.column", vertices.data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("edges.data.sequence.column", edges.data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(vertices.data, NULL)
  .validateInputTableDataType(edges.data, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(target.key)
  .validateTblHasArgumentColumns(target.key, "target.key", edges.data, "edges.data")
  
  .validateInputColumnsNotEmpty(weights)
  .validateTblHasArgumentColumns(weights, "weights", edges.data, "edges.data")
  
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", vertices.data, "vertices.data")
  
  .validateInputColumnsNotEmpty(vertices.data.sequence.column)
  .validateTblHasArgumentColumns(vertices.data.sequence.column, "vertices.data.sequence.column", vertices.data, "vertices.data")
  
  .validateInputColumnsNotEmpty(edges.data.sequence.column)
  .validateTblHasArgumentColumns(edges.data.sequence.column, "edges.data.sequence.column", edges.data, "edges.data")
  
  .validateInputColumnsNotEmpty(vertices.data.partition.column)
  .validateTblHasArgumentColumns(vertices.data.partition.column, "vertices.data.partition.column", vertices.data, "vertices.data")
  
  .validateInputColumnsNotEmpty(edges.data.partition.column)
  .validateTblHasArgumentColumns(edges.data.partition.column, "edges.data.partition.column", edges.data, "edges.data")
  
  .validateInputColumnsNotEmpty(vertices.data.order.column)
  .validateTblHasArgumentColumns(vertices.data.order.column, "vertices.data.order.column", vertices.data, "vertices.data")
  
  .validateInputColumnsNotEmpty(edges.data.order.column)
  .validateTblHasArgumentColumns(edges.data.order.column, "edges.data.order.column", edges.data, "edges.data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetKey")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(target.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(weights)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "EdgeWeight")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(weights,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(accumulate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(accumulate,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(damping) && !missing(damping)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "DampFactor")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(damping, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(niter)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxIterNum")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(niter, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(eps)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StopThreshold")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(eps, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(vertices.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("vertices:", .teradataCollapseArgVector(vertices.data.sequence.column, "")))
  }
  
  if (!is.null(edges.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("edges:", .teradataCollapseArgVector(edges.data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process vertices.data
  vertices.data.partition.column <- .teradataCollapseArgVector(vertices.data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(vertices.data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "vertices")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, vertices.data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(vertices.data.order.column, "\""))
  
  # Process edges.data
  edges.data.partition.column <- .teradataCollapseArgVector(edges.data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(edges.data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "edges")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, edges.data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(edges.data.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "PageRank",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("PageRank", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(vertices.data, edges.data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_page_rank_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_page_rank <- td_page_rank_mle
