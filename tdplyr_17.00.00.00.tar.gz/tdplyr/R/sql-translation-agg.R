# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

# Aggregate extensions for Teradata
# See: sql-translation.R

# Aggregate environment for Teradata
# Arguments:
#  - disable_ext: returns the aggr mapping without custom mappings if TRUE
.td_sql_agg <- function(disable_ext = FALSE){
  aggs <- .getSqlVariantDbplyr()

  if (disable_ext){

    aggs$dbplyr_td$aggregate

  } else {

    .td_add_aggregate_extensions(aggs$dbplyr_td$aggregate)

  }
}

# Add the Aggregate Extensions for Teradata
# Arguments:
#  sql_aggs - Original aggregate mappings by dbplyr using sql_translator
# Returns:
#  An environment with the sql aggregate mappings provided exclusively by this package
# Note: Extensions of mappings here can be contributed to open source
#' @importFrom dbplyr sql_translator build_sql sql_aggregate
#' @importFrom dplyr sql
#' @importFrom rlang quo
.td_add_aggregate_extensions <- function(sql_aggs){

  sql_translator(.parent = sql_aggs,

      # Sample standard deviation and variance of values in a column.
      sd = sql_aggregate('STDDEV_SAMP'),
      var = sql_aggregate('VAR_SAMP'),

      # Population standard deviation and variance of values in a column.
      sdp = sql_aggregate("STDDEV_POP"),
      varp = sql_aggregate("VAR_POP"),

      # Count of non-NULL values in a column, if column name is provided in x.
      # Else, count of rows in the table.
      n = function(x = "*") {
        argInfoMatrix <- list()
        argInfoMatrix <- rbind(argInfoMatrix, list("x", x, TRUE, c("sql", "character")))
        colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")

        .validateArgInfoMatrix(argInfoMatrix)
        build_sql('CAST(COUNT(', sql(x), ') AS BIGINT)')
      },

      # Count of non-NULL distinct values in a column, if column name is provided in x.
      # Else, count of distinct rows in the table.
      n_distinct = function(x) {
        argInfoMatrix <- list()
        argInfoMatrix <- rbind(argInfoMatrix, list("x", x, FALSE, c("sql", "character")))
        colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")

        .validateArgInfoMatrix(argInfoMatrix)
        build_sql('CAST(COUNT(DISTINCT ', sql(x), ') AS BIGINT)')
      },

      # Distinct values of a column.
      distinct = function(x) {
        argInfoMatrix <- list()
        argInfoMatrix <- rbind(argInfoMatrix, list("x", x, FALSE, c("sql", "character")))
        colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")

        .validateArgInfoMatrix(argInfoMatrix)
        build_sql('DISTINCT ', sql(x))
      },

      ## other TD aggregates (used for time series)
      # Mode of non-NULL values of a column in each time group.
      ts.mode = function(value.expression) {
        .validateValueExpressionOnly(value.expression)
        build_sql("MODE(", sql(value.expression), ")")
      },
      # Smallest n (number.of.values) non-NULL values of a column in each time group.
      ts.bottom = function(value.expression, number.of.values, with.ties = FALSE) {
        .validate_arguments_bottom_top(value.expression, number.of.values, with.ties)
        .build.sql.expr.bottom.top("BOTTOM", value.expression, toString(number.of.values), with.ties)
      },
      # Largest n (number.of.values) non-NULL values of a column in each time group.
      ts.top = function(value.expression, number.of.values, with.ties = FALSE) {
        .validate_arguments_bottom_top(value.expression, number.of.values, with.ties)
        .build.sql.expr.bottom.top("TOP", value.expression, toString(number.of.values), with.ties)
      },
      # Median of non-NULL values of a column in each time group.
      ts.median = function(value.expression, use.distinct = FALSE) {
        .validateMedianArgs(value.expression, use.distinct)
        .build_sql_using_distinct_for_multiple_operations(value.expression, use.distinct, operation = "MEDIAN")
      },
      # Median of non-NULL values of a column, with/without grouping by a non-timestamp column.
      median = function(value.expression) {
        .validateValueExpressionOnly(value.expression)
        .build_sql_using_distinct_for_multiple_operations(value.expression, FALSE, operation = "MEDIAN")
      },
      # Oldest value, determined by timecode, of all the values in a column for each time group.
      ts.first = function(value.expression) {
        .validateValueExpressionOnly(value.expression)
        build_sql("FIRST(", sql(value.expression), ")")
      },
      # Newest value, determined by timecode, of all the values in a column for each time group.
      ts.last = function(value.expression) {
        .validateValueExpressionOnly(value.expression)
        build_sql("LAST(", sql(value.expression), ")")
      },
      # Median Absolute Deviation of non-NULL values of a column in each time group.
      ts.mad = function(value.expression, multiplier = NULL) {
        .validateArgumentsForTsMad(value.expression, multiplier)
        if (is.null(multiplier)) {
          build_sql("MAD(", sql(value.expression), ")")
        } else {
          build_sql("MAD(", sql(toString(multiplier)), ", ", sql(value.expression), ")")
        }
      },
      # nth percentile value of non-NULL values of a column in each time group.
      ts.percentile = function(value.expression, percentile, interpolation.type = NULL) {
        .validateArgumentsForTsPercentile(value.expression, percentile, interpolation.type)

        build_sql("PERCENTILE(", sql(value.expression), ", ", sql(toString(percentile)),
                  if (!is.null(interpolation.type)) {
                    build_sql(", ", sql(toupper(interpolation.type)))
                  },
                  ")"
                  )
      },
      # Time difference, or DELTA_T, between a starting and an ending event, in each time group.
      ts.delta_t = function(start.condition, end.condition) {
        argInfoMatrix <- list()
        argInfoMatrix <- rbind(argInfoMatrix, list("start.condition", start.condition, FALSE, c("sql", "character")))
        argInfoMatrix <- rbind(argInfoMatrix, list("end.condition", end.condition, FALSE, c("sql", "character")))

        colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")

        .validateArgInfoMatrix(argInfoMatrix)

        .validateInputColumnsNotEmpty(start.condition)
        .validateInputColumnsNotEmpty(end.condition)
        build_sql("DELTA_T((WHERE ",sql(start.condition) ,"), (WHERE ",sql(end.condition) ,"))")
      },
      # Kurtosis value of non-NULL values of a column in each time group.
      ts.kurtosis = function(value.expression) {
        .validateValueExpressionOnly(value.expression)
        build_sql("KURTOSIS(", sql(value.expression), ")")
      },
      # Kurtosis value of non-NULL values of a column (SQL translation for regular aggregation).
      kurtosis = function(value.expression) {
        .validateValueExpressionOnly(value.expression)
        build_sql("KURTOSIS(", sql(value.expression), ")")
      },
      # Skewness of the distribution of a column in each time group.
      ts.skew = function(value.expression) {
        .validateValueExpressionOnly(value.expression)
        build_sql("SKEW(", sql(value.expression), ")")
      },
      # Skewness of the distribution of a column (SQL translation for regular aggregation).
      skew = function(value.expression) {
        .validateValueExpressionOnly(value.expression)
        build_sql("SKEW(", sql(value.expression), ")")
      },
      # Sum of non-NULL values of a column in each time group.
      ts.sum = function(value.expression) {
        .validateValueExpressionOnly(value.expression)
        build_sql("SUM(", sql(value.expression), ")")
      },
      # Sample standard deviation of non-NULL values of a column in each time group.
      ts.sd = function(value.expression) {
        .validateValueExpressionOnly(value.expression)
        build_sql("STDDEV_SAMP(", sql(value.expression), ")")
      },
      # Population standard deviation of non-NULL values of a column in each time group.
      ts.sdp = function(value.expression) {
        .validateValueExpressionOnly(value.expression)
        build_sql("STDDEV_POP(", sql(value.expression), ")")
      },
      # Sample variance of non-NULL values of a column in each time group.
      ts.var = function(value.expression) {
        .validateValueExpressionOnly(value.expression)
        build_sql("VAR_SAMP(", sql(value.expression), ")")
      },
      # Population variance of non-NULL values of a column in each time group.
      ts.varp = function(value.expression) {
        .validateValueExpressionOnly(value.expression)
        build_sql("VAR_POP(", sql(value.expression), ")")
      },
      # Minimum value of non-NULL values of a column in each time group.
      ts.min = function(value.expression) {
        .validateValueExpressionOnly(value.expression)
        build_sql("MIN(", sql(value.expression), ")")
      },
      # Maximum value of non-NULL values of a column in each time group.
      ts.max = function(value.expression) {
        .validateValueExpressionOnly(value.expression)
        build_sql("MAX(", sql(value.expression), ")")
      },
      # Average value of non-NULL values of a column in each time group.
      ts.mean = function(value.expression) {
        .validateValueExpressionOnly(value.expression)
        build_sql("AVG(", sql(value.expression), ")")
      },
      # Count of non-NULL values of a column in each time group, if column name is provided in x.
      # Else, count of distinct rows in the table.
      ts.n = function(value.expression = "*") {
        .validateValueExpressionOnly(value.expression)
        build_sql("CAST(COUNT(", sql(value.expression), ") AS BIGINT)")
      },
      # Statistics of non-NULL values of a column in each time group.
      ts.describe = function(value.expression) {
        # Validating arguments.
        argInfoMatrix <- list()
        argInfoMatrix <- rbind(argInfoMatrix, list("value.expression", value.expression, FALSE, c("sql", "character")))
        colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")

        .validateArgInfoMatrix(argInfoMatrix)

        ## Creating the list of quosures required for DESCRIBE time series aggregate.
        # Step 1 : Creating required column names.
        col_names <- c("Maximum", "Minimum", "Average", "STDDEV_SAMP", "MEDIAN")
        percent_cols <- c("25", "50", "75")

        # Extracting the actual column name, based on `distinct()`.
        actual_column_name <- gsub(pattern = "\"", replacement = "", x = value.expression)
        if (grepl("DISTINCT ", value.expression, fixed = TRUE)) {
          actual_column_name <- sub(pattern = "^DISTINCT (.*)$", replacement = "\\1",
                                    x = actual_column_name)

          col_name <- paste0("Distinct(", actual_column_name, ")")
          percent_cols <- paste0("PERCENTILE(Distinct(",actual_column_name,", ", percent_cols, ", LINEAR))")

          # col_names here will be of the form "Maximum(Distinct(temperature))".
          col_names <- paste0(col_names, paste0("(", col_name, ")"))
        } else {
          percent_cols <- paste0("PERCENTILE(",actual_column_name,", ", percent_cols, ", LINEAR)")

          # col_names here will be of the form "Maximum(temperature)".
          col_names <- paste0(col_names, paste0("(", actual_column_name, ")"))
        }

        # Distinct is not allowed on MODE.
        mode_col <- paste0("MODE(", actual_column_name, ")")

        # Step 2 : Generating actual quosures.
        all_quos <- list()
        all_quos[[col_names[1]]] <- quo(ts.max(value.expression))
        all_quos[[col_names[2]]] <- quo(ts.min(value.expression))
        all_quos[[col_names[3]]] <- quo(ts.mean(value.expression))
        all_quos[[col_names[4]]] <- quo(ts.sd(value.expression))
        all_quos[[col_names[5]]] <- quo(ts.median(value.expression))
        all_quos[[mode_col]] <- quo(ts.mode(value.expression))
        all_quos[[percent_cols[1]]] <- quo(ts.percentile(value.expression, 25))
        all_quos[[percent_cols[2]]] <- quo(ts.percentile(value.expression, 50))
        all_quos[[percent_cols[3]]] <- quo(ts.percentile(value.expression, 75))

        # Get SQL translations for all quosures.
        sql_trans <- translate_sql_(all_quos, con = td_get_context()$connection, window = FALSE,
                             context = list(clause = "SELECT"))

        # After translation, the expression will be of the form
        # `MIN("value.expression") AS min_val`.
        # Hence, replacing "value.expression" with actual column name that is provided in the
        # argument 'value.expression'.
        sql_trans <- gsub("\"value.expression\"", value.expression, sql_trans, fixed = TRUE)

        # MODE doesn't work with DISTINCT.
        sql_trans <- gsub("MODE(DISTINCT ", "MODE(", sql_trans, fixed = TRUE)
        sql_trans
      }
  )
}
