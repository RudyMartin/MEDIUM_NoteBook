################################################################################
#
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: pankajvinod.purandare@teradata.com
# Secondary Owner:
#
# This file contains getter's to get attributes of tbl object.
################################################################################

#' @importFrom dbplyr remote_con
.get_tbl_connection <- function(tblObj) {
  remote_con(tblObj)
}

#' @importFrom dbplyr remote_name
#' @importFrom dbplyr remote_con
.get_dbname.tbl_teradata <- function(tblObj) {
  # check if the tblObj was created using in_schema
  # In that case it is a subclass of ident_q and extract db name

  # Note the second argument is connection which will be invoked
  # if the first one is not ident_q
  .get_dbname(remote_name(tblObj), remote_con(tblObj))
}

.get_dbname.ident_q <- function(tblObj, ...) {
  # dbname must always be upper case
  toupper(.extractDatabaseNameQuoted(tblObj))
}

.get_dbname.default <- function(tblObj, nextObj, ...) {
  .get_dbname(nextObj)
}

#
# Getter's for getting sourceType attribute
# Args:
#   tblObj - A tbl_teradata object.
# Returns:
#   Source type of tblObj, table or query.
#
.get_source_type <- function(tblObj) {
  UseMethod(".get_source_type")
}

#' @importFrom dbplyr is.ident
#' @importFrom dbplyr remote_name
.get_source_type.tbl_teradata <- function(tblObj) {
  if (is.ident(remote_name(tblObj)))
    "table"
  else
    "query"
}

#
# Getter's for getting sourceDefinition attribute.
# Args:
#   tblObj - A tbl_teradata object.
# Returns:
#   Source definition i.e. table name in case of
#   "table" source type and SQL query in case of
#   "query" source type.
#
.get_source_definition <- function(tblObj) {
  UseMethod(".get_source_definition")
}

#' @importFrom dbplyr remote_name
#' @importFrom dbplyr remote_query
.get_source_definition.tbl_teradata <- function(tblObj) {
  if (.get_source_type(tblObj) == "query") {
    as.character(remote_query(tblObj))
  } else {
    # check if the tblObj was created using in_schema
    # In that case it is a subclass of ident_q and extract table name
    # This will invoke the appropriate S3 method
    .get_source_definition(remote_name(tblObj))
  }
}

.get_source_definition.ident_q <- function(tblObj) {
  .extractTableNameQuoted(tblObj)
}

.get_source_definition.default <- function(tblObj) {
  as.character(tblObj)
}

#
# Getter's for getting object attribute.
# Args:
#   tblObj - A tbl_teradata object.
# Returns:
#   Full name of the table when source type is table, else NULL
#
.get_object <- function(tblObj) {
  UseMethod(".get_object")
}

.get_object.tbl_teradata <- function(tblObj) {
  if (.get_source_type(tblObj) == "query") {
    NULL
  } else {
    gettextf("\"%s\".\"%s\"", .get_dbname(tblObj), .get_source_definition(tblObj))
  }
}

#
# Getter's for getting baseQuery attribute.
# Args:
#   tblObj - A tbl_teradata object.
# Returns:
#   Base SQL query.
#
.get_base_query <- function(tblObj) {
  UseMethod(".get_base_query")
}


#' @importFrom dbplyr sql_render
.get_base_query.tbl_teradata <- function(tblObj) {
  if (.get_source_type(tblObj) == "query") {
    as.character(sql_render(tblObj))
  } else {
    gettextf("SELECT * FROM %s", .get_object(tblObj))
  }
}

#
# Getter's for getting column types
# Args:
#   tblObj - A tbl_teradata object.
# Returns:
#   A vector containing column types of the object.
#
.get_column_datatypes <- function(tblObj) {
  UseMethod(".get_column_datatypes")
}

.is_lazy_ops <- function(op) {
  UseMethod(".is_lazy_ops")
}

# this logic is similar to op_desc S3 method in dbplyr lazy-ops.R
.is_lazy_ops.op_base_remote <- function(op) {
  FALSE
}

# This is our special ops sub class to handle lazy sqlmr for non-driver functions
# This subclass is attached to tbl ops object for which we want to ignore metadata.
.is_lazy_ops.op_base_teradata <- function(op) {
  TRUE
}

# if the class does not contain op_base_remote but has only op
# then it is a lazy op
.is_lazy_ops.op <- function(op) {
  TRUE
}

.is_lazy_ops.default <- function(op) {
  FALSE
}


# This is the only attribute, that get's automatically attached to tbl_teradata
# object, when first time this attribute is requested.
# This is done to avoid connecting to back-end again and again, when
# this method is called.
#' @importFrom dbplyr remote_query
#' @importFrom dplyr tbl
.get_column_datatypes.tbl_teradata <- function(tblObj) {
  retTypes <- tblObj$types
  # If the tbl object is a lazy ops one then we need to reload the types
  # but if it was already re-loaded then we just return the types
  if (.is_lazy_ops(tblObj$ops)) {
    retTypes <- .getTypesCached(tblObj$ops)
    # The retTypes is null if either -
    # a) we never cached any types in the base tbl or b) it is a dplyr lazy ops
    if (is.null(retTypes)) {
      colInfo <- .ta.describe.columns.wrapper(tblObj$src$con, remote_query(tblObj))
      # this will store the metadata in the cache
      .populateLazyVars(tblObj$ops, names = colInfo$names, types = colInfo$types)
      retTypes <- colInfo$types
    }
  }
  retTypes
}
#
# Getter's for getting column types
# Args:
#   tblObj - A tbl_teradata object.
# Returns:
#   A vector containing column names in the table
#
.get_colnames <- function(tblObj) {
  UseMethod(".get_colnames")
}

.get_colnames.tbl_teradata <- function(tblObj) {
  colnames(tblObj)
}

.get_colnames.data.frame <- function(df) {
  colnames(df)
}

#
# Attach attributes to tbl object.
# Args:
#   tblObj - A tbl_teradata object.
# Returns:
#   None
#
.attach_attributes <- function(tblObj) {
  UseMethod(".attach_attributes")
}

.attach_attributes.tbl_teradata <- function(tblObj) {
  attr(tblObj, "databaseName") <- .get_dbname(tblObj)
  attr(tblObj, "sourceType") <- .get_source_type(tblObj)
  attr(tblObj, "sourceDefinition") <- .get_source_definition(tblObj)
  attr(tblObj, "object") <- .get_object(tblObj)
  attr(tblObj, "baseQuery") <- .get_base_query(tblObj)
  attr(tblObj, "columnDataType") <- .get_column_datatypes(tblObj)
  attr(tblObj, "columnNames") <- .get_colnames(tblObj)
  tblObj
}
