# ################################################################## 
#
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# ################################################################## 

# Description:
#    
#' Create a Context to perform analytic functions on Teradata Vantage
#'
#' Use the \code{td_create_context} function to establish a connection to 
#' Teradata Vantage. The established connection will be set as the current 
#' context for all subsequent analytic functions.\cr
#' Note: If a context already exists, this overwrites the previous context and removes all
#' nonpersistent work tables created by the analytic functions, even though the connection
#' parameters \code{host}, \code{uid} and \code{database} (i.e. default schema) are same for both
#' the new connection object and the connection object from the previous context.
#'
#' You should make sure that Teradata driver is properly installed and configured 
#' on the system where this function is being invoked.\cr
#' When logmech argument (other than TD2 which is the current default logon 
#' mechanism) is used, you should setup the client with relevant security 
#' mechanisms.\cr
#' 
#' Note:\cr
#' \enumerate{
#' \item
#' tdplyr requires that the user has certain permissions on the user's default database or the
#' initial default database specified using the "database" argument, or the temporary database
#' when specified using "temp.database".\cr
#' These permissions allow the user to:
#' \enumerate{
#'   \item Create tables to save results of Vantage analytic functions.
#'   \item Create views in the background for objects of class "tbl_teradata" based on query.
#' }
#' It is expected that the user has the required permissions to create these objects in the
#' database that will be used.\cr
#' For views based on Vantage Analytic Functions, additional permissions may be required, which can
#' be granted using:\cr \code{GRANT EXECUTE FUNCTION ON SYSLIB ... WITH GRANT OPTION}.\cr
#' The access to the views created may also require issuing additional permissions depending on
#' which database is used and which object the view being created is based on, which can be granted
#' using:\cr \code{GRANT SELECT ... WITH GRANT OPTION}.
#' \item
#' The "temp.database" and "database" parameters help determine which database is used by default
#' to lookup for tables/views while creating objects of class "tbl_teradata" and which database
#' is used to create all internal temporary objects, as shown in the table below.\cr
#' 
#' \tabular{lll}{
#'  \tab Scenario \tab tdplyr behaviour \cr
#' 1. \tab Both "database" and \tab Internal temporary objects are created in \cr
#' \tab "temp.database" are provided \tab "temp.database", and database table/view lookup \cr
#' \tab \tab is done from "database".\cr
#' 2. \tab "database" is provided \tab Database table/view lookup and internal \cr
#' \tab but "temp.database" is not \tab temporary objects are created in "database". \cr
#' 3. \tab "temp.database" is provided \tab Internal temporary objects are created in \cr
#' \tab but "database" is not \tab "temp.database", database table/view lookup \cr
#' \tab \tab from the users default database. \cr
#' 4. \tab Neither "database" nor \tab Database table/view lookup and internal \cr
#' \tab "temp.database" are provided \tab temporary objects are created in users \cr
#' \tab \tab default database. \cr
#' }
#' }
#'
#' @param dsn 
#'      Optional argument.\cr
#'      Specifies the Data Source Name (DSN) for the ODBC connection. If this argument is not
#'      specified, relevant optional arguments are used to form the connection string.\cr
#'      Note : Only applicable when the argument "dType" is 'ODBC'\cr
#'      Default Value: NULL\cr
#'      Types: character
#'
#' @param host
#'     Optional argument. Required when "dType" is 'NATIVE'.\cr
#'     Specifies the fully qualified domain name or IP address of the Teradata Vantage System.\cr
#'     Default Value: NULL\cr
#'     Types: character
#'
#' @param uid
#'     Optional argument.\cr
#'     Specifies the userId for connection. If not supplied, the userId present in DSN is used.\cr
#'     Default Value: NULL\cr
#'     Types: character
#'
#' @param pwd 
#'     Optional argument.\cr
#'     Specifies the password. If not supplied, the password present in DSN is used.\cr
#'     Default Value: NULL\cr
#'     Types: character\cr
#'     Note: Encrypted passwords can also be passed to this argument, using Stored Password Protection 
#'     feature. Examples section below demonstrates passing encrypted password to "td_create_context".
#'     More details on Stored Password Protection and how to generate key and encrypted password file 
#'     can be found at \href{https://github.com/Teradata/r-driver#StoredPasswordProtection}{StoredPasswordProtection}
#'
#' @param tdWalletString
#'      Optional argument.\cr
#'      Specifies the tdwallet reference string for the password required for the connection. If this
#'      is specified, the argument 'pwd' is ignored.\cr
#'      Note : Only applicable when the argument "dType" is 'ODBC'\cr
#'      Default Value: NULL\cr
#'      Types: character
#'
#' @param database
#'      Optional argument.\cr
#'      Specifies the database name to which connection is needed. If not supplied, 
#'      the database name present in the DSN is used.\cr
#'      Note : Only applicable when the argument "dType" is 'ODBC'\cr
#'      Default Value: NULL\cr
#'      Types: character
#'
#' @param temp.database
#'      Optional argument.\cr
#'      Some of the functions need to create temporary database objects(table/view) for processing 
#'      data. Such objects are garbage collected at the end of the session. If a user wants to 
#'      specifically use a known database for temporary objects, the database name can be specified 
#'      using this argument. Make sure the user has privilege to create objects in this database, 
#'      otherwise the functions that create temporary objects will fail.\cr
#'      If this argument is not supplied, default database of the connection is used for temporary 
#'      objects. To get the temporary database name, use function \code{td_get_context()}.\cr
#'      Default Value: NULL\cr
#'      Types: character
#'
#' @param dType
#'      Required argument.\cr
#'      Specifies the driver type.\cr
#'      Permitted Values: ODBC, NATIVE\cr
#'      Default Value: ODBC\cr
#'      Types: character
#'
#' @param logmech
#'      Optional argument.\cr
#'      Specifies the logon authentication method. Only applicable when "dType" is 'NATIVE'. Ignored 
#'      when used with 'ODBC'.\cr
#'      If the value is NULL, it takes default value used by the 
#'      Teradata SQL driver.\cr
#'      Permitted Values: TD2, LDAP, TDNEGO, KRB5 (for Kerberos) and JWT\cr
#'      Default Value: NULL\cr
#'      Types: character
#'
#' @param logdata
#'      Optional argument.\cr
#'      Specifies additional data for the chosen logon authentication method. Only applicable when 
#'      'dType' is "NATIVE". Ignored when used with "ODBC".\cr
#'      Note: If "logmech" is "JWT", then JWT token should be provided with the key 'jwt.token' 
#'      in the named list of this argument.\cr
#'      Default Value: NULL\cr
#'      Types: Named list of characters
#'
#'
#'
#' @param ... Optional arguments as applicable to the corresponding driver.
#' @rdname td_create_context
#' @return Invisibly returns an object of class: \code{DBIConnection}.
#' @seealso \code{td_remove_context}, \code{td_set_context}, \code{td_get_context}, \code{dbConnect}
#' @examples
#' \donttest{
#' # Note: The default database in the connection is used as the temporary 
#' # database. For retrieving and removing context, check td_get_context
#' # and td_remove_context respectively. 
#' 
#' # Create a context (ODBC connection) specifying a dsn name.
#' con <- td_create_context(dsn = "TeradataDSN")
#'
#' # Example 1: Create a context (ODBC connection) with a different temporary database.
#' td_create_context(dsn = "TeradataDSN", temp.database = "database_for_transient_objects")
#'
#' # Example 2: Create a context (ODBC connection) using TdWallet.
#' td_create_context(dsn = "TeradataDSN", tdWalletString = "password_tduser")
#'
#' # Example 3: Create a context using the Teradata SQL Driver. Note that the argument 'logmech' is
#' # not specified. Connection is established with default logon mechanism.
#' td_create_context(host = "<dbcname>", uid = "<tduser>", pwd = "<tdpwd>", dType = "NATIVE")
#'
#' # Example 4: Create a context using the Teradata SQL Driver with various logon mechanisms.
#' 
#' # Connection using TD2: The Teradata 2(TD2) mechanism provides authentication using a Vantage 
#' # database username and password.
#' td_create_context(host = "<dbcname>", uid = "<tduser>", pwd = "<tdpwd>", dType = "NATIVE", 
#'                   logmech = "TD2")
#' 
#' # Connection using TDNEGO: TDNEGO is a security mechanism that automatically determines the 
#' # actual mechanism required, based on policy, without user's involvement. The actual mechanism 
#' # is determined by the TDGSS server configuration and the security policy's mechanism 
#' # restrictions.
#' td_create_context(host = "<dbcname>", uid = "<tduser>", pwd = "<tdpwd>", dType = "NATIVE", 
#'                   logmech = "TDNEGO")
#' 
#' # Connection using LDAP: LDAP is a directory-based mechanism. User logs on to a Vantage database 
#' # with a directory username and password and is authenticated by the directory.
#' td_create_context(host = "<dbcname>", uid = "<tduser>", pwd = "<tdpwd>", dType = "NATIVE", 
#'                   logmech = "LDAP")
#'                   
#' # Connection using KRB5: KRB5 is a directory-based mechanism. User logs on to a Vantage database 
#' # with a domain username and password and is authenticated by Kerberos (KRB5 or SPNEGO
#' # mechanism).
#' td_create_context(host = "<dbcname>", uid = "<tduser>", pwd = "<tdpwd>", dType = "NATIVE", 
#'                   logmech = "KRB5")
#'
#' # Connection using JWT: Using JWT token to connect to Vantage.
#' td_create_context(host = "<dbcname>", dType = "NATIVE", logmech = "JWT",
#'                   logdata = list(jwt.token="<token_value>"))
#'                   
#' # Example 5: Create context using encrypted password and key passed to "pwd" parameter.
#' # The password should be specified in the format mentioned below:
#' # ENCRYPTED_PASSWORD(file:<PasswordEncryptionKeyFileName>, file:<EncryptedPasswordFileName>)
#' # The PasswordEncryptionKeyFileName specifies the name of a file that contains the password 
#' # encryption key and associated information.
#' # The EncryptedPasswordFileName specifies the name of a file that contains the encrypted password 
#' # and associated information.
#' # Each filename must be preceded by the 'file:' prefix. The PasswordEncryptionKeyFileName must be 
#' # separated from the EncryptedPasswordFileName by a single comma.
#' td_create_context(host = "<dbcname>", uid = "<tduser>", 
#'                   pwd = "ENCRYPTED_PASSWORD(file:PassKey.properties, file:EncPass.properties)",
#'                   dType = "NATIVE")
#'                   
#' # Example 6: Create context using encrypted password in LDAP logon mechanism.
#' td_create_context(host = "<dbcname>", uid = "<tduser>", 
#'                   pwd = "ENCRYPTED_PASSWORD(file:PassKey.properties, file:EncPass.properties)",
#'                   dType = "NATIVE", logmech = "LDAP")
#' }
#' @export
td_create_context <- function(dsn = NULL, host = NULL, uid = NULL, pwd = NULL,
                              tdWalletString = NULL, database = NULL, temp.database = NULL,
                              dType = "odbc", logmech = NULL, logdata = NULL, ...) {
  dType <- tolower(dType)
  
  # Validate arguments.
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("dsn", dsn, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("host", host, !identical(dType, "native"), c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("uid", uid, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("pwd", pwd, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("tdWalletString", tdWalletString, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("database", database, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("temp.database", temp.database, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("dType", dType, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("logmech", logmech, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("logdata", logdata, TRUE, c("list", NA)))

  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")

  # Make sure that a non-NULL value has been supplied for all mandatory arguments.
  .validateMissingRequiredArguments(argInfoMatrix)

  # Make sure that a non-NULL value has been supplied correct type of argument.
  .validateArgumentTypes(argInfoMatrix)
  
  # Check for permitted values
  dType_permittedValues <- list("ODBC", "NATIVE")
  .validatePermittedValues(dType, dType_permittedValues)
  
  # Check for permitted values
  logmech_permittedValues <- .ta.ValidLogonMechanims()
  .validatePermittedValues(logmech, logmech_permittedValues)
  
  if (identical(dType, "native")) {
    if (!is.null(database))
      .ta.stop("TDR_E1107", showFunctionCall = FALSE)
  
    # Do not print this message if only dsn is specified,
    # Since, if host alone is missing the error comes from dbConnect.
    if (!is.null(dsn) && !is.null(host))
      .ta.print("TDR_P1108", "dsn")
  
    if (!is.null(tdWalletString))
      .ta.print("TDR_P1108", "tdWalletString")
    
    conn <- .td_create_context_native(host = host, uid = uid, pwd = pwd,
      temp.database = temp.database, logmech = logmech, logdata = logdata, ...)
    
    # Check if connections pane needs to be notified of the new connection.
    if (!is.null(getOption("connectionObserver"))) {
      tryCatch({
          # Store the code that will be stored with the connections so it can be invoked by the user later from UI.
          connection_str <- paste('library(tdplyr)\ncon <- td_create_context(host = "', host, '", uid = "' , uid , '", pwd = "', pwd , 
                                 '"' , sep = "")
          
           # Store logmech argument and its value if user has specified it.
           if (!is.null(logmech)) {
             connection_str <- paste(connection_str, ', logmech = "', logmech , '"', sep = "")
           }
           # Store temp.database if user has specified it.
           if (!is.null(temp.database)) {
             connection_str <- paste(connection_str, ', temp.database = "', temp.database, '"', sep = "" )
           }
           # Complete the string by adding driver type at the end.
           connection_str <- paste(connection_str,', dType = "' , dType , '")' , sep = "")
           
           # Notify connections pane.
          .onConnectionOpened(conn, connection_str, host, uid)
      }, error = function(e) {
        warning("Could not notify connection observer. ", e$message, call. = FALSE)
      })
    }
  } else {# Default to odbc
    
    # Provide deprecation warning to console - suggesting the user to use Teradata SQL Driver when dType = "odbc".
    .ta.warning("TDR_W1009", showFunctionCall = FALSE)

    conn <- .td_create_context_odbc(dsn = dsn, host = host, uid = uid, pwd = pwd, 
                                    tdWalletString = tdWalletString, database = database,
                                    temp.database = temp.database, ...)
    
    # Assign vantage version using pm.versionInfo table.
    .ta.setVantageVersion(conn)
  }
  
  return(conn)
}

# This internal function works even if an ODBC context already exists
# The native driver can be used interchangeably with the ODBC driver in same session using td_create_context.
#' @importFrom DBI dbConnect
.td_create_context_native <- function(host, uid, pwd = NULL,
                      temp.database = NULL, logmech = NULL, logdata = NULL, ...) {
  
  # Verify if teradatasql package is available
  .checkPkg("teradatasql")
  
  con <- dbConnect(NativeDriver(), host = host, uid = uid, pwd = pwd, logmech = logmech, 
                   logdata = logdata, temp.database = temp.database, from.create.context = TRUE, ...)

  # To notify the user - which logon mechanism is used.
  connection_str <- ""
  if (is.null(logmech))
    connection_str <- "default TD2"
  else
    connection_str <- logmech
  
  # Printing after all the connection is established.
  if (getOption("td.debug.enable"))
    .ta.print("TDR_P1003", connection_str, showStackTrace = FALSE)
  return(invisible(.taConnection()))
}

# Internal function to create connection and context for odbc
# DO NOT import anything from odbc package - so as to support multiple drivers
# This internal function works even if a Native driver context already exists
# ODBC can be used interchangeably with the Native driver in same session using td_create_context.
#' @importFrom DBI dbConnect
.td_create_context_odbc <- function(dsn = NULL, host = NULL, uid = NULL, pwd = NULL, tdWalletString = NULL,
                      database = NULL, temp.database = NULL, ...) {
  # Check if tdWallet is not null and set pwd accordingly
  # If both pwd and tdWallet is set then throw error

  # Verify if odbc package is available
  .checkPkg("odbc")

  # If we have used the Native driver before this in the same session,
  # Then try to cleanup
  .ta.removeNativeTeradataClassDef()

  .loadIODBC()

  # Fix added to set defaultDatabase so that it does not get overridden by odbc.ini
  # Bug in odbc driver 16.20: Simba Jira: https://jira.simba.com/browse/TDS-117
  defaultDatabase <- .getDefaultDatabaseArg(database, list(...))
  if (!is.null(tdWalletString)) {
    if (!is.null(pwd))
      .ta.warning("TDR_W1006")
    pwd <- paste0("$tdwallet(",tdWalletString,")")
  }
  # set dbms.name to Teradata as this is used for subclassing the connection object
  # This is set in case the odbc driver fails to provide it.

  # Re-construct all arguments as a list to be passed to dbConnect
  # This is required to support optional arguments like host and DefaultDatabase
  args <- list(drv = odbc::odbc(), dsn = dsn, uid = uid, pwd = pwd, database = database, dbms.name = "Teradata")
  if (!is.null(defaultDatabase))
    args$DefaultDatabase <- defaultDatabase
  if (!is.null(host))
    args$DBCName <- host
  con <- do.call("dbConnect", args)

  # If verification fails then we dont set the context
  .ta.verifyConnection(con)
  # Initialize the context and session and do any garbage collection if required
  .ta.initializeContext(con, temp.database)
  return(invisible(.taConnection()))
}

# Returns a valid defaultDatabase value
#
# params:
#   database: the database param in the connection
#   args: The optional arguments in the connection
#
# returns:
#   NULL if database is not set otherwise a valid default database value
.getDefaultDatabaseArg <- function(database, args) {
  names(args) <- tolower(names(args))
  # if the argument already has defaultDatabase then just return that
  if ("defaultdatabase" %in% names(args)) {
    return(args[["defaultdatabase"]])
  }
  # If the database param is already present then just return that
  # even if it is empty string
  if (is.character(database))
    return(database)
  # if the args has database param then return that
  if ("database" %in% names(args)) {
    return(args[["database"]])
  }
  return(NULL)
}

# This function is called loading of connection pane creation of schema/tables hierarchy.
#' @importFrom DBI dbGetQuery
#' @importFrom DBI SQL
.connectionListDetails <- function(connection, schema = NULL, name = NULL, type = NULL, ...){
  
  # If schema is NULL that means top level hierarchy of databases/schemas should be shown.
  if (is.null(schema)) {
    df <- DBI::dbGetQuery(connection,"SELECT DatabaseName FROM DBC.DatabasesV order by DatabaseName;")
    return(
      data.frame(
        name = df[["DatabaseName"]],
        type = rep("schema", times = length(df[["DatabaseName"]])),
        stringsAsFactors = FALSE
      ))
  }
  
  # Show tables from the selected schema in the connections pane.
  # Get all tables from the selected database/schema.
  sSQL <- DBI::SQL(paste0(
    "select DatabaseName, TableName",
    " from DBC.TablesV",
    " where TableKind in ('O', 'T', 'V')",
    " and DatabaseName (not casespecific) = ", DBI::dbQuoteLiteral(connection, schema), " (not casespecific) order by TableName"
  ))
  
  # Execute and get all tables, views from the selected database.
  df <- DBI::dbGetQuery(connection, sSQL)
  return(data.frame(
    name = df[["TableName"]],
    type = rep("table", times = length(df[["TableName"]])),
    stringsAsFactors = FALSE
  ))
}

# This method is called when a connection is established using td_create_context function.
.onConnectionOpened <- function(connection, code, host, uid) {
  # make sure we have an observer
  observer <- getOption("connectionObserver")
  if (is.null(observer)) {
    print("observer is NULL")
    return(invisible(NULL))
  }
  
  # Use the default database name, cluster name and username to create the display name.
  # Example - DBName-username@host
  dbname = .ta.getDefaultDatabase()
  display_name <- paste(dbname, " - ", uid, "@", host, sep = "")
  
  server_name <- host
  
  # let observer know that connection has opened
  observer$connectionOpened(
    # connection type
    type = "Teradata",
    
    # name displayed in connection pane
    displayName = display_name,
    
    # host key
    host = server_name,
    
    # Icon for connection.
    # This option is used to display any custom icon in the UI for the given connection type.
    # icon = icon,
    
    # Connection code, This is the code that will be saved against the connection in the history
    # of the connections pane.
    # So when user clicks on the name of the stored connection, the code stored will run.
    connectCode = code,
    
    # Disconnection code to be called on disconnect button in the connection pane.
    disconnect = function() {
      tdplyr::td_remove_context()
    },
    
    # Hierarchy of object types supported by the connection.
    listObjectTypes = function() {
      .connectionListObjectTypes(connection)
    },
    
    # Function to decide the hierarchy of the objects to be displayed.
    listObjects = function(...) {
      .connectionListDetails(connection,...)
    },
    
    # Function to display columns and datatypes of Columns.
    listColumns = function(...) {
      .connectionListTableColumns(connection, table,...)
    },
    
    # Table preview code.
    previewObject = function(rowLimit, ...) {
      .connectionPreviewObjectDetails(connection, rowLimit, ...)
    },
    
    # raw connection object
    connectionObject = connection
  )
}

# Function lists first 1000 rows from the selected table.
#' @importFrom dbplyr in_schema
#' @importFrom DBI dbGetQuery
.connectionPreviewObjectDetails <- function(connection, rowLimit, table = NULL, schema = NULL, ...) {
  
  # append schema if specified
  if (!is.null(table) && !is.null(schema)) {
    name <- in_schema(schema, table) 
    return(dbGetQuery(connection, paste("SELECT * FROM", name), n = rowLimit))
  }
}

# Function will list the columns and data types of columns from the selected table to show.
#' @importFrom dbplyr in_schema
.connectionListTableColumns <- function(connection, table, schema = NULL, ...) {
  
  # Get column names.
  cols  <- colnames(tbl(connection, in_schema(schema,table)))
  # Get column datatypes.
  types <- .get_column_datatypes(tbl(connection, in_schema(schema,table)))
  
  return(data.frame(
    name = cols,
    type = types,
    stringsAsFactors = FALSE))
}

# Below function decides the hierarchy of the objects to be displayed in the 
# R studio connections pane.
# It is - schema -> table/views
.connectionListObjectTypes <- function(connection) {
  
  # All databases contain tables/views.
  obj_types <- list(table = list(contains = "data"))
  
  # database contain schema/databases 
  obj_types <- list(schema = list(contains = obj_types))
  
  return(obj_types)
}