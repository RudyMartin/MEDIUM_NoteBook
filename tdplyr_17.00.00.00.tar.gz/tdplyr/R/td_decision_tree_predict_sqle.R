# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.0
# Function Version: 1.0
# 
# ################################################################## 

# Description:
#   The DecisionTreePredict MLE function applies a tree model to a data 
#   input, outputting predicted labels for each data point.
# 
# Args:
#   object -
#     Required Argument.\cr
#     Specifies the name of the tbl_teradata containing the output model 
#     from single_tree_drive\cr
#   
#   object.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "object".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   newdata -
#     Required Argument.\cr
#     Specifies the name of the tbl_teradata containing the attribute names 
#     and the values\cr
#   
#   newdata.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "newdata".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   newdata.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "newdata".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   attr.table.groupby.columns -
#     Required Argument.\cr
#     Specifies the names of the columns on which attribute_table is 
#     partitioned. Each partition contains one attribute of the input 
#     data.\cr
#     Types: character OR vector of Strings (character)
#   
#   attr.table.pid.columns -
#     Required Argument.\cr
#     Specifies the names of the columns that define the data point 
#     identifiers. \cr
#     Types: character OR vector of Strings (character)
#   
#   attr.table.val.column -
#     Required Argument.\cr
#      Specifies the name of the column that contains the input values.\cr
#     Types: character
#   
#   output.response.probdist -
#     Optional Argument.\cr
#     Specifies whether to output probabilities.\cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   accumulate -
#     Optional Argument.\cr
#     Specifies the names of input_table columns to copy to the output 
#     table.\cr
#     Types: character OR vector of Strings (character)
#   
#   output.responses -
#     Optional Argument.\cr
#     Specifies all responses in input table.\cr
#     Types: character OR vector of characters
# 
# Returns:
#   Function returns an object of class "td_decision_tree_predict_sqle" 
#   which is a named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_decision_tree_predict_sqle <- function(
  object = NULL,
  newdata = NULL,
  attr.table.groupby.columns = NULL,
  attr.table.pid.columns = NULL,
  attr.table.val.column = NULL,
  accumulate = NULL,
  output.response.probdist = FALSE,
  output.responses = NULL,
  newdata.partition.column = NULL,
  newdata.order.column = NULL,
  object.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("object", object, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("object.order.column", object.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata", newdata, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata.partition.column", newdata.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata.order.column", newdata.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("attr.table.groupby.columns", attr.table.groupby.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("attr.table.pid.columns", attr.table.pid.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("attr.table.val.column", attr.table.val.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.response.probdist", output.response.probdist, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.responses", output.responses, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(newdata, NULL)
  .validateInputTableDataType(object, "td_decision_tree_mle")
  
  if (.isRefFuncOutput(object, "td_decision_tree_mle")) {
    object <- object[[1]]
  }
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(attr.table.groupby.columns)
  .validateTblHasArgumentColumns(attr.table.groupby.columns, "attr.table.groupby.columns", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(attr.table.pid.columns)
  .validateTblHasArgumentColumns(attr.table.pid.columns, "attr.table.pid.columns", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(attr.table.val.column)
  .validateTblHasArgumentColumns(attr.table.val.column, "attr.table.val.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(newdata.partition.column)
  .validateTblHasArgumentColumns(newdata.partition.column, "newdata.partition.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(newdata.order.column)
  .validateTblHasArgumentColumns(newdata.order.column, "newdata.order.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(object.order.column)
  .validateTblHasArgumentColumns(object.order.column, "object.order.column", object, "object")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AttrTableGroupbyColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(attr.table.groupby.columns, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AttrTablePidColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(attr.table.pid.columns, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AttrTableValColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(attr.table.val.column, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(accumulate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ACCUMULATELABEL")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(accumulate, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(output.response.probdist) && !missing(output.response.probdist)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputResponseProbDist")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.response.probdist, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(output.responses)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Responses")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.responses, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process newdata
  newdata.partition.column <- .teradataCollapseArgVector(newdata.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(newdata)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "Attribute_Table")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, newdata.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(newdata.order.column, "\""))
  
  # Process object
  tableRef <- .teradataOnClauseFromDataFrame(object)
  funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "Model_Table")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(object.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "DecisionTreePredict",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_SQL")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("DecisionTreePredict", engine = .getEngineName("ENGINE_SQL"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(newdata, object)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_decision_tree_predict_sqle", engine = .getEngineName("ENGINE_SQL"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_decision_tree_predict <- td_decision_tree_predict_sqle
