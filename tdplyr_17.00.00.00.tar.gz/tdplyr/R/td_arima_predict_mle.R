# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.5
# 
# ################################################################## 

# Description:
#   The ARIMAPredict function takes as input the ARIMA model produced by
#   the function ARIMA and predicts a specified number of future values
#   (time point forecasts) for the modeled sequence.
# 
# Args:
#   object -
#     Required Argument.\cr
#     Specifies the name of the tbl_teradata that contains the model. This 
#     tbl_teradata is the model tbl_teradata that is output by the ta.arima 
#     function.\cr
#   
#   object.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "object".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   object.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "object".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   residual.table -
#     Required Argument.\cr
#     Specifies the name of the tbl_teradata that contains the original 
#     input parameters and their residuals. This tbl_teradata is the 
#     residual tbl_teradata that is output by the ta.arima function.\cr
#   
#   residual.table.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "residual.table".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   residual.table.order.column -
#     Required Argument.\cr
#     Specifies Order By columns for "residual.table".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   n.ahead -
#     Optional Argument.\cr
#     Specifies the number of steps to forecast after the end of the time 
#     series. This value must be a positive integer.\cr
#     Default Value: 1\cr
#     Types: integer
#   
#   partition.columns -
#     Required Argument.\cr
#     Specifies the partition columns that are in model tbl_teradata and 
#     residual table.\cr
#     Types: character OR vector of Strings (character)
#   
#   object.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "object". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   residual.table.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "residual.table". The argument is used to 
#     ensure deterministic results for functions which produce results that 
#     vary from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_arima_predict_mle" which is a 
#   named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_arima_predict_mle <- function(
  object = NULL,
  residual.table = NULL,
  n.ahead = 1,
  partition.columns = NULL,
  object.sequence.column = NULL,
  residual.table.sequence.column = NULL,
  object.partition.column = NULL,
  residual.table.partition.column = NULL,
  object.order.column = NULL,
  residual.table.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("object", object, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("object.partition.column", object.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("object.order.column", object.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("residual.table", residual.table, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("residual.table.partition.column", residual.table.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("residual.table.order.column", residual.table.order.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("n.ahead", n.ahead, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("partition.columns", partition.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("object.sequence.column", object.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("residual.table.sequence.column", residual.table.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  if (.isRefFuncOutput(object, "td_arima_mle")) {
    object <- object[[1]]
  }
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(object, "td_arima_mle")
  .validateInputTableDataType(residual.table, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(partition.columns)
  .validateTblHasArgumentColumns(partition.columns, "partition.columns", object, "object")
  
  .validateInputColumnsNotEmpty(object.sequence.column)
  .validateTblHasArgumentColumns(object.sequence.column, "object.sequence.column", object, "object")
  
  .validateInputColumnsNotEmpty(residual.table.sequence.column)
  .validateTblHasArgumentColumns(residual.table.sequence.column, "residual.table.sequence.column", residual.table, "residual.table")
  
  .validateInputColumnsNotEmpty(object.partition.column)
  .validateTblHasArgumentColumns(object.partition.column, "object.partition.column", object, "object")
  
  .validateInputColumnsNotEmpty(residual.table.partition.column)
  .validateTblHasArgumentColumns(residual.table.partition.column, "residual.table.partition.column", residual.table, "residual.table")
  
  .validateInputColumnsNotEmpty(object.order.column)
  .validateTblHasArgumentColumns(object.order.column, "object.order.column", object, "object")
  
  .validateInputColumnsNotEmpty(residual.table.order.column)
  .validateTblHasArgumentColumns(residual.table.order.column, "residual.table.order.column", residual.table, "residual.table")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PartitionColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(partition.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StepAhead")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(n.ahead, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(object.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("ModelTable:", .teradataCollapseArgVector(object.sequence.column, "")))
  }
  
  if (!is.null(residual.table.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("ResidualTable:", .teradataCollapseArgVector(residual.table.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process object
  object.partition.column <- .teradataCollapseArgVector(object.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(object)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "ModelTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, object.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(object.order.column, "\""))
  
  # Process residual.table
  residual.table.partition.column <- .teradataCollapseArgVector(residual.table.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(residual.table)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "ResidualTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, residual.table.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(residual.table.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "ArimaPredictor",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("ArimaPredictor", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(object, residual.table)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_arima_predict_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_arima_predict <- td_arima_predict_mle
