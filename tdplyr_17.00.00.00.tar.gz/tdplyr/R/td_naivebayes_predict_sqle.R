# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.1
# Function Version: 1.0
# 
# ################################################################## 

# Description:
#   The NaiveBayesPredict function uses the model output by the
#   			NaiveBayesReduce function to predict the outcomes for a test set 
#   of data.
# 
# Args:
#   formula -
#     Optional Argument.\cr
#     An object of class "formula". Specifies the model to be fitted. Only 
#     basic formula of the (col1 ~ col2 + col3 +...) form are supported and 
#     all variables must be from the same tbl_teradata object. The 
#     response should be column of type numeric or logical.
#   
#   modeldata -
#     Required Argument.\cr
#     This tbl_teradata contains the model data.\cr
#   
#   modeldata.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "modeldata".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   newdata -
#     Required Argument.\cr
#     This tbl_teradata defining the input test data.\cr
#   
#   newdata.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "newdata".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   id.col -
#     Required Argument.\cr
#     Specify the name of the column that contains the ID that uniquely 
#     identifies the test input data.\cr
#     Types: character
#   
#   responses -
#     Required Argument.\cr
#     Specify a list of Responses to output.\cr
#     Types: character OR vector of characters
# 
# Returns:
#   Function returns an object of class "td_naivebayes_predict_sqle" 
#   which is a named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_naivebayes_predict_sqle <- function(
  modeldata = NULL,
  newdata = NULL,
  id.col = NULL,
  responses = NULL,
  formula = NULL,
  newdata.order.column = NULL,
  modeldata.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("modeldata", modeldata, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("modeldata.order.column", modeldata.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata", newdata, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata.order.column", newdata.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("id.col", id.col, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("responses", responses, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("formula", formula, TRUE, "formula"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(newdata, NULL)
  .validateInputTableDataType(modeldata, "td_naivebayes_mle")
  
  if (.isRefFuncOutput(modeldata, "td_naivebayes_mle")) {
    formula <- modeldata$attributes$formula
    modeldata <- modeldata[[1]]
  } else {
    if(is.null(formula)){
      .ta.stop("Formula is required when model is not of type td_naivebayes_mle")
    }
  }
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(id.col)
  .validateTblHasArgumentColumns(id.col, "id.col", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(newdata.order.column)
  .validateTblHasArgumentColumns(newdata.order.column, "newdata.order.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(modeldata.order.column)
  .validateTblHasArgumentColumns(modeldata.order.column, "modeldata.order.column", modeldata, "modeldata")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IdCol")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(id.col, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Responses")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(responses, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  # Let's process formula argument
  formula.terms.matrix <- .ta.parse.formula(formula, newdata)
  # Target Column
  mc.target.column <- formula.terms.matrix[1,1]
  # numerical input columns
  numerical_inputs <- .ta.getColumnsByType(formula.terms.matrix, newdata, "numerical")
  if (length(numerical_inputs) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NumericInputs")
    numericalColumnsList <- .teradataCollapseArgVector(numerical_inputs, "'")
    funcOtherArgs <- c(funcOtherArgs, numericalColumnsList)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
    mc.sql.specific.attributes[["NumericInputs"]] <- numericalColumnsList
  }
  
  # categorical input columns
  categorical_inputs <- .ta.getColumnsByType(formula.terms.matrix, newdata, "categorical")
  if (length(categorical_inputs) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CategoricalInputs")
    categoricalColumnsList <- .teradataCollapseArgVector(categorical_inputs, "'")
    funcOtherArgs <- c(funcOtherArgs, categoricalColumnsList)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
    mc.sql.specific.attributes[["CategoricalInputs"]] <- categoricalColumnsList
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process newdata
  tableRef <- .teradataOnClauseFromDataFrame(newdata)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "ANY")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(newdata.order.column, "\""))
  
  # Process modeldata
    tableRef <- .teradataOnClauseFromDataFrame(modeldata)
    funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "Model")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(modeldata.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "NaiveBayesPredict",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_SQL")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("NaiveBayesPredict", engine = .getEngineName("ENGINE_SQL"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(newdata, modeldata)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_naivebayes_predict_sqle", engine = .getEngineName("ENGINE_SQL"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_naivebayes_predict <- td_naivebayes_predict_sqle
