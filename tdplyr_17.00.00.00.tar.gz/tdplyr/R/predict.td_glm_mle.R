# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' @export
predict.td_glm_mle <- function(modeldata = NULL,
                           newdata = NULL,
                           terms = NULL,
                           family = NULL,
                           linkfunction = "CANONICAL",
                           newdata.order.column = NULL) {
  td_glm_predict_sqle(modeldata = modeldata,
                 newdata = newdata,
                 terms = terms,
                 family = family,
                 linkfunction = linkfunction,
                 newdata.order.column = newdata.order.column)
}
