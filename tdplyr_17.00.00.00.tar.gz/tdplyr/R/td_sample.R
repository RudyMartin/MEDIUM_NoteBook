#
# Copyright 2019 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: Adithya Avvaru (adithya.avvaru@teradata.com)
# Secondary Owner:
#
###################################################################################

#' Selects one or more samples of rows
#'
#' This function reduces the number of rows to be considered for further processing by returning 
#' one or more samples of rows. Sampling can be done in either of the three ways mentioned below:
#' \enumerate{
#' \item Specifying list of numbers (number of rows in each sample)
#' \item Specifying list of fractions (proportion of the total number of rows in each sample)
#' \item Specifying list of numbers/fractions based on conditions (stratified sampling)
#' }
#' Stratified random sampling is a sampling method that divides a heterogeneous population of 
#' interest into homogeneous subgroups, or strata, and then takes a random sample from each of
#' those subgroups. The arguments 'when_then' and 'case_else' help in stratified sampling.\cr
#' Usage notes for the arguments 'n', 'case_else' and each 'then' element in the argument 
#' 'when_then':
#' \enumerate{
#' \item No more than 16 samples can be requested per count or fraction list i.e. the arguments
#' cannot take a list of elements with more than 16 samples.
#' \item Sum of elements in the list containing fraction values should not be greater than 1 and 
#' each value should be greater than 0.
#' \item If the list contains a float value greater than 1, e.g. \code{c(3, 2.4)}, then the floor 
#' value is considered for sampling i.e. first sample contains 3 rows and second sample contains 2 rows.
#' }
#' Note : 
#' \enumerate{
#' \item A new column 'sampleid' is added to the sampled data to determine the sample set each row  
#' belongs to in the sample. If the parent tbl object already has the column 'sampleid',  
#' this column is removed in the sampled data. This case occurs when multiple or consecutive 
#' sample operations are performed. To retain the 'sampleid' columns across multiple 
#' \code{td_sample} operations, the column must be renamed using \code{mutate} function.
#' \item If the number of samples requested exceed the number of rows available, the sample 
#' size is reduced to the number of remaining rows when the argument `with.replacement` is set to 
#' FALSE.
#' }
#' 
#' @param df Required Argument.\cr
#'           Specifies the teradata_tbl object from which rows are sampled.
#' @param n Optional Argument.\cr
#'          Required if the argument 'when_then' is not specified.\cr
#'          Specifies the number of rows or proportion of rows to be sampled.\cr
#'          Types: numeric OR vector of numerics\cr
#'          Examples: 
#'          \enumerate{\item \code{c(1, 2)} - to get 2 samples, one containing 1 row and the other
#'          containing 2 rows\cr
#'          \item \code{2} - to get one sample containing two rows 
#'          \item \code{c(0.3, 0.5)} -  to get 2 samples, one containing 30\% of rows and the other 
#'          containing 50\% of rows of all samples}
#' @param with.replacement Optional Argument.\cr
#'                         Specifies if sampling should be done with replacement or not.\cr
#'                         If this argument is FALSE, sampling is done without replacement.\cr
#'                         Default value : FALSE.\cr
#'                         Types: logical
#' @param randomize Optional Argument.\cr
#'                  Specifies whether rows are sampled randomly across AMPs (RANDOMIZED 
#'                  ALLOCATION) or proportionate to the number of qualified rows per AMP 
#'                  (PROPORTIONAL ALLOCATION). If this argument is FALSE, sampling is done 
#'                  proportionate to the number of qualified rows per AMP.\cr
#'                  Note : The proportional allocation option does not provide a simple random 
#'                         sample of the entire population. It provides a random sample stratified
#'                         by AMPs, but it is much faster, especially for very large samples.\cr
#'                  Default value : FALSE.\cr
#'                  Types: logical
#' @param when_then Optional Argument.\cr
#'                  Required when the argument 'n' is not specified.\cr
#'                  Specifies the string conditions ('when' element) and the number of samples 
#'                  ('then' element) required to generate sample rows for each 'when' condition.
#'                  \cr
#'                  Default value : NULL \cr
#'                  Types : Named list of numbers OR named list of vector of numbers.\cr
#'                  Example: Suppose sampling is to be performed on a teradata_tbl object having
#'                  columns 'col1' and 'col2'.\cr
#'                  \code{when_then <- list("col1 < 20" = 2, "col2 <> 'value'" = c(1, 3), 
#'                  "col1 = 30" = c(2, 1))}\cr
#'                  The equivalent when - then clauses for this example argument is:\cr
#'                  \enumerate{
#'                  \item \code{WHEN col1 < 20 THEN 2} \item \code{WHEN col2 <> 'value' THEN 1, 3}
#'                  \item \code{WHEN col1 = 30 THEN 2, 1}
#'                  }
#' @param case_else Optional Argument.\cr
#'                  Specifies the number of samples to be sampled from rows where none of the 
#'                  conditions in 'when_then' are met.\cr
#'                  Default value : c() \cr
#'                  Types : numeric OR vector of numerics\cr
#'                  Examples : The equivalent else clause for the argument value:
#'                  \enumerate{
#'                  \item \code{c(1,2)} is \code{ELSE 1, 2}
#'                  \item \code{2} is \code{ELSE 2}
#'                  \item \code{c(0.3, 0.5)} is \code{ELSE 0.3, 0.5}
#'                  }
#' @return A `tbl` object containing the sampled data.
#' @seealso \code{sample}, \code{td_sampling}
#' @examples
#' \donttest{
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#' 
#' # Creates the table "antiselect_input" if it is not present already.
#' loadExampleData("antiselect_example", "antiselect_input")
#' 
#' # Creates a teradata_tbl object.
#' df <- tbl(con, "antiselect_input") # Table contain 7 rows in total.
#' 
#' # Example 1: Get two samples of 3 rows and 2 rows each.
#' td_sample(df = df, n = c(3,2))
#'
#' # Example 2: Get a sample of 3 rows. Note that all the rows have sampleid = 1.
#' td_sample(df = df, n = 3)
#'
#' # Example 3: Get 50% of total rows. Here, it is 50% of 7 rows.
#' td_sample(df = df, n = 0.5)
#'   
#' # Example 4: Get 10 rows from a tbl object of 7 rows using with.replacement = TRUE. 
#' #            'randomize = TRUE' will ensure sampling is done across AMPs in large datasets.
#' td_sample(df = df, n = 10, with.replacement = TRUE, randomize = TRUE)
#' 
#' # Example 5: Get 5 rows which satisfy the condition 'orderid < 300' from a tbl object.
#' #            Here, only three rows are returned as the total number of rows which satisfy this
#' #            condition is 3. If with.replacement = TRUE is specified, then 5 rows will be 
#' #            returned.
#' td_sample(df, when_then = list("orderid < 300" = 5))
#'
#' # Example 6: Get 4 rows (1 row in first sample and 3 rows in second sample) which satisfy the 
#' #            condition 'orderid < 300' from a tbl object.
#' #            Here, only 2 rows have sampleid = 2 as the total number of rows which satisfy
#' #            this condition is 3. If with.replacement = TRUE is specified, then 3 rows having 
#' #            sampleid = 2 will be returned.
#' td_sample(df, when_then = list("orderid < 300" = c(1,3)))
#' 
#' # Example 7: Using stratified sampling with multiple conditions : 4 rows (1 row in first sample
#' #            and 3 rows in second sample) when orderid < 300 and 2 rows when priority != "high".
#' td_sample(df, when_then = list("orderid < 300" = c(1,3), "priority <> 'high'" = 2))
#' 
#' # Example 8: Using 'case_else' argument for stratified sampling : 2 rows when orderid < 300 and
#' #            3 rows from the remaining rows (rows which doesn't satisfy orderid < 300).
#' td_sample(df, when_then = list("orderid < 300" = 2), case_else = 3)
#' }


#' @export
td_sample <- function(df = NULL, n = NULL, with.replacement = FALSE, randomize = FALSE, 
                      when_then = NULL, case_else = c()) {
  
  # Handles the case when the argument 'when_then' contain c(1,2,3) or list(1,3,4) or 
  # list("orderid < 300" = 5, c(2,3)))
  if (!is.null(when_then) && (is.null(names(when_then)) ||
      any(unlist(lapply(names(when_then), function(x) {identical(x, "")})))) ) {
    .ta.stop("TDR_E3104", "argument", "when_then", 
             "Named list of numbers or named list of vector of numbers")
  }
  
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("df", df, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("n", n, TRUE, c("numeric","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("with.replacement", with.replacement, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("randomize", randomize, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("when_then", when_then, TRUE, c("list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("case_else", case_else, TRUE, c("numeric", "list")))
  
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments.
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument.
  .validateArgumentTypes(argInfoMatrix)
  
  if (length(when_then) > 0) {
    error_msgs <- c()
    msg  <- "Each 'then' element of the argument 'when_then' must be of 'numeric' datatype or a vector of 'numeric' datatypes. Found : "
    for (when_cond in names(when_then)) {
      if (!class(when_then[[when_cond]]) %in% c("numeric", "list")) {
        val <- paste0("'", toString(when_then[[when_cond]]), "'")
        if (length(when_then[[when_cond]]) > 1) {
          val <- paste0("'(", toString(when_then[[when_cond]]), ")'")
        }
        error_msgs <- c(error_msgs, val)
      }
    }
    if (length(error_msgs) > 0) {
      .ta.stop("TDR_E3005", paste0(msg, paste0(error_msgs, collapse = ", "), "."))
    }
  }
  
  # Check to make sure input table types is data frame type.
  .validateInputTableDataType(df, NULL)
  
  # Validate other cases.
  .validateSampleArguments(n, when_then, case_else)
  
  query <- .generate_sample_query(df = df, n = n, with.replacement = with.replacement, randomize = randomize,
                                  when_then = when_then, case_else = case_else)
  
  .tbl_query(remote_con(df), build_sql(query, con = remote_con(df)))
}

# This function generate the Sample SQL query given the required arguments.
# Arguments' description is same as that of sample API.
#
#' @importFrom dplyr sql_translate_env
#' @importFrom dplyr sql
#' @importFrom dbplyr sql_build
#' @importFrom dbplyr sql_render
#' @importFrom dbplyr translate_sql_
#' @importFrom dbplyr build_sql
.generate_sample_query <- function(df = NULL, n = NULL, with.replacement = FALSE, randomize = FALSE, 
                                   when_then = NULL, case_else = c()) {
  
  # Get the columns to be printed in result tbl, as columns_expr.
  columnNames <- colnames(df)
  
  # Removing column with name "sampleid".
  # The word "sampleid" is a reserved Teradata word which user cannot provide as a column name.
  # Only way this column is added is through td_sample().
  # Performing td_sample() on td_sample() either consecutively or with other operations (like filter,
  # select etc) in between will add this column to the tbl object.
  # Keeping only latest sampleid (of current td_sample) as multiple columns cannot have same name.
  columnNames <- columnNames[!columnNames %in% c("sampleid")]
  
  columns_expr <- paste0(columnNames, collapse = ", ")
  
  # Add sampleid as one of the column.
  columns_expr <- paste0(columns_expr, ", SAMPLEID AS ", .teradataQuoteArg("sampleid", quote = "\"", callFromWrapper = FALSE))

  # Generate SQL of the columns_expr.
  columns_expr <- sql(columns_expr)
  
  if (is.null(remote_name(df)) || is.sql(remote_name(df)))
    sql_expr <- sql(paste0("SELECT ", columns_expr, "\nFROM (", remote_query(df), ") AS sample_alias" ))
  else if (is.ident(remote_name(df)))
    sql_expr <- sql(paste0("SELECT ", columns_expr, "\nFROM ", remote_name(df)))
  
  # Build the query based on n or when.
  if (!is.null(n))
    sample_expr <- sql(paste0(n, collapse = ", "))
  else if (length(when_then) > 0) {
    sample_expr <- ""
    
    for (when_cond in names(when_then)) {
      then_value <- paste0(when_then[[when_cond]], collapse = ", ")
      sample_expr <- paste0(sample_expr, "\t WHEN ", when_cond, " THEN ", then_value, "\n")
    }

    if (length(case_else) > 0) {
      case_else_expr <- paste0(case_else, collapse = ", ")
      sample_expr <- paste0(sample_expr, "\t ELSE ", case_else_expr, "\n")
    }
    sample_expr <- paste0(sample_expr,   "\t END\n ")
  }
  
  # Append replacement and randomization parameters based on the arguments.
  sample_value <- "SAMPLE"
  if (isTRUE(with.replacement))
    sample_value <- paste0(sample_value, " WITH REPLACEMENT")
  if (isTRUE(randomize))
    sample_value <- paste0(sample_value, " RANDOMIZED ALLOCATION")
  
  sql_qry <- sql(paste0(sql_expr, "\n", sample_value , "\n", sample_expr))
  return(sql_qry)
}


# This function validates the arguments in the sample API.
#
# Parameters:
# n         : Specifies the number of rows or proportion of rows to be sampled.
# when_then : Specifies the string conditions and the number of samples required to generate 
#             sample rows in each 'when' condition.
# case_else : Specifies number of samples to be sampled from rows where none of the 
#             conditions in 'when' are met.
.validateSampleArguments <- function(n, when_then, case_else) {
  
  if ((!is.null(n) & length(when_then) > 0) || (is.null(n) & length(when_then) == 0)) {
    .ta.stop("TDR_E3009", "n", "when_then")
  }
  if (length(when_then) == 0 & length(case_else) > 0) {
    .ta.stop("TDR_E3101", "case_else", "when_then", "specified")
  }
  
  if (!is.null(n)) {
    # Process only when the argument is passed.
    .validateSampleEachListElement(n, "n")
  }
  if (length(when_then) > 0) {
    # Process only when the argument is passed.
    for (when_cond in names(when_then)) {
      .validateSampleEachListElement(when_then[[when_cond]], "when_then")
    }
  }
  if (length(case_else) > 0) {
    # Process only when the argument is passed.
    .validateSampleEachListElement(case_else, "case_else")
  }
}

# Helper function that validates each list element
#
# Parameters:
# val     : Value of the list element
# argName : Argument name of the list element
.validateSampleEachListElement <- function(val, argName) {
  if (length(val) > 16)
    .ta.stop("TDR_E3202", argName)
  if (any(val < 0))
    .ta.stop("TDR_E3104", "argument", argName, "positive real numbers")
  if (any(val > 0 & val < 1) & any(val == 0)) # Any value between 0 and 1 and at least one value as 0
    .ta.stop("TDR_E3201", paste0("'(", toString(val), ")'"), argName)
  if (any(val > 0 & val < 1) & sum(val) > 1) # Any value between 0 and 1 and sum of all values > 1
    .ta.stop("TDR_E3200", paste0("'(", toString(val), ")'"), argName)
}