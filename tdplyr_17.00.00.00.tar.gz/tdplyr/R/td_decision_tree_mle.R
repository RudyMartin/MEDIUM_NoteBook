# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.31
# 
# ################################################################## 

# Description:
#   The Single Tree Drive function creates a single decision tree in a 
#   distributed
#   			fashion, either weighted or unweighted. The model tbl_teradata 
#   that this function outputs can
#   			be input to the function Single Tree Predict.
# 
# Args:
#   data -
#     Optional Argument.
#     Specifies the name of the tbl_teradata that contains the input data 
#     set. *Required if you omit attribute.table and response.table.
#   
#   attribute.name.columns -
#     Required Argument.
#     Specifies the names of the attribute tbl_teradata columns that define 
#     the attribute.
#     Types: character OR vector of Strings (character)
#   
#   attribute.value.column -
#     Required Argument.
#      Specifies the names of the attribute tbl_teradata columns that 
#     define the value.
#     Types: character
#   
#   id.columns -
#     Required Argument.
#     Specifies the names of the columns in the response and attribute 
#     tables that specify the ID of the instance.
#     Types: character OR vector of Strings (character)
#   
#   attribute.table -
#     Optional Argument.
#     Specifies the name of the tbl_teradata that contains the attribute 
#     names and the values. *Required if you omit data.
#   
#   response.table -
#     Optional Argument.
#     Specifies the name of the tbl_teradata that contains the response 
#     values. *Required if you omit data.
#   
#   response.column -
#     Required Argument.
#     Specifies the name of the response tbl_teradata column that contains 
#     the response variable.
#     Types: character
#   
#   categorical.attribute.table -
#     Optional Argument.
#     The name of the input tbl_teradata containing the categorical 
#     attributes.
#   
#   splits.table -
#     Optional Argument.
#     Specifies the name of the input tbl_teradata that contains the 
#     user-specified splits. By default, the function creates new splits.
#   
#   split.value -
#     Optional Argument.
#     If you specify splits.table, this argument specifies the name of the 
#     column that contains the split value. If approx.splits is "true", 
#     then the default value is splits_valcol; if not, then the default 
#     value is the attribute.value.column argument, node_column.
#     Types: character
#   
#   num.splits -
#     Optional Argument.
#     Specifies the number of splits to consider for each variable. The 
#     function does not consider all possible splits for all attributes.
#     Default Value: 10
#     Types: integer
#   
#   approx.splits -
#     Optional Argument.
#     Specifies whether to use approximate percentiles (true) or exact 
#     percentiles (false). Internally, the function uses percentile values 
#     as split values.
#     Default Value: TRUE
#     Types: logical
#   
#   nodesize -
#     Optional Argument.
#      Specifies the decision tree stopping criterion and the minimum size 
#     of any particular node within each decision tree. 
#     Default Value: 1
#     Types: integer
#   
#   max.depth -
#     Optional Argument.
#     Specifies a decision tree stopping criterion. If the tree reaches a 
#     depth past this value, the algorithm stops looking for splits. 
#     Decision trees can grow up to (2(max_depth+1) - 1) nodes. This 
#     stopping criteria has the greatest effect on function performance. 
#     The maximum value is 60. 
#     Default Value: 30
#     Types: integer
#   
#   weighted -
#     Optional Argument.
#      Specifies whether to build a weighted decision tree. If you specify 
#     "true", then you must also specify the weight.column argument.
#     Default Value: FALSE
#     Types: logical
#   
#   weight.column -
#     Optional Argument.
#     Specifies the name of the response tbl_teradata column that contains 
#     the weights of the attribute values.
#     Types: character
#   
#   split.measure -
#     Optional Argument.
#     Specifies the impurity measurement to use while constructing the 
#     decision tree. 
#     Default Value: "gini"
#     Permitted Values: GINI, ENTROPY, CHISQUARE
#     Types: character
#   
#   output.response.probdist -
#     Optional Argument.
#     Switch to enable/disable output of probability distribution for 
#     output labels.
#     Default Value: FALSE
#     Types: logical
#   
#   response.probdist.type -
#     Optional Argument.
#     Specifies the type of algorithm to use to generate output probability 
#     distribution for output labels. Uses one of Laplace, Frequency or 
#     RawCounts to generate Probability Estimation Trees (PET) based 
#     distributions.
#     Default Value: "Laplace"
#     Permitted Values: Laplace, Frequency, RawCount
#     Types: character
#   
#   categorical.encoding -
#     Optional Argument.
#     Specifies which encoding method is used for categorical variables.
#     Default Value: "graycode"
#     Permitted Values: graycode, hashing
#     Types: character
#   
#   attribute.table.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "attribute.table". The argument is used to 
#     ensure deterministic results for functions which produce results that 
#     vary from run to run.
#     Types: character OR vector of Strings (character)
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
#   
#   categorical.attribute.table.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "categorical.attribute.table". The argument is 
#     used to ensure deterministic results for functions which produce 
#     results that vary from run to run.
#     Types: character OR vector of Strings (character)
#   
#   response.table.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "response.table". The argument is used to 
#     ensure deterministic results for functions which produce results that 
#     vary from run to run.
#     Types: character OR vector of Strings (character)
#   
#   splits.table.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "splits.table". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_decision_tree_mle" which is a 
#   named list containing Teradata tbl objects.
#   Named list members can be referenced directly with the "$" operator 
#   using following names:\enumerate{\item model.table\item 
#   intermediate.splits.table\item final.response.tableto\item output}
# 
# 
#' @export
td_decision_tree_mle <- function(
  data = NULL,
  attribute.name.columns = NULL,
  attribute.value.column = NULL,
  id.columns = NULL,
  attribute.table = NULL,
  response.table = NULL,
  response.column = NULL,
  categorical.attribute.table = NULL,
  splits.table = NULL,
  split.value = NULL,
  num.splits = 10,
  approx.splits = TRUE,
  nodesize = 100,
  max.depth = 30,
  weighted = FALSE,
  weight.column = NULL,
  split.measure = "gini",
  output.response.probdist = FALSE,
  response.probdist.type = "Laplace",
  categorical.encoding = "graycode",
  attribute.table.sequence.column = NULL,
  data.sequence.column = NULL,
  categorical.attribute.table.sequence.column = NULL,
  response.table.sequence.column = NULL,
  splits.table.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("attribute.name.columns", attribute.name.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("attribute.value.column", attribute.value.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("id.columns", id.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("attribute.table", attribute.table, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("response.table", response.table, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("response.column", response.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("categorical.attribute.table", categorical.attribute.table, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("splits.table", splits.table, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("split.value", split.value, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("num.splits", num.splits, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("approx.splits", approx.splits, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("nodesize", nodesize, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("max.depth", max.depth, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("weighted", weighted, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("weight.column", weight.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("split.measure", split.measure, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.response.probdist", output.response.probdist, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("response.probdist.type", response.probdist.type, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("categorical.encoding", categorical.encoding, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("attribute.table.sequence.column", attribute.table.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("categorical.attribute.table.sequence.column", categorical.attribute.table.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("response.table.sequence.column", response.table.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("splits.table.sequence.column", splits.table.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure either of the input tables are provided
  if (is.null(data) && (is.null(attribute.table) || is.null(response.table)) || (!is.null(data) && (!is.null(attribute.table) || !is.null(response.table)))) {
    .ta.stop("TDR_E3009","data","attribute.table and response.table")
  }
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(attribute.table, NULL)
  .validateInputTableDataType(data, NULL)
  .validateInputTableDataType(categorical.attribute.table, NULL)
  .validateInputTableDataType(response.table, NULL)
  .validateInputTableDataType(splits.table, NULL)
  
  # Check for permitted values
  split.measurePermittedValues <- list("GINI", "ENTROPY", "CHISQUARE")
  .validatePermittedValues(split.measure, split.measurePermittedValues)
  
  response.probdist.typePermittedValues <- list("LAPLACE", "FREQUENCY", "RAWCOUNT")
  .validatePermittedValues(response.probdist.type, response.probdist.typePermittedValues)
  
  categorical.encodingPermittedValues <- list("GRAYCODE", "HASHING")
  .validatePermittedValues(categorical.encoding, categorical.encodingPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(attribute.name.columns)
  if(!is.null(data)){
    .validateTblHasArgumentColumns(attribute.name.columns, "attribute.name.columns", data, "data")
  }else if(!is.null(attribute.table)){
    .validateTblHasArgumentColumns(attribute.name.columns, "attribute.name.columns", attribute.table, "attribute.table")
  }
  
  .validateInputColumnsNotEmpty(id.columns)
  #manually added code specific to this function.
  if(!is.null(data)){
    .validateTblHasArgumentColumns(id.columns, "id.columns", data, "data")
  } else if(!is.null(attribute.table)){
    .validateTblHasArgumentColumns(id.columns, "id.columns", attribute.table, "attribute.table")
  }
  
  .validateInputColumnsNotEmpty(attribute.value.column)
  #manually added code specific to this function.
  if(!is.null(data)){
    .validateTblHasArgumentColumns(attribute.value.column, "attribute.value.column", data, "data")
  } else if(!is.null(attribute.table)){
    .validateTblHasArgumentColumns(attribute.value.column, "attribute.value.column", attribute.table, "attribute.table")
  }
  
  .validateInputColumnsNotEmpty(response.column)
  #manually added code specific to this function.
  if(!is.null(data)){
    .validateTblHasArgumentColumns(response.column, "response.column", data, "data")
  } else if(!is.null(response.table)){
    .validateTblHasArgumentColumns(response.column, "response.column", response.table, "response.table")
  }
  
  .validateInputColumnsNotEmpty(split.value)
  .validateTblHasArgumentColumns(split.value, "split.value", splits.table, "splits.table")
  
  .validateInputColumnsNotEmpty(weight.column)
  .validateTblHasArgumentColumns(weight.column, "weight.column", data, "data")
  
  .validateInputColumnsNotEmpty(attribute.table.sequence.column)
  .validateTblHasArgumentColumns(attribute.table.sequence.column, "attribute.table.sequence.column", attribute.table, "attribute.table")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(categorical.attribute.table.sequence.column)
  .validateTblHasArgumentColumns(categorical.attribute.table.sequence.column, "categorical.attribute.table.sequence.column", categorical.attribute.table, "categorical.attribute.table")
  
  .validateInputColumnsNotEmpty(response.table.sequence.column)
  .validateTblHasArgumentColumns(response.table.sequence.column, "response.table.sequence.column", response.table, "response.table")
  
  .validateInputColumnsNotEmpty(splits.table.sequence.column)
  .validateTblHasArgumentColumns(splits.table.sequence.column, "splits.table.sequence.column", splits.table, "splits.table")
  
  # Generate temp table names for output table parameters if any.
  model.tableTempTableName <- .teradataGenerateTempTableName("td_decision_tree_mle0_", use.default.database = TRUE, gc.onQuit = TRUE)
  intermediate.splits.tableTempTableName <- .teradataGenerateTempTableName("td_decision_tree_mle1_", use.default.database = TRUE, gc.onQuit = TRUE)
  final.response.tabletoTempTableName <- .teradataGenerateTempTableName("td_decision_tree_mle2_", use.default.database = TRUE, gc.onQuit = TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_decision_tree_mle.internal)
  Call[["model.tableTempTableName"]] <- model.tableTempTableName
  Call[["intermediate.splits.tableTempTableName"]] <- intermediate.splits.tableTempTableName
  Call[["final.response.tabletoTempTableName"]] <- final.response.tabletoTempTableName
  
  retval <- NULL
  tryCatch({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_decision_tree_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(endTime - startTime)
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_decision_tree_mle.internal <- function(
  data = NULL,
  attribute.name.columns = NULL,
  attribute.value.column = NULL,
  id.columns = NULL,
  attribute.table = NULL,
  response.table = NULL,
  response.column = NULL,
  categorical.attribute.table = NULL,
  splits.table = NULL,
  split.value = NULL,
  num.splits = 10,
  approx.splits = TRUE,
  nodesize = 100,
  max.depth = 30,
  weighted = FALSE,
  weight.column = NULL,
  split.measure = "gini",
  output.response.probdist = FALSE,
  response.probdist.type = "Laplace",
  categorical.encoding = "graycode",
  attribute.table.sequence.column = NULL,
  data.sequence.column = NULL,
  categorical.attribute.table.sequence.column = NULL,
  response.table.sequence.column = NULL,
  splits.table.sequence.column = NULL,
  model.tableTempTableName = NULL,
  intermediate.splits.tableTempTableName = NULL,
  final.response.tabletoTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("OutputTable", "IntermediateSplitsTable", "SaveFinalResponseTableTo")
  funcOutputArgs <- c(model.tableTempTableName, intermediate.splits.tableTempTableName, final.response.tabletoTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AttributeNameColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(attribute.name.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IdColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(id.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AttributeValueColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(attribute.value.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ResponseColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(response.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  if (!is.null(split.value)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SplitsValueColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(split.value,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(weight.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "WeightColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(weight.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(num.splits) && !missing(num.splits)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NumSplits")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(num.splits, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(approx.splits) && !missing(approx.splits)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ApproxSplits")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(approx.splits, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(nodesize) && !missing(nodesize)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MinNodeSize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(nodesize, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(max.depth)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxDepth")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(max.depth, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(split.measure) && !missing(split.measure)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SplitMeasure")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(split.measure, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(weighted) && !missing(weighted)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Weighted")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(weighted, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(output.response.probdist) && !missing(output.response.probdist)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputResponseProbDist")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.response.probdist, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(response.probdist.type) && !missing(response.probdist.type)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ResponseProbDistType")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(response.probdist.type, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(categorical.encoding) && !missing(categorical.encoding)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CategoricalEncoding")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(categorical.encoding, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(attribute.table.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("AttributeTableName:", .teradataCollapseArgVector(attribute.table.sequence.column, "")))
  }
  
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (!is.null(categorical.attribute.table.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("CategoricalAttributeTableName:", .teradataCollapseArgVector(categorical.attribute.table.sequence.column, "")))
  }
  
  if (!is.null(response.table.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("ResponseTableName:", .teradataCollapseArgVector(response.table.sequence.column, "")))
  }
  
  if (!is.null(splits.table.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("SplitsTable:", .teradataCollapseArgVector(splits.table.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process attribute.table
  if (!is.null(attribute.table)) {
    tableRef <- .teradataOnClauseFromDataFrame(attribute.table)
    funcInputDistribution <- c(funcInputDistribution, "NONE")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "AttributeTableName")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  }
  
  # Process data
  if (!is.null(data)) {
    tableRef <- .teradataOnClauseFromDataFrame(data)
    funcInputDistribution <- c(funcInputDistribution, "NONE")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  }
  
  # Process categorical.attribute.table
  if (!is.null(categorical.attribute.table)) {
    tableRef <- .teradataOnClauseFromDataFrame(categorical.attribute.table)
    funcInputDistribution <- c(funcInputDistribution, "NONE")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "CategoricalAttributeTableName")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  }
  
  # Process response.table
  if (!is.null(response.table)) {
    tableRef <- .teradataOnClauseFromDataFrame(response.table)
    funcInputDistribution <- c(funcInputDistribution, "NONE")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "ResponseTableName")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  }
  
  # Process splits.table
  if (!is.null(splits.table)) {
    tableRef <- .teradataOnClauseFromDataFrame(splits.table)
    funcInputDistribution <- c(funcInputDistribution, "NONE")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "SplitsTable")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "DecisionTree",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("DecisionTree", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database = TRUE, gc.onQuit = TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(attribute.table, data, categorical.attribute.table, response.table, splits.table)
  
  # Return output table data frames.
  result <- list()
  result[["model.table"]] <- .createDataSetObject(.extractTableName(model.tableTempTableName), sourceType = "table", .extractDatabaseName(model.tableTempTableName), is_dplyr_input)
  result[["intermediate.splits.table"]] <- .createDataSetObject(.extractTableName(intermediate.splits.tableTempTableName), sourceType = "table", .extractDatabaseName(intermediate.splits.tableTempTableName), is_dplyr_input)
  result[["final.response.tableto"]] <- .createDataSetObject(.extractTableName(final.response.tabletoTempTableName), sourceType = "table", .extractDatabaseName(final.response.tabletoTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_decision_tree <- td_decision_tree_mle
