# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.15
# 
# ################################################################## 

# Description:
#   The GLMPredict function uses the model output by the function GLM to
#   perform generalized linear model prediction on new input data.
#   Note: This function is only available when tdplyr is connected to
#   Teradata Vantage 1.1 version or later.
# 
# Args:
#   modeldata -
#     Required Argument.
#     Specifies the tbl_teradata containing the model data.
#   
#   modeldata.order.column -
#     Optional Argument.
#     Specifies Order By columns for modeldata.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   newdata -
#     Required Argument.
#     Specifies the tbl_teradata containing the input data.
#   
#   newdata.order.column -
#     Optional Argument.
#     Specifies Order By columns for newdata.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   terms -
#     Optional Argument.
#     Specifies the names of input tbl_teradata columns to copy to the 
#     output table.
#     Types: character OR vector of Strings (character)
#   
#   family -
#     Optional Argument.
#     Specifies the distribution exponential family. The default value is 
#     read from model table. If you specify this argument, you must give it 
#     the same value that you used for the "family" argument of the function  
#     when you generated the model table.
#     Permitted Values: LOGISTIC, BINOMIAL, POISSON, GAUSSIAN, GAMMA, 
#     INVERSE_GAUSSIAN, NEGATIVE_BINOMIAL
#     Types: character
#   
#   linkfunction -
#     Optional Argument.
#     The canonical link functions (default link functions) and the link 
#     functions that are allowed for each exponential family.
#     Note: Use the same value that you used for the "linkfunction" argument of the
#     function  when you generated the model table.
#     Default Value: "CANONICAL"
#     Permitted Values: CANONICAL, IDENTITY, INVERSE, LOG, 
#     COMPLEMENTARY_LOG_LOG, SQUARE_ROOT, INVERSE_MU_SQUARED, LOGIT, 
#     PROBIT, CAUCHIT
#     Types: character
#   
#   output.response.probdist -
#     Optional Argument.
#     Specifies whether to output probabilities.
#     Note: "output.response.probdist" argument support is only available when tdplyr
#     is connected to Vantage 1.1.1 or later versions.
#     Default Value: FALSE
#     Types: logical
#   
#   output.responses -
#     Optional Argument.
#     Specifies responses to output probability.
#     This argument can only be used when output.response.probdist is set to TRUE.
#     Note: "output.responses" argument support is only available when tdplyr
#     is connected to Vantage 1.1.1 or later versions.
#     Permitted Values: 0, 1
#     Types: character OR vector of characters
#   
#   newdata.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "newdata". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
#   
#   modeldata.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "modeldata". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_glm_predict_mle" which is a 
#   named list containing Teradata tbl object.
#   Named list member can be referenced directly with the "$" operator 
#   using name: result.
# 
# 
#' @export
td_glm_predict_mle <- function(
  modeldata = NULL,
  newdata = NULL,
  terms = NULL,
  family = NULL,
  linkfunction = "CANONICAL",
  output.response.probdist = FALSE,
  output.responses = NULL,
  newdata.sequence.column = NULL,
  modeldata.sequence.column = NULL,
  newdata.order.column = NULL,
  modeldata.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("modeldata", modeldata, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("modeldata.order.column", modeldata.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata", newdata, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata.order.column", newdata.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("terms", terms, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("family", family, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("linkfunction", linkfunction, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.response.probdist", output.response.probdist, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.responses", output.responses, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata.sequence.column", newdata.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("modeldata.sequence.column", modeldata.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(newdata, NULL)
  .validateInputTableDataType(modeldata, "td_glm_mle")
  
  if (.isRefFuncOutput(modeldata, "td_glm_mle")) {
    modeldata <- modeldata[[1]]
  }
  
  # Check for permitted values
  familyPermittedValues <- list("LOGISTIC", "BINOMIAL", "POISSON", "GAUSSIAN", "GAMMA", "INVERSE_GAUSSIAN", "NEGATIVE_BINOMIAL")
  .validatePermittedValues(family, familyPermittedValues)
  
  linkfunctionPermittedValues <- list("CANONICAL", "IDENTITY", "INVERSE", "LOG", "COMPLEMENTARY_LOG_LOG", "SQUARE_ROOT", "INVERSE_MU_SQUARED", "LOGIT", "PROBIT", "CAUCHIT")
  .validatePermittedValues(linkfunction, linkfunctionPermittedValues)
  
  output.responsesPermittedValues <- list("0", "1")
  .validatePermittedValues(output.responses, output.responsesPermittedValues)
  
  # To use output.responses, output.response.probdist must be set to TRUE
  if (!is.null(output.responses) && output.response.probdist == FALSE) {
    .ta.stop("TDR_E3101", "output.responses", "output.response.probdist", "set to TRUE")
  }
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(terms)
  .validateTblHasArgumentColumns(terms, "terms", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(newdata.sequence.column)
  .validateTblHasArgumentColumns(newdata.sequence.column, "newdata.sequence.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(modeldata.sequence.column)
  .validateTblHasArgumentColumns(modeldata.sequence.column, "modeldata.sequence.column", modeldata, "modeldata")
  
  .validateInputColumnsNotEmpty(newdata.order.column)
  .validateTblHasArgumentColumns(newdata.order.column, "newdata.order.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(modeldata.order.column)
  .validateTblHasArgumentColumns(modeldata.order.column, "modeldata.order.column", modeldata, "modeldata")
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  if (!is.null(terms)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(terms,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(family)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Family")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(family, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(linkfunction) && !missing(linkfunction)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "LinkFunction")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(linkfunction, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(output.response.probdist) && !missing(output.response.probdist)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputProb")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.response.probdist, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(output.responses)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Responses")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.responses, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(newdata.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(newdata.sequence.column, "")))
  }
  
  if (!is.null(modeldata.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("model:", .teradataCollapseArgVector(modeldata.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process newdata
  tableRef <- .teradataOnClauseFromDataFrame(newdata)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "ANY")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(newdata.order.column, "\""))
  
  # Process modeldata
  tableRef <- .teradataOnClauseFromDataFrame(modeldata)
  funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "model")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(modeldata.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "GLMPredict",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("GLMPredict", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(newdata, modeldata)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_glm_predict_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
