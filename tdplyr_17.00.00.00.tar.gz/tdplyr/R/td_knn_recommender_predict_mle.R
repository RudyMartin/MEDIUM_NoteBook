# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Jeris Alan Jawahar (jeris.jawahar@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.6
# 
# ################################################################## 

# Description:
#   
# 
# Args:
#   ratings.data -
#     Required Argument.\cr
#     The user rating table.\cr
#   
#   ratings.data.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "ratings.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   ratings.data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "ratings.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   weights.data -
#     Required Argument.\cr
#     The tbl_teradata (produced by ta.knnrecommendertrain) containing the 
#     interpolation weights.\cr
#   
#   weights.data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "weights.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   bias.data -
#     Required Argument.\cr
#     The tbl_teradata (produced by ta.knnrecommendertrain) containing the 
#     global, user, and item bias statistics.\cr
#   
#   bias.data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "bias.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   userid.column -
#     Optional Argument.\cr
#     The user id column in the rating table. The default is the first 
#     column in the rating table.\cr
#     Types: character
#   
#   itemid.column -
#     Optional Argument.\cr
#     The item id column in the rating table. The default is the second 
#     column in the rating table.\cr
#     Types: character
#   
#   rating.column -
#     Optional Argument.\cr
#     The rating column in the rating table. The default is the third 
#     column in the rating table.\cr
#     Types: character
#   
#   topk -
#     Optional Argument.\cr
#     Number of items to recommend for each user. The topk highest-rated 
#     items are recommended.\cr
#     Default Value: 3\cr
#     Types: integer
#   
#   showall -
#     Optional Argument.\cr
#     Specifies whether the function outputs only the top k values or all 
#     the values in case many recommendations have the same predicted 
#     rating.\cr
#     Default Value: TRUE\cr
#     Types: logical
#   
#   ratings.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "ratings.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   weights.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "weights.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   bias.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "bias.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_knn_recommender_predict_mle" 
#   which is a named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_knn_recommender_predict_mle <- function(
  object = NULL,
  ratings.data = NULL,
  weights.data = NULL,
  bias.data = NULL,
  userid.column = NULL,
  itemid.column = NULL,
  rating.column = NULL,
  topk = 3,
  ratings.data.sequence.column = NULL,
  weights.data.sequence.column = NULL,
  bias.data.sequence.column = NULL,
  ratings.data.partition.column = NULL,
  ratings.data.order.column = NULL,
  weights.data.order.column = NULL,
  bias.data.order.column = NULL,
  showall = TRUE
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("object", object, TRUE, "ta.data.frame"))
  argInfoMatrix <- rbind(argInfoMatrix, list("ratings.data", ratings.data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("ratings.data.partition.column", ratings.data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("ratings.data.order.column", ratings.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("weights.data", weights.data, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("weights.data.order.column", weights.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("bias.data", bias.data, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("bias.data.order.column", bias.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("userid.column", userid.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("itemid.column", itemid.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("rating.column", rating.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("topk", topk, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("showall", showall, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("ratings.data.sequence.column", ratings.data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("weights.data.sequence.column", weights.data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("bias.data.sequence.column", bias.data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure either object or (weights.data and bias.data) is provided.
  if ((is.null(object) && is.null(weights.data)) || (is.null(object) && is.null(bias.data))){
    .ta.stop("TDR_E3009", "object", "weights.data and bias.data")
  }
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  if (!is.null(object) && !inherits(object, "td_knn_recommender_mle")){
    .ta.stop("TDR_E3002", "object", "td_knn_recommender_mle")   
  }
  
  if (!is.null(object)){
    # If object is not NULL, then initialize weights.data and bias.data from object
    weights.data <- object$weight.model.table
    bias.data <- object$bias.model.table
  }
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(ratings.data, NULL)
  .validateInputTableDataType(weights.data, NULL)
  .validateInputTableDataType(bias.data, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(userid.column)
  .validateTblHasArgumentColumns(userid.column, "userid.column", ratings.data, "ratings.data")
  
  .validateInputColumnsNotEmpty(itemid.column)
  .validateTblHasArgumentColumns(itemid.column, "itemid.column", ratings.data, "ratings.data")
  
  .validateInputColumnsNotEmpty(rating.column)
  .validateTblHasArgumentColumns(rating.column, "rating.column", ratings.data, "ratings.data")
  
  .validateInputColumnsNotEmpty(ratings.data.sequence.column)
  .validateTblHasArgumentColumns(ratings.data.sequence.column, "ratings.data.sequence.column", ratings.data, "ratings.data")
  
  .validateInputColumnsNotEmpty(weights.data.sequence.column)
  .validateTblHasArgumentColumns(weights.data.sequence.column, "weights.data.sequence.column", weights.data, "weights.data")
  
  .validateInputColumnsNotEmpty(bias.data.sequence.column)
  .validateTblHasArgumentColumns(bias.data.sequence.column, "bias.data.sequence.column", bias.data, "bias.data")
  
  .validateInputColumnsNotEmpty(ratings.data.partition.column)
  .validateTblHasArgumentColumns(ratings.data.partition.column, "ratings.data.partition.column", ratings.data, "ratings.data")
  
  .validateInputColumnsNotEmpty(ratings.data.order.column)
  .validateTblHasArgumentColumns(ratings.data.order.column, "ratings.data.order.column", ratings.data, "ratings.data")
  
  .validateInputColumnsNotEmpty(weights.data.order.column)
  .validateTblHasArgumentColumns(weights.data.order.column, "weights.data.order.column", weights.data, "weights.data")
  
  .validateInputColumnsNotEmpty(bias.data.order.column)
  .validateTblHasArgumentColumns(bias.data.order.column, "bias.data.order.column", bias.data, "bias.data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  if (!is.null(userid.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "UserIdColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(userid.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(itemid.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ItemIdColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(itemid.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(rating.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "RatingColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(rating.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(topk) && !missing(topk)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Topk")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(topk, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(showall) && !missing(showall)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "showall")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(showall, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(ratings.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("ratings:", .teradataCollapseArgVector(ratings.data.sequence.column, "")))
  }
  
  if (!is.null(weights.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("weights:", .teradataCollapseArgVector(weights.data.sequence.column, "")))
  }
  
  if (!is.null(bias.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("bias:", .teradataCollapseArgVector(bias.data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process ratings.data
  ratings.data.partition.column <- .teradataCollapseArgVector(ratings.data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(ratings.data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "ratings")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, ratings.data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(ratings.data.order.column, "\""))
  
  # Process weights.data
  tableRef <- .teradataOnClauseFromDataFrame(weights.data)
  funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "weights")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(weights.data.order.column, "\""))
  
  # Process bias.data
  tableRef <- .teradataOnClauseFromDataFrame(bias.data)
  funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "bias")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(bias.data.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "KNNRecommenderPredict",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("KNNRecommenderPredict", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(object, ratings.data, weights.data, bias.data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_knn_recommender_predict_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units = "secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_knn_recommender_predict <- td_knn_recommender_predict_mle
