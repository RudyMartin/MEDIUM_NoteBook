# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' @export
predict.td_knn_recommender_mle <- function(
  object = NULL,
  ratings.data = NULL,
  weights.data = NULL,
  bias.data = NULL,
  userid.column = NULL,
  itemid.column = NULL,
  rating.column = NULL,
  topk = 3,
  ratings.data.sequence.column = NULL,
  weights.data.sequence.column = NULL,
  bias.data.sequence.column = NULL,
  ratings.data.partition.column = NULL,
  ratings.data.order.column = NULL,
  weights.data.order.column = NULL,
  bias.data.order.column = NULL,
  showall = TRUE
) {
  td_knn_recommender_predict_mle(object = object,
                             ratings.data = ratings.data,
                             weights.data = NULL,
                             bias.data = NULL,
                             userid.column = userid.column,
                             itemid.column = itemid.column,
                             rating.column = rating.column,
                             topk = topk,
                             ratings.data.sequence.column = ratings.data.sequence.column,
                             weights.data.sequence.column = weights.data.sequence.column,
                             bias.data.sequence.column = bias.data.sequence.column,
                             ratings.data.partition.column = ratings.data.partition.column,
                             ratings.data.order.column = ratings.data.order.column,
                             weights.data.order.column = weights.data.order.column,
                             bias.data.order.column = bias.data.order.column,
                             showall = TRUE)
}
