# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Jeris Alan Jawahar (jeris.jawahar@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.6
# 
# ################################################################## 

# Description:
#   The NTree function is a hierarchical analysis SQL function that can 
#   build and traverse tree structures on all worker machines. The 
#   function reads the data only once from the disk and creates the trees 
#   in memory.
# 
# Args:
#   data -
#     Required Argument.\cr
#     Specifies the input tbl_teradata containing the input data.\cr
#   
#   data.partition.column -
#     Optional Argument.\cr
#     Specifies Partition By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Default Value: "1"\cr
#     Types: character OR vector of Strings (character)
#   
#   data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   root.node -
#     Required Argument.\cr
#     Specifies the logical SQL expression that defines the root nodes of 
#     the trees (for example, parent.id IS NULL).\cr
#     Types: character
#   
#   node.id -
#     Required Argument.\cr
#     Specifies the SQL expression whose value uniquely identifies a node 
#     in the input tbl_teradata.\cr
#     Note: A node can appear multiple times in the data set, with 
#     different parents.\cr
#     Types: character
#   
#   parent.id -
#     Required Argument.\cr
#     Specifies the SQL expression whose value identifies the parent node.\cr
#     Types: character
#   
#   allow.cycles -
#     Optional Argument.\cr
#     Specifies whether trees can contain cycles. If not, a cycle in the 
#     data set causes the function to throw an exception.\cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   starts.with -
#     Required Argument.\cr
#     Specifies the node from which to start tree traversal.\cr
#     Permitted Values: ROOT, LEAF, or a SQL expression that identifies a node.\cr
#     Types: character
#   
#   mode -
#     Required Argument.\cr
#     Specifies the direction of tree traversal from the start node, either up to 
#     the root node or down to the leaf nodes.\cr
#     Permitted Values: UP, DOWN\cr
#     Types: character
#   
#   output -
#     Required Argument.\cr
#     Specifies when to output a tuple, either at every node along the traversal 
#     path ("all") or only at the end of the traversal path ("end").\cr
#     Default Value: END\cr
#     Permitted Values: END, ALL\cr
#     Types: character
#   
#   max.distance -
#     Optional Argument.\cr
#     Specifies the maximum tree depth.\cr
#     Default Value: 5\cr
#     Types: integer
#   
#   logging -
#     Optional Argument.\cr
#     Specifies whether the function prints log messages.\cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   result -
#     Required Argument.\cr
#     Specifies aggregate operations to perform during tree traversal. The 
#     function reports the result of each aggregate operation in the output 
#     tbl_teradata. The syntax of aggregate is:\cr
#     operation (expression) [ ALIAS alias ], where\cr
#     \enumerate{
#       \item operation is either PATH, SUM, LEVEL, MAX, MIN, IS_CYCLE, AVG, or 
#       PROPAGATE.
#       \item expression is a SQL expression. If operation is LEVEL or IS_CYCLE,
#       then expression must be *. 
#       \item alias is the name of the output tbl_teradata column that contains the 
#       result of the operation.
#     }
#     The default value is the string "operation(expression)" without the quotation
#     marks. For example, PATH(node_name).\cr
#     Note: The function ignores alias if it is the same as an input 
#     tbl_teradata column name.\cr
#     For the path from the "starts.with" node to the last traversed node, 
#     the operations do the following:\cr
#     \enumerate{
#      \item PATH: Outputs the value of expression for each node, separating 
#      values with "->".
#      \item SUM: Computes the value of expression for each node and outputs the
#      sum of these values.
#      \item LEVEL: Outputs the number of hops.
#      \item MAX: Computes the value of expression for each node and outputs the 
#      highest of these values. 
#      \item MIN: Computes the value of expression for each node and outputs the 
#      lowest of these values. 
#      \item IS_CYCLE: Outputs the cycle (if any). 
#      \item AVG: Computes the value of expression for each node and outputs the 
#      average of these values. 
#      \item PROPAGATE: Evaluates expression with the value of the "starts.with" 
#      node and propagates the result to every node.
#     }
#     Types: character
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_ntree_mle" which is a named 
#   list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_ntree_mle <- function(
  data = NULL,
  data.partition.column = "1",
  data.order.column = NULL,
  root.node = NULL,
  node.id = NULL,
  parent.id = NULL,
  allow.cycles = FALSE,
  starts.with = NULL,
  mode = NULL,
  output = NULL,
  max.distance = 5,
  logging = FALSE,
  result = NULL,
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.partition.column", data.partition.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("root.node", root.node, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("node.id", node.id, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("parent.id", parent.id, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("allow.cycles", allow.cycles, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("starts.with", starts.with, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("mode", mode, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("output", output, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("max.distance", max.distance, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("logging", logging, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("result", result, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check for permitted values
  modePermittedValues <- list("UP", "DOWN")
  .validatePermittedValues(mode, modePermittedValues)
  
  outputPermittedValues <- list("END", "ALL")
  .validatePermittedValues(output, outputPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.partition.column)
  if (.isDefaultOrNot(data.partition.column, "1")) {
    .validateTblHasArgumentColumns(data.partition.column, "data.partition.column", data, "data")
  }
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ROOT_NODE")
  funcOtherArgs <- c(funcOtherArgs, root.node)
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "String")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NODE_ID")
  funcOtherArgs <- c(funcOtherArgs, node.id)
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "String")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PARENT_ID")
  funcOtherArgs <- c(funcOtherArgs, parent.id)
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "String")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MODE")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(mode, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  if (!is.null(allow.cycles) && !missing(allow.cycles)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ALLOW_CYCLES")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(allow.cycles, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "STARTS_WITH")
  # 'starts.with' accepts three values. If the value is 'root' or 'leaf' then we wrap it in
  # quotes in the SQL constructed. If the value is an SQL expression, then we send it
  # without quoting in the SQL for the ntree MLE function.
  if(tolower(starts.with) == 'root' || tolower(starts.with) == 'leaf'){
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(starts.with, "'"))
  }else{
    funcOtherArgs <- c(funcOtherArgs, starts.with)
  }
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OUTPUT")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  if (!is.null(max.distance) && !missing(max.distance)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MAX_DISTANCE")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(max.distance, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "RESULT")
  funcOtherArgs <- c(funcOtherArgs, result)
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "String")
  
  if (!is.null(logging) && !missing(logging)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "LOGGING")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(logging, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  if (.isDefaultOrNot(data.partition.column, "1")) {
    data.partition.column <- .teradataCollapseArgVector(data.partition.column, "\"")
  }
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "nTree",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("nTree", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_ntree_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_ntree <- td_ntree_mle
