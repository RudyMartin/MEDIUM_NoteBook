# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 2.6
# 
# ################################################################## 

# Description:
#   The TrainSentimentExtractor function trains a
#   				model; that is, takes training documents and outputs a maximum 
#   entropy
#   			classification model, which it installs on Aster Database. For 
#   information about maximum
#   			entropy, see http://en.wikipedia.org/wiki/Maximum entropy method.
# 
# Args:
#   data -
#     Required Argument.
#     Specifies the name of the tbl_teradata that contains the training 
#     data.
#   
#   text.column -
#     Required Argument.
#     Specifies the name of the input tbl_teradata column that contains the 
#     training data.
#     Types: character
#   
#   sentiment.column -
#     Required Argument.
#     Specifies the name of the input tbl_teradata column that contains the 
#     sentiment values, which are"POS" (positive), "NEG" (negative), and 
#     "NEU" (neutral).
#     Types: character
#   
#   language -
#     Optional Argument.
#     Specifies the language of the training data: "en" (English), "zh_CN" 
#     (Simple Chinese), "zh_TW" (Traditional Chinese).
#     Default Value: "en"
#     Permitted Values: en, zh_CN, zh_TW
#     Types: character
#   
#   model.file -
#     Required Argument.
#     Specifies the name of the file to which the function outputs the 
#     model.
#     Types: character
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_sentiment_trainer_mle" which 
#   is a named list containing Teradata tbl object.
#   Named list member can be referenced directly with the "$" operator 
#   using name: result.
# 
# 
#' @export
td_sentiment_trainer_mle <- function(
  data = NULL,
  text.column = NULL,
  sentiment.column = NULL,
  language = "en",
  model.file = NULL,
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("text.column", text.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("sentiment.column", sentiment.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("language", language, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("model.file", model.file, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check for permitted values
  languagePermittedValues <- list("EN", "ZH_CN", "ZH_TW")
  .validatePermittedValues(language, languagePermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(text.column)
  .validateTblHasArgumentColumns(text.column, "text.column", data, "data")
  
  .validateInputColumnsNotEmpty(sentiment.column)
  .validateTblHasArgumentColumns(sentiment.column, "sentiment.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  # The below 2 commented lines of code are part of earlier manually commented ones. Keeping these
  # commented lines as it is so that the developer will understand if the wrapper is regenerated 
  # later.
  # Generate temp table names for output table parameters if any.
  # output.tableTempTableName <- .teradataGenerateTempTableName("td_sentiment_trainer0_", use.default.database=TRUE, gc.onQuit=TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_sentiment_trainer_mle.internal)
  # The below commented line of code are part of earlier manually commented ones. Keeping these
  # commented lines as it is so that the developer will understand if the wrapper is regenerated 
  # later.
  # Call[["output.tableTempTableName"]] <- output.tableTempTableName
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 0) {
    attr(retval, "class") <- .getSQLMRClass("td_sentiment_trainer_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(endTime - startTime)
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_sentiment_trainer_mle.internal <- function(
  data = NULL,
  text.column = NULL,
  sentiment.column = NULL,
  language = "en",
  model.file = NULL,
  data.sequence.column = NULL
  # The below commented line of code are part of earlier manually commented ones. Keeping these
  # commented lines as it is so that the developer will understand if the wrapper is regenerated 
  # later.
  # output.tableTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  
  # The below 3 commented lines of code are part of earlier manually commented ones. Keeping these
  # commented lines as it is so that the developer will understand if the wrapper is regenerated 
  # later.
  # funcOutputArgsSqlNames <- c("OutputTable")
  # funcOutputArgs <- c(output.tableTempTableName)
  # names(funcOutputArgs) <- funcOutputArgsSqlNames
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TextColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(text.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SentimentColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(sentiment.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ModelFileName")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(model.file, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  if (!is.null(language) && !missing(language)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "InputLanguage")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(language, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "TrainSentimentExtractor",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("TrainSentimentExtractor", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  # The below commented line of code are part of earlier manually commented ones. Keeping these
  # commented lines as it is so that the developer will understand if the wrapper is regenerated 
  # later.
  # result[["output.table"]] <- .createDataSetObject(.extractTableName(output.tableTempTableName), sourceType = "table", .extractDatabaseName(output.tableTempTableName), is_dplyr_input)
  # Note the changes here as well. Wrapper will generate 'result'. But due to earlier manual 
  # changes, which used to be 'output', keeping the 'output' as it is.
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_sentiment_trainer <- td_sentiment_trainer_mle
