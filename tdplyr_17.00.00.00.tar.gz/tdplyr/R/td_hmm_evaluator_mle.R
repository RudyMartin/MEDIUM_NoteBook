# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Jeris Alan Jawahar (jeris.jawahar@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.8
# 
# ################################################################## 

# Description:
#   The HMMEvaluator function measures the probabilities of sequences, 
#   with respect to each trained HMM.
# 
# Args:
#   init.state.prob -
#     Required Argument.
#     init state table
#   
#   init.state.prob.partition.column -
#     Required Argument.
#     Specifies Partition By columns for init.state.prob.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.
#     Types: character OR vector of Strings (character)
#   
#   init.state.prob.order.column -
#     Optional Argument.
#     Specifies Order By columns for init.state.prob.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   state.transition.prob -
#     Required Argument.
#     state transition table
#   
#   state.transition.prob.partition.column -
#     Required Argument.
#     Specifies Partition By columns for state.transition.prob.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.
#     Types: character OR vector of Strings (character)
#   
#   state.transition.prob.order.column -
#     Optional Argument.
#     Specifies Order By columns for state.transition.prob.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   emission.prob -
#     Required Argument.
#     emission probability table
#   
#   emission.prob.partition.column -
#     Required Argument.
#     Specifies Partition By columns for emission.prob.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.
#     Types: character OR vector of Strings (character)
#   
#   emission.prob.order.column -
#     Optional Argument.
#     Specifies Order By columns for emission.prob.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   observation -
#     Required Argument.
#     observation table
#   
#   observation.partition.column -
#     Required Argument.
#     Specifies Partition By columns for observation.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.
#     Types: character OR vector of Strings (character)
#   
#   observation.order.column -
#     Required Argument.
#     Specifies Order By columns for observation.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   state.model.key -
#     Required Argument.
#     The name of the model attribute column in the init.state.prob table.
#     Types: character OR vector of Strings (character)
#   
#   state.key -
#     Required Argument.
#     The name of the state attribute column in the init.state.prob table.
#     Types: character OR vector of Strings (character)
#   
#   state.prob.key -
#     Required Argument.
#     The name of the initial probability column in the init.state.prob 
#     table.
#     Types: character OR vector of Strings (character)
#   
#   trans.model.key -
#     Required Argument.
#     The name of the model attribute column in the state.transition.prob 
#     table.
#     Types: character OR vector of Strings (character)
#   
#   trans.from.key -
#     Required Argument.
#     The name of the source of the state transition column in the 
#     state.transition.prob table.
#     Types: character OR vector of Strings (character)
#   
#   trans.to.key -
#     Required Argument.
#     The name of the target of the state transition column in the 
#     state.transition.prob table.
#     Types: character OR vector of Strings (character)
#   
#   trans.prob.key -
#     Required Argument.
#     The name of the state transition probability column in the 
#     state.transition.prob table.
#     Types: character OR vector of Strings (character)
#   
#   emit.model.key -
#     Required Argument.
#     The name of the model attribute column in the emission.prob table.
#     Types: character OR vector of Strings (character)
#   
#   emit.state.key -
#     Required Argument.
#     The name of the state attribute in the emission.prob table.
#     Types: character OR vector of Strings (character)
#   
#   emit.observed.key -
#     Required Argument.
#     The name of the observation attribute column in the emission.prob 
#     table.
#     Types: character OR vector of Strings (character)
#   
#   emit.prob.key -
#     Required Argument.
#     The name of the emission probability in the emission.prob table.
#     Types: character OR vector of Strings (character)
#   
#   model.key -
#     Required Argument.
#     The name of the column that contains the model attribute. If you 
#     specify this argument, then model_attribute must match a model_key in 
#     the observation.partition clause.
#     Types: character
#   
#   sequence.key -
#     Required Argument.
#     The name of the column that contains the sequence attribute. The 
#     sequence_attribute must be a sequence attribute in the 
#     observation.partition clause.
#     Types: character
#   
#   observed.key -
#     Required Argument.
#     The name of the column that contains the observed symbols. Note: 
#     Observed symbols are case-sensitive.
#     Types: character
#   
#   incremental -
#     Optional Argument.
#      Specifies whether only new sequence probabilities are computed. If 
#     "true" (the default), only new sequence probabilities are computed. 
#     If "false", all probabilities are computed. Note: If the seq.prob.key 
#     argument is not specified, the function cannot determine whether the 
#     observed sequence is new; therefore, all model sequences in the input 
#     tables are treated as new.
#     Default Value: TRUE
#     Types: logical
#   
#   show.rate.change -
#     Optional Argument.
#     If "true" (the default), the function shows the percentage change 
#     that corresponds to the applied model with the difference from 
#     previous predicted probability.
#     Default Value: TRUE
#     Types: logical
#   
#   seq.prob.key -
#     Optional Argument.
#     The function uses the previous value under the column to calculate 
#     the change rate.
#     Types: character
#   
#   skip.key -
#     Optional Argument.
#     The name of the column whose values determine whether the function 
#     skips the row.The function skips the row if the value is "true", 
#     "yes", "y", or "1". The function does not skip the row if the value 
#     is "false", "f", "no", "n", "0", or NULL.
#     Types: character
#   
#   accumulate -
#     Optional Argument.
#     Specifies the names of the columns in input_table that the function 
#     copies to the output table.
#     Types: character OR vector of Strings (character)
#   
#   observation.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "observation". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
#   
#   init.state.prob.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "init.state.prob". The argument is used to 
#     ensure deterministic results for functions which produce results that 
#     vary from run to run.
#     Types: character OR vector of Strings (character)
#   
#   state.transition.prob.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "state.transition.prob". The argument is used 
#     to ensure deterministic results for functions which produce results 
#     that vary from run to run.
#     Types: character OR vector of Strings (character)
#   
#   emission.prob.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "emission.prob". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_hmm_evaluator_mle" which is a 
#   named list containing Teradata tbl object.
#   Named list member can be referenced directly with the "$" operator 
#   using name: result.
# 
# 
#' @export
td_hmm_evaluator_mle <- function(
  init.state.prob = NULL,
  state.transition.prob = NULL,
  emission.prob = NULL,
  observation = NULL,
  state.model.key = NULL,
  state.key = NULL,
  state.prob.key = NULL,
  trans.model.key = NULL,
  trans.from.key = NULL,
  trans.to.key = NULL,
  trans.prob.key = NULL,
  emit.model.key = NULL,
  emit.state.key = NULL,
  emit.observed.key = NULL,
  emit.prob.key = NULL,
  model.key = NULL,
  sequence.key = NULL,
  observed.key = NULL,
  incremental = TRUE,
  show.rate.change = TRUE,
  seq.prob.key = NULL,
  skip.key = NULL,
  accumulate = NULL,
  observation.sequence.column = NULL,
  init.state.prob.sequence.column = NULL,
  state.transition.prob.sequence.column = NULL,
  emission.prob.sequence.column = NULL,
  observation.partition.column = NULL,
  init.state.prob.partition.column = NULL,
  state.transition.prob.partition.column = NULL,
  emission.prob.partition.column = NULL,
  observation.order.column = NULL,
  init.state.prob.order.column = NULL,
  state.transition.prob.order.column = NULL,
  emission.prob.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("init.state.prob", init.state.prob, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("init.state.prob.partition.column", init.state.prob.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("init.state.prob.order.column", init.state.prob.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("state.transition.prob", state.transition.prob, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("state.transition.prob.partition.column", state.transition.prob.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("state.transition.prob.order.column", state.transition.prob.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("emission.prob", emission.prob, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("emission.prob.partition.column", emission.prob.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("emission.prob.order.column", emission.prob.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("observation", observation, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("observation.partition.column", observation.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("observation.order.column", observation.order.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("state.model.key", state.model.key, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("state.key", state.key, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("state.prob.key", state.prob.key, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("trans.model.key", trans.model.key, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("trans.from.key", trans.from.key, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("trans.to.key", trans.to.key, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("trans.prob.key", trans.prob.key, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("emit.model.key", emit.model.key, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("emit.state.key", emit.state.key, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("emit.observed.key", emit.observed.key, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("emit.prob.key", emit.prob.key, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("model.key", model.key, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("sequence.key", sequence.key, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("observed.key", observed.key, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("incremental", incremental, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("show.rate.change", show.rate.change, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seq.prob.key", seq.prob.key, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("skip.key", skip.key, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("observation.sequence.column", observation.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("init.state.prob.sequence.column", init.state.prob.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("state.transition.prob.sequence.column", state.transition.prob.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("emission.prob.sequence.column", emission.prob.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(observation, NULL)
  .validateInputTableDataType(init.state.prob, NULL)
  .validateInputTableDataType(state.transition.prob, NULL)
  .validateInputTableDataType(emission.prob, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(state.model.key)
  .validateTblHasArgumentColumns(state.model.key, "state.model.key", init.state.prob, "init.state.prob")
  
  .validateInputColumnsNotEmpty(state.key)
  .validateTblHasArgumentColumns(state.key, "state.key", init.state.prob, "init.state.prob")
  
  .validateInputColumnsNotEmpty(state.prob.key)
  .validateTblHasArgumentColumns(state.prob.key, "state.prob.key", init.state.prob, "init.state.prob")
  
  .validateInputColumnsNotEmpty(trans.model.key)
  .validateTblHasArgumentColumns(trans.model.key, "trans.model.key", state.transition.prob, "state.transition.prob")
  
  .validateInputColumnsNotEmpty(trans.from.key)
  .validateTblHasArgumentColumns(trans.from.key, "trans.from.key", state.transition.prob, "state.transition.prob")
  
  .validateInputColumnsNotEmpty(trans.to.key)
  .validateTblHasArgumentColumns(trans.to.key, "trans.to.key", state.transition.prob, "state.transition.prob")
  
  .validateInputColumnsNotEmpty(trans.prob.key)
  .validateTblHasArgumentColumns(trans.prob.key, "trans.prob.key", state.transition.prob, "state.transition.prob")
  
  .validateInputColumnsNotEmpty(emit.model.key)
  .validateTblHasArgumentColumns(emit.model.key, "emit.model.key", emission.prob, "emission.prob")
  
  .validateInputColumnsNotEmpty(emit.state.key)
  .validateTblHasArgumentColumns(emit.state.key, "emit.state.key", emission.prob, "emission.prob")
  
  .validateInputColumnsNotEmpty(emit.observed.key)
  .validateTblHasArgumentColumns(emit.observed.key, "emit.observed.key", emission.prob, "emission.prob")
  
  .validateInputColumnsNotEmpty(emit.prob.key)
  .validateTblHasArgumentColumns(emit.prob.key, "emit.prob.key", emission.prob, "emission.prob")
  
  .validateInputColumnsNotEmpty(model.key)
  .validateTblHasArgumentColumns(model.key, "model.key", observation, "observation")
  
  .validateInputColumnsNotEmpty(sequence.key)
  .validateTblHasArgumentColumns(sequence.key, "sequence.key", observation, "observation")
  
  .validateInputColumnsNotEmpty(observed.key)
  .validateTblHasArgumentColumns(observed.key, "observed.key", observation, "observation")
  
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", observation, "observation")
  
  .validateInputColumnsNotEmpty(seq.prob.key)
  .validateTblHasArgumentColumns(seq.prob.key, "seq.prob.key", observation, "observation")
  
  .validateInputColumnsNotEmpty(skip.key)
  .validateTblHasArgumentColumns(skip.key, "skip.key", observation, "observation")
  
  .validateInputColumnsNotEmpty(observation.sequence.column)
  .validateTblHasArgumentColumns(observation.sequence.column, "observation.sequence.column", observation, "observation")
  
  .validateInputColumnsNotEmpty(init.state.prob.sequence.column)
  .validateTblHasArgumentColumns(init.state.prob.sequence.column, "init.state.prob.sequence.column", init.state.prob, "init.state.prob")
  
  .validateInputColumnsNotEmpty(state.transition.prob.sequence.column)
  .validateTblHasArgumentColumns(state.transition.prob.sequence.column, "state.transition.prob.sequence.column", state.transition.prob, "state.transition.prob")
  
  .validateInputColumnsNotEmpty(emission.prob.sequence.column)
  .validateTblHasArgumentColumns(emission.prob.sequence.column, "emission.prob.sequence.column", emission.prob, "emission.prob")
  
  .validateInputColumnsNotEmpty(observation.partition.column)
  .validateTblHasArgumentColumns(observation.partition.column, "observation.partition.column", observation, "observation")
  
  .validateInputColumnsNotEmpty(init.state.prob.partition.column)
  .validateTblHasArgumentColumns(init.state.prob.partition.column, "init.state.prob.partition.column", init.state.prob, "init.state.prob")
  
  .validateInputColumnsNotEmpty(state.transition.prob.partition.column)
  .validateTblHasArgumentColumns(state.transition.prob.partition.column, "state.transition.prob.partition.column", state.transition.prob, "state.transition.prob")
  
  .validateInputColumnsNotEmpty(emission.prob.partition.column)
  .validateTblHasArgumentColumns(emission.prob.partition.column, "emission.prob.partition.column", emission.prob, "emission.prob")
  
  .validateInputColumnsNotEmpty(observation.order.column)
  .validateTblHasArgumentColumns(observation.order.column, "observation.order.column", observation, "observation")
  
  .validateInputColumnsNotEmpty(init.state.prob.order.column)
  .validateTblHasArgumentColumns(init.state.prob.order.column, "init.state.prob.order.column", init.state.prob, "init.state.prob")
  
  .validateInputColumnsNotEmpty(state.transition.prob.order.column)
  .validateTblHasArgumentColumns(state.transition.prob.order.column, "state.transition.prob.order.column", state.transition.prob, "state.transition.prob")
  
  .validateInputColumnsNotEmpty(emission.prob.order.column)
  .validateTblHasArgumentColumns(emission.prob.order.column, "emission.prob.order.column", emission.prob, "emission.prob")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "InitStateModelColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(state.model.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "InitStateColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(state.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "InitStateProbColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(state.prob.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TransAttributeColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(trans.model.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TransFromStateColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(trans.from.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TransToStateColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(trans.to.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TransProbColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(trans.prob.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "EmitModelColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(emit.model.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "EmitStateColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(emit.state.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "EmitObsColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(emit.observed.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "EmitProbColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(emit.prob.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ModelColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(model.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SeqColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(sequence.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ObsColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(observed.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(accumulate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(accumulate,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(seq.prob.key)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SeqProbColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(seq.prob.key,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(skip.key)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SkipColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(skip.key,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(show.rate.change) && !missing(show.rate.change)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ShowChangeRate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(show.rate.change, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(incremental) && !missing(incremental)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Incremental")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(incremental, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(observation.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("observation:", .teradataCollapseArgVector(observation.sequence.column, "")))
  }
  
  if (!is.null(init.state.prob.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InitStateProb:", .teradataCollapseArgVector(init.state.prob.sequence.column, "")))
  }
  
  if (!is.null(state.transition.prob.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("TransProb:", .teradataCollapseArgVector(state.transition.prob.sequence.column, "")))
  }
  
  if (!is.null(emission.prob.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("EmissionProb:", .teradataCollapseArgVector(emission.prob.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process observation
  observation.partition.column <- .teradataCollapseArgVector(observation.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(observation)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "observation")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, observation.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(observation.order.column, "\""))
  
  # Process init.state.prob
  init.state.prob.partition.column <- .teradataCollapseArgVector(init.state.prob.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(init.state.prob)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InitStateProb")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, init.state.prob.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(init.state.prob.order.column, "\""))
  
  # Process state.transition.prob
  state.transition.prob.partition.column <- .teradataCollapseArgVector(state.transition.prob.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(state.transition.prob)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "TransProb")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, state.transition.prob.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(state.transition.prob.order.column, "\""))
  
  # Process emission.prob
  emission.prob.partition.column <- .teradataCollapseArgVector(emission.prob.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(emission.prob)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "EmissionProb")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, emission.prob.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(emission.prob.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "HMMEvaluator",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("HMMEvaluator", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(observation, init.state.prob, state.transition.prob, emission.prob)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_hmm_evaluator_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_hmm_evaluator <- td_hmm_evaluator_mle
