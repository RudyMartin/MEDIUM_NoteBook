# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# Secondary Owner: Arun kalyanasundaram (arun.kalyanasundaram@teradata.com)
# 
# Version: 1.2
# Function Version: 1.8
# 
# ################################################################## 

# Description:
#   The Modularity function uses a clustering algorithm to detect communities
#   in networks (graphs). The function needs no prior knowledge or estimation of
#   starting cluster centers and assumes no particular data distribution of the
#   input data set.
# 
# Args:
#   vertices.data -
#     Required Argument.\cr
#     Specifies the vertex tbl_teradata where each row represents a vertex
#     of the graph.\cr
#   
#   vertices.data.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "vertices.data".\cr
#     Values to this argument can be provided as a vector, if multiple
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   edges.data -
#     Required Argument.\cr
#     Specifies the edge tbl_teradata where each row represents an edge
#     of the graph.\cr
#   
#   edges.data.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "edges.data".\cr
#     Values to this argument can be provided as a vector, if multiple
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   sources.data -
#     Optional Argument.\cr
#     Specifies the input tbl_teradata containing the source vertices.
#     This is a legacy tbl_teradata, formerly required for directed graph.
#     Function ignores this tbl_teradata and treats all graphs as undirected.\cr
#   
#   sources.data.partition.column -
#     Optional Argument. Required when "sources.data" argument is specified.\cr
#     Specifies Partition By columns for "sources.data".\cr
#     Values to this argument can be provided as a vector, if multiple
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   target.key -
#     Required Argument.\cr
#     Specifies the key of the target vertex of an edge. The key consists 
#     of the names of one or more columns in "edges.data".\cr
#     Types: character OR vector of Strings (character)
#   
#   edge.weight -
#     Optional Argument.\cr
#     Specifies the name of the column in "edges.data" that contains 
#     edge weights. The weights are positive values. By default, the weight 
#     of each edge is 1 (that is, the graph is unweighted). This argument 
#     determines how the function treats duplicate edges (that is, edges 
#     with the same source and destination, which might have different 
#     weights). For a weighted graph, the function treats duplicate edges 
#     as a single edge whose weight is the sum of the weights of the 
#     duplicate edges. For an unweighted graph, the function uses only one 
#     of the duplicate edges.\cr
#     Types: character
#   
#   community.association -
#     Optional Argument.\cr
#     Specifies the name of the column that represents the community
#     association of the vertices. Use this argument if you already know
#     some vertex communities.\cr
#     Types: character
#   
#   resolution -
#     Optional Argument.\cr
#     Specifies hierarchical-level information for the communities. The 
#     default resolution is 1.0. If you specify a list of resolution 
#     values, the function incrementally finds the communities for each 
#     value and for the default value. Each resolution must be a distinct 
#     numeric value in the range [0.0, 1000000.0]. The value 0.0 puts each 
#     node in its own community of size 1. You can specify a maximum of 500 
#     resolution values. To get the modularity of more than 500 resolution 
#     points, call the function multiple times, specifying different values 
#     in each call.\cr
#     Default Value: 1\cr
#     Types: numeric OR vector of numerics
#   
#   seed -
#     Optional Argument.\cr
#     Specifies the seed to use to create a random number during modularity 
#     computation. The seed must be a positive BIGINT value. The function
#     multiplies seed by the hash code of "vertices.data.partition.column"
#     to generate a unique seed for each vertex. The seed significantly
#     impacts community formation (and modularity score), because the function
#     uses seed for these purposes:\cr
#     \enumerate{
#       \item To break ties between different vertices during community
#       formation
#       \item To determine how deeply to analyze the graph.
#     }
#     Deeper analysis of the graph can improve community formation, but can
#     also increase execution time.\cr
#     Default Value: 1\cr
#     Types: numeric
#   
#   accumulate -
#     Optional Argument.\cr
#     Specifies the names of the columns in "vertices.data" to copy to the output
#     tbl_teradata "output". By default, the function copies the
#     "vertices.data.partition.column" columns to the output tbl_teradata "output"
#     for each vertex, changing the column names to id, id_1, id_2, and so on.\cr
#     Types: character OR vector of Strings (character)
#   
#   vertices.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row
#     of the input argument "vertices.data". The argument is used to ensure
#     deterministic results for functions which produce results that vary
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   edges.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row
#     of the input argument "edges.data". The argument is used to ensure
#     deterministic results for functions which produce results that vary
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   sources.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row
#     of the input argument "sources.data". The argument is used to ensure
#     deterministic results for functions which produce results that vary
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_modularity_mle" which is a 
#   named list containing objects of class "tbl_teradata".\cr
#   Named list members can be referenced directly with the "$" operator 
#   using the following names:\enumerate{\item community.edge.data\item 
#   output}
# 
# 
#' @export
td_modularity_mle <- function(
  vertices.data = NULL,
  edges.data = NULL,
  sources.data = NULL,
  target.key = NULL,
  edge.weight = NULL,
  community.association = NULL,
  resolution = 1,
  seed = 1,
  accumulate = NULL,
  vertices.data.sequence.column = NULL,
  edges.data.sequence.column = NULL,
  sources.data.sequence.column = NULL,
  vertices.data.partition.column = NULL,
  edges.data.partition.column = NULL,
  sources.data.partition.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("vertices.data", vertices.data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("vertices.data.partition.column", vertices.data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("edges.data", edges.data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("edges.data.partition.column", edges.data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("sources.data", sources.data, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("sources.data.partition.column", sources.data.partition.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("target.key", target.key, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("edge.weight", edge.weight, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("community.association", community.association, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("resolution", resolution, TRUE, c("numeric","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("seed", seed, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("vertices.data.sequence.column", vertices.data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("edges.data.sequence.column", edges.data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("sources.data.sequence.column", sources.data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # sources.data.partition.column is required when sources.data is specified.
  if(!is.null(sources.data) && is.null(sources.data.partition.column)){
    .ta.stop("TDR_E3001", paste("sources.data.partition.column"))
  }
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(vertices.data, NULL)
  .validateInputTableDataType(edges.data, NULL)
  .validateInputTableDataType(sources.data, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(target.key)
  .validateTblHasArgumentColumns(target.key, "target.key", edges.data, "edges.data")
  
  .validateInputColumnsNotEmpty(community.association)
  .validateTblHasArgumentColumns(community.association, "community.association", vertices.data, "vertices.data")
  
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", vertices.data, "vertices.data")
  
  .validateInputColumnsNotEmpty(edge.weight)
  .validateTblHasArgumentColumns(edge.weight, "edge.weight", edges.data, "edges.data")
  
  .validateInputColumnsNotEmpty(vertices.data.sequence.column)
  .validateTblHasArgumentColumns(vertices.data.sequence.column, "vertices.data.sequence.column", vertices.data, "vertices.data")
  
  .validateInputColumnsNotEmpty(edges.data.sequence.column)
  .validateTblHasArgumentColumns(edges.data.sequence.column, "edges.data.sequence.column", edges.data, "edges.data")
  
  .validateInputColumnsNotEmpty(sources.data.sequence.column)
  .validateTblHasArgumentColumns(sources.data.sequence.column, "sources.data.sequence.column", sources.data, "sources.data")
  
  .validateInputColumnsNotEmpty(vertices.data.partition.column)
  .validateTblHasArgumentColumns(vertices.data.partition.column, "vertices.data.partition.column", vertices.data, "vertices.data")
  
  .validateInputColumnsNotEmpty(edges.data.partition.column)
  .validateTblHasArgumentColumns(edges.data.partition.column, "edges.data.partition.column", edges.data, "edges.data")
  
  .validateInputColumnsNotEmpty(sources.data.partition.column)
  .validateTblHasArgumentColumns(sources.data.partition.column, "sources.data.partition.column", sources.data, "sources.data")
  
  # Generate temp table names for output table parameters if any.
  community.edge.dataTempTableName <- .teradataGenerateTempTableName("td_modularity_mle0_", use.default.database=TRUE, gc.onQuit=TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_modularity_mle.internal)
  Call[["community.edge.dataTempTableName"]] <- community.edge.dataTempTableName
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_modularity_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_modularity_mle.internal <- function(
  vertices.data = NULL,
  edges.data = NULL,
  sources.data = NULL,
  target.key = NULL,
  edge.weight = NULL,
  community.association = NULL,
  resolution = 1,
  seed = 1,
  accumulate = NULL,
  vertices.data.sequence.column = NULL,
  edges.data.sequence.column = NULL,
  sources.data.sequence.column = NULL,
  vertices.data.partition.column = NULL,
  edges.data.partition.column = NULL,
  sources.data.partition.column = NULL,
  community.edge.dataTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("CommunityEdgeTable")
  funcOutputArgs <- c(community.edge.dataTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetKey")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(target.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(community.association)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CommunityAssociation")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(community.association,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(accumulate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(accumulate,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(edge.weight)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "EdgeWeight")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(edge.weight,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(resolution) && !missing(resolution)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Resolution")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(resolution, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "FLOAT")
  }
  
  if (!is.null(seed) && !missing(seed)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Seed")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(seed, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "LONG")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(vertices.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("vertices:", .teradataCollapseArgVector(vertices.data.sequence.column, "")))
  }
  
  if (!is.null(edges.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("edges:", .teradataCollapseArgVector(edges.data.sequence.column, "")))
  }
  
  if (!is.null(sources.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("sources:", .teradataCollapseArgVector(sources.data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process vertices.data
  vertices.data.partition.column <- .teradataCollapseArgVector(vertices.data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(vertices.data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "vertices")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, vertices.data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # Process edges.data
  edges.data.partition.column <- .teradataCollapseArgVector(edges.data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(edges.data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "edges")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, edges.data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # Process sources.data
  if (!is.null(sources.data)) {
    sources.data.partition.column <- .teradataCollapseArgVector(sources.data.partition.column, "\"")
    tableRef <- .teradataOnClauseFromDataFrame(sources.data)
    funcInputDistribution <- c(funcInputDistribution, "FACT")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "sources")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, sources.data.partition.column)
    funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
                                     "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "Modularity",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("Modularity", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(vertices.data, edges.data, sources.data)
  
  # Return output table data frames.
  result <- list()
  result[["community.edge.data"]] <- .createDataSetObject(.extractTableName(community.edge.dataTempTableName), sourceType = "table", .extractDatabaseName(community.edge.dataTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_modularity <- td_modularity_mle
