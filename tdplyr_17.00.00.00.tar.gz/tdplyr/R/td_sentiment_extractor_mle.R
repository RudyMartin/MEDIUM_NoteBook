# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Jeris Alan Jawahar (jeris.jawahar@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 3.7
# 
# ################################################################## 

# Description:
#   The ExtractSentiment function extracts the sentiment (positive, 
#   negative, or
#   			neutral) of each input document or sentence, using either a 
#   classification model output
#   			by the function TrainSentimentExtractor or a dictionary model.
# 
# Args:
#   object -
#     Optional Argument.
#     Specifies the model type and file. The default model type is 
#     dictionary. If you omit this argument or specify dictionary without 
#     dict_file, then you must specify a dictionary tbl_teradata with alias 
#     "dict". If you specify both dict and dict_file, then whenever their 
#     words conflict, dict has higher priority. The dict_file must be a 
#     text file in which each line contains only a sentiment word, a space, 
#     and the opinion score of the sentiment word. If you specify 
#     classification:model_file, model_file must be the name of a model 
#     file generated and installed on the database by the function 
#     aa.sentiment.train. Note: Before running the function, add the 
#     location of dict_file or model_file to the user/session default 
#     search path.
#     Types: character
#   
#   newdata -
#     Required Argument.
#     The tbl_teradata defining the input text.
#   
#   newdata.order.column -
#     Optional Argument.
#     Specifies Order By columns for newdata.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   dict.data -
#     Optional Argument.
#     The tbl_teradata defining the dictionary.
#   
#   dict.data.order.column -
#     Optional Argument.
#     Specifies Order By columns for dict.data.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   text.column -
#     Required Argument.
#     Specifies the name of the input column that contains text from which 
#     to extract sentiments.
#     Types: character
#   
#   language -
#     Optional Argument.
#     Specifies the language of the input text:  en (English, the default), 
#      zh_CN (Simplified Chinese),  zh_TW (Traditional Chinese)
#     Default Value: "en"
#     Permitted Values: en, zh_CN, zh_TW
#     Types: character
#   
#   level -
#     Optional Argument.
#     Specifies the level of analysis—whether to analyze each document (the 
#     default) or each sentence.
#     Default Value: "DOCUMENT"
#     Permitted Values: DOCUMENT, SENTENCE
#     Types: character
#   
#   high.priority -
#     Optional Argument.
#     Specifies the highest priority when returning results:  
#     NEGATIVE_RECALL: Give highest priority to negative results, including 
#     those with lowerconfidence sentiment classifications (maximizes the 
#     number of negative results returned), NEGATIVE_PRECISION: Give 
#     highest priority to negative results with high-confidence sentiment 
#     classifications. POSITIVE_RECALL: Give highest priority to positive 
#     results, including those with lowerconfidence sentiment 
#     classifications (maximizes the number of positive results returned). 
#     POSITIVE_PRECISION: Give highest priority to positive results with 
#     high-confidence sentiment classifications. NONE: Give all results the 
#     same priority.
#     Default Value: "NONE"
#     Permitted Values: NEGATIVE_RECALL, NEGATIVE_PRECISION, 
#     POSITIVE_RECALL, POSITIVE_PRECISION, NONE
#     Types: character
#   
#   filter -
#     Optional Argument.
#     Specifies the kind of results to return: POSITIVE: Return only 
#     results with positive sentiments. NEGATIVE: Return only results with 
#     negative sentiments. ALL: Return all results (default)
#     Default Value: "ALL"
#     Permitted Values: POSITIVE, NEGATIVE, ALL
#     Types: character
#   
#   accumulate -
#     Optional Argument.
#     Specifies the names of the input columns to copy to the output table.
#     Types: character OR vector of Strings (character)
#   
#   newdata.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "newdata". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
#   
#   dict.data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "dict.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_sentiment_extractor_mle" 
#   which is a named list containing Teradata tbl object.
#   Named list member can be referenced directly with the "$" operator 
#   using name: result.
# 
# 
#' @export
td_sentiment_extractor_mle <- function(
  object = NULL,
  newdata = NULL,
  dict.data = NULL,
  text.column = NULL,
  language = "en",
  level = "DOCUMENT",
  high.priority = "NONE",
  filter = "ALL",
  accumulate = NULL,
  newdata.sequence.column = NULL,
  dict.data.sequence.column = NULL,
  newdata.order.column = NULL,
  dict.data.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("object", object, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata", newdata, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata.order.column", newdata.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("dict.data", dict.data, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("dict.data.order.column", dict.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("text.column", text.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("language", language, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("level", level, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("high.priority", high.priority, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("filter", filter, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata.sequence.column", newdata.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("dict.data.sequence.column", dict.data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(newdata, NULL)
  .validateInputTableDataType(dict.data, NULL)
  
  # Check for permitted values
  languagePermittedValues <- list("EN", "ZH_CN", "ZH_TW")
  .validatePermittedValues(language, languagePermittedValues)
  
  levelPermittedValues <- list("DOCUMENT", "SENTENCE")
  .validatePermittedValues(level, levelPermittedValues)
  
  high.priorityPermittedValues <- list("NEGATIVE_RECALL", "NEGATIVE_PRECISION", "POSITIVE_RECALL", "POSITIVE_PRECISION", "NONE")
  .validatePermittedValues(high.priority, high.priorityPermittedValues)
  
  filterPermittedValues <- list("POSITIVE", "NEGATIVE", "ALL")
  .validatePermittedValues(filter, filterPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(text.column)
  .validateTblHasArgumentColumns(text.column, "text.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(newdata.sequence.column)
  .validateTblHasArgumentColumns(newdata.sequence.column, "newdata.sequence.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(dict.data.sequence.column)
  .validateTblHasArgumentColumns(dict.data.sequence.column, "dict.data.sequence.column", dict.data, "dict.data")
  
  .validateInputColumnsNotEmpty(newdata.order.column)
  .validateTblHasArgumentColumns(newdata.order.column, "newdata.order.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(dict.data.order.column)
  .validateTblHasArgumentColumns(dict.data.order.column, "dict.data.order.column", dict.data, "dict.data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TextColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(text.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(accumulate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(accumulate,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(language) && !missing(language)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "InputLanguage")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(language, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(object)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ModelFile")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(object, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(level) && !missing(level)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AnalysisType")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(level, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(high.priority) && !missing(high.priority)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Priority")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(high.priority, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(filter) && !missing(filter)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputType")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(filter, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(newdata.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(newdata.sequence.column, "")))
  }
  
  if (!is.null(dict.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("dict:", .teradataCollapseArgVector(dict.data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process newdata
  tableRef <- .teradataOnClauseFromDataFrame(newdata)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "ANY")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(newdata.order.column, "\""))
  
  # Process dict.data
  if (!is.null(dict.data)) {
    tableRef <- .teradataOnClauseFromDataFrame(dict.data)
    funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "dict")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(dict.data.order.column, "\""))
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
                                     "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "ExtractSentiment",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("ExtractSentiment", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(newdata, dict.data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_sentiment_extractor_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(endTime - startTime)
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_sentiment_extractor <- td_sentiment_extractor_mle
