# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

###############################################################################
# Check virtual object
#
#  params:
#    tadf : the virtual object
#    arg.name: arg name of tadf for reporting errors
#    type : A c() of types (as strings) to match class(tadf) with
#    silent : TRUE/FALSE if FALSE, stop if class(tadf) and type don't match
#  returns:
#    TRUE if class(tadf) is in type
#    else FALSE
.CheckVirtualObject <- function(tadf, 
                                arg.name = deparse(substitute(tadf)),
                                type = "all", 
                                silent = FALSE) {
  # We are supposed to see argument name of the calling function, not  
  # actual variable name passed to the calling function's argument, in the error
  # thrown here.
  if (identical(type, "all"))
    type <- c("tbl_teradata")

  if (inherits(tadf, type)) {
    return(TRUE)
  }

  if (identical(silent, FALSE)) {
    # This is a Generic error so adding it to error codes
    .ta.stop("TDR_E1006", arg.name, paste0(type, collapse = " or "))
  }
  return(FALSE)
}

###############################################################################
# Some internal functions which will return vectors containing specific 
# data type categories.
#
# Get numeric data types
.getNumericDatatypes <- function() {
  # For "unknown", it might be "bigint", "bool" or errors. But we try to treat
  # it as "bigint" here.
  return(c("double", "int", "smallint", "numeric", "byteint", "decimal", "integer","double precesion",
           "float", "real", "bigint", "unknown"))
}
 
# Get character data types.
.getCharacterDatatypes <- function() {
  return(c("character","char","varchar"))
}

# Get categorical data types.
.getCategoricalDatatypes <- function() {
  return(c(.getCharacterDatatypes(), .getTimeDateDatatypes()))
}

# Get time-date data types.
.getTimeDateDatatypes <- function() {
  return(c("timestamp","date","time"))
}

.getAllDatatypes <- function() {
  return(c(.getNumericDatatypes(), .getCharacterDatatypes(), 
           .getTimeDateDatatypes()))
}

# Helper function to check if a packafge is available
# This is required to dynamically check for driver packages
# For example: depending on if user wants to connect with ODBC or say gosql
# then we check for the corresponding R package.
# Arguments:
#     name: name of the R package
.checkPkg <- function(name) {
  if (!requireNamespace(name, quietly = TRUE)) {
    .ta.stop("TDR_E1103", name, showFunctionCall = FALSE)
  }
}
