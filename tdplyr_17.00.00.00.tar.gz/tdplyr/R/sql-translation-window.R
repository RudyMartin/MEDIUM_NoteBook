# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

# Window extensions for Teradata
# See: sql-translation.R

# Window environment for Teradata
# Arguments:
#  - disable_ext: returns the aggr mapping without custom mappings if TRUE
.td_sql_window <- function(disable_ext = FALSE){
  win <- .getSqlVariantDbplyr()

  if (disable_ext){

    win$dbplyr_td$window

  } else {

    .td_add_window_extensions(win$dbplyr_td$window)

  }
}

# Add the Window Extensions for Teradata
# Arguments:
#  sql_window - Original Window mappings in dbplyr using sql_translator
# Returns:
#  An environment with the sql window mappings provided exclusively by this package
# Note: Extensions of mappings here can be contributed to open source
# See Teradata Database SQL Functions, Operators, Expressions, and Predicates
#     Chapter 24: Ordered Analytical/Window Aggregate Functions
#' @importFrom dbplyr sql_translator win_absent build_sql win_over
#' @importFrom dbplyr win_current_frame win_current_group win_current_order
#' @importFrom dbplyr win_cumulative win_aggregate
.td_add_window_extensions <- function(sql_window){

  check_vignettes_doc_msg <- "\nPlease check vignettes and documentation for correct usage."
  sql_translator(.parent = sql_window,

      # Ordered window.
      nth = win_absent("nth"),
      # Population standard deviation of non-NULL values of a column in a window.
      sdp = win_aggregate('STDDEV_POP'),
      # Population variance of non-NULL values of a column in a window.
      varp = win_aggregate('VAR_POP'),
      # Rank over order by.
      ntile = function(n, order_by = NULL){
        # Quantile is discouraged. The manual suggests to use:
        # (RANK() OVER (ORDER BY order_by) - 1) * n / COUNT(*) OVER()

        num <- sql_window$rank(order_by)
        den <- sql_window$n()

        if (!is.numeric(n))
          .ta.stop('n must be numeric when using ntile')

        build_sql('(', num, ' - 1) * ', n, ' / ', den)
      },
      # First function.
      first = function(x, order_by = NULL, ignore_nulls = FALSE) {

         expr <- x
         if (ignore_nulls)
           expr <- build_sql(x, " ignore nulls")

         order <- order_by
         if (is.null(order_by))
           order <- win_current_order()

         win_over(
              build_sql("first_value", list(expr)),
              order = order,
              partition = win_current_group(),
              frame = win_current_frame()
         )
      },
      # Last function.
      last = function(x, order_by = NULL, ignore_nulls = FALSE) {

         expr <- x
         if (ignore_nulls)
           expr <- build_sql(x, " ignore nulls")

         order <- order_by
         if (is.null(order_by))
           order <- win_current_order()

         win_over(
              build_sql("last_value", list(expr)),
              order = order,
              partition = win_current_group(),
              frame = win_current_frame()
         )
      },

      # Window offset.
      lead = function(x, n = 1L,
                      default = NA, order_by = NULL,
                      ignore_nulls = FALSE) {

         expr <- x
         if (ignore_nulls)
           expr <- build_sql(x, " ignore nulls")

         sql_window$lead(expr, n, default, order_by)
      },
      # Lag function.
      lag = function(x, n = 1L,
                     default = NA, order_by = NULL,
                     ignore_nulls = FALSE) {

         expr <- x
         if (ignore_nulls)
           expr <- build_sql(x, " ignore nulls")

         sql_window$lag(expr, n, default, order_by)
      },

      # Cumulative window.
      cummean = win_cumulative('avg'),

      # Count of non-NULL values of a column in a given window, if column name is provided in x.
      # Else, count of rows in that window.
      n = function(x = "*") {
        argInfoMatrix <- list()
        argInfoMatrix <- rbind(argInfoMatrix, list("x", x, TRUE, c("sql", "character")))
        colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")

        .validateArgInfoMatrix(argInfoMatrix)

        build_sql("CAST(",
                  win_over(sql(paste0("COUNT(",x ,")")), win_current_group()),
                  " AS BIGINT)")
      },

      # Distinct variants are not supported.
      n_distinct = win_distinct_not_supported('COUNT'),
      distinct = function(...) {
                       .ta.stop(
                           'The DISTINCT clause is not permitted in window aggregate functions'
                        )
      },

      # Other TD aggregates (used for time series).
      ts.mode = win_time_series_not_supported("TDR_E3300", check_vignettes_doc_msg),
      ts.bottom = win_time_series_not_supported("TDR_E3300", check_vignettes_doc_msg),
      ts.top = win_time_series_not_supported("TDR_E3300", check_vignettes_doc_msg),
      ts.median = win_aggregate_not_supported("ts.median", check_vignettes_doc_msg),
      median = win_aggregate_not_supported("median", check_vignettes_doc_msg),
      ts.first = win_time_series_not_supported("TDR_E3300",
                "\nPlease use `first(x, order_by = NULL, ignore_nulls = FALSE)` to get first value of an ordered set of values."),
      ts.last = win_time_series_not_supported("TDR_E3300",
                "\nPlease use `last(x, order_by = NULL, ignore_nulls = FALSE)` to get last value of an ordered set of values."),
      ts.mad = win_time_series_not_supported("TDR_E3300", check_vignettes_doc_msg),
      ts.percentile = win_time_series_not_supported("TDR_E3300", check_vignettes_doc_msg),
      ts.delta_t = win_time_series_not_supported("TDR_E3300", check_vignettes_doc_msg),
      ts.kurtosis = win_aggregate_not_supported("ts.kurtosis", check_vignettes_doc_msg),
      kurtosis = win_aggregate_not_supported("kurtosis", check_vignettes_doc_msg),
      ts.skew = win_aggregate_not_supported("ts.skew", check_vignettes_doc_msg),
      skew = win_aggregate_not_supported("skew", check_vignettes_doc_msg),
      ts.sum = win_aggregate_not_supported("ts.sum", check_vignettes_doc_msg),
      ts.sd = win_aggregate_not_supported("ts.sd", check_vignettes_doc_msg),
      ts.sdp = win_aggregate_not_supported("ts.sdp", check_vignettes_doc_msg),
      ts.var = win_aggregate_not_supported("ts.var", check_vignettes_doc_msg),
      ts.varp = win_aggregate_not_supported("ts.varp", check_vignettes_doc_msg),
      ts.min = win_aggregate_not_supported("ts.min", check_vignettes_doc_msg),
      ts.max = win_aggregate_not_supported("ts.max", check_vignettes_doc_msg),
      ts.mean = win_aggregate_not_supported("ts.mean", check_vignettes_doc_msg),
      ts.n = win_aggregate_not_supported("ts.n", check_vignettes_doc_msg),
      ts.describe = win_time_series_not_supported("TDR_E3300", check_vignettes_doc_msg)
  )
}
