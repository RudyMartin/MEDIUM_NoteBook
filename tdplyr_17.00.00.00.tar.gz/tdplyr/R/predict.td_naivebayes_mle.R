# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' @export
predict.td_naivebayes_mle <-  function(modeldata = NULL,
                            newdata = NULL,
                            id.col = NULL,
                            responses = NULL,
                            formula = NULL,
                            newdata.order.column = NULL,
                            modeldata.order.column = NULL) {
    td_naivebayes_predict_sqle(
          modeldata = modeldata,
          newdata = newdata,
          id.col = id.col,
          responses = responses,
          formula = formula,
          newdata.order.column = newdata.order.column,
          modeldata.order.column = modeldata.order.column
  )
}
