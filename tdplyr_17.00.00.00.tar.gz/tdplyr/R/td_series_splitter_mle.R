# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.13
# 
# ################################################################## 

# Description:
#   The SeriesSplitter function splits partitions into subpartitions 
#   (called splits) to balance the partitions for time series 
#   manipulation. The function creates an additional column that contains 
#   split identifiers. Each row contains the identifier of the split to 
#   which the row belongs. Optionally, the function also copies a 
#   specified number of boundary rows to each split.
# 
# Args:
#   data -
#     Required Argument.\cr
#     Specifies the name of the input tbl_teradata to be split.\cr
#   
#   partition.columns -
#     Required Argument.\cr
#     Specifies the partitioning columns of input_table. These columns 
#     determine the identity of a partition. For data type restrictions of 
#     these columns, see the Aster Database Documentation.\cr
#     Types: character OR vector of Strings (character)
#   
#   duplicate.rows.count -
#     Optional Argument.\cr
#     Specifies the number of rows to duplicate across split boundaries. By 
#     default, the function duplicates one row from the previous partition 
#     and one row from the next partition. If you specify only value1, then 
#     the function duplicates value1 rows from the previous partition and 
#     value1 rows from the next partition. If you specify both value1 and 
#     value2, then the function duplicates value1 rows from the previous 
#     partition and value2 rows from the next partition. Each argument 
#     value must be nonnegative integer less than or equal to 1000. \cr
#     Default Value: [1]\cr
#     Types: numeric OR vector of numerics
#   
#   order.by.columns -
#     Optional Argument.\cr
#     Specifies the ordering columns of input_table. These columns 
#     establish the order of the rows and splits. Without this argument, 
#     the function can split the rows in any order.\cr
#     Types: character OR vector of Strings (character)
#   
#   split.count -
#     Optional Argument.\cr
#     Note: If input_table has multiple partitions, then you cannot specify 
#     split.count. Instead, specify rows.per.split. Specifies the desired 
#     number of splits in a partition of the output table. The value of 
#     split_count must be a positive BIGINT, and its upper bound is the 
#     number of rows in the partition. The default value is 4. Base the 
#     value of split_count on the desired amount of parallelism. For 
#     example, for a cluster with 10 vworkers, make split_count a multiple 
#     of 10. If the number of rows in input_table (n) is not exactly 
#     divisible by split_count, then the function estimates the number of 
#     splits in the partition, using this formula: ceiling (n / ceiling (n 
#     / split_count) ) \cr
#     Default Value: 4\cr
#     Types: numeric
#   
#   rows.per.split -
#     Optional Argument.\cr
#     Note: If input_table has multiple partitions, then specify 
#     rows.per.split instead of split.count. Specifies the desired maximum 
#     number of rows in each split in the output table. If the number of 
#     rows in input_table is not exactly divisible by rows_per_split, then 
#     the last split contains fewer than rows_per_split rows, but no row 
#     contains more than rows_per_split rows. The value of rows_per_split 
#     must be a positive BIGINT. If input_table has multiple partitions and 
#     you do not specify rows.per.split, then the function uses the value 
#     1000.\cr
#     Default Value: 1000\cr
#     Types: numeric
#   
#   accumulate -
#     Optional Argument.\cr
#     Specifies the names of input_table columns (other than those 
#     specified by partition.columns and order.by.columns) to copy to the 
#     output table. By default, only the columns specified by 
#     partition.columns and order.by.columns are copied to the output 
#     table.\cr
#     Types: character OR vector of Strings (character)
#   
#   split.id.column -
#     Optional Argument.\cr
#     Specifies the name for the output tbl_teradata column that is to 
#     contain the split identifiers. (specified by accumulate, 
#     partition.columns, or Order_By_Columns), then you must use 
#     split.id.column to specify a different split_id_column.\cr
#     Default Value: "split_id"\cr
#     Types: character
#   
#   return.stats.table -
#     Optional Argument.\cr
#     Specifies whether the function returns the data in stats_table in 
#     response to the command SELECT * FROM SeriesSplitter. When this value 
#     is "false", the function returns only the data in output_table.\cr
#     Default Value: TRUE\cr
#     Types: logical
#   
#   values.before.first -
#     Optional Argument.\cr
#     If duplicate.rows.count is nonzero and order.by.columns is specified, 
#     then values.before.first specifies the values to be stored in the 
#     ordering columns that precede the first row of the first split in a 
#     partition as a result of duplicating rows across split boundaries. If 
#     values.before.first specifies only one value and order.by.columns 
#     specifies multiple ordering columns, then the specified value is 
#     stored in every ordering column. If values.before.first specifies 
#     multiple values, then it must specify a value for each ordering 
#     column. The value and the ordering column must have the same data 
#     type. For the data type VARCHAR, the values are case-insensitive. The 
#     default values for different data types are:  Numeric: -1,  CHAR(n) 
#     or VARCHAR : "-1",  Date- or time-based: 1900-01-01 0:00:00,  
#     CHARACTER: "0",  Bit: 0,  Boolean: "false",  IP4 : 0.0.0.0,  UUID: 
#     0000-0000-0000-0000-0000-0000-0000-0000 \cr
#     Default Value: "["-1"]"\cr
#     Types: character OR vector of characters
#   
#   values.after.last -
#     Optional Argument.\cr
#     If duplicate.rows.count is nonzero and order.by.columns is specified, 
#     then values.after.last specifies the values to be stored in the 
#     ordering columns that follow the last row of the last split in a 
#     partition as a result of duplicating rows across split boundaries. If 
#     values.after.last specifies only one value and order.by.columns 
#     specifies multiple ordering columns, then the specified value is 
#     stored in every ordering column. If values.after.last specifies 
#     multiple values, then it must specify a value for each ordering 
#     column. The value and the ordering column must have the same data 
#     type.  For the data type VARCHAR, the values are case-insensitive. 
#     The default value is NULL. \cr
#     Default Value: "["null"]"\cr
#     Types: character OR vector of characters
#   
#   duplicate.column -
#     Optional Argument.\cr
#     Specifies the name of the column that indicates whether a row is 
#     duplicated from the neighboring split. If the row is duplicated, this 
#     column contains 1; otherwise it contains 0.\cr
#     Types: character
#   
#   partial.split.id -
#     Optional Argument.\cr
#     Specifies whether split_id_column contains only the numeric split 
#     identifier. If the value is "true", then split_id_column contains a 
#     numeric representation of the split identifier that is unique for 
#     each partition. To distribute the output tbl_teradata by split, use a 
#     combination of all partitioning columns and split_id_column. If the 
#     value is "false", then split_id_column contains a string 
#     representation of the split that is unique across all partitions. The 
#     function generates the string representation by concatenating the 
#     partitioning columns with the order of the split inside the partition 
#     (the numeric representation). In the string representation, hyphens 
#     separate partitioning column names from each other and from the 
#     order. For example, "pcol1- pcol2-3". \cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_series_splitter_mle" which is 
#   a named list containing objects of class "tbl_teradata".\cr
#   Named list members can be referenced directly with the "$" operator 
#   using the following names:\enumerate{\item output.table\item 
#   stats.table\item output}
# 
# 
#' @export
td_series_splitter_mle <- function(
  data = NULL,
  partition.columns = NULL,
  duplicate.rows.count = 1,
  order.by.columns = NULL,
  split.count = 4,
  rows.per.split = 1000,
  accumulate = NULL,
  split.id.column = "split_id",
  return.stats.table = TRUE,
  values.before.first = "-1",
  values.after.last = NULL,
  duplicate.column = NULL,
  partial.split.id = FALSE,
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("partition.columns", partition.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("duplicate.rows.count", duplicate.rows.count, TRUE, c("numeric","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("order.by.columns", order.by.columns, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("split.count", split.count, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("rows.per.split", rows.per.split, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("split.id.column", split.id.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("return.stats.table", return.stats.table, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("values.before.first", values.before.first, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("values.after.last", values.after.last, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("duplicate.column", duplicate.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("partial.split.id", partial.split.id, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(partition.columns)
  .validateTblHasArgumentColumns(partition.columns, "partition.columns", data, "data")
  
  .validateInputColumnsNotEmpty(order.by.columns)
  .validateTblHasArgumentColumns(order.by.columns, "order.by.columns", data, "data")
  
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  # Validate that value passed to the output column argument is not empty.
  .validateInputColumnsNotEmpty(split.id.column)
  .validateInputColumnsNotEmpty(duplicate.column)
  # Generate temp table names for output table parameters if any.
  output.tableTempTableName <- .teradataGenerateTempTableName("td_series_splitter_mle0_", use.default.database=TRUE, gc.onQuit=TRUE)
  stats.tableTempTableName <- .teradataGenerateTempTableName("td_series_splitter_mle1_", use.default.database=TRUE, gc.onQuit=TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_series_splitter_mle.internal)
  Call[["output.tableTempTableName"]] <- output.tableTempTableName
  Call[["stats.tableTempTableName"]] <- stats.tableTempTableName
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_series_splitter_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_series_splitter_mle.internal <- function(
  data = NULL,
  partition.columns = NULL,
  duplicate.rows.count = 1,
  order.by.columns = NULL,
  split.count = 4,
  rows.per.split = 1000,
  accumulate = NULL,
  split.id.column = "split_id",
  return.stats.table = TRUE,
  values.before.first = "-1",
  values.after.last = NULL,
  duplicate.column = NULL,
  partial.split.id = FALSE,
  data.sequence.column = NULL,
  output.tableTempTableName = NULL,
  stats.tableTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("OutputTable", "StatsTable")
  funcOutputArgs <- c(output.tableTempTableName, stats.tableTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PartitionByColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(partition.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  if (!is.null(order.by.columns)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OrderByColumns")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(order.by.columns,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(accumulate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(accumulate,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(split.count) && !missing(split.count)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SplitCount")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(split.count, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "LONG")
  }
  
  if (!is.null(rows.per.split) && !missing(rows.per.split)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "RowsPerSplit")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(rows.per.split, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "LONG")
  }
  
  if (!is.null(duplicate.rows.count) && !missing(duplicate.rows.count)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "DuplicateRowsCount")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(duplicate.rows.count, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "LONG")
  }
  
  if (!is.null(split.id.column) && !missing(split.id.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SplitIdColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(split.id.column, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(return.stats.table) && !missing(return.stats.table)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ReturnStatsTable")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(return.stats.table, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(values.before.first) && !missing(values.before.first)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ValuesBeforeFirst")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(values.before.first, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(values.after.last) && !missing(values.after.last)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ValuesAfterLast")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(values.after.last, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(duplicate.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "DuplicateColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(duplicate.column, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(partial.split.id) && !missing(partial.split.id)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PartialSplitId")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(partial.split.id, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "SeriesSplitter",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("SeriesSplitter", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["output.table"]] <- .createDataSetObject(.extractTableName(output.tableTempTableName), sourceType = "table", .extractDatabaseName(output.tableTempTableName), is_dplyr_input)
  if(!is.null(return.stats.table) && return.stats.table == TRUE){
    result[["stats.table"]] <- .createDataSetObject(.extractTableName(stats.tableTempTableName), sourceType = "table", .extractDatabaseName(stats.tableTempTableName), is_dplyr_input)
  }
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_series_splitter <- td_series_splitter_mle
