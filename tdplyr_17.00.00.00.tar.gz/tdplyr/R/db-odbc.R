# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: karthik.thelukuntla@teradata.com
# Secondary Owner:
#
# Functions copied and modified from the odbc R package.
# See: https://github.com/r-dbi/odbc/blob/master/R/DataTypes.R
#
###################################################################################


# Returns the mapping for Teradata specific SQL type from R type
# This is adapted from "odbcDataType" function in the odbc package.
# The copy_to function uses this to create the table with correct types
# In addition this function is called from DBI::dbDataType to support dbWriteTable
.getSQLDataType <- function(con, obj, ...) {
  varchar <- .ta.varcharSize()
  .switch_type(con, obj,
              factor    = varchar,
              time_tz   = "time with time zone",
              timestamp_tz = "timestamp with time zone",
              datetime  = "timestamp",
              date      = "date",
              integer   = "int",
              double    = "float",
              raw       = "byte",
              character = varchar,
              complex   = varchar,
              logical   = "byteint",
              blob      = "blob",
              time      = "time",
              varchar
  )
}

.switch_type <- function(con, obj, factor    = .ta.varcharSize(),
                         time_tz   = "time with time zone",
                         timestamp_tz = "timestamp with time zone",
                         datetime  = "timestamp",
                         date      = "date",
                         integer   = "int",
                         double    = "float",
                         raw       = "byte",
                         character = .ta.varcharSize(),
                         complex   = .ta.varcharSize(),
                         logical   = "byteint",
                         blob      = "blob",
                         time      = "time",
                         vc = .ta.varcharSize()) {
  switch(.object_type(con, obj),  factor    = .ta.varcharSize(),
         time_tz   = "time with time zone",
         timestamp_tz = "timestamp with time zone",
         datetime  = "timestamp",
         date      = "date",
         integer   = "int",
         double    = "float",
         raw       = "byte",
         character = .ta.varcharSize(),
         complex   = .ta.varcharSize(),
         logical   = "byteint",
         blob      = "blob",
         time      = "time",
         vc)
}

#' @importFrom methods is
#' @importFrom teradatasql is.TimeWithTimeZone
#' @importFrom teradatasql is.TimestampWithTimeZone
.object_type <- function(con, obj) {
  if(.get_driver_name(con) == "Teradata Native Driver"){
    if(is.TimeWithTimeZone (obj)) return("time_tz")
    if(is.TimestampWithTimeZone (obj)) return("timestamp_tz") 
  }
  if (is.factor(obj)) return("factor")
  if (is(obj, "POSIXct")) return("datetime")
  if (is(obj, "POSIXlt")) return("datetime")
  if (is(obj, "Date")) return("date")
  if (is(obj, "blob")) return("blob")
  if (is(obj, "difftime")) return("time")
  
  return(typeof(obj))
}

.ta.varcharSize <- function() {
  # Returns Varchar size based on Environment variable
  
  if(nchar(Sys.getenv("TD_VARCHAR_COLUMN_SIZE")[1])==0)
    Sys.setenv(TD_VARCHAR_COLUMN_SIZE = 1024)
  
  return(paste0("varchar(",Sys.getenv("TD_VARCHAR_COLUMN_SIZE"),")"))
}