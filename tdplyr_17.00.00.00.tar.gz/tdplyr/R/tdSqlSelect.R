################################################################################
#
# Copyright 2019 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: Adithya Avvaru (adithya.avvaru@teradata.com)
# Secondary Owner:
#
# This file has:
#   1.  sql_select of dbplyr with addition of group_by_time argument.
#
################################################################################

# SQL generation ----------------------------------------------------------
# This function generates SQL query containing group_by_time clause, based on 
# the arguments.
#' @export
#' @importFrom purrr compact
sql_select.Teradata <- function(con, select, from, where = NULL,
                        group_by = NULL, having = NULL,
                        group_by_time = NULL,
                        order_by = NULL,
                        limit = NULL,
                        distinct = FALSE,
                        ...) {
  out <- vector("list", 8)
  names(out) <- c("select", "from", "where", "group_by", "group_by_time",
                  "having", "order_by","limit")
  
  stopifnot(is.character(select), length(select) > 0L)
  out$select    <- build_sql(
    "SELECT ",
    
    if (distinct) sql("DISTINCT "),
    
    # Teradata uses the TOP statement instead of LIMIT which is what SQL92 uses
    # TOP is expected after DISTINCT and not at the end of the query
    # e.g: SELECT TOP 100 * FROM my_table
    if (!is.null(limit) && !identical(limit, Inf)) {
      stopifnot(is.numeric(limit), length(limit) == 1L, limit > 0)
      build_sql(" TOP ", as.integer(limit), " ", con = con)
    },
    
    escape(select, collapse = ", ", con = con),
    con = con
  )
  
  out$from      <- sql_clause_from(from, con)
  out$where     <- sql_clause_where(where, con)
  out$group_by  <- sql_clause_group_by(group_by, con)
  out$group_by_time <- group_by_time
  out$having    <- sql_clause_having(having, con)
  out$order_by  <- sql_clause_order_by(order_by, con)

  escape(unname(compact(out)), collapse = "\n", parens = FALSE, con = con)
}