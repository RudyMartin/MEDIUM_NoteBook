# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' Initialize a context to perform analytic functions on Teradata Vantage
#'
#' A context must be initialized before executing analytic functions. Use the \code{td_set_context}
#' function to initialize or update a context using an already established connection.\cr
#' \cr
#' Note:
#' \itemize{
#' \item If there is no previous context, then a new context is initialized.
#' \item If the context already exists, and
#' \enumerate{
#'    \item the connection object "con" is created using \code{tdplyr::NativeDriver()} (as in 
#'    Example 4), then the context attribute "temp.database" is updated if
#'    it is different compared to that of previous context. Since the connection parameters
#'    host, user/uid and database (i.e. default schema) are same for both
#'    "con" and the connection object from the context (because \code{dbConnect} on
#'    \code{NativeDriver} object initializes the context), the previous context (that is created by
#'    \code{dbConnect}) is NOT overwritten and all nonpersistent work tables remain in the session.
#'    \item the connection object "con" is created using \code{teradatasql::TeradataDriver()} (as 
#'    in Example 5) object (For more information on this, please check documentation from 
#'    TeradataSQLDriver for R), then
#'      \enumerate{
#'      \item the previous context is overwritten and all nonpersistent work tables are removed if
#'      the connection parameters of "con" are different than those of the connection object
#'      from the previous context.
#'      \item the previous context is NOT overwritten and all nonpersistent work tables remain in 
#'      the session if the connection parameters are same for both "con" and the connection 
#'      object from the previous context.
#'      }
#'      In this case, the new connection object should be retrieved using 
#'      \code{td_get_context()$connection} before using it.
#'  }
#'}
#'
#' @param con Required Argument\cr
#' Specifies a \code{DBIConnection} object with a \code{Teradata} or a
#' \code{TeradataConnection} subclass.
#' @param temp.database Optional Argument\cr
#' Specifies the database name which needs to be used to create temporary database objects
#' (table/view) for processing data. Such objects are garbage collected at the end of the session.
#' If a user wants to specifically use a known database for temporary objects, the database name
#' can be specified using this argument.\cr
#' Note:
#' \enumerate{
#' \item Make sure the user has privilege to create objects in this database, otherwise the 
#' functions that create temporary objects will fail.
#' \item If this argument is not specified, default database of the connection is used for 
#' temporary objects.
#' \item To get the temporary database name, use function \code{td_get_context()}.
#' }
#' Default: NULL\cr
#' Types: character
#' @return Returns NULL invisibly
#' @seealso \code{td_remove_context}, \code{td_create_context}, \code{td_get_context},
#' \code{dbConnect}
#' @examples
#' \donttest{
#' # Establish an ODBC connection to Teradata Vantage using the dbConnect API.
#' con <- DBI::dbConnect(odbc::odbc(), dsn = "TeradataDSN")
#'
#' # Example 1: Changing the temp.database of an existing context without removing  
#' # nonpersistent work tables.
#' # Use td_set_context function to initialize a context with a given connection.
#' td_set_context(con = con, temp.database = "database_for_transient_objects")
#' 
#' # Use td_get_context function to get the current context information.
#' context <- td_get_context()
#' 
#' # Change the temp.database of an existing context.
#' td_set_context(context$connection, temp.database = context$default.database)
#' 
#' # Remove the current context.
#' td_remove_context()
#'
#' # Example 2: Managing multiple connections with td_set_context function.
#' con1 <- DBI::dbConnect(odbc::odbc(), dsn = "TeradataDSN")
#' con2 <- DBI::dbConnect(odbc::odbc(), dsn = "TeradataDSN")
#' 
#' # Initialize the context with con1.
#' td_set_context(con = con1, temp.database = "database_for_transient_objects")
#' 
#' # Initialize the context with con2.
#' td_set_context(con = con2)
#'
#' # Remove the current context.
#' # Note: This performs garbage collection and disconnects current context connection i.e., con2.
#' td_remove_context()
#'
#' # Explicit call to dbDisconnect() disconnects the connection "con1".
#' DBI::dbDisconnect(con1)
#'
#' # Example 3: Create a new ODBC context and switch its temporary database using 
#' # td_set_context function.
#' con <- td_create_context(dsn = "TeradataDSN")
#' 
#' # Use td_get_context function to get the current context information.
#' td_get_context()
#' 
#' # Use td_set_context function to change temporary database.
#' td_set_context(con, temp.database = "database_for_transient_objects")
#' 
#' # Use td_get_context function to get the current context information.
#' td_get_context()
#' 
#' # Remove the current context.
#' td_remove_context()
#'
#' # Example 4: Use dbConnect function to connect to Advanced SQL Engine through Teradata SQL Driver
#' # and set context using different temporary database.
#' db <- DBI::dbConnect(tdplyr::NativeDriver(), "<dbcname>", "<tduser>", "<tdpwd>")
#' 
#' # Use td_set_context function to set context using different temporary database.
#' td_set_context(db, temp.database = "database_for_transient_objects")
#' 
#' # Remove the current context.
#' td_remove_context()
#' 
#' # Example 5: Use dbConnect function to connect to Advanced SQL Engine directly through Teradata
#' # SQL Driver (i.e. TeradataDriver()).
#' con <- DBI::dbConnect (teradatasql::TeradataDriver(),
#'                        '{"host":"<dbcname>","user":"<tduser>","password":"<tdpwd>"}')
#'
#' td_set_context(con, temp.database = "database_for_transient_objects")
#'
#' # The td_set_context function just sets the context and does not return the connection object.
#' # Hence, get the connection object using td_get_context()$connection.
#' con <- td_get_context()$connection
#'
#' # Remove the current context.
#' td_remove_context()
#' }
#' @export
#' @rdname td_set_context
td_set_context <- function(con, temp.database = NULL){

  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("con", con, FALSE, c("Teradata", "TeradataConnection", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("temp.database", temp.database, TRUE, c("character", NA)))
  
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments.
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument.
  .validateArgumentTypes(argInfoMatrix)

  # Provide deprecation warning to console - suggesting the user to use 
  # Teradata SQL Driver when 'con' is created using ODBC driver.
  if (inherits(con, "OdbcConnection")) {
    .ta.warning("TDR_W1009", showFunctionCall = FALSE)
  }

  # If the connection is through teradatasql::TeradataDriver(), the class of the connection object
  # is "TeradataConnection". Assigning S4 class "Teradata" to the connection 'con'.
  if (inherits(con, "TeradataConnection")) {
    con <- .ta.AddTeradataS4Class(con)
  }

  skipGC <- FALSE

  # if context already exists and connection is the same as this one then just print a message and return
  if (.ta.contextExists() &&
    .ta.isIdenticalConnection(con, .taConnection())) {
    skipGC <- TRUE
  }

  # If the connection is through teradatasql::TeradataDriver(), the class of the connection object
  # is "TeradataConnection". Assigning S4 class "Teradata" to the connection 'con'.
  if (inherits(con, "TeradataConnection")) {
    con <- .ta.AddTeradataS4Class(con)
  }

  # verify if the connection is valid and has the correct subclass
  .ta.verifyConnection(con)
  
  .ta.initializeContext(con, temp.database, is.skip.gc = skipGC)

  # Assign vantage version using pm.versionInfo table.
  .ta.setVantageVersion(con)

  return(invisible(NULL))
}
