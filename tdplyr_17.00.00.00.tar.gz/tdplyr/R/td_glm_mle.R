# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.20
# 
# ################################################################## 

# Description:
#   The generalized linear model (GLM) is an extension of the linear 
#   regression model that enables the linear equation to be related to
#   the dependent variables by a link function. GLM performs linear
#   regression analysis for distribution functions using a user-specified
#   distribution family and link function. GLM selects the link function
#   based upon the distribution family and the assumed nonlinear
#   distribution of expected outcomes. The table in Background describes
#   the supported link function combinations.
# 
# Args:
#   formula -
#     Required Argument.
#     An object of class "formula". Specifies the model to be fitted. Only 
#     basic formula of the (col1 ~ col2 + col3 +...) form are supported and 
#     all variables must be from the same tbl_teradata object. The 
#     response should be column of type numeric or logical.
#   
#   family -
#     Optional Argument.
#     Specifies the distribution exponential family
#     Default Value: "gaussian"
#     Permitted Values: LOGISTIC, BINOMIAL, POISSON, GAUSSIAN, GAMMA, 
#     INVERSE_GAUSSIAN, NEGATIVE_BINOMIAL
#     Types: character
#   
#   linkfunction -
#     Optional Argument.
#     The canonical link functions (default link functions) and the link 
#     functions that are allowed.
#     Default Value: "CANONICAL"
#     Permitted Values: CANONICAL, IDENTITY, INVERSE, LOG, 
#     COMPLEMENTARY_LOG_LOG, SQUARE_ROOT, INVERSE_MU_SQUARED, LOGIT, 
#     PROBIT, CAUCHIT
#     Types: character
#   
#   data -
#     Required Argument.
#     Specifies the name of the tbl_teradata that contains the columns
#   
#   weights -
#     Optional Argument.
#     Specifies the name of an input tbl_teradata column that contains the 
#     weights to assign to responses. You can use non-NULL weights 
#     to indicate that different observations have different  
#     dispersions (with the weights being inversely proportional 
#     to the dispersions).Equivalently, when the weights are positive 
#     integers wi, each response yi is the mean of wi unit-weight 
#     observations. A binomial GLM uses prior weights to give the number of 
#     trials when the response is the proportion of successes. A Poisson 
#     GLM rarely uses weights. If the weight is less than the response 
#     value, then the function throws an exception. Therefore, if the 
#     response value is greater than 1 (the default weight), then you must 
#     specify a weight that is greater than or equal to the response value.
#     Default Value: "1.0"
#     Types: character
#   
#   threshold -
#     Optional Argument.
#     Specify the convergence threshold. 
#     Default Value: 0.01
#     Types: numeric
#   
#   maxit -
#     Optional Argument.
#     Specifies the maximum number of iterations that the algorithm runs 
#     before quitting if the convergence threshold has not been met. 
#     Default Value: 25
#     Types: integer
#   
#   step -
#     Optional Argument.
#     Specifies whether the function uses a step. If the function uses a 
#     step, then it runs with the GLM model that has the lowest Akaike 
#     information criterion (AIC) score, drops one predictor from the 
#     current predictor group, and repeats this process until no predictor 
#     remains.
#     Default Value: FALSE
#     Types: logical
#   
#   intercept -
#     Optional Argument.
#     Specifies whether the function uses an intercept. For example, in 
#     B0+B1*X1+B2*X2+ ....+BpXp, the intercept is B0. 
#     Default Value: TRUE
#     Types: logical
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_glm_mle" which is a named 
#   list containing Teradata tbl objects.
#   Named list members can be referenced directly with the "$" operator 
#   using following names:\enumerate{\item coefficients\item output}
# 
# 
#' @export
td_glm_mle <- function(
  formula = NULL,
  family = "gaussian",
  linkfunction = "CANONICAL",
  data = NULL,
  weights = "1.0",
  threshold = 0.01,
  maxit = 25,
  step = FALSE,
  intercept = TRUE,
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("formula", formula, FALSE, "formula"))
  argInfoMatrix <- rbind(argInfoMatrix, list("family", family, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("linkfunction", linkfunction, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("weights", weights, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("threshold", threshold, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("maxit", maxit, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("step", step, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("intercept", intercept, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check for permitted values
  familyPermittedValues <- list("LOGISTIC", "BINOMIAL", "POISSON", "GAUSSIAN", "GAMMA", "INVERSE_GAUSSIAN", "NEGATIVE_BINOMIAL")
  .validatePermittedValues(family, familyPermittedValues)
  
  linkfunctionPermittedValues <- list("CANONICAL", "IDENTITY", "INVERSE", "LOG", "COMPLEMENTARY_LOG_LOG", "SQUARE_ROOT", "INVERSE_MU_SQUARED", "LOGIT", "PROBIT", "CAUCHIT")
  .validatePermittedValues(linkfunction, linkfunctionPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(weights)
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  # Generate temp table names for output table parameters if any.
  coefficientsTempTableName <- .teradataGenerateTempTableName("td_glm_mle0_", use.default.database=TRUE, gc.onQuit=TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_glm_mle.internal)
  Call[["coefficientsTempTableName"]] <- coefficientsTempTableName
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_glm_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_glm_mle.internal <- function(
  formula = NULL,
  family = "gaussian",
  linkfunction = "CANONICAL",
  data = NULL,
  weights = "1.0",
  threshold = 0.01,
  maxit = 25,
  step = FALSE,
  intercept = TRUE,
  data.sequence.column = NULL,
  coefficientsTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("OutputTable")
  funcOutputArgs <- c(coefficientsTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  if (!is.null(weights) && !missing(weights)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "WeightColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(weights, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(family)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Family")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(family, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(linkfunction) && !missing(linkfunction)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "LinkFunction")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(linkfunction, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(threshold) && !missing(threshold)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StopThreshold")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(threshold, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(maxit) && !missing(maxit)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxIterNum")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(maxit, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(intercept) && !missing(intercept)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Intercept")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(intercept, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(step) && !missing(step)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Step")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(step, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Let's process formula argument
  formula.terms.matrix <- .ta.parse.formula(formula, data)
  # Target Column
  mc.target.column <- formula.terms.matrix[1,1]
  # all input columns
  all_inputs <- .ta.getColumnsByType(formula.terms.matrix, data, "all")
  if (length(all_inputs) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "InputColumns")
    allColumnsList <- .teradataCollapseArgVector(.teradataQuoteArg(all_inputs,"\""), "'")
    funcOtherArgs <- c(funcOtherArgs, allColumnsList)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
    mc.sql.specific.attributes[["TargetColumns"]] <- allColumnsList
  }
  
  # categorical input columns
  categorical_inputs <- .ta.getColumnsByType(formula.terms.matrix, data, "categorical")
  if (length(categorical_inputs) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CategoricalColumns")
    categoricalColumnsList <- .teradataCollapseArgVector(.teradataQuoteArg(categorical_inputs,"\""), "'")
    funcOtherArgs <- c(funcOtherArgs, categoricalColumnsList)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
    mc.sql.specific.attributes[["CategoricalColumns"]] <- categoricalColumnsList
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "GLM",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("GLM", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["coefficients"]] <- .createDataSetObject(.extractTableName(coefficientsTempTableName), sourceType = "table", .extractDatabaseName(coefficientsTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_glm <- td_glm_mle
