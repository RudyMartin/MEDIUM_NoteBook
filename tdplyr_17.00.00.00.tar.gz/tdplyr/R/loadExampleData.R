################################################################################
#
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: pankajvinod.purandare@teradata.com
# Secondary Owner:
################################################################################
#' @title Loading example data for tdplyr functions
#' @name loadExampleData
#' @description
#' Function to load the example data to a specified table.\cr
#' This is used only in loading example data for trying examples for the tdplyr functions.\cr\cr
#' Note: This function\cr
#' \enumerate{
#'   \item can be used in restricted way in that it can only accept predefined values as can
#'   be found only in the examples provided in the function reference guide and the user guide;
#'   \item creates new table(s) in Vantage. If required, the user must drop them manually;
#'   \item will skip creation of the table and loading of the data to it if a table with the name
#'   provided already exists.
#' }
#' @param fileName Required Argument.\cr
#'                 Specifies the name of the file in inst/extdata directory for data load.\cr
#'                 Note: This argument must be used to specify values only as specified in the
#'                 calls to the function in the example sections of the tdplyr functions.\cr
#'                 Types: character
#' @param ... Required Argument.\cr
#'            Specifies the name(s) of the table(s) to create and load the example data to.\cr
#'            Note: The name(s) of table(s) provided with this argument must have corresponding data
#'            (CSV) file(s) present in the inst/extdata directory.\cr
#'            Types: character
#' @examples
#' \donttest{
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#' 
#' # Example 1 - Loading single table used in the example for "td_glm_mle".
#' # Load example data.
#' loadExampleData("glm_example", "admissions_train")
#' 
#' # Create object of class "tbl_teradata" based on the data loaded to use as input.
#' admissions_train <- tbl(con, "admissions_train")
#' 
#' # Example 2 - Loading multiple tables used in the examples for "td_glm_predict_mle".
#' loadExampleData("glmpredict_example", "admissions_test", "housing_test")
#' 
#' # Create objects of class "tbl_teradata" based on the data loaded to use as inputs.
#' admissions_test <- tbl(con, "admissions_test")
#' housing_test <- tbl(con, "housing_test")
#' }
## Sample '*_example' file
# --load--
# table_without_types
# --loadByTypes--
# table_with_types::TIMESTAMP(6),integer,integer,integer
# --loadPTI--
# pti_seq_table::TIMESTAMP(6),integer,integer::SEQ$$TIMESTAMP(6), DATE '2012-01-01', HOURS(1), COLUMNS(buoyid), sequenced
# --loadPTI--
# pti_nonseq_table::TIMESTAMP(6),integer::NON_SEQ$$TIMESTAMP(6), DATE '2012-01-01', HOURS(1), COLUMNS(buoyid), nonsequenced

#' @importFrom DBI dbExistsTable
#' @importFrom dplyr copy_to
#' @importFrom utils read.csv
#' @export
loadExampleData <- function(fileName, ...){
  # Get table names from dots (...)
  tableNames <- unlist(eval(substitute(alist(...))))

  # Validating arguments
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("fileName", fileName, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("...", tableNames, FALSE, c("character","list")))    
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  .validateMissingRequiredArguments(argInfoMatrix)
  .validateArgumentTypes(argInfoMatrix)
  .validateInputColumnsNotEmpty(fileName)
  
  conn <- system.file("extdata", fileName, package="tdplyr")
  lines <- readLines(conn)

  # Has the data loading type for each table.
  load_types <- c()
  # Has the table names in '_example' file.
  file_table_names <- c()
  # Has the data type of columns for each table if data loading type is loadByTypes and loadPTI.
  data_types <- c()
  # Stores PTI information if load type is loadPTI.
  pti_infos <- c()
  i <- 1
  while(i < length(lines)) {
    table_details <- strsplit(lines[i+1], split = "::")[[1]]
    load_types <- c(load_types, lines[i])
    file_table_names <- c(file_table_names, table_details[1])
    data_types <- c(data_types, table_details[2])
    pti_info <- ""
    if (lines[i] == "--loadPTI--") {
      pti_info <- table_details[3]
    }
    pti_infos <- c(pti_infos, pti_info)
    i <- i + 2
  }

  # Check if given table(s) is/are non-empty and present in the example file.
  # Table names are passed in dots '...'.
  table_not_present <- c()
  tables_empty <- c()
  tableIndices <- c()
  for (table in tableNames) {
    if (! table %in% file_table_names)
      table_not_present <- c(table_not_present, table)
    if(grepl("^$", table) || grepl("^\\s*$", table))
      # Empty table name or table name containing only spaces
      tables_empty <- c(tables_empty, table)
    tableIndices <- c(tableIndices, match(table, file_table_names))
  }
  if (length(tables_empty) > 0)
    .ta.stop("TDR_E3003", "...")
  if (length(table_not_present) > 0)
    .ta.stop("TDR_E2101", fileName, paste0(table_not_present, collapse = "', '"))
  
  con <- .taConnection()
  # Get the temporary schema name.
  databaseName <- td_get_context()$temp.database

  # For all the table names given in loadExampleData dots.
  for (i in 1:length(tableNames)) {
    ind <- tableIndices[i]

    if (load_types[ind] == "--query--") {
      # TODO: If needed to create a table, we need to work on this in here
      #       For future purpose.
      # res <- taQuery(query)
    } else {
      # Get full table name.
      tableName <- in_schema(databaseName, tableNames[i])

      # Load only if the table doesn't exists in that schema.
      if (!dbExistsTable(con, tableName)) {
        cat(paste("Loading: ", tableName, "....\n"))

        # Get the data from the .csv file ans store in 'res'
        fName <- paste(tableNames[i], ".csv", sep="")
        confName <- system.file("extdata", fName, package="tdplyr")
        # Get the table name from the args even if it is same as dataFile name.
        res <- read.csv(confName)

        # Load the data based on the data loading type.
        colTypesInsert = NULL # Used when inserting the data into the table
        colTypesCreate = NULL # Used when creating the table; different from colTypesInsert when load type is PTI.
        pti_clause = NULL # if load type is "load" and "loadByTypes"
        pti_type = NULL # if load type is "load" and "loadByTypes"

        # Fetch metadata if load type is not --load--.
        if (load_types[ind] == "--loadByTypes--") {
          colTypesInsert <- strsplit(data_types[ind], ",")[[1]]
          colTypesInsert <- unlist(lapply(colTypesInsert, function(x) {.ta.trimString(x)}))
          colTypesCreate <- colTypesInsert
        }
        timecode_col_info <- NULL
        seq_col <- NULL
        if (load_types[ind] == "--loadPTI--") {
          timecode_col_info <- c("TD_TIMECODE" = "TIMESTAMP(6)")
          colTypesInsert <- strsplit(data_types[ind], ",")[[1]]
          pti_info <- strsplit(pti_infos[ind], "$$", fixed = TRUE)[[1]]
          pti_type <- pti_info[1]
          pti_clause <- pti_info[2]
          if(pti_type == "SEQ") {
            seq_col <- "TD_SEQNO"
            # Excluding first 2 column types when table is sequenced table.
            colTypesCreate <- colTypesInsert[-c(1,2)]
          } else if (pti_type == "NON_SEQ") {
            # Excluding first column type when table is non-sequenced table.
            colTypesCreate <- colTypesInsert[-1]
          }
        }

        # Create table using 'types = colTypesCreate'
        createTableStmnt <- .ta.constructCreateTableSQL(con, res, table.name = tableName,
                                                        table.type = "PI", primary.index = NULL,
                                                        row.names = FALSE, types = colTypesCreate,
                                                        temporary = FALSE, pti_clause = pti_clause,
                                                        pti_type = pti_type)

        # Execute the create table query
        dbExecute(con, createTableStmnt)

        # Insert data into table using 'types = colTypesInsert'
        # Since table is already created, we can directly insert data into the table. This will 
        # avoid unnecessary checks.
        # The function ".insertDataInDBandAnalyzeTable" needs table name as class "Id".
        if (inherits(tableName, "ident_q")) {
          tableName <- DBI::Id(schema = .extractDatabaseNameQuoted(tableName), 
                               table = .extractTableNameQuoted(tableName))
        }
        .insertDataInDBandAnalyzeTable(dest = con, df = res, name = tableName, table.type = "PI",
                                       primary.index = NULL, row.names = FALSE, 
                                       types = colTypesInsert, analyze = FALSE)
      } else
        cat(paste("Skipping: ", tableName, " - Already exists.\n"))
    }
  }
}
