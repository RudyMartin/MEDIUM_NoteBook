# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.7
# 
# ################################################################## 

# Description:
#   The TextTagging function tags text documents according to user-defined
#   			rules that use text-processing and logical operators.
# 
# Args:
#   data -
#     Required Argument.\cr
#     The input tbl_teradata that contains the texts.\cr
#   
#   data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   rules.data -
#     Optional Argument.\cr
#     The input tbl_teradata that contains the rules.\cr
#   
#   rules.data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "rules.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   language -
#     Optional Argument.\cr
#     Specifies the language of the input text:  "en": English (default),  
#     "zh_cn": Simple Chinese,  "zh_tw": Traditional Chinese, If Tokenize 
#     specifies "true", then the function uses the value of Language to 
#     create the word tokenizer.\cr
#     Default Value: "en"\cr
#     Permitted Values: en, zh_CN, zh_TW\cr
#     Types: character
#   
#   rules -
#     Optional Argument.\cr
#     Specifies the tag names and tagging rules. Use this argument if and 
#     only if you do not specify a rules table. For information about 
#     defining tagging rules, refer to "/Defining Tagging Rules"/ \cr
#     Types: character OR vector of characters
#   
#   tokenize -
#     Optional Argument.\cr
#     Specifies whether the function tokenizes the input text before 
#     evaluating the rules and tokenizes the text string parameter in the 
#     rule definition when parsing a rule. If you specify "true", then you 
#     must also specify the Language argument. \cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   outputby.tag -
#     Optional Argument.\cr
#     Specifies whether the function outputs a tuple when a text document 
#     matches multiple tags. which means that one tuple in the output 
#     stands for one document and the matched tags are listed in the output 
#     column tag.\cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   tag.delimiter -
#     Optional Argument.\cr
#     Specifies the delimiter that separates multiple tags in the output 
#     column tag if outputby.tag has the value "false" (the default). The 
#     default value is the comma (,). If outputby.tag has the value "true", 
#     specifying this argument causes an error.\cr
#     Default Value: ","\cr
#     Types: character
#   
#   accumulate -
#     Optional Argument.\cr
#     Specifies the names of text tbl_teradata columns to copy to the 
#     output table. Note: Do not use the name "tag" for an 
#     accumulate_column, because the function uses that name for the output 
#     tbl_teradata column that contains the tags. \cr
#     Types: character OR vector of Strings (character)
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   rules.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "rules.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_text_tagger_mle" which is a 
#   named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_text_tagger_mle <- function(
  data = NULL,
  rules.data = NULL,
  language = "en",
  rules = NULL,
  tokenize = FALSE,
  outputby.tag = FALSE,
  tag.delimiter = ",",
  accumulate = NULL,
  data.sequence.column = NULL,
  rules.data.sequence.column = NULL,
  data.order.column = NULL,
  rules.data.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("rules.data", rules.data, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("rules.data.order.column", rules.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("language", language, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("rules", rules, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("tokenize", tokenize, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("outputby.tag", outputby.tag, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("tag.delimiter", tag.delimiter, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("rules.data.sequence.column", rules.data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  .validateInputTableDataType(rules.data, NULL)
  
  # Check for permitted values
  languagePermittedValues <- list("EN", "ZH_CN", "ZH_TW")
  .validatePermittedValues(language, languagePermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(rules.data.sequence.column)
  .validateTblHasArgumentColumns(rules.data.sequence.column, "rules.data.sequence.column", rules.data, "rules.data")
  
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  .validateInputColumnsNotEmpty(rules.data.order.column)
  .validateTblHasArgumentColumns(rules.data.order.column, "rules.data.order.column", rules.data, "rules.data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  if (!is.null(accumulate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(accumulate,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(rules)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TaggingRules")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(rules, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(language) && !missing(language)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "InputLanguage")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(language, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(tokenize) && !missing(tokenize)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Tokenize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(tokenize, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(outputby.tag) && !missing(outputby.tag)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputbyTag")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(outputby.tag, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(tag.delimiter) && !missing(tag.delimiter)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TagDelimiter")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(tag.delimiter, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (!is.null(rules.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("rules:", .teradataCollapseArgVector(rules.data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "ANY")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # Process rules.data
  if (!is.null(rules.data)) {
    tableRef <- .teradataOnClauseFromDataFrame(rules.data)
    funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "rules")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(rules.data.order.column, "\""))
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "TextTagging",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("TextTagging", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data, rules.data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_text_tagger_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_text_tagger <- td_text_tagger_mle