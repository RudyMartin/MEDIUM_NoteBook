# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Arun Kalyanasundaram (arun.kalyanasundaram@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.3
# 
# ################################################################## 

# Description:
#   The StringSimilarity function calculates the similarity between two
#   strings, using either the Jaro, Jaro-Winkler, N-Gram, or
#   Levenshtein distance. The similarity is a value in the range [0, 1].
# 
# Args:
#   data -
#     Required Argument.
#     The relation that contains the string pairs to be compared.
#   
#   data.order.column -
#     Optional Argument.
#     Specifies Order By columns for data.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   comparison.columns -
#     Required Argument.
#     Specifies pairs of input tbl_teradata columns that contain strings to 
#     be compared (column1 and column2), how to compare them 
#     (comparison_type), and (optionally) a constant and the name of the 
#     output column for their similarity (output_column). The similarity is 
#     a value in the range [0, 1]. For comparison_type, use one of these 
#     values:  "jaro": Jaro distance,  "jaro_winkler": Jaro-Winkler 
#     distance (1 for an exact match, 0 otherwise),  "n-gram": N-gram 
#     similarity. If you specify this comparison type, you can specify the 
#     value of N with constant.  "LD": Levenshtein distance (the number of 
#     edits needed to transform one string into the other, where edits 
#     include insertions, deletions, or substitutions of individual 
#     characters), "LDWS": Levenshtein distance without substitution. 
#     Number of edits needed to transform one string into the other using 
#     only insertions or deletions of individual characters. "OSA": Optimal 
#     string alignment distance. Number of edits needed to transform one 
#     string into the other. Edits are insertions, deletions, 
#     substitutions, or transpositions of characters. A substring can be 
#     edited only once. "DL": Damerau-Levenshtein distance. Like OSA, 
#     except that a substring can be edited any number of times. "hamming": 
#     Hamming distance. For strings of equal length, number of positions 
#     where corresponding characters differ (that is, minimum number of 
#     substitutions needed to transform one string into the other). For 
#     strings of unequal length, -1. "LCS": Longest common substring. 
#     Length of longest substring common to both strings. "jaccard": 
#     Jaccard indexed-based comparison. "cosine": Cosine similarity. 
#     "soundexcode": Only for English strings: -1 if either string has a 
#     non-English character; otherwise, 1 if their soundex codes are the 
#     same and 0 otherwise. You can specify a different comparison_type for 
#     every pair of columns. The default output_column is "sim_i", where i 
#     is the sequence number of the column pair.
#     Types: character OR vector of characters
#   
#   case.sensitive -
#     Optional Argument.
#     Specifies whether string comparison is case-sensitive. The default 
#     value is "false". You can specify either one value for all pairs or 
#     one value for each pair. If you specify one value for each pair, then 
#     the ith value applies to the ith pair.
#     Types: logical OR vector of logicals
#   
#   accumulate -
#     Optional Argument.
#     Specifies the names of input tbl_teradata columns to be copied to the 
#     output table
#     Types: character OR vector of Strings (character)
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_string_similarity_mle" which 
#   is a named list containing Teradata tbl object.
#   Named list member can be referenced directly with the "$" operator 
#   using name: result.
# 
# 
#' @export
td_string_similarity_mle <- function(
  data = NULL,
  comparison.columns = NULL,
  case.sensitive = NULL,
  accumulate = NULL,
  data.sequence.column = NULL,
  data.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("comparison.columns", comparison.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("case.sensitive", case.sensitive, TRUE, c("logical","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  if (!is.null(accumulate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(accumulate,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ComparisonColumnPairs")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(comparison.columns, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  if (!is.null(case.sensitive)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Casesensitive")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(case.sensitive, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "ANY")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "StringSimilarity",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("StringSimilarity", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_string_similarity_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
