# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Adithya Avvaru (adithya.avvaru@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.11
# 
# ################################################################## 

# Description:
#   The TextClassifierTrainer function trains a machine-learning 
#   classifier for text
#   			classification and creates a model file. After installing the 
#   model file in Aster
#   			Database, you can input it to the function TextClassifier.
# 
# Args:
#   data -
#     Required Argument.\cr
#     Specifies the name of the tbl_teradata that contains the documents to 
#     use to train the model.\cr
#   
#   text.column -
#     Required Argument.\cr
#     Specifies the name of the column that contains the text of the 
#     training documents.\cr
#     Types: character
#   
#   category.column -
#     Required Argument.\cr
#     Specifies the name of the column that contains the category of the 
#     training documents.\cr
#     Types: character
#   
#   classifier.type -
#     Optional Argument.\cr
#     Specifies the classifier type of the model, KNN algorithm or maximum 
#     entropy model.\cr
#     Default Value: "maxEnt"\cr
#     Permitted Values: maxEnt, knn\cr
#     Types: character
#   
#   classifier.parameters -
#     Optional Argument.\cr
#     Applies only if the classifier type of the model is KNN. Specifies 
#     parameters for the classifier. The name must be "compress" and value 
#     must be in the range (0, 1). The n training documents are clustered 
#     into value*n groups (for example, if there are 100 training 
#     documents, then ClassifierParameters("compress:0.6") clusters them 
#     into 60 groups), and the model uses the center of each group as the 
#     feature vector.\cr
#     Types: character OR vector of characters
#   
#   nlp.parameters -
#     Optional Argument.\cr
#     Specifies natural language processing (NLP) parameters for 
#     preprocessing the text data and produce tokens. Each name:value pair 
#     must be one of the following:  tokenDictFile: token_file where 
#     token_file is the name of an Aster Database file in which each line 
#     contains a phrase, followed by a space, followed by the token for the 
#     phrase (and nothing else).  stopwordsFile:stopword_file where 
#     stopword_file is the name of an Aster Database file in which each 
#     line contains exactly one stop word (a word to ignore during 
#     tokenization, such as a, an, or the).  useStem:{true|false} which 
#     specifies whether the function stems the tokens. The default value is 
#     "false".  stemIgnoreFile:stem_ignore_file where stem_ignore_file is 
#     the name of an Aster Database file in which each line contains 
#     exactly one word to ignore during stemming. Specifying this parameter 
#     with "useStem:false" causes an exception.  useBgram:{ true | false } 
#     which specifies whether the function uses Bigram, which considers the 
#     proximity of adjacent tokens when analyzing them. The default value 
#     is "false".  language:{ en | zh_CN | zh_TW } which specifies the 
#     language of the input text - English (en), Simplified Chinese (zh_CN), 
#     or Traditional Chinese (zh_TW). The default value is en. For the 
#     values zh_CN and zh_TW, the function ignores the parameters useStem 
#     and stemIgnoreFile. Example: nlp.parameters 
#     ("tokenDictFile:token_dict.txt", "stopwordsFile:fileName", 
#     "useStem:true", "stemIgnoreFile:fileName", "useBgram:true", 
#     "language:zh_CN")\cr
#     Types: character OR vector of characters
#   
#   feature.selection -
#     Optional Argument.\cr
#     Specifies the feature selection method, DF (document frequency). The 
#     values min and max must be in the range (0, 1). The function selects 
#     only the tokens that appear in at least min*n documents and at most 
#     max*n documents, where n is the number of training documents. For 
#     example, FeatureSelection ("DF:[0.1:0.9]") causes the function to 
#     select only the tokens that appear in at least 10% but no more than 
#     90% of the training documents. If min exceeds max, the function uses 
#     min as max and max as min.\cr
#     Types: character
#   
#   model.file -
#     Required Argument.\cr
#     The name of the model file to be generated.\cr
#     Types: character
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_text_classifier_trainer_mle" 
#   which is a named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_text_classifier_trainer_mle <- function(
  data = NULL,
  text.column = NULL,
  category.column = NULL,
  classifier.type = "maxEnt",
  classifier.parameters = NULL,
  nlp.parameters = NULL,
  feature.selection = NULL,
  model.file = NULL,
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("text.column", text.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("category.column", category.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("classifier.type", classifier.type, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("classifier.parameters", classifier.parameters, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("nlp.parameters", nlp.parameters, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("feature.selection", feature.selection, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("model.file", model.file, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check for permitted values
  classifier.typePermittedValues <- list("MAXENT", "KNN")
  .validatePermittedValues(classifier.type, classifier.typePermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(text.column)
  .validateTblHasArgumentColumns(text.column, "text.column", data, "data")
  
  .validateInputColumnsNotEmpty(category.column)
  .validateTblHasArgumentColumns(category.column, "category.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  # Manually added - 'model.file' cannot be empty string as it is filename.
  # Without this check, actual error message is
  # "TEXTCLASSIFIERTRAINER: Error occured when constructing trainer: 
  # The length of file name must be greater than 0 and less than or equal to 32. ()"
  .validateInputColumnsNotEmpty(model.file)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_text_classifier_trainer_mle.internal)
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 0) {
    attr(retval, "class") <- .getSQLMRClass("td_text_classifier_trainer_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_text_classifier_trainer_mle.internal <- function(
  data = NULL,
  text.column = NULL,
  category.column = NULL,
  classifier.type = "maxEnt",
  classifier.parameters = NULL,
  nlp.parameters = NULL,
  feature.selection = NULL,
  model.file = NULL,
  data.sequence.column = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TextColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(text.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CategoryColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(category.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  # Actual conditions should be "if (!is.null(classifier.type) && !missing(classifier.type))"
  # Modifying this because of a bug in analytical function ANLY-10944.
  if (!is.null(classifier.type)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ClassifierType")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(classifier.type, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ModelFile")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(model.file, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  if (!is.null(classifier.parameters)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ClassifierParameters")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(classifier.parameters, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(nlp.parameters)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NlpParameters")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(nlp.parameters, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(feature.selection)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "FeatureSelectionMethod")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(feature.selection, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "TextClassifierTrainer",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("TextClassifierTrainer", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input = is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 0) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}