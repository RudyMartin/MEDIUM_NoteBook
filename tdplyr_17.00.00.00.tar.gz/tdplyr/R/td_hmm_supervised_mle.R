# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Jeris Alan Jawahar (jeris.jawahar@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 2.1
# 
# ################################################################## 

# Description:
#   The HMMSupervised function runs on the SQL-GR framework. The function 
#   can produce multiple HMM models simultaneously, where each model is 
#   learned from a set of sequences and where each sequence represents a 
#   vertex.
# 
# Args:
#   vertices -
#     Required Argument.
#     vertex table
#   
#   vertices.partition.column -
#     Required Argument.
#     Specifies Partition By columns for vertices.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.
#     Types: character OR vector of Strings (character)
#   
#   vertices.order.column -
#     Required Argument.
#     Specifies Order By columns for vertices.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   model.key -
#     Optional Argument.
#     The name of the column that contains the model attribute. If you 
#     specify this argument, then its value must match a model_key in the 
#     partition.columns clause.
#     Types: character
#   
#   sequence.key -
#     Required Argument.
#     The name of the column that contains the sequence attribute. The 
#     sequence_attribute must be a sequence attribute in the 
#     partition.columns clause. A sequence must contain more than two 
#     observation symbols.
#     Types: character
#   
#   observed.key -
#     Required Argument.
#     The name of the column that contains the observed symbols. The 
#     function scans the input tbl_teradata to find all possible observed 
#     symbols. Note: Observed symbols are case-sensitive.
#     Types: character
#   
#   state.key -
#     Required Argument.
#     The state attributes. You can specify multiple states. The states are 
#     case-sensitive.
#     Types: character
#   
#   skip.key -
#     Optional Argument.
#     The name of the column whose values determine whether the function 
#     skips the row. The function skips the row if the value is "true", 
#     "yes", "y", or "1". The function does not skip the row if the value 
#     is "false", "f", "no", "n", "0", or NULL.
#     Types: character
#   
#   batch.size -
#     Optional Argument.
#     The number of models to process. The size must be positive. If the 
#     batch size is not specified, the function avoids out-of-memory errors 
#     by determining the appropriate size. If the batch size is specified 
#     and there is insufficient free memory, the function reduces the batch 
#     size. The batch size is determined dynamically, based on the memory 
#     conditions. For example, at time T1, the specified batch size 1000 
#     might be adjusted to 980, and at time T2, the batch size might be 
#     adjusted to 800.
#     Types: integer
#   
#   vertices.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "vertices". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_hmm_supervised_mle" which is 
#   a named list containing Teradata tbl objects.
#   Named list members can be referenced directly with the "$" operator 
#   using following names:\enumerate{\item output.initialstate.table\item 
#   output.statetransition.table\item output.emission.table\item output}
# 
# 
#' @export
td_hmm_supervised_mle <- function(
  vertices = NULL,
  model.key = NULL,
  sequence.key = NULL,
  observed.key = NULL,
  state.key = NULL,
  skip.key = NULL,
  batch.size = NULL,
  vertices.sequence.column = NULL,
  vertices.partition.column = NULL,
  vertices.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("vertices", vertices, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("vertices.partition.column", vertices.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("vertices.order.column", vertices.order.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("model.key", model.key, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("sequence.key", sequence.key, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("observed.key", observed.key, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("state.key", state.key, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("skip.key", skip.key, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("batch.size", batch.size, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("vertices.sequence.column", vertices.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(vertices, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(state.key)
  .validateTblHasArgumentColumns(state.key, "state.key", vertices, "vertices")
  
  .validateInputColumnsNotEmpty(observed.key)
  .validateTblHasArgumentColumns(observed.key, "observed.key", vertices, "vertices")
  
  .validateInputColumnsNotEmpty(sequence.key)
  .validateTblHasArgumentColumns(sequence.key, "sequence.key", vertices, "vertices")
  
  .validateInputColumnsNotEmpty(skip.key)
  .validateTblHasArgumentColumns(skip.key, "skip.key", vertices, "vertices")
  
  .validateInputColumnsNotEmpty(model.key)
  .validateTblHasArgumentColumns(model.key, "model.key", vertices, "vertices")
  
  .validateInputColumnsNotEmpty(vertices.sequence.column)
  .validateTblHasArgumentColumns(vertices.sequence.column, "vertices.sequence.column", vertices, "vertices")
  
  .validateInputColumnsNotEmpty(vertices.partition.column)
  .validateTblHasArgumentColumns(vertices.partition.column, "vertices.partition.column", vertices, "vertices")

  .validateInputColumnsNotEmpty(vertices.order.column)
  .validateTblHasArgumentColumns(vertices.order.column, "vertices.order.column", vertices, "vertices")
  
  # Generate temp table names for output table parameters if any.
  output.initialstate.tableTempTableName <- .teradataGenerateTempTableName("td_hmm_supervised_mle0_", use.default.database=TRUE, gc.onQuit=TRUE)
  output.statetransition.tableTempTableName <- .teradataGenerateTempTableName("td_hmm_supervised_mle1_", use.default.database=TRUE, gc.onQuit=TRUE)
  output.emission.tableTempTableName <- .teradataGenerateTempTableName("td_hmm_supervised_mle2_", use.default.database=TRUE, gc.onQuit=TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_hmm_supervised_mle.internal)
  Call[["output.initialstate.tableTempTableName"]] <- output.initialstate.tableTempTableName
  Call[["output.statetransition.tableTempTableName"]] <- output.statetransition.tableTempTableName
  Call[["output.emission.tableTempTableName"]] <- output.emission.tableTempTableName
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_hmm_supervised_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_hmm_supervised_mle.internal <- function(
  vertices = NULL,
  model.key = NULL,
  sequence.key = NULL,
  observed.key = NULL,
  state.key = NULL,
  skip.key = NULL,
  batch.size = NULL,
  vertices.sequence.column = NULL,
  vertices.partition.column = NULL,
  vertices.order.column = NULL,
  output.initialstate.tableTempTableName = NULL,
  output.statetransition.tableTempTableName = NULL,
  output.emission.tableTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("InitStateTable", "StateTransitionTable", "EmissionTable")
  funcOutputArgs <- c(output.initialstate.tableTempTableName, output.statetransition.tableTempTableName, output.emission.tableTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StateColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(state.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ObservationColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(observed.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SeqColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(sequence.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(skip.key)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SkipColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(skip.key,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(model.key)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ModelColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(model.key,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(batch.size)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "BatchSize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(batch.size, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(vertices.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("vertices:", .teradataCollapseArgVector(vertices.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process vertices
  vertices.partition.column <- .teradataCollapseArgVector(vertices.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(vertices)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "vertices")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, vertices.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(vertices.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "HMMSupervisedLearner",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("HMMSupervisedLearner", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(vertices)
  
  # Return output table data frames.
  result <- list()
  result[["output.initialstate.table"]] <- .createDataSetObject(.extractTableName(output.initialstate.tableTempTableName), sourceType = "table", .extractDatabaseName(output.initialstate.tableTempTableName), is_dplyr_input)
  result[["output.statetransition.table"]] <- .createDataSetObject(.extractTableName(output.statetransition.tableTempTableName), sourceType = "table", .extractDatabaseName(output.statetransition.tableTempTableName), is_dplyr_input)
  result[["output.emission.table"]] <- .createDataSetObject(.extractTableName(output.emission.tableTempTableName), sourceType = "table", .extractDatabaseName(output.emission.tableTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_hmm_supervised <- td_hmm_supervised_mle
