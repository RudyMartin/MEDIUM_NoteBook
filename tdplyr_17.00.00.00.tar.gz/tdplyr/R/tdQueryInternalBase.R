#
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: pankajvinod.purandare@teradata.com
# Secondary Owner:gouri.patwardhan@teradata.com
#
# Core classes for generating SQLMR / Table Operator queries and expressions based on input
#

# Design Notes:
# The code is heavily based on R Reference Classes which is one of
# the OOP abstractions provided by R and also the one with most
# similarity to the OOP features provided by languages like C++
# and Java.
#
# These classes will help us to generate SQL for the following
# types of invocations
#
# (1) Map Only Sqlmr Function (e.g 'unpack')
# (2) Reduce Only Sqlmr Function
# (3) Multi-Input Reduce Sqlmr Function (e.g 'kmeansplot')
# (4) Table Operator Function
#
# .TeradataQueryFunctionBase is the base class from which the classes
# for generating Map Reduce SQL or Table operator SQL derive.
# It contains methods that will be common for derived (present and future)
# classes
#
#' @importFrom methods new
#' @importFrom rlang is_empty
#' @importFrom utils type.convert
.TeradataQueryFunctionBase <- setRefClass(
  ".TeradataQueryFunctionBase",
  contains = "VIRTUAL",
  # This will prevent instantiaion of this class
  fields = list(
    # This will be the name of the SQLMR function as it should
    # appear in the invocation of the SQL
    sqlmrFuncName = "character",
    
    # This should be a named vector containing the arguments to the
    # function except input and output arguments.
    # Names in the vector should correspond to the argument
    # names accepted by the SQLMR function.
    # All the arguments and argument names are assumed to be of character
    # type
    sqlmrFuncArgs = "vector",
    
    # This should be a named vector containing output table arguments to the
    # function. Names in the vector should correspond to the argument
    # names accepted by the SQLMR function.
    # All the arguments and argument names are assumed to be of character
    # type.
    sqlmrOutputTabArgs = "vector",
    
    # This is the name of the engine for the given analytic function.
    # Example : ml, sql(for native Teradata functions)
    sqlmrEngine = "character"
  ),
  
  methods = list(
    # This is equivalent to a constructor for the class
    initialize = function(sqlmrFuncName,
                          sqlmrFuncArgs,
                          sqlmrOutputTabArgs,
                          sqlmrEngine = .getEngineName("ENGINE_ML"))
    {
      # Check that all the required arguments have been supplied
      if (missing("sqlmrFuncName")) {
        stop("sqlmr function name must be provided")
      }
      
      # Check for null arguments. In any null's are observed throw an error.
      if (is.null(sqlmrFuncArgs)) {
        stop("sqlmrFuncArgs cannot be null. If empty please pass NA. ",
             "It must always be a vector.")
      }
      
      if (is.null(sqlmrOutputTabArgs)) {
        stop(
          "sqlmrOutputTabArgs cannot be null. If empty please pass NA. ",
          "It must always be a vector."
        )
      }
      
      # Make sure that the arguments vector has names corresponding
      # to each of the argument vectors.
      .self$validateFunctionArguments(sqlmrOutputTabArgs, "output ")
      .self$validateFunctionArguments(sqlmrFuncArgs, "")
      
      # Update the class members based on the arguments
      sqlmrFuncName <<-
        .getAliasNameForFunction(sqlmrFuncName, sqlmrEngine)
      sqlmrFuncArgs <<-
        setNames(sqlmrFuncArgs,
                 .processVectorForTeradataKeyword(names(sqlmrFuncArgs)))
      sqlmrOutputTabArgs <<-
        setNames(sqlmrOutputTabArgs,
                 .processVectorForTeradataKeyword(names(sqlmrOutputTabArgs)))
    },
    
    # Generates the SQL with argument names with values for use in the
    # SQLMR query
    genSqlmrFuncArgSql = function(sep = " ") {
      if (length(sqlmrFuncArgs) > 0 && !is.na(sqlmrFuncArgs)) {
        return(paste0(
          "\n\t",
          names(sqlmrFuncArgs),
          "(",
          sqlmrFuncArgs,
          ")",
          collapse = sep
        ))
      }
      else
        return("")
    },
    
    # Generates the complete ON clause for the SQLMR invocation
    # Process input tables
    genSqlmrInputFuncArgSql = function(tableRef, tableRefType, alias = NULL) {
      returnSql <- "\n\tON"
      if (tableRefType == "TABLE") {
        returnSql <- paste0(returnSql, " ", tableRef)
      } else if (tableRefType == "QUERY") {
        returnSql <- paste(returnSql, "(", tableRef, ")")
      } else {
        stop("invalid tableRefType")
      }
      
      if (!is.null(alias) &&
          !is.na(alias) && nchar(alias) > 0) {
        # Add quotes to the alias name, if alias name is one of the SQL keyword
        # in teradata.
        returnSql <-
          paste(returnSql, "as",
                .processFactorForTeradataKeyword(alias))
      }
      return(returnSql)
    },
    
    # Generates the SQL for the output table argument names with values for
    # use in the SQLMR query
    genSqlmrOutputFuncArgSql = function(sep = " ") {
      if (length(sqlmrOutputTabArgs) > 0 && !is.na(sqlmrOutputTabArgs))
        return(paste0(
          "\n\tOUT TABLE ",
          names(sqlmrOutputTabArgs),
          "(",
          sqlmrOutputTabArgs,
          ")",
          collapse = sep
        ))
      else
        return("")
    },
    
    # Generates the complete SELECT Sql statement for the SQLMR
    # function invocation. Any character vector supplied as an argument
    # will simply be appended to the resulting sql.
    genSqlmrSelectStmtSql = function(optClauses) {
      # Note that the function genSqlmrInvocationSql() will be implemented
      # by the derived classes
      resultSql <-
        paste("SELECT * FROM", .self$genSqlmrInvocationSql(),
              " as sqlmr")
      if (!missing(optClauses) &&
          !is.na(optClauses)) {
        resultSql <- paste(resultSql, optClauses)
      }
      return(resultSql)
    },
    
    # Method to make sure that the arguments vector has names corresponding
    # to each of the argument vectors.
    validateFunctionArguments = function(argumentVector, argType) {
      throwError <- FALSE
      # If SQL-MR function arguments are not assigned with NA then perform
      # following check.
      if (!is.na(argumentVector[1])) {
        # Case 1: All arguments in vector does not have names.
        if (is.null(names(argumentVector)) &&
            length(argumentVector) > 0)
          throwError <- TRUE
        
        # Case 2: Few arguments does not have names associated with the same.
        missingArgNameIdx <-
          (which(nchar(names(argumentVector)) == 0))
        if (length(missingArgNameIdx) > 0) {
          throwError <- TRUE
          argumentVector <-
            argumentVector[missingArgNameIdx]
        }
      }
      
      if (throwError)
        stop(
          paste0(
            "Name not supplied for following SQL-MR function ",
            argType,
            "arguments:"
          ),
          paste0("\n", argumentVector)
        )
    }
  )
  
)


# The class .TeradataSqlmrQueryGenerator derives from the base class
# .TeradataQueryFunctionBase and implements functionality specifically
# for generating the SQL for invocation of  SQLMR functions
# which can accept single or multi input.
.TeradataSqlmrQueryGenerator <- setRefClass(
  ".TeradataSqlmrQueryGenerator",
  contains = ".TeradataQueryFunctionBase",
  fields = list(inputTableRefMatrix  = "matrix"),
  methods = list(
    initialize = function(inputTableRefMatrix = list(), ...)
    {
      callSuper(...)
      
      if (missing("inputTableRefMatrix")) {
        stop("Input matrix is required for multi-input function")
      }
      
      # Validate the column names of the input table info matrix
      expectedColnames = c("tableRef",
                           "tableRefType",
                           "distribution",
                           "column",
                           "column_order",
                           "alias")
      
      if (!all(expectedColnames %in% colnames(inputTableRefMatrix))) {
        stop(paste(
          "Input matrix must have all the columns",
          paste(expectedColnames, collapse = ", ")
        ))
      }
      
      inputTableRefMatrix <<- inputTableRefMatrix
    },
    
    # Generates the invocation of the SQLMR function containing
    # the function name, ON clause, all the arguments and the
    # PARTITION BY clause
    genSqlmrInvocationSql = function() {
      genSqlmrInputPartitionClause <- function(distribution, column) {
        if (distribution == "FACT") {
          return(paste("\n\tPARTITION BY", column))
        } else if (distribution == "DIMENSION") {
          return("\n\tDIMENSION")
        } else if (distribution == "NONE") {
          return("")
        } else {
          stop("invalid distribution type")
        }
      }
      
      genSqlmrInputOrderClause <- function(column_order) {
        if (is.na(column_order)) {
          return("")
        }
        returnSql <- paste("\n\tORDER BY", column_order)
        return(returnSql)
      }
      
      singleCompleteTableRefClause <- function(argList) {
        paste(
          genSqlmrInputFuncArgSql(argList[[1]], argList[[2]], argList[[6]]),
          genSqlmrInputPartitionClause(argList[[3]], argList[[4]]),
          genSqlmrInputOrderClause(argList[[5]])
        )
      }
      
      invocationSql <- paste(
        .self$sqlmrFuncName,
        "(",
        paste0(
          apply(.self$inputTableRefMatrix, 1,
                singleCompleteTableRefClause),
          collapse = ' '
        ),
        .self$genSqlmrOutputFuncArgSql()
      )
      
      checkForNa <- sqlmrFuncArgs[[1]]
      if (!is.na(checkForNa)) {
        invocationSql <- paste(invocationSql, "\n\tUSING",
                               .self$genSqlmrFuncArgSql())
      }
      
      invocationSql <- paste(invocationSql, "\n)")
      
      
      return(invocationSql)
    }
  )
)

# The class .TeradataTblOpQueryGenerator derives from the base class
# .TeradataQueryFunctionBase and implements functionality specifically
# for generating the SQL for invocation of Table Operator functions
# which can accept single input.
.TeradataTblOpQueryGenerator <- setRefClass (
  ".TeradataTblOpQueryGenerator",
  contains = ".TeradataQueryFunctionBase",
  fields = list(
    inputTableRefMatrix  = "matrix",
    funcInputOrderByType = "character",
    funcInputNullsFirst = "logical",
    funcInputSortAscending = "logical"
  ),
  methods = list(
    initialize = function(inputTableRefMatrix = list(),
                          funcInputOrderByType,
                          funcInputSortAscending = "TRUE",
                          funcInputNullsFirst = NA ,
                          ...)
    {
      callSuper(...)
      
      if (missing("inputTableRefMatrix")) {
        stop("Input matrix is required for multi-input function")
      }
      if (!is.null(inputTableRefMatrix)) {
        # Validate the column names of the input table info matrix
        expectedColnames = c("tableRef",
                             "tableRefType",
                             "distribution",
                             "column",
                             "column_order",
                             "alias")
        
        if (!all(expectedColnames %in% colnames(inputTableRefMatrix))) {
          stop(paste(
            "Input matrix must have all the columns",
            paste(expectedColnames, collapse = ", ")
          ))
        }
        inputTableRefMatrix <<- inputTableRefMatrix
      }
      
      if (!is.null(funcInputOrderByType))
        funcInputOrderByType <<- funcInputOrderByType
      
      if (!is.null(funcInputNullsFirst))
        funcInputNullsFirst <<- funcInputNullsFirst
      
      funcInputSortAscending <<- funcInputSortAscending
    },
    
    # Generates the invocation of the SQLMR function containing
    # the function name, ON clause, all the arguments and the
    # PARTITION BY clause
    genSqlmrInvocationSql = function() {
      genTblOpInputPartitionClause <- function(distribution, column) {
        if ((distribution == "FACT") && !is.na(column))  {
          args_sql_str <- paste("\n\tPARTITION BY", column)
        } else if ((distribution == "FACT") && is.na(column)) {
          args_sql_str <- "\n\tPARTITION BY ANY"
        } else if (distribution == "DISTRIBUTION") {
          args_sql_str <- "\n\tDIMENSION"
        } else if ((distribution == "HASH") && !is.null(column)) {
          args_sql_str <- paste("\n\t HASH BY", column)
        } else
          return (" ")
        
        return(args_sql_str)
        
      }
      
      genTblOpInputOrderClause <- function(order_by_type,
                                           sort_ascending,
                                           nulls_first,
                                           column_order) {
        sort_order <- "ASC"
        nulls_order <- NULL
        if (is.na(column_order) || is.null(column_order)) {
          return("")
        }
        if (!isTRUE(sort_ascending)) {
          sort_order <- "DESC"
        }
        if (isTRUE(nulls_first)) {
          nulls_order <- "NULLS FIRST"
        } else {
          nulls_order <- "NULLS LAST"
        }
        if (!is_empty(order_by_type)) {
          if (order_by_type == "LOCAL") {
            returnSql <-
              paste("\n\t LOCAL ORDER BY",
                    column_order,
                    sort_order,
                    nulls_order)
          }
        } else {
          returnSql <-
            paste("\n\tORDER BY", column_order, sort_order, nulls_order)
        }
        return(returnSql)
      }
      
      singleCompleteTableRefClause <- function(argList) {
        paste(
          genSqlmrInputFuncArgSql(argList[[1]], argList[[2]], argList[[6]]),
          genTblOpInputPartitionClause(argList[[3]], argList[[4]]),
          genTblOpInputOrderClause(
            funcInputOrderByType,
            funcInputSortAscending,
            funcInputNullsFirst,
            argList[[5]]
          )
        )
      }
      
      if (!is_empty(.self$inputTableRefMatrix)) {
        invocationSql <- paste(
          .self$sqlmrFuncName,
          "(",
          paste0(
            apply(
              .self$inputTableRefMatrix,
              1,
              singleCompleteTableRefClause
            ),
            collapse = ' '
          ),
          .self$genSqlmrFuncArgSql()
        )
      } else {
        invocationSql <-
          paste(.self$sqlmrFuncName, "(", .self$genSqlmrFuncArgSql())
      }
      
      invocationSql <- paste(invocationSql, "\n)")
      
      return(invocationSql)
    }
  )
)