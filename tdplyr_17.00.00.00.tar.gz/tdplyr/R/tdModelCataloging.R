#
# Copyright 2020 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: Rohit Khurd (rohit.khurd@teradata.com)
# Secondary Owner: 
#
# Model Cataloging APIs
# The Model Cataloging APIs provide the user an easy and intuitive approach 
# to save/persist models to the database and allow them to be retrieved/loaded
# for any further use. The basic set of features provided are as follows:
# 1. Save model
# 2. List saved models
# 3. Describe model
# 4. Delete model
# 5. Retrieve model
# 6. Publish model
#
###############################################################################
#
#' td_save_model
#' 
#' Function to save a tdplyr analytic function model to the Model Catalog.
#' 
#' @param model Required Argument.\cr
#'              Specifies the tdplyr analytic function model to be saved.\cr
#'              Types: Object of class td_analytics
#' @param name  Required Argument.\cr
#'              Specifies the unique name to identify the model to be saved.\cr
#'              The maximum length of the "name" is 128 characters.\cr
#'              Types: character
#' @param description Required Argument.\cr
#'                    Specifies a note describing the model to be saved.\cr
#'                    The maximum length of the "description" is 1024
#'                    characters.\cr
#'                    Types: character
#' @param model.project Optional Argument.\cr
#'                      Specifies a project name that the model is
#'                      associated with.\cr
#'                      The maximum length of the "model.project" is 128
#'                      characters.\cr
#'                      Types: character
#' @param entity.target Optional Argument.\cr
#'                      Specifies a group or team that the model is associated
#'                      with.\cr
#'                      The maximum length of the "entity.target" is 128
#'                      characters.\cr
#'                      Types: character
#' @param performance.metrics Optional Argument.\cr
#'                            Specifies the performance metrics for the
#'                            model.\cr
#'                            "performance.metrics" must be a named list of the
#'                            following form:\cr
#'                                list(<metric> = list(measure = <value>), ...)\cr
#'                            For example:\cr
#'                                list(AUC = list(measure = 0.5), ...)\cr
#'                            The value should be of type numeric.\cr
#'                            Types: Named list of numeric values
#' @examples
#' \donttest{
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#' 
#' # Load example data.
#' loadExampleData("glm_example", "admissions_train")
#' 
#' # Create object of class "tbl_teradata" to use as input.
#' admissions_train <- tbl(con, "admissions_train")
#' 
#' # Create the GLM model.
#' td_glm_out1 <- td_glm_mle(formula = (admitted ~ stats + masters + gpa + programming),
#'                           family = "LOGISTIC",
#'                           linkfunction = "LOGIT",
#'                           data = admissions_train,
#'                           weights = "1",
#'                           threshold = 0.01,
#'                           maxit = 25,
#'                           step = FALSE,
#'                           intercept = TRUE
#' )
#' 
#' # Save this generated model.
#' td_save_model(model = td_glm_out1, name = "glm_model", description = "GLM test")
#' }
#' 
#' @importFrom dbplyr in_schema
#' @importFrom DBI dbBegin
#' @importFrom DBI dbCommit
#' @importFrom DBI dbRollback
#' @importFrom dbplyr ident_q
#' @importFrom dplyr copy_to
#' @importFrom jsonlite toJSON
#' @export
td_save_model <- function(model, name, description,
                          model.project = NULL, entity.target = NULL,
                          performance.metrics = NULL) {
  # First, check if model catalog exists
  .checkIfModelCatalogingTablesExists()
  
  # If model is not specified, then throw an error.
  if (is.null(model))
    .ta.stop("TDR_E3001", "model")
  
  # If model is not of td_analytics class, then throw an error
  if (!inherits(model, "td_analytics"))
    .ta.stop("TDR_E3002", "model", "td_analytics")
  
  # Argument validation
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("name", name, FALSE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("description", description, FALSE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("model.project", model.project, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("entity.target", entity.target, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("performance.metrics", performance.metrics, TRUE, c("numeric", "named list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check for length of model name, description, model.project, entity.target
  .validateArgValueLength(name, 128, "LE")
  .validateArgValueLength(description, 1024, "LE")
  .validateArgValueLength(model.project, 128, "LE")
  .validateArgValueLength(entity.target, 128, "LE")
  
  # Check if the values are empty
  .validateInputColumnsNotEmpty(name)
  .validateInputColumnsNotEmpty(description)
  .validateInputColumnsNotEmpty(model.project)
  .validateInputColumnsNotEmpty(entity.target)

  # Add check to make sure model is not a retrieved model
  sqlSpecificAttributes <- attr(model, "mc.sql.specific.attributes")
  if (is.null(sqlSpecificAttributes))
    .ta.stop("TDR_E4008")
  
  # Check to make sure that the model name is not already taken
  .checkIfModelExists(name = name, raise.error.if.found = TRUE,
                      raise.error.if.not.found = FALSE)
  
  modelEngineAdvSQL <- .get(".mc.modelEngineAdvSQL")
  
  # Get the username
  con <- .taConnection()
  createdBy <- .get_username(con)
  # Generating Engine
  generatingEngine <- .td.mc.getExecutionEngine(model)
  # Generating client
  generatingClient <- .get(".mc.generatingClientTdplyr")
  # Algorithm name
  algorithm <- tolower(attr(model, "mc.algorithm.name"))
  # Time to get the run the function
  buildTime <- attr(model, "mc.build.time")
  # The target column for the function
  targetColumn <- attr(model, "mc.target.column")
  if (is.list(targetColumn)) {
    # This condition will be TRUE for response in a formula.
    # We pick the first and for the repsonse.
    targetColumn <- targetColumn[[1]]
  }
  # The prediction type for the function
  predictionType <- attr(model, "mc.prediction.type")
  
  status <- .get(".mc.defaultSaveStatus")
  access <- .get(".mc.defaultSaveAccess")
  location <- modelEngineAdvSQL
  
  functionArgMapper <- .getFunctionArgMapper(generatingEngine, algorithm)
  vantageVersion <- .get("functionArgumentMap")$vantageVersion
  
  # Performace metrics
  if (!is.null(performance.metrics))
    performance.metrics <- jsonlite::toJSON(performance.metrics, auto_unbox = TRUE)
  
  # Get training objects, data
  trainingData <- jsonlite::toJSON(.td.mc.getModelInputs(model, functionArgMapper), auto_unbox = TRUE)
  outputInfo <- .td.mc.getModelOuputs(model, functionArgMapper)
  trainingObjects <- jsonlite::toJSON(outputInfo$outputs, auto_unbox = TRUE)
  gcTables <- outputInfo$gcTables
  
  # Get algorithm parameters
  algorithmParameters <- jsonlite::toJSON(.td.mc.getAlgorithmParameters(model, functionArgMapper), auto_unbox = TRUE)
  # Escape single quotes in the values with double quotes
  algorithmParameters <- gsub("'", "''", algorithmParameters)
  
  # Form stored procedure query and call it
  saveSP <- .get(".mc.saveModel")
  saveSP <- .td.mc.getStoredProcedureName(saveSP)
  
  # Form the stored procedure call
  spCall <- gettextf(paste0("CALL %s('%s', %s, '%s', %s,",
                            " '%s', '%s', '%s', '%s', '%s',",
                            " %s, '%s', '%s', '%s', '%s',",
                            " '%s', '%s', '%s', '%s', %s, %s, SaveStatus)"),
                     saveSP,
                     name,
                     if (!is.null(model.project)) gettextf("'%s'", model.project) else "NULL",
                     description,
                     if (!is.null(targetColumn)) gettextf("'%s'", targetColumn) else "NULL",
                     predictionType,
                     generatingEngine,
                     generatingClient,
                     vantageVersion,
                     algorithm,
                     if (!is.null(entity.target)) gettextf("'%s'", entity.target) else "NULL",
                     buildTime,
                     createdBy,
                     status,
                     access,
                     location,
                     trainingObjects,
                     algorithmParameters,
                     trainingData,
                     if (!is.null(performance.metrics)) gettextf("'%s'", performance.metrics) else "NULL",
                     "NULL")
  
  # Start database transaction
  dbBegin(con)
  tryCatch({
    
    # Execute the stored procedure call
    dbExecute(con, spCall)
    
    # Commit the database transactions
    dbCommit(con)
    
    # If we have come till here, then the transaction was successfully committed.
  }, error = function(err){
    # Rollback the transaction on any error
    dbRollback(con)
    
    # Note: If any failure occurs in the above transaction block, entries for the model output tables will be 
    # in the GC file and we need not add anything explicitly here to the GC file again.
    
    # Print the error message
    .ta.stop(err)
  })
  
  # Print the information for the user experience.
  cat("Persisting model information.", "\n")
  
  # Remove entries of new model outputs from GC file.
  for (temptable in gcTables){
    isRemoved <- .ta.removeTempObject(tolower(temptable), "table", forcePersist = TRUE)
    if (isRemoved)
      cat(gettextf("Persisted table: %s", temptable), "\n")
  }
  cat("Successfully persisted model.", "\n")
}

#
#' td_delete_model
#' 
#' Function to delete a saved model, and optionally the model objects.\cr
#' A model can be deleted only by its creator.
#' 
#' @param name  Required Argument.\cr
#'              Specifies the name of the model to be deleted.\cr
#'              Types: character
#' @param delete.objects Required Argument.\cr
#'                       Specifies whether to drop objects of the model
#'                       to be deleted.\cr
#'                       When TRUE, the model objects are deleted/dropped.\cr
#'                       Default Value: FALSE\cr
#'                       Types: logical
#' @examples 
#' \donttest{
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#' 
#' # Load example data.
#' loadExampleData("glm_example", "admissions_train")
#' 
#' # Create object of class "tbl_teradata" to use as input.
#' admissions_train <- tbl(con, "admissions_train")
#' 
#' # Create the GLM model.
#' td_glm_out1 <- td_glm_mle(formula = (admitted ~ stats + masters + gpa + programming),
#'                           family = "LOGISTIC",
#'                           linkfunction = "LOGIT",
#'                           data = admissions_train,
#'                           weights = "1",
#'                           threshold = 0.01,
#'                           maxit = 25,
#'                           step = FALSE,
#'                           intercept = TRUE
#' )
#' 
#' # Save this generated model.
#' td_save_model(model = td_glm_out1, name = "glm_model", description = "GLM test")
#' 
#' # Example 1 - Only delete model information from the Model Catalog.
#' td_delete_model('glm_model')
#' 
#' # Example 2 - Delete model information from the Model Catalog 
#' # and drop model objects as well.
#' # This example does not apply to the model we just saved, as we have already
#' # deleted it from the catalog in Example 1.
#' # We save the model again with another name for this example.
#' td_save_model(model = td_glm_out1, name = "glm_model_2", description = "GLM test 2")
#'
#' td_delete_model('glm_model_2', TRUE)
#' }
#' 
#' @importFrom DBI dbExecute
#' @importFrom DBI dbBegin
#' @importFrom DBI dbCommit
#' @importFrom DBI dbRollback
#' @importFrom dbplyr in_schema
#' @export
td_delete_model <- function(name, delete.objects = FALSE) {
  # First, check if model catalog exists
  .checkIfModelCatalogingTablesExists()
  
  # Argument validation
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("name", name, FALSE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("delete.objects", delete.objects, TRUE, c("logical", NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check if the values are empty
  .validateInputColumnsNotEmpty(name)
  
  # Check if model exists
  .checkIfModelExists(name, created = TRUE, raise.error.if.not.found = TRUE)
  
  # Get the username
  con <- .taConnection()
  currentUser <- .get_username(con)
  
  # Get the models tables for the given model
  modelTables <- .td.mc.getTablesForModel(name, currentUser)
  
  # Form stored procedure query and call it
  deleteSP <- .get(".mc.deleteModel")
  deleteSP <- .td.mc.getStoredProcedureName(deleteSP)
  
  # Form the stored procedure call
  spCall <- gettextf("CALL %s('%s', DeleteStatus)",
                     deleteSP, name)
  
  # Start database transaction
  dbBegin(con)
  tryCatch({
    
    # Execute the stored procedure call
    dbExecute(con, spCall)
    
    # Commit the database transactions
    dbCommit(con)
    
    # If we have come till here, then the transaction was successfully committed.
  }, error = function(err){
    # Rollback the transaction on any error
    dbRollback(con)
    
    # Print the error message
    .ta.stop(err)
  })
  
  cat(gettextf("Deleted the model '%s' successfully.", name), "\n")
  
  if (isTRUE(delete.objects)) {
    failedToDrop <- c()
    
    for (tableName in modelTables) {
      dbName <- .extractDatabaseNameQuoted(tableName)
      tabName <- .extractTableNameQuoted(tableName)
      
      tryCatch({
        db_drop_table(con, in_schema(dbName, tabName))
      }, error = function(err){
        # Append to the vector of tables that couldn't be dropped.
        failedToDrop <<- c(tableName, failedToDrop)
      })
    }
    
    if (length(failedToDrop) > 0)
      .ta.warning(gettextf("Failed to drop the following Model Objects: %s.",
                           paste0(failedToDrop, collapse=", ", sep="")))
    else if (length(modelTables) > 0)
      cat("Model Objects dropped successfully.", "\n")
  }
  else
    if (length(modelTables) > 0)
      cat(gettextf("Model Objects that can be dropped: %s.",
                   paste0(modelTables, collapse=", ", sep="")), "\n")
}

# 
#' td_list_models
#' 
#' Function to list models accessible to the user and optionally only models
#' created by the user.
#' 
#' @param name Optional Argument.\cr
#'             Specifies the search string for model name.\cr
#'             When this argument is used, all models matching the name
#'             are listed.\cr
#'             The search is case-insensitive.\cr
#'             Types: character
#' @param algorithm.name Optional Argument.\cr
#'                       Specifies the search string for the analytic
#'                       function name.\cr
#'                       When this argument is used, all models matching
#'                       it are listed.\cr
#'                       The search is case-insensitive.\cr
#'                       Types: character
#' @param engine Optional Argument.\cr
#'               Specifies the model generating engine as a filter.\cr
#'               The search is case-insensitive.\cr
#'               Permitted Values: "ML Engine", "MLE", "Advanced SQL Engine",
#'               "SQLE"\cr
#'               Types: character
#' @param accessible Optional Argument.\cr
#'                   Specifies whether to list all models that the user has
#'                   access to, or only the models that the user created.\cr
#'                   When TRUE, all models which the user has access to are
#'                   listed.\cr
#'                   When FALSE, only models created by the user are listed.\cr
#'                   Default Value: TRUE\cr
#'                   Types: logical
#' @param public Optional Argument.\cr
#'               Specifies whether to filter only those models that have
#'               public access.\cr
#'               Default Value: FALSE\cr
#'               Types: logical
#' @return A data.frame representation of the model listing.
#' @examples 
#' \donttest{
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#' 
#' # Load example data.
#' loadExampleData("glm_example", "admissions_train")
#' 
#' # Create object of class "tbl_teradata" to use as input.
#' admissions_train <- tbl(con, "admissions_train")
#' 
#' # Create the GLM model.
#' td_glm_out1 <- td_glm_mle(formula = (admitted ~ stats + masters + gpa + programming),
#'                           family = "LOGISTIC",
#'                           linkfunction = "LOGIT",
#'                           data = admissions_train,
#'                           weights = "1",
#'                           threshold = 0.01,
#'                           maxit = 25,
#'                           step = FALSE,
#'                           intercept = TRUE
#' )
#' 
#' # Save this generated model.
#' td_save_model(model = td_glm_out1, name = "glm_model", description = "GLM test")
#' 
#' # Example 1 - List all models saved and accessible to the current user.
#' td_list_models()
#' 
#' # Example 2 - List models accessible to the user with
#' # name = 'glm_model'.
#' td_list_models(name = "glm_model")
#' 
#' # Example 3 - List all models accessible to the user with algorithm
#' # name 'GLM'.
#' td_list_models(algorithm.name = "GLM")
#' 
#' # Example 4 - List all models accessible to user with algorithm name
#' # 'GLM' and name containing string 'glm'.
#' td_list_models(name = "glm", algorithm.name = "GLM")
#' 
#' # Example 5 - List all models accessible to user with algorithm name
#' # 'GLM' and generated using 'ML Engine'.
#' td_list_models(algorithm.name = "GLM", engine = "ML Engine")
#' 
#' # Example 6 - List all models created by the user with algorithm name
#' # 'GLM', generated using 'MLE', and access not set to Public.
#' td_list_models(algorithm.name = "GLM", engine = "MLE",
#'                accessible = FALSE, public = FALSE)
#' }
#' 
#' @importFrom dbplyr in_schema
#' @importFrom dplyr filter
#' @importFrom rlang UQ
#' @export
td_list_models <- function(name = NULL, algorithm.name = NULL,
                           engine = NULL, accessible = TRUE,
                           public = FALSE) {
  # First, check if model catalog exists
  .checkIfModelCatalogingTablesExists()
  
  # Argument validation
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("name", name, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("algorithm.name", algorithm.name, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("engine", engine, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accessible", accessible, TRUE, c("logical", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("public", public, TRUE, c("logical", NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check for permitted values
  validEngines <- .get(".mc.validEngines")
  enginePermittedValues <- as.list(append(names(validEngines),
                                          unlist(validEngines, use.names = FALSE)))
  .validatePermittedValues(engine, enginePermittedValues)
  
  # Check if the values are empty
  .validateInputColumnsNotEmpty(name)
  .validateInputColumnsNotEmpty(algorithm.name)

  public <- if (is.null(public)) FALSE else public
  accessible <- if (is.null(accessible)) TRUE else accessible
  
  # Get the username
  con <- .taConnection()
  userName <- .get_username(con)
  
  if (!isTRUE(accessible)) {
    # This is to help list models that exist and are created by the current user,
    # but their underlying objects are not accessible as they may been deleted.
    # The creator of a model would see such a model in the listing when
    # accessible=FALSE.
    modelDetails <- tbl(con, in_schema(.get(".mc.modelCatalogDB"),
                                       .get(".mc.modelDetails")))
    modelDetails <- modelDetails %>% filter(tolower(CreatedBy) == tolower(userName))
  } else {
    modelDetails <- tbl(con, in_schema(.get(".mc.modelCatalogDB"),
                                       .get(".mc.modelDetailsX")))
  }
  
  if (isTRUE(public)) {
    publicAccess <- .get(".mc.publicAccess")
    modelDetails <- modelDetails %>% filter(ModelAccess == publicAccess)
  }
  
  if (!is.null(name))
    modelDetails <- modelDetails %>% filter(!is.na(grep(tolower(name), tolower(ModelName))))
  
  if (!is.null(algorithm.name))
    modelDetails <- modelDetails %>% filter(!is.na(grep(tolower(algorithm.name),
                                                        tolower(ModelAlgorithm))))
  
  if (!is.null(engine)) {
    # Check for abbreviated form of accepted engine values.
    if (toupper(engine) %in% names(validEngines))
      engine <- validEngines[[toupper(engine)]]
    
    modelDetails <- modelDetails %>% filter(!is.na(grep(tolower(engine),
                                                        tolower(ModelGeneratingEngine))))
  }
  
  modelDetails <- as.data.frame(modelDetails %>% select(UQ(.get(".mc.modelListingList"))))
  
  # If no models with the search criteria is found, then throw an error.
  if (nrow(modelDetails) < 1)
    if (!is.null(name) || !is.null(algorithm.name) || !is.null(engine) || !isTRUE(accessible) || isTRUE(public)) {
      .ta.stop("TDR_E4004", " with the given search criteria")
    } else {
      cat(gettextf(.global__error__list__$TDR_E4004, ""), "\n")
    }
  else
    return(modelDetails)
}

# 
#' td_describe_model
#' 
#' Function to display details of the model from the Model Catalog,
#' if the model is accessible to the user.
#' 
#' @param name Required Argument.\cr
#'             Specifies the name of the model to list the details for.\cr
#'             Types: character
#' @examples 
#' \donttest{
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#' 
#' # Load example data.
#' loadExampleData("glm_example", "admissions_train")
#' 
#' # Create object of class "tbl_teradata" to use as input.
#' admissions_train <- tbl(con, "admissions_train")
#' 
#' # Create the GLM model.
#' td_glm_out1 <- td_glm_mle(formula = (admitted ~ stats + masters + gpa + programming),
#'                           family = "LOGISTIC",
#'                           linkfunction = "LOGIT",
#'                           data = admissions_train,
#'                           weights = "1",
#'                           threshold = 0.01,
#'                           maxit = 25,
#'                           step = FALSE,
#'                           intercept = TRUE
#' )
#' 
#' # Save this generated model.
#' td_save_model(model = td_glm_out1, name = "glm_model", description = "GLM test")
#' 
#' # List all details of recently saved model "glm_model".
#' td_describe_model("glm_model")
#' }
#' 
#' @importFrom dbplyr in_schema
#' @importFrom dplyr filter
#' @importFrom dplyr select
#' @importFrom dplyr mutate
#' @importFrom dplyr bind_rows
#' @export
td_describe_model <- function(name) {
  # First, check if model catalog exists
  .checkIfModelCatalogingTablesExists()
  
  # Argument validation
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("name", name, FALSE, c("character", NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check if the values are empty
  .validateInputColumnsNotEmpty(name)
  
  # Check if model exists
  .checkIfModelExists(name, accessible = TRUE, raise.error.if.not.found = TRUE)
  
  # Let's get the globals to use as keys.
  modelObjects <- .get(".mc.modelObjects")
  modelDetails <- .get(".mc.modelDetails")
  modelAttrs <- .get(".mc.modelAttrs")
  modelInputs <- .get(".mc.modelInputsX")
  modelPerf <- .get(".mc.modelPerf")
  modelLocation <- .get(".mc.modelLoc")
  
  dfInfoMapper <- list()
  dfInfoMapper[[modelDetails]] <- "Model Details"
  dfInfoMapper[[modelAttrs]] <- "Model Attributes"
  dfInfoMapper[[modelInputs]] <- "Model Training Data"
  dfInfoMapper[[modelObjects]] <- "Model Training Objects"
  dfInfoMapper[[modelPerf]] <- "Model Performance Metrics"
  dfInfoMapper[[modelLocation]] <- "Model Location Based Information"
  
  schema <- .get(".mc.modelCatalogDB")
  for (tab in names(dfInfoMapper)) {
    displayDf <- NULL
    
    if (tab %in% c(modelObjects, modelAttrs, modelInputs)) {
      modelClientEngAlgo <- .td.mc.retrieveModelClientEngineAlgorithm(name)
      functionArgMap <- .getFunctionArgMapper(modelClientEngAlgo$modelEngine,
                                              tolower(modelClientEngAlgo$modelAlgorithm))
      
      if (tab == modelObjects) {
        # Output Information.
        # We wish to display tdplyr relevant information, so we get that using
        # this function call instead of directly reading the underlying view.
        displayDf <- .td.mc.retrieveModelOutputs(name,
                                                 modelClientEngAlgo$modelClient,
                                                 functionArgMap)
      } else if (tab == modelAttrs) {
        # Attribute Information.
        # We wish to display tdplyr relevant information, so we get that using
        # this function call instead of directly reading the underlying view.
        modelParameters <- .td.mc.retrieveModelAttributes(name,
                                                          modelClientEngAlgo$modelClient,
                                                          functionArgMap)
        if (length(modelParameters) > 0) {
          displayDf <- data.frame(AttrName = names(modelParameters),
                                  AttrValue = as.character(modelParameters))
          row.names(displayDf) <- NULL
        } else
          # Dummy data.frame which will not get printed.
          displayDf <- data.frame(dummy = list())
      } else {
        # Input data Information.
        # We wish to display tdplyr relevant information, so we get that using
        # this function call instead of directly reading the underlying view.
        modelInputs <- .td.mc.retrieveModelInputs(name,
                                                  modelClientEngAlgo$modelClient,
                                                  functionArgMap)
        if (length(modelInputs) > 0)
          displayDf <- as.data.frame(bind_rows(modelInputs) %>%
            mutate(InputName = names(modelInputs), InputTableName = TableName) %>%
            select("InputName",
                   "InputTableName",
                   .get(".mc.modelInputRows"),
                   .get(".mc.modelInputCols")))
        else
          # Dummy data.frame which will not get printed.
          displayDf <- data.frame(dummy = list())
      }
    } else {
      con <- .taConnection()
      displayDf <- as.data.frame(tbl(con,
                                     in_schema(schema,
                                               tab)) %>% filter(ModelName == name))
      
      if (tab == modelDetails)
        # We do a transpose of the Model Details to provide better readability of
        # the ouptut since it is one record with multiple columns.
        displayDf <- t(displayDf)
      else {
        if (nrow(displayDf) > 0) {
          # Otherwise, we remove the 'ModelName' column from the
          # projection which is redundant.
          colNames <- names(displayDf)
          displayDf <- displayDf %>% select(colNames[!colNames == .get(".mc.modelDerivedName")])
        }
      }
    }
    
    if (nrow(displayDf) > 0) {
      cat(gettextf("\n\n*** '%s': %s ***\n",name, dfInfoMapper[[tab]]))
      print(displayDf)
    }
  }
}

#
#' td_retrieve_model
#' 
#' Function to retrieve a saved model accessible to the current user.
#' 
#' @param name  Required Argument.\cr
#'              Specifies the name of the saved model to be retrieved.\cr
#'              Types: character
#' @return Object of class "td_analytics" corresponding to the model retrieved.
#' @examples 
#' \donttest{
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#' 
#' # Load example data.
#' loadExampleData("glm_example", "admissions_train")
#' 
#' # Create object of class "tbl_teradata" to use as input.
#' admissions_train <- tbl(con, "admissions_train")
#' 
#' # Create the GLM model.
#' td_glm_out1 <- td_glm_mle(formula = (admitted ~ stats + masters + gpa + programming),
#'                           family = "LOGISTIC",
#'                           linkfunction = "LOGIT",
#'                           data = admissions_train,
#'                           weights = "1",
#'                           threshold = 0.01,
#'                           maxit = 25,
#'                           step = FALSE,
#'                           intercept = TRUE
#' )
#' 
#' # Save this generated model.
#' td_save_model(model = td_glm_out1, name = "glm_model", description = "GLM test")
#' 
#' # Retrieve the saved model.
#' retrieved_glm_model <- td_retrieve_model("glm_model")
#' 
#' # Use the retrieved model for scoring.
#' loadExampleData("glmpredict_example", "admissions_test")
#' admissions_test <- tbl(con, "admissions_test")
#' 
#' td_glm_predict_out1 <- td_glm_predict_sqle(modeldata = retrieved_glm_model,
#'                                            newdata = admissions_test,
#'                                            terms = c("id","masters","gpa","stats",
#'                                                      "programming","admitted"),
#'                                            family = "LOGISTIC",
#'                                            linkfunction = "LOGIT"
#'                                            )
#' 
#' }
#' 
#' @export
td_retrieve_model <- function(name) {
  # First, check if model catalog exists
  .checkIfModelCatalogingTablesExists()
  
  # Argument validation
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("name", name, FALSE, c("character", NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check if the values are empty
  .validateInputColumnsNotEmpty(name)
  
  # Check if model exists
  .checkIfModelExists(name, accessible = TRUE)
  
  # Let's read model attributes and their values/output tables.
  modelClassEngineAttrOutList <- .td.mc.retrieveArgumentAndOutputMap(name)
  
  # Get wrapper class for which model is to be instantiated.
  eng <- modelClassEngineAttrOutList$modelEngine
  if (eng == .get(".mc.modelEngineML"))
    eng <- "ENGINE_ML"
  else if (eng == .get(".mc.modelEngineAdvSQL"))
    eng <- "ENGINE_SQL"
  else
    .ta.stop("TDR_E4009", eng)
  
  retval <- list()
  attr(retval, "class") <- .getSQLMRClass(modelClassEngineAttrOutList$modelClass,
                                          engine = .getEngineName(eng))
  
  # Set the output objects.
  for (name in names(modelClassEngineAttrOutList$modelTables))
    retval[[name]] <- modelClassEngineAttrOutList$modelTables[[name]]
  
  # Set the inputs and parameters.
  retval[["attributes"]] <- modelClassEngineAttrOutList$modelParameters
  
  # Set the attributes.
  for (name in names(modelClassEngineAttrOutList$modelAttributes))
    attr(retval, name) <- modelClassEngineAttrOutList$modelAttributes[[name]]
  
  return(retval)
}

#
#' td_publish_model
#' 
#' Function to publish a saved model.\cr
#' It can be used to update the access level from PRIVATE to PUBLIC or TEAM.\cr
#' It can also be used to update the status of the model to one of the permitted values.\cr
#' A model can only be published by its creator.
#' 
#' @param name Required Argument.\cr
#'             Specifies the name of the model to be published.\cr
#'             Types: character
#' @param grantee Optional Argument. Must be specified when "status" is not specified.\cr
#'                Specifies a user or role (including PUBLIC) to update the
#'                model's access level to.\cr
#'                Types: character
#' @param status Optional Argument. Must be specified when "grantee" is not specified.\cr
#'               Specifies a status to set the the model's status to.\cr
#'               Permitted Values: "ACTIVE", "RETIRED", "CANDIDATE", "PRODUCTION",
#'               "IN-DEVELOPMENT"\cr
#'               Types: character
#' @examples 
#' \donttest{
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#' 
#' # Load example data.
#' loadExampleData("glm_example", "admissions_train")
#' 
#' # Create object of class "tbl_teradata" to use as input.
#' admissions_train <- tbl(con, "admissions_train")
#' 
#' # Create the GLM model.
#' td_glm_out1 <- td_glm_mle(formula = (admitted ~ stats + masters + gpa + programming),
#'                           family = "LOGISTIC",
#'                           linkfunction = "LOGIT",
#'                           data = admissions_train,
#'                           weights = "1",
#'                           threshold = 0.01,
#'                           maxit = 25,
#'                           step = FALSE,
#'                           intercept = TRUE
#' )
#' 
#' # Save this generated model.
#' td_save_model(model = td_glm_out1, name = "glm_model", description = "GLM test")
#' 
#' # Example 1 - Update only the access.
#' td_publish_model('glm_model', grantee='john')
#' 
#' # Example 2 - Update only the status.
#' td_publish_model('glm_model', status='Active')
#' 
#' # Example 3 - Update both the access and status.
#' # This example does not apply to the model we just saved, as we can update
#' # the access only when the current access is 'Private'.
#' # We save the model again with another name for this example.
#' td_save_model(model = td_glm_out1, name = "glm_model_2", description = "GLM test 2")
#' 
#' td_publish_model('glm_model_2', grantee='PUBLIC', status='Production')
#' }
#' 
#' @importFrom dplyr filter
#' @export
td_publish_model <- function(name, grantee = NULL, status = NULL) {
  # Perform required validations for the API.
  # Check whether Model Cataloging tables exist or not.
  .checkIfModelCatalogingTablesExists()

  # Let's perform argument validations.
  # Create argument information matrix to do parameter checking.
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("name", name, FALSE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("grantee", grantee, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("status", status, TRUE, c("character", NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments.
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument.
  .validateArgumentTypes(argInfoMatrix)
  
  # Check if the values are empty.
  .validateInputColumnsNotEmpty(name)
  .validateInputColumnsNotEmpty(grantee)
  .validateInputColumnsNotEmpty(status)
  
  # Check for permitted values for status.
  if (!is.null(status))
    .validatePermittedValues(status, as.list(.get(".mc.modelValidStatus")))
  
  # Both grantee and status cannot be null.
  if (is.null(grantee) && is.null(status))
    .ta.stop("TDR_E3009", "grantee", "status")

  # Let's check if the user created the model since only the creator can publish it
  .checkIfModelExists(name, created = TRUE, raise.error.if.not.found = TRUE)
  
  con <- .taConnection()
  
  # Form stored procedure query and call it
  publishSP <- .get(".mc.publishModel")
  publishSP <- .td.mc.getStoredProcedureName(publishSP)
  
  printMessage <- NULL
  currentUser <-  .get_username(con)
  oldAccess <- .td.mc.getModelAccess(name)
  # Update the access only when we have a grantee that is not the same as
  # the current user or 'private', and when the current access level is PRIVATE.
  if (!is.null(grantee) && tolower(grantee) != tolower(currentUser) &&
      tolower(grantee) != "private" && tolower(oldAccess) == "private") {
    
    tableList <- .td.mc.getTablesForModel(name, currentUser)
    
    if (length(tableList) > 0) {
      grantList <- c()
      for (tableName in tableList)
        grantList <- c(grantList,
                       gettextf("GRANT SELECT ON %s to %s;",
                                tableName, grantee))
      
      printMessage <- "Please execute the following GRANT statements:\n"
      printMessage <- paste0(printMessage,
                             paste0(grantList, collapse="\n"))
    }
  } else if (!is.null(grantee)) {
    defaultSaveAccess <- .get(".mc.defaultSaveAccess")
    .ta.warning(
      gettextf(
        paste0("'grantee' must not be equal to '%s' or the current",
               " user's name, and the earlier access level must be '%s'."),
        defaultSaveAccess,
        defaultSaveAccess))
    
    # Set grantee to None so that it is not passed in stored procedure
    grantee <- NULL
  }
  
  # Form the stored procedure call
  spCall <- gettextf("CALL %s('%s', %s, %s, PublishStatus)",
                     publishSP,
                     name,
                     if (!is.null(grantee)) gettextf("'%s'", grantee) else "NULL",
                     if (!is.null(status)) gettextf("'%s'", status) else "NULL")
  
  # Start database transaction
  dbBegin(con)
  tryCatch({
    
    # Execute the stored procedure call
    dbExecute(con, spCall)
    
    # Commit the database transactions
    dbCommit(con)
    
    # If we have come till here, then the transaction was successfully committed.
  }, error = function(err){
    # Rollback the transaction on any error
    dbRollback(con)
    
    # Print the error message
    .ta.stop(err)
  })
  
  cat("Model published successfully!", "\n")
  if (!is.null(printMessage))
    cat(printMessage, "\n")
}

#This is necessary to avoid devtools::check() from raising warnings and adding a NOTE.
globalVariables(c("AttrName", "AttrValue", "AttributeName", "ClientSpecificAttributeName", 
                  "CreatedBy", "ModelAccess", "ModelAlgorithm", "ModelGeneratingEngine",
                  "ModelId", "ModelName", "Name", "TableName"))
