# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

# Scalar extensions for Teradata
# See: sql-translation.R

# Scalar environment for Teradata as defined in dbplyr
# Arguments:
#  - disable_ext: returns the aggr mapping without custom mappings if TRUE
.td_sql_scalar <- function(disable_ext = FALSE){
  
  scalars <- .getSqlVariantDbplyr()
  
  if (disable_ext){
    
    scalars$dbplyr_td$scalar
    
  } else {
    
    .td_add_scalar_extensions(scalars$dbplyr_td$scalar)
    
  }
}


# character extensions

# SQL Functions, Operators, Expressions, and Predicates
# Chapter 26: String Operators and Functions
# SUBSTRING
.td_substr <- function(x, start, stop = NULL){

  len <- NULL

  if (!is.null(stop))
    len <- build_sql(' FOR (', stop, ' - ', start, ' + 1)')
  
  build_sql('SUBSTRING(', x, ' FROM ', start, len, ')')
}

# SQL Functions, Operators, Expressions, and Predicates
# Chapter 24: Regular Expression Functions
# REGEXP_SUBSTR
.td_grep <- function(pattern, x, ignore.case = FALSE)
{
  res <- build_sql('REGEXP_SUBSTR(', x, ', ', pattern)

  suffix <- .td_regexp_options(position = 1L, 
                               occurrence = 1L, 
                               match = if (ignore.case) 'i' else 'c')
  build_sql(res, suffix, ')')
}

# SQL Functions, Operators, Expressions, and Predicates
# Chapter 24: Regular Expression Functions
# REGEXP_REPLACE
.td_sub <- function(pattern, replacement, x, ignore.case = FALSE){

  suffix <- .td_regexp_options(position = 1L, 
                               occurrence = 1L, 
                               match = if (ignore.case) 'i' else 'c')

  res <- build_sql('REGEXP_REPLACE(', x, ', ', pattern, ', ', replacement)
  build_sql(res, suffix, ')')
}

# REGEXP_REPLACE
.td_gsub <- function(pattern, replacement, x, ignore.case = FALSE){

  suffix <- .td_regexp_options(position = 1L, 
                               occurrence = 0L, 
                               match = if (ignore.case) 'i' else 'c')

  res <- build_sql('REGEXP_REPLACE(', x, ', ', pattern, ', ', replacement)
  build_sql(res, suffix, ')')
}

# REGEXP_INSTR
.td_locate <- function(string, pattern, return_opt = 0L){

 if (length(return_opt) != 1L || !is.numeric(return_opt))
    .ta.stop('return_opt must be 1 or 0')

  res <- build_sql('REGEXP_INSTR(', string, ', ', pattern)

  suffix <- .td_regexp_options(position = 1L, 
                               occurrence = 1L,
                               as.integer(return_opt),
                               match = 'c')
  res <- build_sql(res, suffix, ')')

  if (as.integer(return_opt) == 1L){
    # the ending index is off by 1
    res <- sql_if(build_sql(res ,' > 0'), 
                  build_sql(res,' - 1'), 
                  res)
  }

  res
}

# Chapter 28: String Operators and Functions
# Concatenation Operator
.td_paste <- function(..., sep = " ") {
    sql(
        paste0(
          sapply(list(...), function(x) escape(x, con = .taConnection())),
          collapse = sprintf(" || %s || ", escape(sep, con = .taConnection()))
        )
    )
}

# Chapter 28: String Operators and Functions
# LTRIM/RTRIM
# Note: currently TRIM only takes 1 trim expression
#       this makes implementing functions like str_trim
#       tedious since it can trim multiple expressions
#       RTRIM and LTRIM don't have this limitation.
.td_trim <- function(string, side = c("both", "left", "right")){

    if (length(side) != 1L)
      .ta.stop('side must be one of "both", "left", or "right"')

    whitespace <- sql("' \n\t\r\v\f'")
    side <- switch(side,
                   both  = 'BOTH',
                   left  = 'LTRIM',
                   right = 'RTRIM',
                   'BOTH')
   
    if (side == 'BOTH'){
   
       # do left then right
       l <- build_sql('LTRIM(', string, ', ', whitespace, ')')
       r <- build_sql('RTRIM(', l, ', ', whitespace, ')')

       r

    } else {
   
       build_sql(sql(side), '(', string, ', ', whitespace,')')
    }
}


# Chapter 14: Data Type Conversions
# CAST
.td_cast <- function(exp, type) build_sql('CAST(', sql(as.character(exp)), ' AS ', sql(type))

# Chapter 7: Bit/Byte Manipulation Functions
# The corresponding bitw* functions in base R coerce
# the arguments to integer.
.td_bit <- function(fn, a, b = NULL) {

      res <-  build_sql(sql(fn), '(',
                 .td_cast(as.character(a), 'INTEGER'), ')'
              )

      if (is.null(b)){

        res <- build_sql(res, ')')

      } else {

        res <- build_sql(res, ', ', 
                  .td_cast(as.character(b), 'INTEGER'),'))'
               )

      }

      res
}

# Add the Scalar Extensions for Teradata
# Arguments:
#  sql_scalars - Original dbplyr scalar mappings created by sql_translator
# Returns:
#  An environment with the sql scalar mappings provided exclusively by this package
# Note: Extensions of mappings here can be contributed to open source
#' @importFrom dbplyr sql_translator
#' @importFrom dbplyr sql_infix escape build_sql sql_prefix
.td_add_scalar_extensions <- function(sql_scalars){
  
  sql_translator(.parent = sql_scalars,

    # math operators
    `%%`   = sql_infix("MOD"),
    `%/%`  = function (x, y) sql(sprintf("FLOOR((%1$s) / (%2$s))", escape(x, con = .taConnection()), escape(y, con = .taConnection()))),

    # string functions
    substr = .td_substr,
    substring = .td_substr,
    grep = .td_grep,
    str_extract = function(string, pattern) .td_grep(pattern, string),
    str_replace = function(string, pattern, replacement) .td_sub(pattern, replacement, string),
    sub = .td_sub,
    gsub = .td_gsub,
    paste = .td_paste,
    paste0 = function(...) .td_paste(..., sep = ''),
    str_trim = .td_trim,
    str_join = .td_paste,
    str_locate = .td_locate,
    str_detect = function(string, pattern){
      build_sql(
        "INSTR(", string, ", ", pattern, ") > 0"
      )},
    str_replace_all = function(string, pattern, replacement){
      build_sql(
        "OREPLACE(", string, ", ", pattern, ", ", replacement, ")"
      )},
    strsplit = function(x, split = ' ', tokennum = 1L) build_sql('STRTOK(',x, ', ', split, ', ',  as.integer(tokennum), ')'),
    unicode_to_latin = function(x) build_sql(escape(x, con = .taConnection()), " USING UNICODE_TO_LATIN"),

    # math and arithmetic functions
    ln      = sql_prefix("LN", 1),
    log10   = sql_prefix("LOG", 1),
    cosh    = sql_prefix('COSH', 1),
    degrees = sql_prefix("degrees", 1),
    radians = sql_prefix("radians", 1),
    sign    = sql_prefix("SIGN", 1),
    sinh    = sql_prefix('SINH', 1),

    # conversion functions
    as = function(x, y) build_sql(.td_cast(x, y), ')'),
    as.integer = function(x) build_sql(.td_cast((x), 'INTEGER'), ')'),
    as.double  = function(x) build_sql(.td_cast((x), 'FLOAT'), ')'),
    as.numeric = function(x, precision = 5L ,scale = 0L){
  
       build_sql(.td_cast(x, 'NUMERIC'),"(", precision, ", ", scale, "))")
  
    },
    as.character = function(x, n = NULL, charset = NULL){
  
       res <- build_sql("CAST((", x, ") AS VARCHAR(")


       if (is.null(n)){
         .ta.varcharSize() # ensure variable is set
         n <- as.integer(Sys.getenv("TD_VARCHAR_COLUMN_SIZE"))
       }

       res <- build_sql(res, as.integer(n), ")")
  
       if (!is.null(charset))
         res <- build_sql(res, " CHARACTER SET ", sql(charset))

       build_sql(res, ')')
    },
    as.Date = function(x, format){
      build_sql(.td_cast(x, paste0('DATE FORMAT ',"'",format,"')")))
    },

    # bit functions
    bitwAnd = function(a, b) .td_bit('BITAND', a, b),
    bitwOr = function(a, b) .td_bit('BITOR', a, b),
    bitwNot = function(a) .td_bit('BITNOT', a),
    bitwXor = function(a, b) .td_bit('BITXOR', a, b),
    bitwShiftL = function(a, n) .td_bit('SHIFTLEFT', a, n),
    bitwShiftR = function(a, n) .td_bit('SHIFTRIGHT', a, n)
  )
}
