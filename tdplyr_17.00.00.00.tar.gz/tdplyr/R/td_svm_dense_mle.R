# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.7
# 
# ################################################################## 

# Description:
#   The DenseSVMTrainer function takes training data in dense format and
#   outputs a predictive model in binary format, which is input to the
#   functions DenseSVMPredictor and DenseSVMModelPrinter.
# 
# Args:
#   data -
#     Required Argument.
#     Name of the tbl_teradata containing the training samples. Each row 
#     consists of a sample_id, a set of attribute values, and a 
#     corresponding label.
#   
#   sample.id.column -
#     Required Argument.
#     Name of the column in the data that contains the identifier of the 
#     training samples.
#     Types: character
#   
#   attribute.columns -
#     Required Argument.
#     Specifies all the attribute columns. Attribute columns must have a 
#     numeric value.
#     Types: character OR vector of Strings (character)
#   
#   kernel.function -
#     Optional Argument.
#     Possible values are linear, polynomial, RBF, or sigmoid. The 
#     distribution exponential family used to compute the hash function. 
#     For linear, a Pegasos algorithm is used to solve the linear SVM. 
#     For polynomial, RBF, or sigmoid, a Hash-SVM algorithm is used. Each 
#     sample is represented by compact hash bits, over which an inner 
#     product is defined to serve as the surrogate of the original 
#     nonlinear kernels. The default value is linear. 
#     Default Value: "LINEAR"
#     Permitted Values: LINEAR, POLYNOMIAL, RBF, SIGMOID
#     Types: character
#   
#   gamma -
#     Optional Argument.
#     Only used when kernel.function is polynomial, RBF, or sigmoid. A 
#     positive double that specifies . The minimum value is 0.0. 
#     Default Value: 1.0
#     Types: numeric
#   
#   constant -
#     Optional Argument.
#     Only used when kernel.function is polynomial or sigmoid. A double 
#     value that specifies c. If kernel.function is polynomial, the minimum 
#     value is 0.0. 
#     Default Value: 1.0
#     Types: numeric
#   
#   degree -
#     Optional Argument.
#     Only used when kernel.function is polynomial. A positive integer that 
#     specifies the degree (d) of the polynomial kernel. The input value 
#     must be greater than 0. 
#     Default Value: 2
#     Types: integer
#   
#   subspace.dimension -
#     Optional Argument.
#     Only valid if kernel is polynomial, RBF, or sigmoid. A positive 
#     integer that specifies the random subspace dimension of the basis 
#     matrix V obtained by the Gram-Schmidt process. Since the Gram-Schmidt 
#     process cannot be parallelized, this dimension cannot be too large. 
#     Accuracy will increase with higher values of this number, but 
#     computation costs will also increase. The input value must be in the 
#     range [1, 2048]. 
#     Default Value: 256
#     Types: integer
#   
#   hash.bits -
#     Optional Argument.
#     Only valid if kernel is polynomial, RBF, or sigmoid. A positive 
#     integer specifying the number of compact hash bits used to represent 
#     a data point. Accuracy will increase with higher values of this 
#     number, but computation costs will also increase. The input value 
#     must be in the range [8, 8192]. 
#     Default Value: 256
#     Types: integer
#   
#   label.column -
#     Required Argument.
#     Column that identifies the class of the corresponding sample. Must be 
#     an integer or a string.
#     Types: character
#   
#   cost -
#     Optional Argument.
#     The regularization parameter in the SVM soft-margin loss function : 
#     Must be greater than 0.0. 
#     Default Value: 1.0
#     Types: numeric
#   
#   bias -
#     Optional Argument.
#     A non-negative value. If the value is greater than zero, each sample 
#     (x) in the training set will be converted to ( x, b); that is, it 
#     will add another dimension containing the bias value b. This argument 
#     addresses situations where not all samples center at 0. 
#     Default Value: 0.0
#     Types: numeric
#   
#   class.weights -
#     Optional Argument.
#     Specifies the weights for different classes. The format should be: 
#     "classlabel m:weight m, classlabel n:weight n". If weight for a class 
#     is given, the cost parameter for this class will be weight * cost. A 
#     weight larger than 1 often increases the accuracy of the 
#     corresponding class; however, it may decrease global accuracy. 
#     Classes not assigned a weight in this argument will be assigned a 
#     weight of 1.0.
#     Types: character OR vector of characters
#   
#   max.step -
#     Optional Argument.
#     A positive integer value that specifies the maximum number of 
#     iterations of the training process. One step means that each sample 
#     is seen once by the trainer. The input value must be in the range (0, 
#     10000]. 
#     Default Value: 100
#     Types: integer
#   
#   epsilon -
#     Optional Argument.
#     Termination criterion. When the difference between the values of the 
#     loss function in two sequential iterations is less than this number, 
#     the function stops. Must be greater than 0.0. 
#     Default Value: 0.01
#     Types: numeric
#   
#   seed -
#     Optional Argument.
#     A long integer value used to order the training set randomly and 
#     consistently. This value can be used to ensure that the same model 
#     will be generated if the function is run multiple times in a given 
#     database with the same arguments. The input value must be in the 
#     range [0, 9223372036854775807]. The default value is 0. 
#     Default Value: 0
#     Types: numeric
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_svm_dense_mle" which is a 
#   named list containing Teradata tbl objects.
#   Named list members can be referenced directly with the "$" operator 
#   using following names:\enumerate{\item model.table\item output}
# 
# 
#' @export
td_svm_dense_mle <- function(
  data = NULL,
  sample.id.column = NULL,
  attribute.columns = NULL,
  kernel.function = "LINEAR",
  gamma = 1.0,
  constant = 1.0,
  degree = 2,
  subspace.dimension = 256,
  hash.bits = 256,
  label.column = NULL,
  cost = 1.0,
  bias = 0.0,
  class.weights = NULL,
  max.step = 100,
  epsilon = 0.01,
  seed = 0,
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("sample.id.column", sample.id.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("attribute.columns", attribute.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("kernel.function", kernel.function, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("gamma", gamma, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("constant", constant, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("degree", degree, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("subspace.dimension", subspace.dimension, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("hash.bits", hash.bits, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("label.column", label.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("cost", cost, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("bias", bias, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("class.weights", class.weights, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("max.step", max.step, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("epsilon", epsilon, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seed", seed, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check for permitted values
  kernel.functionPermittedValues <- list("LINEAR", "POLYNOMIAL", "RBF", "SIGMOID")
  .validatePermittedValues(kernel.function, kernel.functionPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(sample.id.column)
  .validateTblHasArgumentColumns(sample.id.column, "sample.id.column", data, "data")
  
  .validateInputColumnsNotEmpty(attribute.columns)
  .validateTblHasArgumentColumns(attribute.columns, "attribute.columns", data, "data")
  
  .validateInputColumnsNotEmpty(label.column)
  .validateTblHasArgumentColumns(label.column, "label.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  # Generate temp table names for output table parameters if any.
  model.tableTempTableName <- .teradataGenerateTempTableName("td_svm_dense_mle0_", use.default.database=TRUE, gc.onQuit=TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_svm_dense_mle.internal)
  Call[["model.tableTempTableName"]] <- model.tableTempTableName
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_svm_dense_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_svm_dense_mle.internal <- function(
  data = NULL,
  sample.id.column = NULL,
  attribute.columns = NULL,
  kernel.function = "LINEAR",
  gamma = 1.0,
  constant = 1.0,
  degree = 2,
  subspace.dimension = 256,
  hash.bits = 256,
  label.column = NULL,
  cost = 1.0,
  bias = 0.0,
  class.weights = NULL,
  max.step = 100,
  epsilon = 0.01,
  seed = 0,
  data.sequence.column = NULL,
  model.tableTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("ModelTable")
  funcOutputArgs <- c(model.tableTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IdColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(sample.id.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "InputColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(attribute.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ResponseColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(label.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  if (!is.null(kernel.function) && !missing(kernel.function)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "KernelFunction")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(kernel.function, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(gamma) && !missing(gamma)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Gamma")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(gamma, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(constant) && !missing(constant)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Constant")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(constant, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(degree) && !missing(degree)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "degree")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(degree, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(subspace.dimension) && !missing(subspace.dimension)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SubspaceDimension")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(subspace.dimension, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(hash.bits) && !missing(hash.bits)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "HashBits")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(hash.bits, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(cost) && !missing(cost)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Cost")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(cost, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(bias) && !missing(bias)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Bias")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(bias, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(class.weights)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ClassWeights")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(class.weights, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(max.step) && !missing(max.step)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxStep")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(max.step, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(epsilon) && !missing(epsilon)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Epsilon")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(epsilon, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(seed) && !missing(seed)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Seed")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(seed, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "LONG")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "DenseSVMTrainer",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("DenseSVMTrainer", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["model.table"]] <- .createDataSetObject(.extractTableName(model.tableTempTableName), sourceType = "table", .extractDatabaseName(model.tableTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_svm_dense <- td_svm_dense_mle
