# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 2.8
# 
# ################################################################## 

# Description:
#   The ConfusionMatrix function shows how often a classification
#   algorithm correctly classifies items. The function takes an input
#   table that includes two columns one containing the observed class of
#   an item and the other containing the class predicted by the algorithm
#   and outputs three tables.
# 
# Args:
#   data -
#     Required Argument.
#     The input tbl_teradata of ConfusionMatrix function
#   
#   reference -
#     Required Argument.
#     Specifies the name of the input column that contains the observed 
#     class.
#     Types: character
#   
#   prediction -
#     Required Argument.
#     Specifies the name of the input column that contains the predicted 
#     class.
#     Types: character
#   
#   classes -
#     Optional Argument.
#     Specifies the classes to output in output_table.
#     Types: character OR vector of characters
#   
#   prevalence -
#     Optional Argument.
#     Specifies the prevalences for the classes to output in 
#     output_table_3. Therefore, if you specify prevalence, then you must 
#     also specify classes, and for every class, you must specify a 
#     prevalence
#     Types: numeric OR vector of numerics
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_confusion_matrix_mle" which 
#   is a named list containing Teradata tbl objects.
#   Named list members can be referenced directly with the "$" operator 
#   using following names:\enumerate{\item counttable\item stattable\item 
#   accuracytable\item output}
# 
# 
#' @export
td_confusion_matrix_mle <- function(
  data = NULL,
  reference = NULL,
  prediction = NULL,
  classes = NULL,
  prevalence = NULL,
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("reference", reference, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("prediction", prediction, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("classes", classes, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("prevalence", prevalence, TRUE, c("numeric","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(reference)
  .validateTblHasArgumentColumns(reference, "reference", data, "data")
  
  .validateInputColumnsNotEmpty(prediction)
  .validateTblHasArgumentColumns(prediction, "prediction", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  # Generate temp table names for output table parameters if any.
  counttableTempTableName <- .teradataGenerateTempTableName("td_confusion_matrix_mle0_", use.default.database=TRUE, gc.onQuit=TRUE)
  stattableTempTableName <- .teradataGenerateTempTableName("td_confusion_matrix_mle1_", use.default.database=TRUE, gc.onQuit=TRUE)
  accuracytableTempTableName <- .teradataGenerateTempTableName("td_confusion_matrix_mle2_", use.default.database=TRUE, gc.onQuit=TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_confusion_matrix_mle.internal)
  Call[["counttableTempTableName"]] <- counttableTempTableName
  Call[["stattableTempTableName"]] <- stattableTempTableName
  Call[["accuracytableTempTableName"]] <- accuracytableTempTableName
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_confusion_matrix_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_confusion_matrix_mle.internal <- function(
  data = NULL,
  reference = NULL,
  prediction = NULL,
  classes = NULL,
  prevalence = NULL,
  data.sequence.column = NULL,
  counttableTempTableName = NULL,
  stattableTempTableName = NULL,
  accuracytableTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("CountTable", "StatTable", "AccuracyTable")
  funcOutputArgs <- c(counttableTempTableName, stattableTempTableName, accuracytableTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ObservationColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(reference,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PredictColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(prediction,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(classes)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "classes")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(classes, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(prevalence)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Prevalence")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(prevalence, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "1")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "ConfusionMatrix",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("ConfusionMatrix", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["counttable"]] <- .createDataSetObject(.extractTableName(counttableTempTableName), sourceType = "table", .extractDatabaseName(counttableTempTableName), is_dplyr_input)
  result[["stattable"]] <- .createDataSetObject(.extractTableName(stattableTempTableName), sourceType = "table", .extractDatabaseName(stattableTempTableName), is_dplyr_input)
  result[["accuracytable"]] <- .createDataSetObject(.extractTableName(accuracytableTempTableName), sourceType = "table", .extractDatabaseName(accuracytableTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_confusion_matrix <- td_confusion_matrix_mle
