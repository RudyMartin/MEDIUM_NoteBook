# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Jeris Alan Jawahar (jeris.jawahar@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.5
# 
# ################################################################## 

# Description:
#   Histograms are useful for assessing the shape of a data distribution. 
#   The Histogram function calculates the frequency distribution of a data 
#   set using sophisticated binning techniques that can automatically calculate 
#   the bin width and number of bins. The function maps each input row to one bin and 
#   returns the frequency (row count) and proportion (percentage of rows) of each bin.
# 
# Args:
#   data -
#     Required Argument.\cr
#     The tbl_teradata containing the input data.\cr
#   
#   auto.bin -
#     Optional Argument.\cr
#     Specifies either the algorithm to be used for selecting bin 
#     boundaries or the approximate number of bins to be found. The 
#     permitted values are STURGES, SCOTT, or a positive integer. If this 
#     argument is present, custom.bin.table, custom.bin.column, 
#     start.value, bin.size, and end.value cannot be present.\cr
#     Types: character
#   
#   custom.bin.table -
#     Optional Argument.\cr
#     A tbl_teradata containing the boundary points between bins. If this 
#     argument is present, custom.bin.column must also be present. 
#     auto.bin, start.value, bin.size, and end.value cannot be present.\cr
#   
#   custom.bin.column -
#     Optional Argument.\cr
#     The column in the custom.bin.table containing the boundary values. 
#     Input columns must contain numeric SQL types. If this argument is 
#     present, custom.bin.table must also be present. auto.bin, 
#     start.value, bin.size, and end.value cannot be present.\cr
#     Types: character
#   
#   bin.size -
#     Optional Argument.\cr
#     For equally sized bins, a double value specifying the width of the 
#     bin. Omit this argument if you are not using equally sized bins. The 
#     input value must be greater than 0.0. If this argument is present, 
#     start.value and end.value must also be present. auto.bin, 
#     custom.bin.table and custom.bin.column cannot be present.\cr
#     Types: numeric
#   
#   start.value -
#     Optional Argument.\cr
#     The smallest value to be used in binning. If this argument is 
#     present, bin.size and en.value must also be present. auto.bin, 
#     custom.bin.table and custom.bin.column cannot be present.\cr
#     Types: numeric
#   
#   end.value -
#     Optional Argument.\cr
#     The largest value to be used in binning. If this argument is present, 
#     start.value and bin.size must also be present. auto.bin, 
#     custom.bin.table and custom.bin.column cannot be present.\cr
#     Types: numeric
#   
#   value.column -
#     Required Argument.\cr
#     The column in the input tbl_teradata for which statistics will be 
#     computed. Column must contain a numeric SQL types (integer, bigint, 
#     real, double precision, numeric, decimal, smallint).\cr
#     Types: character
#   
#   inclusion -
#     Optional Argument.\cr
#     Indicates whether points on bin boundaries should be included in the 
#     bin on the left or the bin on the right. The permitted values are 
#     [left, right]. The default value is left.\cr
#     Default Value: "left"\cr
#     Permitted Values: left, right\cr
#     Types: character
#   
#   groupby.columns -
#     Optional Argument.\cr
#     Columns in the input tbl_teradata used to group values for binning. 
#     These columns cannot contain doubles or floats.\cr
#     Types: character OR vector of Strings (character)
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   custom.bin.table.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "custom.bin.table". The argument is used to 
#     ensure deterministic results for functions which produce results that 
#     vary from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_histogram_mle" which is a 
#   named list containing objects of class "tbl_teradata".\cr
#   Named list members can be referenced directly with the "$" operator 
#   using the following names:\enumerate{\item output.table\item output}
# 
# 
#' @export
td_histogram_mle <- function(
  data = NULL,
  auto.bin = NULL,
  custom.bin.table = NULL,
  custom.bin.column = NULL,
  bin.size = NULL,
  start.value = NULL,
  end.value = NULL,
  value.column = NULL,
  inclusion = "left",
  groupby.columns = NULL,
  data.sequence.column = NULL,
  custom.bin.table.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("auto.bin", auto.bin, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("custom.bin.table", custom.bin.table, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("custom.bin.column", custom.bin.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("bin.size", bin.size, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("start.value", start.value, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("end.value", end.value, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("value.column", value.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("inclusion", inclusion, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("groupby.columns", groupby.columns, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("custom.bin.table.sequence.column", custom.bin.table.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  .validateInputTableDataType(custom.bin.table, NULL)
  
  # Check for permitted values
  inclusionPermittedValues <- list("LEFT", "RIGHT")
  .validatePermittedValues(inclusion, inclusionPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(value.column)
  .validateTblHasArgumentColumns(value.column, "value.column", data, "data")
  
  .validateInputColumnsNotEmpty(custom.bin.column)
  .validateTblHasArgumentColumns(custom.bin.column, "custom.bin.column", custom.bin.table, "custom.bin.table")
  
  .validateInputColumnsNotEmpty(groupby.columns)
  .validateTblHasArgumentColumns(groupby.columns, "groupby.columns", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(custom.bin.table.sequence.column)
  .validateTblHasArgumentColumns(custom.bin.table.sequence.column, "custom.bin.table.sequence.column", custom.bin.table, "custom.bin.table")
  
  # Generate temp table names for output table parameters if any.
  output.tableTempTableName <- .teradataGenerateTempTableName("td_histogram_mle0_", use.default.database=TRUE, gc.onQuit=TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_histogram_mle.internal)
  Call[["output.tableTempTableName"]] <- output.tableTempTableName
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_histogram_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_histogram_mle.internal <- function(
  data = NULL,
  auto.bin = NULL,
  custom.bin.table = NULL,
  custom.bin.column = NULL,
  bin.size = NULL,
  start.value = NULL,
  end.value = NULL,
  value.column = NULL,
  inclusion = "left",
  groupby.columns = NULL,
  data.sequence.column = NULL,
  custom.bin.table.sequence.column = NULL,
  output.tableTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("OutputTable")
  funcOutputArgs <- c(output.tableTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(value.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  if (!is.null(custom.bin.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CustomBinColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(custom.bin.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(groupby.columns)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "GroupbyColumns")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(groupby.columns,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(inclusion) && !missing(inclusion)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Inclusion")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(inclusion, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(auto.bin)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AutoBin")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(auto.bin, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(start.value)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StartValue")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(start.value, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(end.value)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "EndValue")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(end.value, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(bin.size)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "BinSize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(bin.size, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (!is.null(custom.bin.table.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("CustomBinTable:", .teradataCollapseArgVector(custom.bin.table.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # Process custom.bin.table
  if (!is.null(custom.bin.table)) {
    tableRef <- .teradataOnClauseFromDataFrame(custom.bin.table)
    funcInputDistribution <- c(funcInputDistribution, "NONE")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "CustomBinTable")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "Histogram",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("Histogram", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data, custom.bin.table)
  
  # Return output table data frames.
  result <- list()
  result[["output.table"]] <- .createDataSetObject(.extractTableName(output.tableTempTableName), sourceType = "table", .extractDatabaseName(output.tableTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_histogram <- td_histogram_mle
