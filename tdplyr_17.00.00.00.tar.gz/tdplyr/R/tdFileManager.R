################################################################################
#
# Copyright 2020 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: Adithya Avvaru (adithya.avvaru@teradata.com)
# Secondary Owner: Gouri Patwardhan (Gouri.Patwardhan@Teradata.com)
#
# This file has functions that:
#   1.  install/replace user files/scripts in Vantage.
#   2.  remove user files/scripts from Vantage.
#
################################################################################

#' Install or replace file in Vantage
#'
#' This function installs or replaces external language script or model file in Vantage.
#' On success, it prints a message that the file is installed or replaced.\cr
#' Note: This function is not supported with ODBC driver connection.
#' 
#' @param file.path.loc Required Argument.\cr
#'                      Specifies the absolute/relative path of the file (including file name) to 
#'                      be installed.\cr
#'                      This file is identified in Vantage by "file.identifier".\cr
#'                      Types: character
#' @param file.identifier Required Argument.\cr
#'                        Specifies the name associated with the user-installed file.\cr
#'                        It cannot have a schema name associated with it, as the file is always 
#'                        installed in the current schema.\cr
#'                        The name should be unique within the schema. It can be any valid Teradata 
#'                        identifier.\cr
#'                        Types: character
#' @param file.on.client Optional Argument.\cr
#'                       Specifies whether the file is present on client or remote location on 
#'                       Vantage.\cr
#'                       Set this to FALSE if the file to be installed is present at remote 
#'                       location on Vantage.\cr
#'                       Default Value: TRUE\cr
#'                       Types: logical
#' @param is.binary Optional Argument.\cr
#'                 Specifies if file to be installed is a binary file.\cr
#'                 Default Value: FALSE\cr
#'                 Types: logical
#' @param replace Optional Argument.\cr
#'                 Specifies if the file is to be installed or replaced.\cr
#'                 If set to TRUE, then the file is replaced based on the value of "force.replace" 
#'                 argument.\cr
#'                 Default Value: FALSE\cr
#'                 Types: logical
#' @param force.replace Optional Argument.\cr
#'                Specifies whether the file is to be replaced even if it is being executed.\cr
#'                If set to TRUE, the file is replaced even if it is being executed.\cr
#'                If set to FALSE, an error is raised if it is being executed.\cr
#'                Note: This argument is ignored if the argument "replace" is set to FALSE.\cr
#'                Default Value: FALSE\cr
#'                Types: logical
#' @param ... Any additional parameters required for the function.
#' @return None. Prints message if the operation is successful.
#' @seealso \code{td_remove_file}
#' @examples
#' \donttest{
#' # Note:
#' #  1. Connection must be established before running these examples.
#' #  2. File can be on client or remote database server.
#' #  3. Files mentioned in the examples are part of the package and can be found at
#' #     package install location as shown in the below examples.
#' 
#' # Replace "<tdplyr_install_location>" with the absolute path of the install location of the
#' # tdplyr library. One can get this location using '.libPaths()'.
#' # Make sure to include 'tdplyr' in the path. For example, <r_pkg_install_location>/tdplyr.
#'
#' tdplyr_install_location <- "<tdplyr_install_location>"
#'
#' # Example 1: Install the file 'mapper.R' found at the path mentioned in "file.path.loc"
#' #            argument.
#' td_install_file(file.path.loc = file.path(tdplyr_install_location, "scripts", "mapper.R"),
#'                 file.identifier = 'mapper')
#' 
#' # Example 2: Install the binary file 'binary_file.dms' found at the path mentioned in
#' #            "file.path.loc" argument.
#' td_install_file(file.path.loc = file.path(tdplyr_install_location, "scripts",
#'                                           "binary_file.dms"),
#'                 file.identifier = 'binaryfile',
#'                 file.on.client = TRUE,
#'                 is.binary = TRUE)
#'
#' # Example 3: Replace the file 'mapper.R' with 'mapper_replace.R' found at the path mentioned
#' #            in "file.path.loc" argument.
#' td_install_file(file.path.loc = file.path(tdplyr_install_location, "scripts", "mapper_replace.R"),
#'                 file.identifier = 'mapper',
#'                 file.on.client = TRUE,
#'                 is.binary = False,
#'                 replace = TRUE,
#'                 force.replace = TRUE)
#' }
#' 
#' @export
td_install_file <- function(file.path.loc = NULL, file.identifier = NULL, file.on.client = TRUE, 
                            is.binary = FALSE, replace = FALSE, force.replace = FALSE, ...) {
  con <- .taConnection()
  
  if (identical(.get_driver_name(con), "Teradata ODBC")) {
    .ta.stop("TDR_E1101", "Teradata SQL driver to use td_install_file() function.")
  }
  
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("file.path.loc", file.path.loc, FALSE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("file.identifier", file.identifier, FALSE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("file.on.client", file.on.client, TRUE, c("logical", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("is.binary", is.binary, TRUE, c("logical", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("replace", replace, TRUE, c("logical", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("force.replace", force.replace, TRUE, c("logical", NA)))
  
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments.
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument.
  .validateArgumentTypes(argInfoMatrix)
  
  .validateInputColumnsNotEmpty(file.path.loc)
  .validateInputColumnsNotEmpty(file.identifier)
  
  # Raise error when the file mentioned does not exist in the client machine or the 
  # directory is provided.
  if (isTRUE(file.on.client) && (dir.exists(file.path.loc) || !file.exists(file.path.loc))) {
    .ta.stop("TDR_E5001", file.path.loc, "'file.path.loc'")
  }
  
  # Extract the file name from the absolute or relative path.
  file_name <- basename(file.path.loc)
  # Assign location of the file based on whether it is on client or Vantage.
  file_location <- if (isTRUE(file.on.client)) "c" else "s"
  # Assign type of the file based on whether it is binary or not.
  file_type <- if (isTRUE(is.binary)) "b" else "z"
  
  # Generate the location of the file as per Teradata Vantage SQL Operations and User-Defined 
  # Functions documentation.
  file_path_arg <- gettextf("%s%s!%s", file_location, file_type, file.path.loc)
  
  # Generate the Stored Procedure call.
  stored_proc_call <- ""
  if (!isTRUE(replace)) {
    stored_proc_call <- gettextf("call SYSUIF.install_file('%s', '%s', '%s')", file.identifier,
                                 file_name, file_path_arg)
  } else {
    stored_proc_call <- gettextf("call SYSUIF.replace_file('%s', '%s', '%s', %d)", file.identifier,
                                 file_name, file_path_arg, as.integer(force.replace))
  }
  
  # Printing the procedure call, when debug mode is enabled.
  if (isTRUE(getOption("td.debug.enable"))) {
    .ta.print("TDR_P5001", stored_proc_call)
  }
  
  # Execute the stored procedure call.
  tryCatch({
    call_val <- dbExecute(con, stored_proc_call)
  }, error = function(emsg) {
    operation <- if (isTRUE(replace)) "replace" else "install"
    .ta.stop("TDR_E5002", operation, file.identifier, emsg)
  })
  
  operation <- if (isTRUE(replace)) "replaced" else "installed"
  cat(gettextf("File '%s' %s in Vantage.\n", file.identifier, operation))
}

#' Remove file from Vantage
#'
#' This function removes external language script or model file from Vantage.
#' On success, it prints a message that the file is removed.
#' 
#' @param file.identifier Required Argument.\cr
#'                        Specifies the name associated with the user-installed file.\cr
#'                        It cannot have a schema name associated with it, as the file is always 
#'                        installed in the current schema.\cr
#'                        The name should be unique within the schema. It can be any valid Teradata 
#'                        identifier.\cr
#'                        Types: character
#' @param force.remove Optional Argument.\cr
#'                     Specifies whether the file is to be removed even if it is being executed.\cr
#'                     If set to TRUE, the file is removed even if it is being executed.\cr
#'                     If set to FALSE, an error is raised if it is being executed.\cr
#'                     Default Value: FALSE\cr
#'                     Types: logical
#'                
#' @return None. Prints message if the operation is successful. 
#' @seealso \code{td_install_file}
#' @examples
#' \donttest{
#' # Note:
#' #  1. Connection must be established before running these examples.
#' #  2. File can be on client or remote database server.
#' #  3. Files mentioned in the examples are part of the package and can be found at
#' #     package install location as shown in the below examples.
#'
#' # Replace "<tdplyr_install_location>" with the absolute path of the install location of the
#' # tdplyr library. One can get this location using '.libPaths()'.
#' # Make sure to include 'tdplyr' in the path. For example, <r_pkg_install_location>/tdplyr.
#'
#' tdplyr_install_location <- "<tdplyr_install_location>"
#'
#' # Example 1: Remove text file.
#'
#' # Run the following before removing file.
#' td_install_file(file.identifier = 'mapper1',
#'                 file.path.loc = file.path(tdplyr_install_location, "scripts", "mapper.R"))
#'
#' # Remove the file 'mapper1'.
#' td_remove_file(file.identifier='mapper1', force.remove = TRUE)
#' 
#' # Example 2: Remove binary file.
#'
#' # Run the following before removing file.
#' td_install_file(file.identifier='binaryfile1',
#'                 file.path.loc = file.path(tdplyr_install_location, "scripts",
#'                                           "binary_file_replace.dms"),
#'                 file.on.client = TRUE,
#'                 is.binary = TRUE)
#'
#' # Remove the file 'binaryfile1'.
#' td_remove_file(file.identifier = 'binaryfile1', force.remove = TRUE)
#' }
#' 
#' @export
td_remove_file <- function(file.identifier = NULL, force.remove = FALSE) {
  con <- .taConnection()
  if (identical(.get_driver_name(con), "Teradata ODBC")) {
    .ta.stop("TDR_E1101", "Teradata SQL driver to use td_remove_file() function.")
  }
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("file.identifier", file.identifier, FALSE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("force.remove", force.remove, TRUE, c("logical", NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Validate if file.identifier is empty
  .validateInputColumnsNotEmpty(file.identifier)
  
  # Validate input argument datatypes.
  .validateArgumentTypes(argInfoMatrix) 
  
  # Construct stored_proc_call command
  stored_proc_call <- paste0("CALL SYSUIF.REMOVE_FILE('", file.identifier, "', ", as.integer(force.remove), ")")
  
  # Print stored procedure call if td.debug.enable = TRUE
  if (isTRUE(getOption("td.debug.enable"))) {
    .ta.print("TDR_P5001", stored_proc_call)
  }

  # Execute the stored procedure call.
  tryCatch({
    call_val <- dbExecute(con, stored_proc_call)
  }, error = function(emsg) {
    .ta.stop("TDR_E5002", "remove", file.identifier, emsg)
  })
  
  cat(gettextf("File '%s' removed from Vantage.\n", file.identifier))
}