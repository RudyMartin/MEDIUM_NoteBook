#' Number of rows in a data.frame or a tibble object
#'
#' This function retrieves number of rows in a tibble or data.frame object.
#' @param df Required Argument\cr
#'           Specifies a data.frame or a tibble object.\cr
#'           Types: R data.frame OR tibble
#' @return Returns the number of rows in a data.frame or a tibble object.
#' @examples 
#' \donttest{
#' # Get remote data source connection
#' con <- td_get_context()$connection
#' 
#' # Create a dataframe.
#' df <- data.frame(column1 = c(1, 2, 3), column2 = c('teradata', 'vantage', 'release'), 
#'                  column3 = c(TRUE, FALSE, TRUE))
#' # Returns the number of rows for data.frame.
#' td_nrow(df)
#' 
#' # Create table from R dataframe "df".
#' copy_to(con, df, name = "test_table", analyze = TRUE, overwrite = TRUE)
#' 
#' # Create remote tibble object.
#' test_table <- tbl(con, "test_table")
#' 
#' # Returns the number of rows for tibble object.
#' td_nrow(test_table)
#' }
#' @importFrom dplyr pull
#' @importFrom dplyr sql
#' @importFrom dbplyr remote_query
#' @importFrom dbplyr remote_con
#' @export
#' @rdname td_nrow
#' @aliases td_nrow
td_nrow <- function(df) {
  # Raise error when the provided input is not a tbl or data.frame object.
  if ((!inherits(df, "tbl")) && (!inherits(df, "data.frame"))) {
    .ta.stop("TDR_E3002", "df", paste("tbl", "data.frame object", sep = " or "))
  }
  # Extract rows using nrow if df is data.frame type else create a SQL query with count(*) and 
  # extract the output using pull().
  val <- NULL
  if (inherits(df, "data.frame")) {
    val <- nrow(df)
  } else {
    query <- sql(paste0("select CAST(count(*) AS BIGINT) as cnt from (", remote_query(df), ") as cnt_tbl"))
    val <- tbl(remote_con(df), query) %>% pull()
  }
  return(val)
}

