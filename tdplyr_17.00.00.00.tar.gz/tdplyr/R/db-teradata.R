#
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: karthik.thelukuntla@teradata.com
# Secondary Owner:
#
# Overridden functions from DBI and dbplyr
#
### List of functions that dont work and may need to be overridden
# db_create_table
#
###################################################################################

#' @importFrom DBI dbExistsTable
#' @importFrom DBI dbGetQuery
# This function is only for inputs Teradata connection and SQL object, for other inputs 
# DBI::dbExistsTable will call

# TODO : while loading the package getting following warning:
#       in method for ‘dbExistsTable’ with signature ‘"Teradata","ident_q" dbExistsTable"’: no definition for class “Teradata”
#       Need to address it later. User sees this message only when installing package.
setMethod(
  "dbExistsTable",c("Teradata", "ident_q"),
  function(conn, name, ...) {
    # This condition copied from DBI
    stopifnot(length(name) == 1)
    # Here name can be class: character or ident_q
    # This getter should always return upper case
    dbName <- .get_dbname(name)

    tableName <- .get_source_definition(name)

    # The following query from TeradataR wont work because say,
    # if user creates a table TAB1 and then tries to check if table tab1 exists
    # query <- gettextf("SELECT count(TableName) as tableCount FROM DBC.TABLESV
    #                    WHERE TABLENAME ='%s' and databasename = '%s'",
    #                     tableName, dbName)
    query <- gettextf("SELECT count(TableName) as tableCount FROM DBC.TABLESV
                       WHERE UPPER(databasename) = '%s' and UPPER(TABLENAME) = '%s'",
                        toupper(dbName), toupper(tableName))
    
    res <- dbGetQuery(conn, query)
    
    return(res$tableCount > 0)
  })

# No need to export these as the S4 generics are exported in DBI
# We cannot combine this function with ident_q above because then
# it wont work for temporary tables
# 1. The default function in DBI compares case sensitive and so dbExistsTable fails
# E.g.: dbExistsTable("tab1") returns true but dbExistsTable("Tab1") returns false
# 2. Another bug with the DBI dbExistsTable is say if you create a table in 
# say tab2 in DB1 and then check dbExistsTable(con, "tab2") it will return true
#' @importFrom DBI dbExistsTable
#' @importFrom DBI dbGetQuery
#' @importFrom dbplyr in_schema
setMethod(
  "dbExistsTable",c("Teradata", "character"),
  function(conn, name, ...) {
    # This condition copied from DBI
    stopifnot(length(name) == 1)
    # since the DBI code does not work we reuse the ident_q code above
    if(dbExistsTable(conn,
        in_schema(.get_dbname(conn), name), ...))
      return(TRUE)

    # It might be a temporary table so check that
    query <- "help volatile table"
    res <- dbGetQuery(conn, query)
    if (!is.null(res$`Table SQL Name`)) {
      return(toupper(name) %in% toupper(res$`Table SQL Name`))
    }
    FALSE
  })

#' @importFrom dplyr db_drop_table
#' @export
#' @importFrom DBI dbQuoteIdentifier
# We need to override this function because the 'if exists' clause is not supported
# When force = TRUE, this function does not throw error when table does not exist
# However, if force = TRUE and if table exists and there is some other error then
# we must throw error.
db_drop_table.Teradata <- function(con, table, force = FALSE, ...) {
  # A naive approach is to first check if table does not exist,
  # Then just return 0, if force is TRUE
  # However checking table exists is expensive and not needed here.
  # if (force && !db_has_table(con, table))
  #   return(0)

  # This could throw error when a) if table exists, or
  # b) the user does not have drop Priviliges
  query <- gettextf("DROP TABLE %s;", dbQuoteIdentifier(con, table))
  tryCatch({
    dbExecute(con, query)},
      error = function(e) {
        emsg <- e[["message"]]
        # if force and table does not exist ignore the error
        if (force && .isTableDoesNotExists(emsg)) {
          # log the error for debug purposes
          if(getOption("td.debug.enable"))
            .ta.print(emsg, showStackTrace = FALSE)
          return(0)
        }
        # otherwise just throw back the same error
        .ta.stop(emsg, showFunctionCall = FALSE)
      })
}

#' @importFrom dplyr db_has_table
#' @export
db_has_table.Teradata <- function(con, table) 
  dbExistsTable(con, table)

#' @importFrom dplyr db_write_table
#' @importFrom DBI dbWriteTable
#' @export
db_write_table.Teradata <- function(con, table, types, values, temporary = FALSE, append = TRUE, row.names = FALSE, ...) {
  
  dbWriteTable(
    con,
    name = table,
    value = values,
    field.types = types,
    temporary = temporary,
    row.names = row.names,
    append = append
  )
  
  table
}

#' @importFrom DBI dbExecute
#' @importFrom DBI dbQuoteIdentifier
.db_delete_table <- function(con, table){
  #Truncates(delete all rows) the table
  #Arguments:
  #   con   : Connection object
  #   table : Table which needs to be truncated
  if (is.null(table) || is.na(table) ||
      typeof(table) != "character" || nchar(table) <= 0)
    .ta.stop("Invalid 'table' argument")
  
  dbExecute(con, gettextf('delete %s all',dbQuoteIdentifier(con, table)))
}

# This is required to avoid quoting when the table name is
# coming from in_schema function.
# Otherwise if input is in_schema("alice", "t1") then DBI will
# convert it to "\"alice.t1\""
#' @importFrom DBI dbQuoteIdentifier
#' @importFrom DBI SQL
# TODO : while loading the package getting following warning:
#       in method for ‘dbExistsTable’ with signature ‘"Teradata","ident_q"’: no definition for class “Teradata”
#       Need to address it later. User sees this message only when installing package.
setMethod(
  "dbQuoteIdentifier", c("Teradata", "ident_q"),
  function(conn, x, ...) {
    SQL(x)
  })


# This returns Teradata specific SQL data types for a given R data frame
# This is overridden to support the DBI::sqlCreateTable and DBI::dbWriteTable functions
setMethod(
  "dbDataType", c("Teradata", "data.frame"),
  function(dbObj, obj, ...) {
    vapply(obj, .getSQLDataType, con = dbObj, FUN.VALUE = character(1), USE.NAMES = TRUE)
  })

# This returns Teradata specific SQL data types for a given R object
# This is overridden to support the DBI::sqlCreateTable and DBI::dbWriteTable functions
#' @importFrom DBI dbDataType
setMethod(
  "dbDataType", "Teradata",
  function(dbObj, obj, ...) {
    .getSQLDataType(dbObj, obj)
  })

#' Analyze the table
#'
#' This function collects the statistics of the given table.
#'
#' @param con Required Argument.
#'            Specifies remote data source.
#' @param table Required Argument.
#'              Specifies remote table name. 
#' @param column Required Argument.
#'               Specifies name of the remote table column(s). Column name is required to collect the statistics in Teradata.
#'               This argument allows multiple columns as a vector.
#' @param ...    Other parameters passed to methods.
#' @return Returns 2 on successful, error on any failure.
#' @seealso \code{db_begin(),db_commit(),db_rollback()}
#' @examples
#' \donttest{
#' con <- td_get_context()$connection
#' iris2 <-  copy_to(con, iris, overwrite = FALSE)
#' db_analyze(con, "iris", "Sepal.Length")
#' }
#' @rdname db_analyze
#' @aliases db_analyze
#' @importFrom DBI dbExecute
#' @importFrom dbplyr build_sql
#' @importFrom DBI dbQuoteIdentifier
#' @export
db_analyze.Teradata <- function(con, table,column, ...) {
  
  if(is.null(table) || is.na(table) ||
     !is.character(table)  || nchar(table) <= 0)
    .ta.stop("'table' argument should be a valid table name.")
  if(is.null(column) || is.na(column) ||
     !is.character(column) || nchar(column) <= 0)
    .ta.stop("'column' argument should be a valid column.")
  
  sql <- build_sql(
    "COLLECT STATISTICS COLUMN ",dbQuoteIdentifier(con,column),"  ON ",
    dbQuoteIdentifier(con,table), con = con)
  DBI::dbExecute(con, sql)
}

# This function overrides db_query_fields in dbplyr so as to avoid
# fetching the column names from the backend.
# This will be replaced by a SINGLE call to the backend to retrieve both
# the column names and types.
#' @importFrom dplyr db_query_fields
#' @export
db_query_fields.Teradata <- function(con, sql, ...) {
  # Do nothing here so that we can attach both the
  # column names and types in tbl creation

  # Check if this was called from the tbl.src_Teradata function
  if (any(
    grepl("tbl.src_Teradata",
        sys.calls()
      )
    )) {
    # This debug message will also show the stack trace
    if(getOption("td.debug.enable"))
      .ta.print("Ignoring query: ", sql, showStackTrace = TRUE)
    return(c(""))
  }

  # If the function is not called via tbl.Teradata
  # then invoke the original function
  NextMethod()
}

#' Creates a Table
#'
#' Creates a table from query.
#'
#' @param con Required Argument.\cr
#'            Specifies remote data source.
#' @param table Required Argument.\cr
#'              Specifies name of the new remote table.\cr
#'              Types : character
#' @param sql Required Argument.\cr
#'            Specifies a query from which new table is to be created.\cr
#'            Types : sql OR character
#' @param temporary Optional Argument.\cr
#'                  Specifies whether to create a temporary remote table(TRUE) or not(FALSE).\cr
#'                  Default : FALSE\cr
#'                  Types : logical
#' @param table.type Optional Argument.\cr
#'                   Specifies type of remote table - NOPI(No Primary Index), PI(Primary Index).\cr 
#'                   Default : PI\cr
#'                   Types : character
#' @param primary.index Optional Argument.\cr
#'                      Specifies name of the primary index column. You can provide multiple columns 
#'                      as a vector. When primary.index is not specified and table.type is "PI", 
#'                      the behavior is specified by the "PrimaryIndexDefault" field in DBS 
#'                      Control.\cr
#'                      Default : NULL\cr
#'                      Types : character OR vector of characters
#' @param ... Other parameters passed to methods.
#' @return Returns name of the newly created remote table.
#' @seealso \code{db_save_query()}
#' @examples
#' \donttest{
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#' 
#' # Save iris dataset into table 'db_compute_test'.
#' iris2 <-  copy_to(con, iris, name = "db_compute_test", overwrite = FALSE)
#' 
#' sql <- "select * from db_compute_test"
#' 
#' # Create PI table from the result set of "sql".
#' db_compute(con, "db_compute_test1", sql, temporary = FALSE, table.type = "PI",
#'            primary.index = c("Petal.Length","Species"))
#' }
#' @rdname db_compute
#' @aliases db_compute
#' @importFrom dplyr db_save_query
#' @importFrom dbplyr db_compute
#' @importFrom DBI dbQuoteIdentifier
#' @export
db_compute.Teradata <- function(con, table, sql, temporary = FALSE, table.type = "PI", 
                                primary.index = NULL, ... ) {
  table <- db_save_query(con, sql, table, temporary = temporary, table.type = table.type, 
                         primary.index = primary.index, ...)
  table
}

#' Creates a Table
#'
#' Builds and executes a create table query.
#'
#' @param con Required Argument.\cr
#'            Specifies remote data source.
#' @param sql Required Argument.\cr
#'            Specifies a query from which new table is to be created.\cr
#'            Types : sql OR character
#' @param name Required Argument.\cr
#'             Specifies name of the new remote table.\cr
#'             Types : character
#' @param temporary Optional Argument.\cr
#'                  Specifies whether to create a temporary remote table(TRUE) or not(FALSE).\cr
#'                  Default : FALSE\cr
#'                  Types : logical
#' @param table.type Optional Argument.\cr
#'                   Specifies type of remote table - NOPI(No Primary Index), PI(Primary Index).\cr 
#'                   Default : PI\cr
#'                   Types : character
#' @param primary.index Optional Argument.\cr
#'                      Specifies name of the primary index column. You can provide multiple columns 
#'                      as a vector. When primary.index is not specified and table.type is "PI", 
#'                      the behavior is specified by the "PrimaryIndexDefault" field in DBS 
#'                      Control.\cr
#'                      Default : NULL\cr
#'                      Types : character OR vector of characters
#' @param ... Other parameters passed to methods.
#' @return Returns name of newly created remote table.
#' @seealso \code{db_compute()}
#' @examples
#' \donttest{
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#' 
#' # Save iris dataset into table 'db_save_query_test'.
#' iris2 <-  copy_to(con, iris, name = "db_save_query_test", overwrite = FALSE)
#' 
#' sql <- "select * from db_save_query_test"
#' 
#' # Create PI table from the result set of "sql".
#' db_save_query(con, sql, "db_save_query_test1", temporary = FALSE, table.type = "PI",
#'               primary.index = c("Petal.Length","Species"))
#' }
#' @rdname db_save_query
#' @aliases db_save_query
#' @importFrom DBI dbExecute
#' @importFrom dbplyr build_sql
#' @importFrom dplyr db_save_query
#' @importFrom dplyr sql
#' @export
db_save_query.Teradata <- function(con, sql, name, temporary = FALSE, table.type = "PI", 
                                   primary.index = NULL, ...) {
  
  arguments <- list(...)
  
  pti.clause <- arguments[["pti.clause"]]
  pti.name <- arguments[["pti.name"]]
  
  statement = "" 
  if (!is.null(pti.clause)) {
    statement <- "PRIMARY TIME INDEX"
    if (!is.null(pti.name)) {
      statement <- gettextf("%s %s", statement, pti.name)
    }
    statement <- gettextf("%s (%s)", statement, pti.clause)
  } else if (toupper(table.type) == "PI" && !is.null(primary.index)) {
    statement = gettextf("PRIMARY INDEX ( %s )",paste0("\"", primary.index, "\"", collapse = ","))
  } else if (toupper(table.type) == "NOPI") {
    statement = "NO PRIMARY INDEX"
  }
  
  tt_sql <- build_sql( "CREATE ", if (temporary) sql("VOLATILE "),
    " MULTISET TABLE ", sql(dbQuoteIdentifier(con,name)), " AS (", sql(sql),") with data ", sql(statement), 
    if (temporary) sql(" ON COMMIT PRESERVE ROWS"),
    con = con
  )
  dbExecute(con, tt_sql)
  name
}

#' @importFrom dplyr db_desc
#' @export
db_desc.Teradata <- function(x){

  info <- DBI::dbGetInfo(x)

  host <- .get_servername(x)
  port <- .get_port(x)
  version <- .get_version(x)
  driver_version <- .get_driver_version(x)
  driver <- .get_driver_name(x)
  dbname <- .get_dbname(x)
  dbms.name <- "Teradata"
  username <- .get_username(x)

  res <- ""

  # read td.db_desc.output options
  if (!is.null(getOption('td.db_desc.output'))){

    opts <- getOption('td.db_desc.output')

    if (opts$db)
      res <- paste0(res, ' [', dbms.name, " ", version,'] ')

    if (opts$driver)
      res <- paste0(res, " [", driver, " ", driver_version, "] ")

    if (opts$machine)
      res <- paste0(res, "[", username, "@", host, port, "/", dbname , "]")
  }

  # ensure output
  if (res == ""){

    res <- dbms.name

  }

  res

}

# This function is overridden because we want to automatically populate column names
# of the tbl object in case it is a teradata lazy tbl (ignore metadata)
# Note: collect is called internally by print and as.data.frame functions too.
#' @importFrom dplyr collect
#' @export
collect.tbl_teradata <- function(x, ...) {
  out <- NextMethod(x, ...)
  .populateLazyVars(x$ops, names = names(out), types = NULL)
  return(out)
}

# This function is overridden because when user calls print on a tbl object,
# it internally invokes the nrow function which ends up calling op_vars.
# Since we dont want to retrieve metadata for teradata lazy tbls, we avoid calling it.
#' @export
print.tbl_teradata <- function(x, ...) {
  # we must avoid refetching the column names if it is of class op_base_teradata
  if (.is_ignore_metadata(x$ops))
    class(x$ops) <- c("op_ignore_teradata", class(x$ops))
  NextMethod(x, ...)
}
