################################################################################
#
# Copyright 2019 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: Adithya Avvaru (adithya.avvaru@teradata.com)
# Secondary Owner:
#
# This file has:
#   1.  The constants for valid timebucket durations (formal and shorthand).
#   2.  Regular expression for both formal and shorthand notation for timebucket duration.
#   3.  The mapping for short hand notation of timebucket duration to formal notation. 
#   4.  A function '.validate_time_bucket_duration' which validates timebucket duration syntax.
#
###################################################################################

VALID_TIMEBUCKET_DURATIONS_FORMAL     <- c('CAL_YEARS', 'CAL_MONTHS', 'CAL_DAYS', 'WEEKS', 'DAYS', 
                                           'HOURS', 'MINUTES', 'SECONDS', 'MILLISECONDS', 
                                           'MICROSECONDS')
VALID_TIMEBUCKET_DURATIONS_SHORTHAND  <- c('cy', 'cyear', 'cyears',
                                           'cm', 'cmonth', 'cmonths',
                                           'cd', 'cday', 'cdays',
                                           'w', 'week', 'weeks',
                                           'd', 'day', 'days',
                                           'h', 'hr', 'hrs', 'hour', 'hours',
                                           'm', 'mins', 'minute', 'minutes',
                                           's', 'sec', 'secs', 'second', 'seconds',
                                           'ms', 'msec', 'msecs', 'millisecond', 'milliseconds',
                                           'us', 'usec', 'usecs', 'microsecond', 'microseconds')

PATTERN_TIMEBUCKET_DURATION_SHORT   <- "^(-?[0-9]+)([a-z]+)$"
PATTERN_TIMEBUCKET_DURATION_FORMAL  <- "^([a-z_]+)\\((-?[0-9]+)\\)$"

TIMEBUCKET_DURATION_FORMAT_MAPPER   <- list('cy' = 'CAL_YEARS',
                                            'cyear' = 'CAL_YEARS',
                                            'cyears' = 'CAL_YEARS',
                                            'cm' = 'CAL_MONTHS',
                                            'cmonth' = 'CAL_MONTHS',
                                            'cmonths' = 'CAL_MONTHS',
                                            'cd' = 'CAL_DAYS',
                                            'cday' = 'CAL_DAYS',
                                            'cdays' = 'CAL_DAYS',
                                            'w' = 'WEEKS',
                                            'week' = 'WEEKS',
                                            'weeks' = 'WEEKS',
                                            'd' = 'DAYS',
                                            'day' = 'DAYS',
                                            'days' = 'DAYS',
                                            'h' = 'HOURS',
                                            'hr' = 'HOURS',
                                            'hrs' = 'HOURS',
                                            'hour' = 'HOURS',
                                            'hours' = 'HOURS',
                                            'm' = 'MINUTES',
                                            'mins' = 'MINUTES',
                                            'minute' = 'MINUTES',
                                            'minutes' = 'MINUTES',
                                            's' = 'SECONDS',
                                            'sec' = 'SECONDS',
                                            'secs' = 'SECONDS',
                                            'second' = 'SECONDS',
                                            'seconds' = 'SECONDS',
                                            'ms' = 'MILLISECONDS',
                                            'msec' = 'MILLISECONDS',
                                            'msecs' = 'MILLISECONDS',
                                            'millisecond' = 'MILLISECONDS',
                                            'milliseconds' = 'MILLISECONDS',
                                            'us' = 'MICROSECONDS',
                                            'usec' = 'MICROSECONDS',
                                            'usecs' = 'MICROSECONDS',
                                            'microsecond' = 'MICROSECONDS',
                                            'microseconds' = 'MICROSECONDS')

# Intenal function to validate timebucket duration and return the formal notation.
# Parameters:
#   timebucket.duration : timebucket duration of the group by time clause.
# Returns:
#   The formal notation of the given timebucket duration, if it is available in
#   list of valid time bucket durations.
# Raises:
#   Exception when the given timebucket.duration is not valid.
.validate_time_bucket_duration <- function (timebucket.duration = NULL) {
  if (is.null(timebucket.duration)) {
    return(TRUE)
  }
  
  # Return the same timebucket.duration if it is unbounded timebucket duration.
  # No validations are needed.
  if (timebucket.duration == "*") return(timebucket.duration)
  
  N <- sub(PATTERN_TIMEBUCKET_DURATION_SHORT, "\\1", timebucket.duration, ignore.case = TRUE)
  if (grepl("^-?[[:digit:]]+$", N)) {
    # If the timebucket duration is in shorthand format, then get the long format along 
    # with the duration.
    # Shorthand format starts with digit.
    duration_units <- sub(PATTERN_TIMEBUCKET_DURATION_SHORT, "\\2", timebucket.duration, ignore.case = TRUE)
    # Shorthand notations are in lower case in the mapper.
    if (! tolower(duration_units) %in% names(TIMEBUCKET_DURATION_FORMAT_MAPPER)) 
      .ta.stop ("TDR_E1008", "timebucket.duration", paste0(timebucket.duration, ". Please check documentation."))
    duration_units <- TIMEBUCKET_DURATION_FORMAT_MAPPER[[tolower(duration_units)]]
  } else if (grepl("^-?[[:digit:]]+$", sub(PATTERN_TIMEBUCKET_DURATION_FORMAL, "\\2", 
                                         timebucket.duration, ignore.case = TRUE))) {
    # If the timebucket duration is in formal format, then fetch the long format along 
    # with the duration.
    N <- sub(PATTERN_TIMEBUCKET_DURATION_FORMAL, "\\2", timebucket.duration, ignore.case = TRUE)
    duration_units <- sub(PATTERN_TIMEBUCKET_DURATION_FORMAL, "\\1", timebucket.duration, ignore.case = TRUE)
    # Formal notation is in upper case in VALID_TIMEBUCKET_DURATIONS_FORMAL
    if (! toupper(duration_units) %in% VALID_TIMEBUCKET_DURATIONS_FORMAL) 
      .ta.stop ("TDR_E1008", "timebucket.duration", paste0(timebucket.duration, ". Please check documentation."))
  } else {
    # If the timebucket duration is not in either of formal and shorthand format
    .ta.stop ("TDR_E1008", "timebucket.duration", paste0(timebucket.duration, ". Please check documentation."))
  }
  N <- as.numeric(N)
  
  if (!.validate_integer_bounds(N, lbound = 1, ubound = 32767)) {
    .ta.stop("TDR_E1008", "timebucket.duration", paste0(timebucket.duration, ". The numeric part in the argument should have positive integer with a maximum value of 32767."))
  }
  
  timebucket.duration <- paste0(toupper(duration_units), "(", N, ")")
  return(timebucket.duration)
}

# Internal function to validate whether the integer value is in the lowe and 
# upper bounds.
# Parameters:
#   val     : Specifies the integer value which is to be validated.
#   lbound  : Specifies the lower bound value of the integer.
#   ubound  : Specifies the upper bound value of the integer.
#   lbound_inclusive  : TRUE if the lower bound is inclusive; FALSE otherwise.
#   ubound_inclusive  : TRUE if the upper bound is inclusive; FALSE otherwise.
.validate_integer_bounds <- function(val, lbound = 0, ubound = 65537, lbound_inclusive = TRUE, ubound_inclusive = TRUE) {
  is_in_bounds = TRUE
  if (lbound_inclusive && val < lbound) is_in_bounds = FALSE
  if (!lbound_inclusive && val <= lbound) is_in_bounds = FALSE
  if (ubound_inclusive && val > ubound) is_in_bounds = FALSE
  if (!ubound_inclusive && val >= ubound) is_in_bounds = FALSE
  return(is_in_bounds)
}