# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 2.19
# 
# ################################################################## 

# Description:
#   The XGBoost Drive function takes a training data set and uses 
#   gradient boosting to produce a strong classifying model that can be 
#   input to the function XGBoost PredictExample of XGBoost Predict 
#   function that uses binary classification.Input for example of XGBoost 
#   Predict function that uses binary classification.SQL-MapReduce call 
#   for example of XGBoost Predict function that uses binary 
#   classification.Output for example of XGBoost Predict function that 
#   uses binary classification.Example of XGBoost Predict function that 
#   uses multiple-class classification.Input for example of XGBoost 
#   Predict function that uses multiple-class 
#   classification.SQL-MapReduce call for example of XGBoost Predict 
#   function that uses multiple-class classification.Output for example 
#   of XGBoost Predict function that uses multiple-class classification..
# 
# Args:
#   formula -
#     Required Argument.
#     An object of class "formula". Specifies the model to be fitted. Only 
#     basic formula of the (col1 ~ col2 + col3 +...) form are supported and 
#     all variables must be from the same tbl_teradata object. The 
#     response should be column of type numeric or logical.
#   
#   data -
#     Required Argument.
#     Specifies the tbl_teradata containing the input data set.
#   
#   id.column -
#     Optional Argument.
#     Specifies the name of the partitioning column of input table. This 
#     column is used as a row identifier to distribute data among different 
#     vworkers for parallel boosted trees. 
#     Types: character
#   
#   loss.function -
#     Optional Argument.
#     loss function
#     Default Value: "SOFTMAX"
#     Permitted Values: BINOMIAL, SOFTMAX
#     Types: character
#   
#   prediction.type -
#     Optional Argument.
#     prediction type
#     Default Value: "CLASSIFICATION"
#     Permitted Values: CLASSIFICATION
#     Types: character
#   
#   reg.lambda -
#     Optional Argument.
#     regularization
#     Default Value: 1
#     Types: numeric
#   
#   shrinkage.factor -
#     Optional Argument.
#     shrinkage factor
#     Default Value: 0.1
#     Types: numeric
#   
#   iter.num -
#     Optional Argument.
#     Specifies the number of iterations to boost the weak classifiers, 
#     which is also the number of weak classifiers in the ensemble (T). The 
#     number must an integer in the range [1, 100000]. 
#     Default Value: 10
#     Types: integer
#   
#   min.node.size -
#     Optional Argument.
#     Specifies the minimum size of any particular node within each 
#     decision tree. The min_node_size must an integer. 
#     Default Value: 1
#     Types: integer
#   
#   max.depth -
#     Optional Argument.
#     Specifies the maximum depth of the tree. The max_depth must an 
#     integer in the range [1, 100000]. 
#     Default Value: 5
#     Types: integer
#   
#   variance -
#     Optional Argument.
#     Specifies a decision tree stopping criterion. If the variance within 
#     any nodedips below this value, the algorithm stops looking for splits 
#     in the branch. The default value is 0.
#     Default Value: 0
#     Types: numeric
#   
#   seed -
#     Optional Argument.
#     Specifies the seed to use to create a random number. The seed must be 
#     a positive BIGINT value.
#     Types: numeric
#   
#   attribute.name.column -
#     Optional Argument.
#     Required for sparse data format, if the data set is in sparse format, 
#     this argument indicates the column containing the attributes in the 
#     input table
#     Types: character
#   
#   num.boosted.trees -
#     Optional Argument.
#     Specifies the number of boosted trees to be trained. By default, the 
#     number of boosted trees equals the number of vworkers available for 
#     the functions.
#     Types: integer
#   
#   attribute.table -
#     Optional Argument.
#     Name of the tbl_teradata containing the features in the input data. 
#     Required for sparse data format
#   
#   attribute.value.column -
#     Optional Argument.
#     If the data is in the sparse format, this argument indicates the 
#     column containing the attribute values in the input table
#     Types: character
#   
#   column.subsampling -
#     Optional Argument.
#     column subsampling
#     Default Value: 1.0
#     Types: numeric
#   
#   response.column -
#     Required Argument.
#     Specifies the name of the response tbl_teradata column that contains 
#     the responses (labels) of the data.
#     Types: character
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
#   
#   attribute.table.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "attribute.table". The argument is used to 
#     ensure deterministic results for functions which produce results that 
#     vary from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_xgboost_mle" which is a named 
#   list containing Teradata tbl objects.
#   Named list members can be referenced directly with the "$" operator 
#   using following names:\enumerate{\item model.table\item output}
# 
# 
#' @export
td_xgboost_mle <- function(
  formula = NULL,
  data = NULL,
  id.column = NULL,
  loss.function = "SOFTMAX",
  prediction.type = "CLASSIFICATION",
  reg.lambda = 1,
  shrinkage.factor = 0.1,
  iter.num = 10,
  min.node.size = 1,
  max.depth = 5,
  variance = 0,
  seed = NULL,
  attribute.name.column = NULL,
  num.boosted.trees = NULL,
  attribute.table = NULL,
  attribute.value.column = NULL,
  column.subsampling = 1.0,
  response.column = NULL,
  data.sequence.column = NULL,
  attribute.table.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("formula", formula, TRUE, "formula"))
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("id.column", id.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("loss.function", loss.function, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("prediction.type", prediction.type, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("reg.lambda", reg.lambda, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("shrinkage.factor", shrinkage.factor, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("iter.num", iter.num, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("min.node.size", min.node.size, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("max.depth", max.depth, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("variance", variance, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seed", seed, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("attribute.name.column", attribute.name.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("num.boosted.trees", num.boosted.trees, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("attribute.table", attribute.table, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("attribute.value.column", attribute.value.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("column.subsampling", column.subsampling, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("response.column", response.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("attribute.table.sequence.column", attribute.table.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure either formula or response.column is provided.
  if((is.null(formula) && is.null(response.column)) || (!is.null(formula) && !is.null(response.column) ) ){
    .ta.stop("TDR_E3009","formula","response.column")
  }
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  .validateInputTableDataType(attribute.table, NULL)
  
  # Check for permitted values
  loss.functionPermittedValues <- list("BINOMIAL", "SOFTMAX")
  .validatePermittedValues(loss.function, loss.functionPermittedValues)
  
  prediction.typePermittedValues <- list("CLASSIFICATION")
  .validatePermittedValues(prediction.type, prediction.typePermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(response.column)
  .validateTblHasArgumentColumns(response.column, "response.column", data, "data")
  
  .validateInputColumnsNotEmpty(id.column)
  .validateTblHasArgumentColumns(id.column, "id.column", data, "data")
  
  .validateInputColumnsNotEmpty(attribute.name.column)
  .validateTblHasArgumentColumns(attribute.name.column, "attribute.name.column", data, "data")
  
  .validateInputColumnsNotEmpty(attribute.value.column)
  .validateTblHasArgumentColumns(attribute.value.column, "attribute.value.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(attribute.table.sequence.column)
  .validateTblHasArgumentColumns(attribute.table.sequence.column, "attribute.table.sequence.column", attribute.table, "attribute.table")
  
  # Generate temp table names for output table parameters if any.
  model.tableTempTableName <- .teradataGenerateTempTableName("td_xgboost0_", use.default.database = TRUE, gc.onQuit = TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_xgboost_mle.internal)
  Call[["model.tableTempTableName"]] <- model.tableTempTableName
  
  retval <- NULL
  tryCatch({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_xgboost_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units = "secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_xgboost_mle.internal <- function(
  formula = NULL,
  data = NULL,
  id.column = NULL,
  loss.function = "SOFTMAX",
  prediction.type = "CLASSIFICATION",
  reg.lambda = 1,
  shrinkage.factor = 0.1,
  iter.num = 10,
  min.node.size = 1,
  max.depth = 5,
  variance = 0,
  seed = NULL,
  attribute.name.column = NULL,
  num.boosted.trees = NULL,
  attribute.table = NULL,
  attribute.value.column = NULL,
  column.subsampling = 1.0,
  response.column = NULL,
  data.sequence.column = NULL,
  attribute.table.sequence.column = NULL,
  model.tableTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("OutputTable")
  funcOutputArgs <- c(model.tableTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  if (!is.null(id.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IdColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(id.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(attribute.name.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AttributeNameColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(attribute.name.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(attribute.value.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AttributeValueColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(attribute.value.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(num.boosted.trees)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NumBoostedTrees")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(num.boosted.trees, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(loss.function) && !missing(loss.function)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "LossFunction")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(loss.function, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(prediction.type) && !missing(prediction.type)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PredictionType")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(prediction.type, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(reg.lambda) && !missing(reg.lambda)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "RegularizationLambda")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(reg.lambda, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(shrinkage.factor) && !missing(shrinkage.factor)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ShrinkageFactor")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(shrinkage.factor, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(column.subsampling) && !missing(column.subsampling)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ColumnSubSampling")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(column.subsampling, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(iter.num) && !missing(iter.num)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IterNum")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(iter.num, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(min.node.size) && !missing(min.node.size)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MinNodeSize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(min.node.size, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(max.depth) && !missing(max.depth)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxDepth")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(max.depth, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(variance) && !missing(variance)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Variance")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(variance, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(seed)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Seed")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(seed, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "LONG")
  }
  
  if (!is.null(response.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ResponseColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(response.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (!is.null(attribute.table.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("AttributeTable:", .teradataCollapseArgVector(attribute.table.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  if (!is.null(formula)) {
  # Let's process formula argument
  formula.terms.matrix <- .ta.parse.formula(formula, data)
  # response variable
  response <- formula.terms.matrix[1,1]
  mc.target.column <- response
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ResponseColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(response,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  mc.sql.specific.attributes[["ResponseColumn"]] <- response
  
  # numerical input columns
  numerical_inputs <- .ta.getColumnsByType(formula.terms.matrix, data, "numerical")
  if (length(numerical_inputs) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NumericInputs")
    numericalColumnsList <- .teradataCollapseArgVector(.teradataQuoteArg(numerical_inputs,"\""), "'")
    funcOtherArgs <- c(funcOtherArgs, numericalColumnsList)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
    mc.sql.specific.attributes[["NumericInputs"]] <- numericalColumnsList
  }
  
  # categorical input columns
  categorical_inputs <- .ta.getColumnsByType(formula.terms.matrix, data, "categorical")
  if (length(categorical_inputs) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CategoricalInputs")
    categoricalColumnsList <- .teradataCollapseArgVector(.teradataQuoteArg(categorical_inputs,"\""), "'")
    funcOtherArgs <- c(funcOtherArgs, categoricalColumnsList)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
    mc.sql.specific.attributes[["CategoricalInputs"]] <- categoricalColumnsList
  }
}
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # Process attribute.table
  if (!is.null(attribute.table)) {
    tableRef <- .teradataOnClauseFromDataFrame(attribute.table)
    funcInputDistribution <- c(funcInputDistribution, "NONE")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "AttributeTable")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "XGBoost",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("XGBoost", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database = TRUE, gc.onQuit = TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data, attribute.table)
  
  # Return output table data frames.
  result <- list()
  result[["model.table"]] <- .createDataSetObject(.extractTableName(model.tableTempTableName), sourceType = "table", .extractDatabaseName(model.tableTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_xgboost <- td_xgboost_mle
