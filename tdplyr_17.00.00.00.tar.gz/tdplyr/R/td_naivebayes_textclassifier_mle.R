# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.7
# 
# ################################################################## 

# Description:
#   The NaiveBayesTextClassifierTrainer function takes training data as 
#   input
#   			and outputs a model table.
# 
# Args:
#   data -
#     Required Argument.
#     The tbl_teradata defining the training tokens.
#   
#   data.partition.column -
#     Required Argument.
#     Specifies Partition By columns for data.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.
#     Types: character OR vector of Strings (character)
#   
#   data.order.column -
#     Optional Argument.
#     Specifies Order By columns for data.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   token.column -
#     Required Argument.
#     Specifies the name of the token_table column that contains the tokens 
#     to be classified.
#     Types: character
#   
#   doc.id.columns -
#     Optional Argument.
#     Specifies the names of the token_table columns that contain the 
#     document identifier.
#     Types: character OR vector of Strings (character)
#   
#   doc.category.column -
#     Required Argument.
#      Specifies the name of the token_table column that contains the 
#     document category.
#     Types: character
#   
#   model.type -
#     Optional Argument.
#     Specifies the model type of the text classifier. The formulas for the 
#     two model types follow this table.
#     Default Value: "MULTINOMIAL"
#     Permitted Values: MULTINOMIAL, BERNOULLI
#     Types: character
#   
#   categories.data -
#     Optional Argument.
#     The tbl_teradata defining allowed categories.
#   
#   categories.data.order.column -
#     Optional Argument.
#     Specifies Order By columns for categories.data.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   category.column -
#     Optional Argument.
#      Specifies the name of the categories_table column that contains the 
#     prediction categories. The default value is the first column of 
#     categories_table.
#     Default Value: "[0:0]"
#     Types: character
#   
#   prediction.categories -
#     Optional Argument.
#     Specifies the prediction categories. Note: Specify either this 
#     argument or the categories_table, but not both.
#     Types: character OR vector of characters
#   
#   stopwords.data -
#     Optional Argument.
#     The tbl_teradata defining stop words.
#   
#   stopwords.data.order.column -
#     Optional Argument.
#     Specifies Order By columns for stopwords.data.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   stopwords.column -
#     Optional Argument.
#     Specifies the name of the stop_words_table column that contains the 
#     stop words. The default value is the first column of stop_words_table.
#     Types: character
#   
#   stopwords.list -
#     Optional Argument.
#     Specifies words to ignore (such as a, an, and the). Note: Specify 
#     either this argument or the stop_words_table, but not both.
#     Types: character OR vector of characters
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
#   
#   stopwords.data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "stopwords.data". The argument is used to 
#     ensure deterministic results for functions which produce results that 
#     vary from run to run.
#     Types: character OR vector of Strings (character)
#   
#   categories.data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "categories.data". The argument is used to 
#     ensure deterministic results for functions which produce results that 
#     vary from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class 
#   "td_naivebayes_textclassifier_mle" which is a named list containing 
#   Teradata tbl object.
#   Named list member can be referenced directly with the "$" operator 
#   using name: result.
# 
# 
#' @export
td_naivebayes_textclassifier_mle <- function(
  data = NULL,
  data.partition.column = NULL,
  token.column = NULL,
  doc.id.columns = NULL,
  doc.category.column = NULL,
  model.type = "MULTINOMIAL",
  categories.data = NULL,
  category.column = "[0:0]",
  prediction.categories = NULL,
  stopwords.data = NULL,
  stopwords.column = NULL,
  stopwords.list = NULL,
  data.sequence.column = NULL,
  stopwords.data.sequence.column = NULL,
  categories.data.sequence.column = NULL,
  data.order.column = NULL,
  stopwords.data.order.column = NULL,
  categories.data.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.partition.column", data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("token.column", token.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("doc.id.columns", doc.id.columns, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("doc.category.column", doc.category.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("model.type", model.type, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("categories.data", categories.data, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("categories.data.order.column", categories.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("category.column", category.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("prediction.categories", prediction.categories, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("stopwords.data", stopwords.data, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("stopwords.data.order.column", stopwords.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("stopwords.column", stopwords.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("stopwords.list", stopwords.list, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("stopwords.data.sequence.column", stopwords.data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("categories.data.sequence.column", categories.data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  .validateInputTableDataType(stopwords.data, NULL)
  .validateInputTableDataType(categories.data, NULL)
  
  # Check for permitted values
  model.typePermittedValues <- list("MULTINOMIAL", "BERNOULLI")
  .validatePermittedValues(model.type, model.typePermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(token.column)
  .validateTblHasArgumentColumns(token.column, "token.column", data, "data")
  
  .validateInputColumnsNotEmpty(doc.category.column)
  .validateTblHasArgumentColumns(doc.category.column, "doc.category.column", data, "data")
  
  .validateInputColumnsNotEmpty(doc.id.columns)
  .validateTblHasArgumentColumns(doc.id.columns, "doc.id.columns", data, "data")
  
  .validateInputColumnsNotEmpty(category.column)
  # Skipping check for default value "[0:0]" in category.column.
  if (!missing(category.column) && category.column != "[0:0]") {
    .validateTblHasArgumentColumns(category.column, "category.column", categories.data, "categories.data")  
  }
  
  .validateInputColumnsNotEmpty(stopwords.column)
  .validateTblHasArgumentColumns(stopwords.column, "stopwords.column", stopwords.data, "stopwords.data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(stopwords.data.sequence.column)
  .validateTblHasArgumentColumns(stopwords.data.sequence.column, "stopwords.data.sequence.column", stopwords.data, "stopwords.data")
  
  .validateInputColumnsNotEmpty(categories.data.sequence.column)
  .validateTblHasArgumentColumns(categories.data.sequence.column, "categories.data.sequence.column", categories.data, "categories.data")
  
  .validateInputColumnsNotEmpty(data.partition.column)
  .validateTblHasArgumentColumns(data.partition.column, "data.partition.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  .validateInputColumnsNotEmpty(stopwords.data.order.column)
  .validateTblHasArgumentColumns(stopwords.data.order.column, "stopwords.data.order.column", stopwords.data, "stopwords.data")
  
  .validateInputColumnsNotEmpty(categories.data.order.column)
  .validateTblHasArgumentColumns(categories.data.order.column, "categories.data.order.column", categories.data, "categories.data")
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TokenColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(token.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "DocCategoryColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(doc.category.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(doc.id.columns)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "DocIdColumns")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(doc.id.columns,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(category.column) && !missing(category.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CategoryColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(category.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(stopwords.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StopwordsColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(stopwords.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(model.type) && !missing(model.type)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ModelType")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(model.type, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(prediction.categories)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PredictionCategories")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(prediction.categories, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(stopwords.list)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StopwordsList")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(stopwords.list, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (!is.null(stopwords.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("stopwords:", .teradataCollapseArgVector(stopwords.data.sequence.column, "")))
  }
  
  if (!is.null(categories.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("categories:", .teradataCollapseArgVector(categories.data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  data.partition.column <- .teradataCollapseArgVector(data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # Process stopwords.data
  if (!is.null(stopwords.data)) {
    tableRef <- .teradataOnClauseFromDataFrame(stopwords.data)
    funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "stopwords")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(stopwords.data.order.column, "\""))
  }
  
  # Process categories.data
  if (!is.null(categories.data)) {
    tableRef <- .teradataOnClauseFromDataFrame(categories.data)
    funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "categories")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(categories.data.order.column, "\""))
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "NaiveBayesTextClassifierInternal",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("NaiveBayesTextClassifierInternal", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, mapReduceObject$genSqlmrInvocationSql())
  funcInputDataframeType <- c(funcInputDataframeType, "TABLE")
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "1")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "NaiveBayesTextClassifierTrainer",
    sqlmrFuncArgs = NA,
    sqlmrOutputTabArgs = NA,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("NaiveBayesTextClassifierTrainer", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data, stopwords.data, categories.data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_naivebayes_textclassifier_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(endTime - startTime)
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_naivebayes_textclassifier <- td_naivebayes_textclassifier_mle
