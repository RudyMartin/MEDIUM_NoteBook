#
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: arun.kalyanasundaram@teradata.com
# Secondary Owner:
#
# Internal helper functions for Garbage Collection.
# Note: The functions implemented here should not be exposed to users.
#
###################################################################################
# Session Management and Garbage Collection:
#     - Initialize a session to store temp objects in memory
#     - Garbage collect (drop object from DB and memory) at the end of each session
#     - Persist the objects to a local file
#     - Load the session file and see if we should merge it with existing session
#
####################################################################################

##############################################################################
###  Temporary Database Management                                          ###
###  ===========================                                            ###
###  If user specifies a temporary database, it is used for storing         ###
### implicit objects, else, the default database is used.                   ###
##############################################################################

# Gives the full path of the directory where we store the session object
.ta.getSessionObjectsDirectory <- function() {
  root <- .ta.getHomeDirectory()
  return(paste0(root,"/.R.td.session"))
}

# Helper function to return the prefix used for session file
.ta.getSessionObjectsFilePrefix <- function() {
  return(".td.objects")
}
# Returns the full path of the session objects file
# params:
#     dirPath : full path of the session files directory
# Returns: the file with full path
.ta.getSessionObjectsFileName <- function(dirPath) {
  # add a .txt suffix to the file so it can be opened in text editors easily
  fileName <- paste0(.ta.getSessionObjectsFilePrefix(),".",.ta.getPID(),".txt")
  return(file.path(dirPath,fileName))
}

#
# we will persist temp db objects in .R.td.session/.td.objects file inside
# user's home folder or R_HOME folder.
# This function makes sure file exists and if not then initialize one
#
.ta.initSessionDataFile <- function() {
    # Store the session file name in a package variable
    # If it is already set, we overwrite it because the user
    # could have changed their home directory and so we set this param again
    .assign(".session_temp_objects_file__", NULL)
    
    #check and create dir
    fullPath <- .ta.getSessionObjectsDirectory()
    if(!file.exists(fullPath) &&
      !isTRUE(dir.create(fullPath))) {
        if(getOption("td.debug.enable"))
          print(paste("Unable to create directory for session:",fullPath))
        return(FALSE)
    }

    #create session temp objects
    tmpObjectFile <- .ta.getSessionObjectsFileName(fullPath)
    if(!file.exists(tmpObjectFile) &&
      !isTRUE(file.create(tmpObjectFile))) {
        if(getOption("td.debug.enable"))
          print(paste("Unable to create session objects file:",fullPath))
        return(FALSE)
    }

    # We are successfully able to create the session file, so set it.
    .assign(".session_temp_objects_file__", tmpObjectFile)

    return(TRUE)
}

# Helper function to return the list of all session files in the current session directory
# This will only return the filenames with full paths
.getAllSessionFiles <- function(dir = .ta.getSessionObjectsDirectory()) {
  ret <- list.files(dir,
    pattern = "^.td.objects\\.[0-9]{0,20}\\.txt$", all.files = TRUE, full.names = TRUE)
  # for backward compatibility add the default .td.objects file to the list without any extn and PID
  ret <- append(ret, list.files(dir,
    pattern = "^.td.objects$", all.files = TRUE, full.names = TRUE))
  ret
}
# Helper function to get a list of all Session files that are not
# associated with a active PID
# params:
#   ignoreFile : Ignore checking this file. This is used to avoid checking the file of current PID
#               Note: this should be file name with the full path
# return:
#       Defunct Session File names (with full path) as a list of strings
#
.ta.getAllDefunctSessionFiles <- function(ignoreFile = NULL) {
  # notice this pattern will match the pid upto 20 digits.
  # Technically PID can only be max 5 digits on any OS, but keeping our match bigger in case that changes.
  # Also notice the dot is optional so this will also match our older file: ".td.objects" without the suffix
  allFiles <- .getAllSessionFiles()
  retFiles <- c()
  for (x in allFiles) {
    if (!identical(ignoreFile, x) && !.ta.isProcessActive(.ta.extractPIDSuffix(x)))
      retFiles <- append(retFiles, x)
  }
  return(retFiles)
}

# Helper function to remove a given list of files
# params:
#   fileList : The list of file names (could be a vector) with full path
.ta.removeFiles <- function(fileList) {
  for (f in fileList) {
    tryCatch({
      suppressWarnings(file.remove(f))
    }, error = function(e) {
      # an error could occur if the user does not have permissions
      # or another process already removed the file.
      if(getOption("td.debug.enable"))
        print(paste("Error removing file: ", f))
    })
  }
}

# Helper function to invoke load objects on all session files
# params:
#   sessionFileName : The current Session file name (with full path)
#   defunctSessionFiles : List of all defunct session files
# return:
#       A list containing two elements:
#       1. The loaded session Data frame.
#       2. The updated defunctSessionFiles after ignoring any files that could not be loaded.
#
.ta.loadObjectsFromAllFiles <- function(sessionFileName, defunctSessionFiles) {
  loadedSessionDf <- .ta.loadObjectsFromFile(sessionFileName)
  removeIndexes <- c()
  for (i in 1:length(defunctSessionFiles)) {
    sFile <- defunctSessionFiles[i]
    df <- .ta.loadObjectsFromFile(sFile)
    tryCatch({
      # Even if df and loadedSessionDf are null the rbind wont fail
      # However, it could fail if the defunct file is corrupt or invalid contents
      loadedSessionDf <- unique(rbind(df, loadedSessionDf))
    }, error = function(e) {
        removeIndexes <- append(removeIndexes, i)
        if(getOption("td.debug.enable"))
          print(paste("Error merging data from defunct file:",sFile))
    })
  }
  # make sure to discard the defunct files that could not be loaded
  if (!is.null(removeIndexes))
    defunctSessionFiles <- defunctSessionFiles[-removeIndexes]
  return(list(loadedSessionDf, defunctSessionFiles))
}

# This is just a helper to load dataframe from the session file
.ta.loadObjectsFromFile <- function(sessionFileName) {
  # if file exists and its size > 0, load it as well
  fileSize <- 0
  if (!is.null(sessionFileName)) {
    fileSize <- file.info(sessionFileName)$size
  }
  # file.info may not throw error but return NA
  if (fileSize == 0 || is.na(fileSize))
    return(NULL)
  loadedSessionDf <- NULL
  if (fileSize > 0) {
    tryCatch(
      {loadedSessionDf <- utils::read.table(sessionFileName, stringsAsFactors=FALSE,
        header=FALSE, row.names=NULL)},
      error = function(e) {
        if(getOption("td.debug.enable")) print(e)})
  }
  return(loadedSessionDf)
  
}
#
# Load previously persisted session
# First checks if session objects
# It only loads the session from file if thre is no
# or the number of objects in file are large than in memory
# Which is unlikely to happen as the memory is almost always latest
# but for some reason the file is larger, we load it and to be safe merge to existing session.
.ta.loadSession <- function() {
  
  # First check if the session objects already exists
  sessionObjectsE <- NULL
  defunctSessionFiles <- NULL
  sessionFile <- .get(".session_temp_objects_file__")
  if (.exists(".session_temp__objects__")) {
    sessionObjectsE <- .get(".session_temp__objects__")
  } else { # this implies init session for first time
    # we store the session objects inside a data frame inside this env
    # The df is enclosed in environment to be able to modify it in place
    sessionObjectsE <- new.env(parent = emptyenv())
    # Since this is the very first time context is initialized in this R instance
    # We attempt to do a global garbage cleanup by combining all session files
    defunctSessionFiles <- .ta.getAllDefunctSessionFiles(ignoreFile = sessionFile)
  }
  
  ret <- .ta.loadObjectsFromAllFiles(sessionFile, defunctSessionFiles)
  loadedSessionDf <- ret[[1]]
  defunctSessionFiles <- ret[[2]]

  # the session df must have exactly two columns, if not we will discard it
  if (is.null(loadedSessionDf) || ncol(loadedSessionDf) != 2)
    # Handle invalid session file or non existent defunct files
    loadedSessionDf <- as.data.frame(matrix(vector(), 0, 2),stringsAsFactors = FALSE, row.names = FALSE)

  # If we have objects in memory and objects loaded from session file,
  # Then we combine them both and remove duplicates. We will anyway garbage collect
  # at the end of session and persist objects to the file.
  # Note: even if both are null, this will not throw any error.
  sessionObjectsE$df <- unique(rbind(sessionObjectsE$df, loadedSessionDf))
  
  if (is.null(sessionObjectsE$df)) {
    sessionObjectsE$df <- as.data.frame(matrix(vector(), 0, 2),stringsAsFactors = FALSE, row.names = FALSE)
  }
  
  .assign(".session_temp__objects__",sessionObjectsE)
  # force a persist of session here if we had defunct files
  if (length(defunctSessionFiles) > 0) {
    # make sure to remove defunct files only if the persist operation succeeds
    if (.ta.persistSession())
      .ta.removeFiles(defunctSessionFiles)
  }
}


# Initialize and load data structures for garbage collection
.ta.initSessionMetadata <- function() {
  
  # Try initializing the session file every time because
  # if for some reason the folder creation failed first time in td_create_context
  # then the user can fix permissions and try again
  # or he might want to change the home directory and try again
  .ta.initSessionDataFile()

  .ta.loadSession()

  # This is a counter to keep track of number of temp object operations.
  # This is required to know when to update the persistent session file
  # If this variable equals option: td.tmpobject.sync.threshold 
  # Then we can persist the temp objects to file. Otherwise we wait till we reach the threshold
  # Forcefully set this to zero evey time we create the session
  .assign(".temp_operations_count__", 0)
}

# Persist the objects to session file
# Return FALSE on error. TRUE otherwise
.ta.persistSession <- function() {
  # This function is also called from gc, so we check if objects exist
  sessionFileName <- .get(".session_temp_objects_file__")
  if (is.null(sessionFileName))
    return(FALSE)

  status <- tryCatch({
    utils::write.table(.get(".session_temp__objects__")$df, sessionFileName, row.names=FALSE, col.names=FALSE)
    TRUE
    },
    error = function(e) {
      if(getOption("td.debug.enable"))
        print(e)
      FALSE
      })
  return(status)
}

# Checks if the number of garbage collection operations has 
# reached the threshold, then we persist to file
# Return:
#  TRUE if call to persist session was invoked. FALSE otherwise
.ta.persistPeriodically <- function() {

    threshold <- getOption("td.tmpobject.sync.threshold")

    count <- .get(".temp_operations_count__")
    # if threshold is set to 0, then we will persist only at the end of session
    if(threshold != 0 && count >= threshold) {
        .ta.persistSession()
        .assign(".temp_operations_count__", 0)
        return(TRUE)
    }
    return(FALSE)
}

# Add a tempory object to be tracked for garbage collection
# 
# params:
#   name : Object name. This should always be fully qualified name
#          name cannot be na or null
#   type: Either table or view
# return:
#       TRUE if object was added and persisted
#
.ta.addTempObject <- function(name, type) {

  # dont check for nchar(obj) == 0 as it will seriously impact performance
  if (is.null(name) || is.na(name) || is.null(type) || is.na(type))
    return(FALSE)

  # this object is always set in connect
  # Using .validateContextVariable to throw error if context is not initialized.
  # For. E.g. create connection using dbConnect and 
  # call copy_to in the magritr operator use case.
  tmpObjects <- .validateContextVariable(".session_temp__objects__", silent = FALSE)
  idx <- nrow(tmpObjects$df) + 1
  # The caller should make sure this is the full name
  tmpObjects$df[idx,1] <- tolower(name)
  tmpObjects$df[idx,2] <- tolower(type)
  # Update the counter so that we can persist to session file,
  # if it equals the threshold
  .assign(".temp_operations_count__", .get(".temp_operations_count__")+1)

  #sync to disc
  return(.ta.persistPeriodically())
}

#
# If object is already in the backend, we update our data structure.
# This is to avoid unnessary droping the object which is already
# dropped though it will not have any side effect.
# params:
#   name : Object name. This should always be fully qualified name
#          This is case sensitive.
#          name cannot be na or null
#   type: table or view
#   forcePersist: If set, we will always persist the objects. 
#                 Default Value: FALSE
# return:
#       TRUE if object was removed and persisted
.ta.removeTempObject <- function(name, type, forcePersist = FALSE) {

  # dont check for nchar(obj) == 0 as it will seriously impact performance
  if (is.null(name) || is.na(name) || is.null(type) || is.na(type))
    return(FALSE)

  tmpObjects <- .validateContextVariable(".session_temp__objects__", silent = FALSE)
  countBefore <- nrow(tmpObjects$df)
  if (countBefore == 0)
    return(FALSE)

  #Just Filter out objects that dont match name and type
  tmpObjects$df <- tmpObjects$df[(tmpObjects$df[1] != name | tmpObjects$df[2] != type),]
  
  diff = countBefore - nrow(tmpObjects$df)
  # the object could not be found, so nothing was filtered
  if (diff == 0)
    return(FALSE)
  
  # We usually force persist when we want to make sure the object must NOT be GCed.
  if(forcePersist)
    return(.ta.persistSession())

  # Also incremenet count here (dont decrement)
  # Because we also want to sync to disk after some objects are removed
  # diff is almost always = 1, but in rare cases there could be duplicates, then diff > 1
  .assign(".temp_operations_count__", .get(".temp_operations_count__") + diff)

  #sync to disc
  return(.ta.persistPeriodically())

}

# This is a helper function to perform a drop table/view
# If object does not exist we perform a silent drop
# This function is useful since we dont have a "drop if exists" SQL clause
# params:
#   con: A connection object
#   name : Object name. This should always be fully qualified name
#          Name cannot be na or null
#   type: table or view
# Return:
#   TRUE, if object exists (we drop) or does not exist
#   FALSE, if any other error occurs dropping the object e.g. No privilege
#' @importFrom DBI dbExecute
.ta.DropDatabaseObject <- function(con, obj, type) {

  # silently return true if the object name is invalid, so as to avoid hitting backend
  # dont check for nchar(obj) == 0 as it will seriously impact performance
  if (is.null(obj) || is.na(obj) || is.null(type) || is.na(type))
    return(TRUE)

  # This will drop the table even if it has data
  query <- gettextf("drop %s %s;",type, obj)
  #in case of error in dropping table/view, quitely proceed and try it during next call to gc
  status <- tryCatch({
    dbExecute(con, query)
      TRUE},
      error = function(e) {
        if(getOption("td.debug.enable")) print(e)
        # The error could be due to a) Object does not exist, b) User does not have privileges
        # if option b) then we must retain this object
        # Since we dont have "drop if exists" clause, the only way to know is from the error code.
        # Error code: 3807 is for object not exist.
        if (.isTableDoesNotExists(e[["message"]])) {
          TRUE
        } else {
          # Could be error due to no privilige e.g. 3523, 3524, 3525...
          # so for all of these we will try again
          FALSE
        }
      })
  return(status)
}

##############################################################################
###  When to Call Garbage collection
###  ===========================
###  The following are the places where garbage collection could be called
### 1) R session Exit
### 2) Calling td_create_context / td_set_context first time in the session
### 3) Re-connecting / Overwriting existing context (Calling td_create_context / td_set_context second time)
##### 3a) Calling set context twice will skip GC if the existing connection has identical info
### 4) On Package Unload (If user explicitluy unloads the package)
### 5) On remove context. Note: if user uses dbDisconnect then the GC WILL NOT fire.
### 6) Explicitly calling clear temp objects API (clear_context) : NOT MVP-1
##############################################################################

# Drops all temporary objects and persists the session file.
# If user does not have permissions to drop a table, then we retain the object
# Otherwise we remove the object from our list
# Params:
#   forcePersist: If set, we will always persist the objects back to the session file
#   con: Connection object
# Return:
#     TRUE if any object was garbage collected. FALSE otherwise
.ta.gcTempObjects <- function(forcePersist = FALSE, con) {
  sessionObjectsE <- .get(".session_temp__objects__")

  if (is.null(sessionObjectsE) || nrow(sessionObjectsE$df) == 0)
    return(FALSE)

  # This vector will contain objects that could not be dropped due to no privileges
  # So we retain those objects, so user can try again with different privilege
  preserve <- vector("numeric")

  countBefore <- nrow(sessionObjectsE$df)
  for (idx in 1:countBefore) {
    status <- .ta.DropDatabaseObject(con, sessionObjectsE$df[idx,1], sessionObjectsE$df[idx,2])
    if (!status)
        preserve[length(preserve)+1] <- idx
  }
  sessionObjectsE$df <- sessionObjectsE$df[preserve,]
  if (forcePersist || countBefore != nrow(sessionObjectsE$df))
    .ta.persistSession()
}

#' @importFrom DBI dbExecute
#' @importFrom dplyr select
#' @importFrom dplyr filter
listTempModelTables <- function() {
  con <- .taConnection()
  tableNameFormat <- paste0("r__t__%")  
  
  # Get all tables in the database whose name are in the format 'r__t__%'
  temp_tables_query <- paste0("select trim(tablename) as tablename from dbc.tablesv where databasename='", td_get_context()$temp.database, "' and tablename like '", tableNameFormat, "';")
  tempTables <- DBI::dbGetQuery(con, temp_tables_query)
  # Note: If no temp model tables are found, then tempTables after casting will have character(0)
  tempTables <- as.vector(tempTables$tablename)
  
  modelCatalogDB <- .get(".mc.modelCatalogDB")
  modelObjectsView <- .get(".mc.modelObjects")
  
  modelTablesSaved <- character(0)
  if (db_has_table(con, in_schema(modelCatalogDB,
                                  modelObjectsView))) {
    # Retrieve table name entries in TD_ModelCataloging.ModelObjectsV view,
    # and convert it to a char vector.
    # No need to filter by creator name as any model tables saved by any of
    # the users must not be considered as temp tables.
    tableNameColumn <- .get(".mc.modelObjTableName")
    tablesSavedList <- tbl(con, in_schema(modelCatalogDB,
                                           modelObjectsView)) %>%
      filter(!is.na(grep("r__t__", TableName))) %>%
      select(tableNameColumn)
    
    # Check if row count is greater than 0.
    if (as.numeric(td_nrow(tablesSavedList)) > 0) {
      modelTablesSaved <- tablesSavedList %>% pull()
      
      # Extract the table names from in_schema format
      for (i in 1:length(modelTablesSaved)) {
        modelTablesSaved[i] <- .extractTableNameQuoted(modelTablesSaved[i])
      }
    }
  }
  
  # Return the set difference of two vectors which gives the orphan temp tables.
  return(setdiff(tolower(tempTables), tolower(modelTablesSaved)))
}
