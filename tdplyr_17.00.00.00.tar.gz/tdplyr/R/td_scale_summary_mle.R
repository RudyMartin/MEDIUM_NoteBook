# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.6
# 
# ################################################################## 

# Description:
#   The ScalePrinter function takes as input ScaleMap output (statistics
#   assembled at the vworker level) and outputs global statistical
#   information for the entire input data set.
# 
# Args:
#   object -
#     Required Argument.
#     The output ta.scalemap function
#   
#   object.order.column -
#     Optional Argument.
#     Specifies Order By columns for object.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_scale_summary_mle" which is a 
#   named list containing Teradata tbl object.
#   Named list member can be referenced directly with the "$" operator 
#   using name: result.
# 
# 
#' @export
td_scale_summary_mle <- function(
  object = NULL,
  object.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("object", object, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("object.order.column", object.order.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(object, "td_scale_map_mle")
  
  if (.isRefFuncOutput(object, "td_scale_map_mle")) {
    object <- object[[1]]
  }
  
  .validateInputColumnsNotEmpty(object.order.column)
  .validateTblHasArgumentColumns(object.order.column, "object.order.column", object, "object")
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process object
  tableRef <- .teradataOnClauseFromDataFrame(object)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "1")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(object.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "ScalePrinter",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("ScalePrinter", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(object)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_scale_summary_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_scale_summary <- td_scale_summary_mle
