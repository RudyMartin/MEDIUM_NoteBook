# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Jeris Alan Jawahar (jeris.jawahar@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.8
# 
# ################################################################## 

# Description:
#   The NGramSplitter MLE function tokenizes (splits) an input stream of 
#   text and outputs n multigrams (called n-grams) based on the specified 
#   delimiter and reset parameters. NGramSplitter MLE provides more 
#   flexibility than standard tokenization when performing text analysis. 
#   Many two-word phrases carry important meaning (for example, "machine 
#   learning") that unigrams (single-word tokens) do not capture. This, 
#   combined with additional analytical techniques, can be useful for 
#   performing sentiment analysis, topic identification, and document 
#   classification.
# 
# Args:
#   data -
#     Required Argument.\cr
#     Each row of the input tbl_teradata contains a document to be 
#     tokenized. The input tbl_teradata can have additional rows, some or 
#     all of which the function returns in the output table.\cr
#   
#   data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   text.column -
#     Required Argument.\cr
#     The name of the column that contains the input text. Input columns 
#     must contain string SQL types.\cr
#     Types: character
#   
#   delimiter -
#     Optional Argument.\cr
#     A character or string that separates words in the input text. The 
#     default value is the set of all whitespace characters which includes 
#     the characters for space, tab, newline, carriage return and some 
#     others.\cr
#     Default Value: " "\cr
#     Types: character
#   
#   grams -
#     Required Argument.\cr
#     A list of integers or ranges of integers that specify the length, in 
#     words, of each ngram (that is, the value of n). A range_of_values has 
#     the syntax integer1- integer2, where integer1 <= integer2. The values 
#     of n, integer1, and integer2 must be positive.\cr
#     Types: character OR vector of characters
#   
#   overlapping -
#     Optional Argument.\cr
#     A Boolean value that specifies whether the function allows 
#     overlapping n-grams. When this value is "true" (the default), each 
#     word in each sentence starts an n-gram, if enough words follow it (in 
#     the same sentence) to form a whole n-gram of the specified size. For 
#     information on sentences, see the description of the reset 
#     argument.\cr
#     Default Value: TRUE\cr
#     Types: logical
#   
#   to.lower.case -
#     Optional Argument.\cr
#     A Boolean value that specifies whether the function converts all 
#     letters in the input text to lowercase. \cr
#     Default Value: TRUE\cr
#     Types: logical
#   
#   punctuation -
#     Optional Argument.\cr
#     A string that specifies the punctuation characters for the function 
#     to remove before evaluating the input text. The default characters to 
#     remove are: `~#^&*()-\cr
#     Default Value: "`~#^&*()-"\cr
#     Types: character
#   
#   reset -
#     Optional Argument.\cr
#     A string that specifies the character or string that ends a sentence. 
#     The default sentence-ending characters are: .,?! At the end of a 
#     sentence, the function discards any partial n-grams and searches for 
#     the next n-gram at the beginning of the next sentence. An n-gram 
#     cannot span two sentences.\cr
#     Default Value: ".,?!"\cr
#     Types: character
#   
#   total.gram.count -
#     Optional Argument.\cr
#     A Boolean value that specifies whether the function returns the total 
#     number of ngrams in the document (that is, in the row). If you 
#     specify "true", then the name of the returned column is specified by 
#     the total.count.column argument. Note: The total number of n-grams is 
#     not necessarily the number of unique ngrams.\cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   total.count.column -
#     Optional Argument.\cr
#     The name of the column to return if the value of the total.gram.count 
#     argument is "true". \cr
#     Default Value: "totalcnt"\cr
#     Types: character
#   
#   accumulate -
#     Optional Argument.\cr
#     The names of the columns to return for each n-gram. These columns 
#     cannot have the same names as those specified by the arguments ngram, 
#     num.grams.column, and total.count.column. By default, the function 
#     returns all input columns for each n-gram.\cr
#     Types: character OR vector of Strings (character)
#   
#   n.gram.column -
#     Optional Argument.\cr
#     The name of the column that is to contain the generated n-grams. \cr
#     Default Value: "ngram"\cr
#     Types: character
#   
#   num.grams.column -
#     Optional Argument.\cr
#     The name of the column that is to contain the length of n-gram (in 
#     words). \cr
#     Default Value: "n"\cr
#     Types: character
#   
#   frequency.column -
#     Optional Argument.\cr
#      The name of the column that is to contain the count of each unique 
#     n-gram (that is, the number of times that each unique n-gram appears 
#     in the document). \cr
#     Default Value: "frequency"\cr
#     Types: character
# 
# Returns:
#   Function returns an object of class "td_ngramsplitter_sqle" which is a named 
#   list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_ngramsplitter_sqle <- function(
  data = NULL,
  text.column = NULL,
  delimiter = " ",
  grams = NULL,
  overlapping = TRUE,
  to.lower.case = TRUE,
  punctuation = "`~#^&*()-",
  reset = ".,?!",
  total.gram.count = FALSE,
  total.count.column = "totalcnt",
  accumulate = NULL,
  n.gram.column = "ngram",
  num.grams.column = "n",
  frequency.column = "frequency",
  data.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("text.column", text.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("delimiter", delimiter, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("grams", grams, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("overlapping", overlapping, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("to.lower.case", to.lower.case, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("punctuation", punctuation, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("reset", reset, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("total.gram.count", total.gram.count, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("total.count.column", total.count.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("n.gram.column", n.gram.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("num.grams.column", num.grams.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("frequency.column", frequency.column, TRUE, c("character",NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(text.column)
  .validateTblHasArgumentColumns(text.column, "text.column", data, "data")
  
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", data, "data")
  
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  # Validate that value passed to the output column argument is not empty.
  .validateInputColumnsNotEmpty(n.gram.column)
  .validateInputColumnsNotEmpty(num.grams.column)
  .validateInputColumnsNotEmpty(frequency.column)
  .validateInputColumnsNotEmpty(total.count.column)
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TextColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(text.column, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(accumulate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(accumulate, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Grams")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(grams, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  if (!is.null(overlapping) && !missing(overlapping)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OverLapping")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(overlapping, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(to.lower.case) && !missing(to.lower.case)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ConvertToLowerCase")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(to.lower.case, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(delimiter) && !missing(delimiter)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Delimiter")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(delimiter, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(punctuation) && !missing(punctuation)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Punctuation")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(punctuation, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(reset) && !missing(reset)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Reset")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(reset, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(total.gram.count) && !missing(total.gram.count)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputTotalGramCount")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(total.gram.count, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(n.gram.column) && !missing(n.gram.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NGramColName")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(n.gram.column, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(num.grams.column) && !missing(num.grams.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "GramLengthColName")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(num.grams.column, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(frequency.column) && !missing(frequency.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "FrequencyColName")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(frequency.column, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(total.count.column) && !missing(total.count.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TotalCountColName")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(total.count.column, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "ANY")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "ngramsplitter",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_SQL")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("ngramsplitter", engine = .getEngineName("ENGINE_SQL"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_ngramsplitter_sqle", engine = .getEngineName("ENGINE_SQL"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_ngramsplitter <- td_ngramsplitter_sqle
