# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Jeris Alan Jawahar (jeris.jawahar@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.7
# 
# ################################################################## 

# Description:
#   Note:  
#               For information about the authentication arguments, see 
#   the following topics in the Usage Notes section of Chapter 2, 
#   Installing Aster Analytics Functions, of the Teradata Aster  
#   Analytics Foundation User Guide.
#               Database Connections with Authentication Cascading
#               Database Connections with SSL JDBC Connections
# 
# Args:
#   rating.table -
#     Required Argument.\cr
#     The user rating table.\cr
#   
#   userid.column -
#     Optional Argument.\cr
#      The user id column in the rating table. The default is the first 
#     column in the rating table.\cr
#     Types: character
#   
#   itemid.column -
#     Optional Argument.\cr
#     The item id column in the rating table. The default is the second 
#     column in the rating table.\cr
#     Types: character
#   
#   rating.column -
#     Optional Argument.\cr
#     The rating column in the rating table. The default is the third 
#     column in the rating table.\cr
#     Types: character
#   
#   k -
#     Optional Argument.\cr
#     The number of nearest neighbors used in the calculation of the 
#     interpolation weights. Default is 20.\cr
#     Default Value: 20\cr
#     Types: integer
#   
#   learning.rate -
#     Optional Argument.\cr
#     Initial learning rate. The learning rate adjusts automatically during 
#     training based on changes in the rmse. Default is 0.001.\cr
#     Default Value: 0.001\cr
#     Types: numeric
#   
#   max.iternum -
#     Optional Argument.\cr
#     Maximum number of iterations. Default is 10\cr
#     Default Value: 10\cr
#     Types: integer
#   
#   threshold -
#     Optional Argument.\cr
#     The function stops when the rmse drops below this level. Default is 
#     0.0002.\cr
#     Default Value: 2.0E-4\cr
#     Types: numeric
#   
#    item.similarity -
#     Optional Argument.\cr
#     The method used to calculate item similarity. The default is the 
#     Pearson correlation coefficient. Options include: Pearson (Pearson 
#     correlation coefficient), adjustedcosine (adjusted cosine 
#     similarity)\cr
#     Default Value: "Pearson"\cr
#     Permitted Values: AdjustedCosine, Pearson\cr
#     Types: character
#   
#   rating.table.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "rating.table". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_knn_recommender_mle" which is 
#   a named list containing objects of class "tbl_teradata".\cr
#   Named list members can be referenced directly with the "$" operator 
#   using the following names:\enumerate{\item weight.model.table\item 
#   bias.model.table\item nearest.items\item output}
# 
# 
#' @export
td_knn_recommender_mle <- function(
  rating.table = NULL,
  userid.column = NULL,
  itemid.column = NULL,
  rating.column = NULL,
  k = 20,
  learning.rate = 0.001,
  max.iternum = 10,
  threshold = 2.0E-4,
  item.similarity = "Pearson",
  rating.table.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("rating.table", rating.table, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("userid.column", userid.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("itemid.column", itemid.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("rating.column", rating.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("k", k, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("learning.rate", learning.rate, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("max.iternum", max.iternum, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("threshold", threshold, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("item.similarity",  item.similarity, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("rating.table.sequence.column", rating.table.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(rating.table, NULL)
  
  # Check for permitted values
   item.similarityPermittedValues <- list("ADJUSTEDCOSINE", "PEARSON")
  .validatePermittedValues( item.similarity,  item.similarityPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(userid.column)
  .validateTblHasArgumentColumns(userid.column, "userid.column", rating.table, "rating.table")
  
  .validateInputColumnsNotEmpty(itemid.column)
  .validateTblHasArgumentColumns(itemid.column, "itemid.column", rating.table, "rating.table")
  
  .validateInputColumnsNotEmpty(rating.column)
  .validateTblHasArgumentColumns(rating.column, "rating.column", rating.table, "rating.table")
  
  .validateInputColumnsNotEmpty(rating.table.sequence.column)
  .validateTblHasArgumentColumns(rating.table.sequence.column, "rating.table.sequence.column", rating.table, "rating.table")
  
  # Generate temp table names for output table parameters if any.
  weight.model.tableTempTableName <- .teradataGenerateTempTableName("td_knn_recommender0_", use.default.database = TRUE, gc.onQuit = TRUE)
  bias.model.tableTempTableName <- .teradataGenerateTempTableName("td_knn_recommender1_", use.default.database = TRUE, gc.onQuit = TRUE)
  nearest.itemsTempTableName <- .teradataGenerateTempTableName("td_knn_recommender2_", use.default.database = TRUE, gc.onQuit = TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_knn_recommender_mle.internal)
  Call[["weight.model.tableTempTableName"]] <- weight.model.tableTempTableName
  Call[["bias.model.tableTempTableName"]] <- bias.model.tableTempTableName
  Call[["nearest.itemsTempTableName"]] <- nearest.itemsTempTableName
  
  retval <- NULL
  tryCatch({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_knn_recommender_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units = "secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_knn_recommender_mle.internal <- function(
  rating.table = NULL,
  userid.column = NULL,
  itemid.column = NULL,
  rating.column = NULL,
  k = 20,
  learning.rate = 0.001,
  max.iternum = 10,
  threshold = 2.0E-4,
  item.similarity = "Pearson",
  rating.table.sequence.column = NULL,
  weight.model.tableTempTableName = NULL,
  bias.model.tableTempTableName = NULL,
  nearest.itemsTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("WeightModelTable", "BiasModelTable", "NearestItemsTable")
  funcOutputArgs <- c(weight.model.tableTempTableName, bias.model.tableTempTableName, nearest.itemsTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  if (!is.null(userid.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "UserIdColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(userid.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(itemid.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ItemIdColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(itemid.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(rating.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "RatingColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(rating.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(learning.rate) && !missing(learning.rate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "LearningRate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(learning.rate, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(max.iternum) && !missing(max.iternum)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxIterNum")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(max.iternum, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(k) && !missing(k)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "K")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(k, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(threshold) && !missing(threshold)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StopThreshold")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(threshold, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null( item.similarity) && !missing( item.similarity)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SimilarityMethod")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector( item.similarity, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(rating.table.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("RatingTable:", .teradataCollapseArgVector(rating.table.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process rating.table
  tableRef <- .teradataOnClauseFromDataFrame(rating.table)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "RatingTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "KNNRecommender",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("KNNRecommender", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database = TRUE, gc.onQuit = TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(rating.table)
  
  # Return output table data frames.
  result <- list()
  result[["weight.model.table"]] <- .createDataSetObject(.extractTableName(weight.model.tableTempTableName), sourceType = "table", .extractDatabaseName(weight.model.tableTempTableName), is_dplyr_input)
  result[["bias.model.table"]] <- .createDataSetObject(.extractTableName(bias.model.tableTempTableName), sourceType = "table", .extractDatabaseName(bias.model.tableTempTableName), is_dplyr_input)
  result[["nearest.items"]] <- .createDataSetObject(.extractTableName(nearest.itemsTempTableName), sourceType = "table", .extractDatabaseName(nearest.itemsTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_knn_recommender <- td_knn_recommender_mle
