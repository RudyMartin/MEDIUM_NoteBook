# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owners: Trupti Purohit (trupti.purohit@teradata.com), 
#                   Adithya Avvaru (adithya.avvaru@teradata.com)
# 
# Version: 1.2
# Function Version: 1.10
# 
# ################################################################## 

# Description:
#   The LDA function uses training data and parameters to build a topic 
#   model, using an unsupervised method to estimate the correlation 
#   between the topics and words according to the topic number and other 
#   parameters. Optionally, the function creates the topic distributions 
#   for each training document.
# 
# Args:
#   data -
#     Required Argument.
#     Specifies the name of the tbl_teradata or view that contains the new 
#     documents.
#   
#   topic.num -
#     Required Argument.
#     Specifies the number of topics for all the documents in the input 
#     table, an integer value in the range [2, 1000].
#     Types: integer
#   
#   docid.column -
#     Required Argument.
#     Specifies the name of the input column that contains the document 
#     identifiers. 
#     Types: character
#   
#   word.column -
#     Required Argument.
#     Specifies the name of the input column that contains the words (one 
#     word in each row).
#     Types: character
#   
#   alpha -
#     Optional Argument.
#     Specifies a hyperparameter of the model, the prior smooth parameter 
#     for the topic distribution over documents.As alpha decreases, fewer 
#     topics are associated with each document. 
#     Default Value: 0.1
#     Types: numeric
#   
#   eta -
#     Optional Argument.
#     Specifies a hyperparameter of the model, the prior smooth parameter 
#     for the word distribution over topics.As eta decreases, fewer words 
#     are associated with each topic.
#     Default Value: 0.1
#     Types: numeric
#   
#   count.column -
#     Optional Argument.
#      Specifies the name of the input column that contains the count of 
#     the corresponding word in the row, a NUMERIC value.
#     Types: character
#   
#   maxiter -
#     Optional Argument.
#     Specifies the maximum number of iterations to perform if the model 
#     does not converge, a positive integer value. 
#     Default Value: 50
#     Types: integer
#   
#   convergence.delta -
#     Optional Argument.
#     Specifies the convergence delta of log perplexity, a NUMERIC value in 
#     the range [0.0,1.0]. The default value is 1e-4.
#     Default Value: 1.0E-4
#     Types: numeric
#   
#   seed -
#     Optional Argument.
#     Specifies the seed with which to initialize the model, a numeric 
#     value. Given the same seed, cluster configuration, and input table, 
#     the function generates the same model. By default, the function 
#     initializes the model randomly.
#     Types: numeric
#   
#   out.topicnum -
#     Optional Argument.
#     Specifies the number of top-weighted topics and their weights to 
#     include in the output tbl_teradata for each training document. The 
#     value topics must be a positive integer. The default value, "all", 
#     specifies all topics and their weights.
#     Default Value: "all"
#     Types: character
#   
#   out.topicwordnum -
#     Optional Argument.
#     Specifies the number of top topic words and their topic identifiers 
#     to include in the output tbl_teradata for each training document. The 
#     value topic_words must be a positive integer. The value "all" 
#     specifies all topic words and their topic identifiers. The default 
#     value, "none", specifies no topic words or topic identifiers.
#     Default Value: "none"
#     Types: character
#   
#   initmodeltaskcount -
#     Optional Argument.
#     Specifies the number of vWorkers that are adopted to generate 
#     initalized model.
#     Types: integer
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_lda_mle" which is a named 
#   list containing Teradata tbl objects.
#   Named list members can be referenced directly with the "$" operator 
#   using following names:\enumerate{\item model.table\item 
#   doc.distribution.data\item output}
# 
# 
#' @export
td_lda_mle <- function(
  data = NULL,
  topic.num = NULL,
  docid.column = NULL,
  word.column = NULL,
  alpha = 0.1,
  eta = 0.1,
  count.column = NULL,
  maxiter = 50,
  convergence.delta = 1.0E-4,
  seed = NULL,
  out.topicnum = "all",
  out.topicwordnum = "none",
  initmodeltaskcount = NULL,
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("topic.num", topic.num, FALSE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("docid.column", docid.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("word.column", word.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("alpha", alpha, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("eta", eta, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("count.column", count.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("maxiter", maxiter, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("convergence.delta", convergence.delta, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seed", seed, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("out.topicnum", out.topicnum, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("out.topicwordnum", out.topicwordnum, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("initmodeltaskcount", initmodeltaskcount, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(docid.column)
  .validateTblHasArgumentColumns(docid.column, "docid.column", data, "data")
  
  .validateInputColumnsNotEmpty(word.column)
  .validateTblHasArgumentColumns(word.column, "word.column", data, "data")
  
  .validateInputColumnsNotEmpty(count.column)
  .validateTblHasArgumentColumns(count.column, "count.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  # Generate temp table names for output table parameters if any.
  model.tableTempTableName <- .teradataGenerateTempTableName("td_lda_mle0_", use.default.database=TRUE, gc.onQuit=TRUE)
  doc.distribution.dataTempTableName <- .teradataGenerateTempTableName("td_lda_mle1_", use.default.database=TRUE, gc.onQuit=TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_lda_mle.internal)
  Call[["model.tableTempTableName"]] <- model.tableTempTableName
  Call[["doc.distribution.dataTempTableName"]] <- doc.distribution.dataTempTableName
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_lda_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(endTime - startTime)
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_lda_mle.internal <- function(
  data = NULL,
  topic.num = NULL,
  docid.column = NULL,
  word.column = NULL,
  alpha = 0.1,
  eta = 0.1,
  count.column = NULL,
  maxiter = 50,
  convergence.delta = 1.0E-4,
  seed = NULL,
  out.topicnum = "all",
  out.topicwordnum = "none",
  initmodeltaskcount = NULL,
  data.sequence.column = NULL,
  model.tableTempTableName = NULL,
  doc.distribution.dataTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("ModelTable", "OutputTable")
  funcOutputArgs <- c(model.tableTempTableName, doc.distribution.dataTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "DocIDColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(docid.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "WordColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(word.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  if (!is.null(count.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CountColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(count.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TopicNum")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(topic.num, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  
  if (!is.null(alpha) && !missing(alpha)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Alpha")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(alpha, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(eta) && !missing(eta)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Eta")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(eta, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(maxiter) && !missing(maxiter)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxIterNum")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(maxiter, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(convergence.delta) && !missing(convergence.delta)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ConvergenceDelta")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(convergence.delta, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(seed)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Seed")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(seed, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "LONG")
  }
  
  if (!is.null(initmodeltaskcount)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "InitModelTaskCount")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(initmodeltaskcount, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(out.topicnum) && !missing(out.topicnum)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputTopicNum")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(out.topicnum, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(out.topicwordnum) && !missing(out.topicwordnum)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputTopicWordNum")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(out.topicwordnum, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "LDATrainer",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("LDATrainer", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["model.table"]] <- .createDataSetObject(.extractTableName(model.tableTempTableName), sourceType = "table", .extractDatabaseName(model.tableTempTableName), is_dplyr_input)
  result[["doc.distribution.data"]] <- .createDataSetObject(.extractTableName(doc.distribution.dataTempTableName), sourceType = "table", .extractDatabaseName(doc.distribution.dataTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_lda <- td_lda_mle
