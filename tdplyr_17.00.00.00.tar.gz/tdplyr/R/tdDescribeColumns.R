################################################################################
#
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: adithya.avvaru@teradata.com
# Secondary Owner:
#
# This file has:
#   1.  The help column to data types mapping from Driver 
#       (when `help column "table_name".*;` is used).
#   2.  The functions needed to get column information.
#   3.  The functions to create and drop view.
#
################################################################################


# Mapping of 'Type' column fom 'help column table_name.*' to R types.
td_help_column_types_mapping <- list(
  "I"  = c("int", "integer"),
  "I1" = "byteint",
  "I2" = "smallint",
  "I8" = "bigint",
  "CF" = "char",
  "D"  = c("decimal", "numeric"),
  "F"  = c("float", "real", "double precision"),
  "N"  = "number",
  "TS" = "timestamp",
  "SZ" = "timestamp",
  "AT" = "time",
  "TZ" = "time",
  "YR" = "interval_year",
  "YM" = "interval_year_to_month",
  "DA" = "date",
  "MO" = "interval_month",
  "DY" = "interval_day",
  "DH" = "interval_day_to_hour",
  "DM" = "interval_day_to_minute",
  "DS" = "interval_day_to_second",
  "HR" = "interval_hour",
  "HM" = "interval_hour_to_minute",
  "HS" = "interval_hour_to_second",
  "MI" = "interval_minute",
  "MS" = "interval_minute_to_second",
  "SC" = "interval_second",
  "PT" = "period_time",
  "PD" = "period_date",
  "PS" = "period_timestamp",
  "PZ" = "period_time_with_time_zone",
  "PM" = "period_timestamp_with_time_zone",
  "CV" = "varchar",
  "CO" = "clob",
  "BO" = "blob",
  "BF" = "byte",
  "BV" = "varbyte",
  "JN" = "json",
  "XM" = "xml",
  "A1" = "array",
  "DT" = "dataset"
)

#
# Function to get name for the unknown data type.
# This also prints, unknown data type if needed.
#
.get_unknown_type <- function(x) {
  unknownType <- "unknown"
  .ta.warning("Unknown type: %s", x)
  return(unknownType)
}

#
# Function to retrieve the column data types and column names.
# Params:
#   con           : A connection object.
#   name          : A Table/View name for which the column types are to be retrieved.
#   return.vector : TRUE to return datatypes with aliases.
#
# Returns:
#   A list containing data types and column names.
#
#'@importFrom DBI dbSendQuery
#'@importFrom DBI dbColumnInfo
#'@importFrom DBI dbClearResult
#' @importFrom dplyr sql
.ta.describe.columns <- function(con, name, return.vector = FALSE) {
  # This only does a prepare query.
  # If any  other prepare is pending then this will throw a warning
  tryCatch({
    query <- sql(paste0("help column ", name, ".*;"))
    help_opt <- DBI::dbGetQuery(conn = con, query)
  }, error = function(msg) {
    # do not show function call here as it shows tryCatch function name
    .ta.stop("TDR_E1014", query, msg, showFunctionCall = FALSE)
  })
  
  # The 'help_out' is a R data.frame which has the columns as shown below:
  # > colnames(help_opt)
  # [1] "Column Name"                    "Type"                           "Nullable"                      
  # [4] "Format"                         "Max Length"                     "Decimal Total Digits"          
  # [7] "Decimal Fractional Digits"      "Range Low"                      "Range High"                    
  # [10] "UpperCase"                      "Table/View?"                    "Indexed?"                      
  # [13] "Unique?"                        "Primary?"                       "Title"                         
  # [16] "Column Constraint"              "Char Type"                      "IdCol Type"                    
  # [19] "UDT Name"                       "Temporal Column"                "Current ValidTime Unique"      
  # [22] "Sequenced ValidTime Unique"     "NonSequenced ValidTime Unique"  "Current TransactionTime Unique"
  # [25] "Partitioning Column"            "Column Partition Number"        "Column Partition Format"       
  # [28] "Column Partition AC"            "Security Constraint"            "Derived_UDT"                   
  # [31] "Derived_UDTFieldID"             "Column Dictionary Name"         "Column SQL Name"               
  # [34] "Column Name UEscape"            "Dictionary Title"               "SQL Title"                     
  # [37] "Title UEscape "                 "UDT Database Dictionary Name"   "UDT Database SQL Name"         
  # [40] "UDT Database Name UEscape"      "UDT Dictionary Name"            "UDT SQL Name"                  
  # [43] "UDT Name UEscape"               "Without Overlaps Unique"        "Storage Format"                
  # [46] "SchemaName"                     "Inline Length"                  "Transform Length"              
  # [49] "Time Series Column Type"        "Auto Column"    
  
  # > help_opt[["Column Dictionary Name"]] # This will have column names.
  # [1] "rowids"      "orderid"     "orderdate"   "priority"    "quantity"    "sales"       "discount"
  # [8] "shipmode"    "custname"    "province"    "region"      "custsegment" "prodcat"

  column_names <- help_opt[["Column Dictionary Name"]]

  # help_opt[["Type"]] contain the types of each column in the table name passed in argument 'name'.
  # > help_opt[["Type"]]
  # [1] "I   " "I   " "CV  " "CV  " "I   " "F   " "F   " "CV  " "CV  " "CV  " "CV  " "CV  " "CV  "
  
  # trimws will trim the spaces of each value in the data.frame.
  # Based on the data type value of each column in help_opt[["Type"]], we are retrieving the R data type
  # from the mapping defined in 'td_help_column_types_mapping' above.
  
  types <- sapply(trimws(help_opt[["Type"]]), function(x) {
    ifelse(is.null(td_help_column_types_mapping[[x]]), .get_unknown_type(x), 
           ifelse(isTRUE(return.vector), td_help_column_types_mapping[x], td_help_column_types_mapping[[x]][1]) )})

  ###
  # Adding "Time Series Column Type" in ta.describe.columns for FUTURE purpose.
  ###
  
  # > help_opt[["Time Series Column Type"]]
  # Contain time series column type for columns
  # For TD_TIMECODE column, the value is TC
  # For TD_TIMEBUCKET column, the value is TB (hidden column)
  # For TD_SEQNO column, the value is TN
  # For other columns, the value is NA

  time_series_types <- trimws(help_opt[["Time Series Column Type"]])

  # Number of columns
  num_cols <- nrow(help_opt)

  # PTI tables have 1st column as TD_TIMEBUCKET, which is a hidden column (not to be shown to
  # the user). Removing this from the list of column names and types.
  if ("TD_TIMEBUCKET" %in% column_names) {
    column_names <- column_names[-1]
    types <- types[-1]
    time_series_types <- time_series_types[-1]
    num_cols <- nrow(help_opt) - 1
  }
  
  ret <- list(names = column_names, types = types, colnum = num_cols, time_series_types = time_series_types)
  return(ret)
}

# A wrapper function to invoke the .ta.describe.columns function
# Params:
#   con : A connection object
#   from: A character vector / sql query / ident / identq object representing
#       the remote database object / query for which to retrieve column info
#' @importFrom dbplyr tbl_sql is.sql
#' @importFrom dplyr sql
#' @importFrom dplyr sql_select
#' @importFrom dplyr sql_subquery
#' @importFrom dbplyr ident
.ta.describe.columns.wrapper <- function(con, from, return.vector = FALSE) {
  only_table <- FALSE # flag to determine if there is table name but not schema name
                      # in argument 'from'
  is_view_created <- FALSE
  if (is.sql(from)) {
    view_name <- .teradataGenerateTempTableName(prefix = "view_", 
                                                use.default.database = TRUE, gc.onQuit = FALSE)
    from <- .create.view(con = con, query = from, view_name = view_name)
    from <- ident(from)
    is_view_created <- TRUE
  }
  if (!inherits(from, "ident")) {
    # tbl can be from in_schema or user could have wrapped it as a ident (unlikely)
    # Only If tbl is purely a char vector then we wrap it in ident
    from <- ident(from)
    only_table <- TRUE
  }
  # Just print the query for debugging purposes
  if (isTRUE(getOption("td.debug.enable")))
    .ta.print("Describe Columns given query/table/view: %s",from, showStackTrace = FALSE)
  
  if (isTRUE(only_table)) { 
    # tbl containing char vector, ie table name
    from <- .teradataQuoteArg(from, quote = "\"", callFromWrapper = FALSE)
  } else {
    db_name <- .extractDatabaseNameQuoted(from)
    tab_name <- .extractTableNameQuoted(from)
    if (!is.null(db_name)) {
      from <- paste0(.teradataQuoteArg(db_name, quote = "\"", callFromWrapper = FALSE), ".",
                     .teradataQuoteArg(tab_name, quote = "\"", callFromWrapper = FALSE))
    } else {
      from <- .teradataQuoteArg(tab_name, quote = "\"", callFromWrapper = FALSE)
    }
  }

  colInfo <- tryCatch(.ta.describe.columns(con, from, return.vector),
                      error = function(e) { return(e) })
  
  # Dropping view, after getting column information from SQL query.
  if (isTRUE(is_view_created)) {
    .drop.view(con = con, view_name = from)
  }
  
  if (inherits(colInfo, "error")) {
    
    # in case of error stop execution and prepare error message
    msg <- paste0(colInfo, 
                  "Exiting since failed to create tbl.",
                  collapse = "\n")
    .ta.stop(msg)
  }
  return(colInfo)
  
}

# A function to create view given the query
# Params:
#   con       : Required Argument. A connection object.
#   query     : Required Argument. A query for which view is to be created.
#   view_name : Required Argument. Name of the view that is to be created.
#
# Returns:
#   Name of the view that is created, if view creation is successful.
#   Otherwise, raise an error.
#' @importFrom DBI dbExecute
.create.view <- function(con, query = NULL, view_name = NULL) {
  # Validations for the arguments - query and view_name
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("con", con, FALSE, c("Teradata", "TeradataConnection", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("query", query, FALSE, c("sql","character")))
  argInfoMatrix <- rbind(argInfoMatrix, list("view_name", view_name, FALSE, c("character",NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  .validateMissingRequiredArguments(argInfoMatrix)
  .validateArgumentTypes(argInfoMatrix)
  .validateInputColumnsNotEmpty(view_name)
  .validateInputColumnsNotEmpty(query) 
  
  # Create view statement.  
  create_view <- paste0("CREATE VIEW ", view_name ," as ", query, " ; ")
  
  # Executing the view creation statement.
  tryCatch({
    dbExecute(conn = con, create_view)
  }, error = function(msg) {
    .ta.stop("TDR_E3106", view_name, msg, showFunctionCall = FALSE)
  })
  return(view_name)
}

# A function to drop view given view name
# Params:
#   con       : Required Argument. A connection object.
#   view_name : Required Argument. Name of the view that is to be dropped.
#
# Returns:
#   None
#' @importFrom DBI dbExecute
.drop.view <- function(con, view_name = NULL) {
  # Validations for the argument view_name
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("con", con, FALSE, c("Teradata",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("view_name", view_name, FALSE, c("character",NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  .validateMissingRequiredArguments(argInfoMatrix)
  .validateArgumentTypes(argInfoMatrix)
  .validateInputColumnsNotEmpty(view_name)
  
  tryCatch({
    DBI::dbExecute(con, paste0("DROP VIEW ", view_name, "; "))
  }, error = function(emsg) {
    .ta.stop("TDR_E3107", view_name, emsg, showFunctionCall = FALSE)
  })
}