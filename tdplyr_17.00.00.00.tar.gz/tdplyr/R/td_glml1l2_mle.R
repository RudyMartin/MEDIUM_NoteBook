# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Rohit Khurd (rohit.khurd@teradata.com)
# Secondary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# 
# Version: 1.2
# Function Version: 1.19
# 
# ################################################################## 

# Description:
#   The GLML1L2 function differs from the GLM function in these ways:
#      1. GLML1L2 supports the regularization models Ridge, LASSO, and
#   Elastic Net.
#      2. GLML1L2 outputs a model tbl_teradata and, optionally, a
#   factor tbl_teradata (GLM outputs only a model).
# 
# Args:
#   formula -
#     Required Argument.
#     An object of class "formula". Specifies the model to be fitted. Only 
#     basic formula of the (col1 ~ col2 + col3 +...) form are supported and 
#     all variables must be from the same tbl_teradata object. The 
#     response should be a column of type numeric or logical.
#   
#   data -
#     Required Argument.
#     Specifies the name of the tbl_teradata that contains the input data.
#   
#   alpha -
#     Optional Argument.
#     Specifies whether to use Lasso, Ridge or Elastic Net. If the value is
#     0, Ridge is used. If the value is 1, Lasso is used. For any value
#     between 0 and 1, Elastic Net is applied.
#     Default Value: 0.0
#     Types: numeric
#   
#   lambda -
#     Optional Argument.
#     Specifies the parameter that controls the magnitude of the regularization
#     term. The value of lambda must be in the range [0.0, 100.0].
#     A value of zero disables regularization.
#     Default Value: 0
#     Types: numeric
#   
#   max.iter.num -
#     Optional Argument.
#     Specifies the maximum number of iterations over the data.
#     The parameter max.iter.num must be a positive numeric value in the
#     range [1, 100000].
#     Default Value: 10000
#     Types: integer
#   
#   stop.threshold -
#     Optional Argument.
#     Specifies the convergence threshold.
#     Default Value: 1.0E-7
#     Types: numeric
#   
#   family -
#     Optional Argument.
#     Specifies the distribution exponential family.
#     Default Value: "Gaussian"
#     Permitted Values: Binomial, Gaussian
#     Types: character
#   
#   randomization -
#     Optional Argument.
#     Specifies whether to randomize the input tbl_teradata data.
#     Default Value: FALSE
#     Types: logical
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_glml1l2_mle" which is a named 
#   list containing Teradata tbl objects.
#   Named list members can be referenced directly with the "$" operator 
#   using following names:\enumerate{\item factor.table\item output}
# 
#   Note:
#       1. When argument randomization is TRUE or if any categorical columns
#          are provided in formula argument, then and only then the output
#          tbl_teradata object factor.data is created.
#       2. factor.data can be used as the input (data) for future GLML1L2
#          function calls, thereby saving the function from repeating the
#          categorical-to-numerical conversion or randomization.
# 
#' @export
td_glml1l2_mle <- function(
  formula = NULL,
  data = NULL,
  alpha = 0.0,
  lambda = 0,
  max.iter.num = 10000,
  stop.threshold = 1.0E-7,
  family = "Gaussian",
  randomization = FALSE,
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("formula", formula, FALSE, "formula"))
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("alpha", alpha, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("lambda", lambda, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("max.iter.num", max.iter.num, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("stop.threshold", stop.threshold, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("family", family, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("randomization", randomization, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check for permitted values
  familyPermittedValues <- list("BINOMIAL", "GAUSSIAN")
  .validatePermittedValues(family, familyPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  # Validate max.iter.num
  if (!.validate_integer_bounds(max.iter.num, lbound = 1, ubound = 100000)) {
    .ta.stop("TDR_E1008", "max.iter.num", paste0(max.iter.num, ". max.iter.num must be a positive numeric value in the range [1, 100000]."))
  }
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_glml1l2_mle.internal)
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 0) {
    attr(retval, "class") <- .getSQLMRClass("td_glml1l2_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_glml1l2_mle.internal <- function(
  formula = NULL,
  data = NULL,
  alpha = 0.0,
  lambda = 0,
  max.iter.num = 10000,
  stop.threshold = 1.0E-7,
  family = "Gaussian",
  randomization = FALSE,
  data.sequence.column = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  if (!is.null(alpha) && !missing(alpha)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Alpha")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(alpha, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(lambda) && !missing(lambda)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Lambda")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(lambda, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(max.iter.num) && !missing(max.iter.num)) {
    # Explicitly casting to integer to avoid shortened scientific notation like 1e+05 for 100000
    max.iter.num <- as.integer(max.iter.num)
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxIterNum")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(max.iter.num, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(stop.threshold) && !missing(stop.threshold)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StopThreshold")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(stop.threshold, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(family) && !missing(family)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Family")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(family, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(randomization) && !missing(randomization)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Randomization")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(randomization, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Let's process formula argument
  formula.terms.matrix <- .ta.parse.formula(formula, data)
  # response variable
  response <- formula.terms.matrix[1,1]
  mc.target.column <- response
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ResponseColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(response,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  mc.sql.specific.attributes[["ResponseColumn"]] <- response
  
  # all input columns
  all_inputs <- .ta.getColumnsByType(formula.terms.matrix, data, "all")
  # Exclude the response column (first column) from FeatureColumns
  all_inputs <- all_inputs[-1]
  if (length(all_inputs) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "FeatureColumns")
    allColumnsList <- .teradataCollapseArgVector(.teradataQuoteArg(all_inputs,"\""), "'")
    funcOtherArgs <- c(funcOtherArgs, allColumnsList)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
    mc.sql.specific.attributes[["FeatureColumns"]] <- allColumnsList
  }
  
  # categorical input columns
  categorical_inputs <- .ta.getColumnsByType(formula.terms.matrix, data, "categorical")
  if (length(categorical_inputs) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CategoricalColumns")
    categoricalColumnsList <- .teradataCollapseArgVector(.teradataQuoteArg(categorical_inputs,"\""), "'")
    funcOtherArgs <- c(funcOtherArgs, categoricalColumnsList)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
    mc.sql.specific.attributes[["CategoricalColumns"]] <- categoricalColumnsList
  }
  
  # Output table the arguments vector for the mapReduceObject.
  # factor.data is output only when there are any categorical columns used or
  # if randomization is TRUE.
  outputFactorTableFlag = FALSE
  funcOutputArgs <- NA
  if ((randomization == TRUE) || (length(categorical_inputs) > 0)) {
    # Generate temp table names for output table parameters if any.
    factor.dataTempTableName <- .teradataGenerateTempTableName("td_glml1l2_mle0_", use.default.database=TRUE, gc.onQuit=TRUE)
    
    funcOutputArgsSqlNames <- c("FactorTable")
    funcOutputArgs <- c(factor.dataTempTableName)
    names(funcOutputArgs) <- funcOutputArgsSqlNames
    outputFactorTableFlag = TRUE
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "GlmL1L2",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("GlmL1L2", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (outputFactorTableFlag == TRUE) {
    # factor.data is output only on the when Categorical columns are used or if randomization is TRUE.
    result[["factor.data"]] <- .createDataSetObject(.extractTableName(factor.dataTempTableName), sourceType = "table", .extractDatabaseName(factor.dataTempTableName), is_dplyr_input)
  }
  # Else factor.data wont be generated and hence needs no output object.
  
  if (class(result) == "list" && length(result) > 0) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
