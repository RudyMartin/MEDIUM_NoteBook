# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.14
# 
# ################################################################## 

# Description:
#   The Text Parser function tokenizes an input stream of words, 
#   optionally
#   				stems them (reduces them to their root forms), and then
#   			outputs them. The function can either output all words in one row 
#   or output each word in
#   			its own row with (optionally) the number of times that the word 
#   appears.
# 
# Args:
#   data -
#     Required Argument.\cr
#     The relation that contains the text to be tokenized.\cr
#   
#   data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   text.column -
#     Required Argument.\cr
#     Specifies the name of the input column whose contents are to be 
#     tokenized.\cr
#     Types: character
#   
#   to.lower.case -
#     Optional Argument.\cr
#     Specifies whether to convert input text to lowercase. Note: The 
#     function ignores this argument if the Stemming argument has the value 
#     "true".\cr
#     Default Value: TRUE\cr
#     Types: logical
#   
#   stemming -
#     Optional Argument.\cr
#     Specifies whether to stem the tokens that is, whether to apply the 
#     Porter2 stemming algorithm to each token to reduce it to its root 
#     form. Before stemming, the function converts the input text to 
#     lowercase and applies the remove.stop.words argument. \cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   delimiter -
#     Optional Argument.\cr
#     Specifies a regular expression that represents the word delimiter. 
#     .\cr
#     Default Value: "[ 	
#     ]+"\cr
#     Types: character
#   
#   total.words.num -
#     Optional Argument.\cr
#     Specifies whether to output a column that contains the total number 
#     of words in the input document. \cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   punctuation -
#     Optional Argument.\cr
#     Specifies a regular expression that represents the punctuation 
#     characters to remove from the input text. With stemming ("true"), the 
#     recommended value is "[\\\[.,?!:;~()\\\]]+". \cr
#     Default Value: "[.,!?]"\cr
#     Types: character
#   
#   accumulate -
#     Optional Argument.\cr
#     Specifies the names of the input columns to copy to the output table. 
#     By default, the function copies all input columns to the output 
#     table. Note: No accumulate_column can be the same as token_column or 
#     total_column.\cr
#     Types: character OR vector of Strings (character)
#   
#   token.column -
#     Optional Argument.\cr
#     Specifies the name of the output column that contains the tokens. \cr
#     Default Value: "token"\cr
#     Types: character
#   
#   frequency.column -
#     Optional Argument.\cr
#     Specifies the name of the output column that contains the frequency 
#     of each token. \cr
#     Default Value: "frequency"\cr
#     Types: character
#   
#   total.column -
#     Optional Argument.\cr
#     Specifies the name of the output column that contains the total 
#     number of words in the input document. \cr
#     Default Value: "total_count"\cr
#     Types: character
#   
#   remove.stop.words -
#     Optional Argument.\cr
#      Specifies whether to remove stop words from the input text before 
#     parsing. \cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   position.column -
#     Optional Argument.\cr
#     Specifies the name of the output column that contains the position of 
#     a word within a document. \cr
#     Default Value: "location"\cr
#     Types: character
#   
#   list.positions -
#     Optional Argument.\cr
#     Specifies whether to output the position of a word in list form. 
#     which causes the function to output a row for each occurrence of the 
#     word. Note: The function ignores this argument if the output.by.word 
#     argument has the value "false".\cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   output.by.word -
#     Optional Argument.\cr
#     Specifies whether to output each token of each input document in its 
#     own row in the output table. If you specify "false", then the 
#     function outputs each tokenized input document in one row of the 
#     output table.\cr
#     Default Value: TRUE\cr
#     Types: logical
#   
#   stemming.exceptions -
#     Optional Argument.\cr
#     Specifies the location of the file that contains the stemming 
#     exceptions. A stemming exception is a word followed by its stemmed 
#     form. The word and its stemmed form are separated by white space. 
#     Each stemming exception is on its own line in the file. For example: 
#     bias bias news news goods goods lying lie ugly ugli sky sky early 
#     earli The words "lying", "ugly", and "early" are to become "lie", 
#     "ugli", and "earli", respectively. The other words are not to 
#     change.\cr
#     Types: character
#   
#   stop.words -
#     Optional Argument.\cr
#     Specifies the location of the file that contains the stop words 
#     (words to ignore when parsing text). Each stop word is on its own 
#     line in the file. For example: a an the and this with but will\cr
#     Types: character
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_text_parser_mle" which is a 
#   named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_text_parser_mle <- function(
  data = NULL,
  text.column = NULL,
  to.lower.case = TRUE,
  stemming = FALSE,
  delimiter = "[ \\t\\f\\r\\n]+",
  total.words.num = FALSE,
  punctuation = "[.,!?]",
  accumulate = NULL,
  token.column = "token",
  frequency.column = "frequency",
  total.column = "total_count",
  remove.stop.words = FALSE,
  position.column = "location",
  list.positions = FALSE,
  output.by.word = TRUE,
  stemming.exceptions = NULL,
  stop.words = NULL,
  data.sequence.column = NULL,
  data.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("text.column", text.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("to.lower.case", to.lower.case, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("stemming", stemming, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("delimiter", delimiter, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("total.words.num", total.words.num, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("punctuation", punctuation, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("token.column", token.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("frequency.column", frequency.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("total.column", total.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("remove.stop.words", remove.stop.words, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("position.column", position.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("list.positions", list.positions, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.by.word", output.by.word, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("stemming.exceptions", stemming.exceptions, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("stop.words", stop.words, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(text.column)
  .validateTblHasArgumentColumns(text.column, "text.column", data, "data")
  
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  # Validate that value passed to the output column argument is not empty.
  .validateInputColumnsNotEmpty(token.column)
  .validateInputColumnsNotEmpty(frequency.column)
  .validateInputColumnsNotEmpty(total.column)
  .validateInputColumnsNotEmpty(position.column)
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TextColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(text.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(accumulate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(accumulate,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(to.lower.case) && !missing(to.lower.case)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ToLowerCase")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(to.lower.case, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(stemming) && !missing(stemming)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Stemming")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(stemming, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(output.by.word) && !missing(output.by.word)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputByWord")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.by.word, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(stemming.exceptions)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StemmingExceptions")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(stemming.exceptions, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(remove.stop.words) && !missing(remove.stop.words)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "RemoveStopWords")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(remove.stop.words, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(stop.words)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StopWords")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(stop.words, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(delimiter) && !missing(delimiter)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Delimiter")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(delimiter, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(total.words.num) && !missing(total.words.num)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TotalWordsNum")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(total.words.num, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(punctuation) && !missing(punctuation)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Punctuation")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(punctuation, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(list.positions) && !missing(list.positions)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ListPositions")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(list.positions, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(token.column) && !missing(token.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TokenColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(token.column, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(frequency.column) && !missing(frequency.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "FrequencyColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(frequency.column, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(total.column) && !missing(total.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TotalColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(total.column, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(position.column) && !missing(position.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PositionColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(position.column, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "ANY")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "Text_Parser",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("Text_Parser", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_text_parser_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_text_parser <- td_text_parser_mle