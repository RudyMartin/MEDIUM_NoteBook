#
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: arun.kalyanasundaram@teradata.com
# Secondary Owner:
#
# This file implements the set of functions that may depend on the type of OS / platform
# the package is running on. For example: getting client user name, R process ID.
######################################################################################


.ta.getPlatform <- function() {
  # we could potentially cache this in a global variable but
  # the problem is if user changes this for some reason
  # it wont get reflected in the session
  Sys.info()["sysname"]
}

.ta.isPlatformWindows <- function() {
  platform <- .ta.getPlatform()
  any(grepl("windows", platform, ignore.case=TRUE, perl=TRUE))
}

.ta.isPlatformLinux <- function() {
  platform <- .ta.getPlatform()
  any(grepl("linux", platform, ignore.case=TRUE, perl=TRUE))
}

# Simba-9.2 does not expose UID. We will use system user name
# to identify a user objects in database
# Function is used during the creation of temporary objects.
.ta.getUserName <- function() {
    userName <- ""
    #for windows
    if(.ta.isPlatformWindows()) {
        sys.uid <- tolower(Sys.getenv("USERNAME"))
        if(length(sys.uid) > 0 && nchar(sys.uid[1]) > 0)
            userName <- sys.uid
    } else {
        #for all other platforms
        sys.uid <- tolower(Sys.getenv("USER"))
        if(length(sys.uid) > 0 && nchar(sys.uid[1]) > 0)
            userName <- sys.uid
    }
    #making sure that we always store this in upper case
    return (toupper(userName))
}

# This returns the user's full home directory
# Note this may not be the current working directorhy
.ta.getHomeDirectory <- function() {
  #use home directory. If not set, use R_HOME (for windows)
  root <- Sys.getenv("HOME")
  if(nchar(root) == 0)
    root <- Sys.getenv("R_HOME")
  return(root)
}

 # A constant getter function to the default value of PID in case it is not available
 #
 # Returns: the default PID to use when PID is not retrievable or found
 .ta.getDefaultPID <- function() {
    # Use 0 because valid PID can only be greater than 0
   0L
 }
 
 # Function to set the Process ID of the R session in the global variable
 #
 # Returns: NONE
 .ta.initializePID <- function() {
    # store the PID of this R session
    # if there is any error display a warning to user and store generic pid 0
    tryCatch({
      .assign("__pid_", as.integer(Sys.getpid()))
    }, error = function(e) {
      # assign to default pid and warn.
      # User can fix the issue and reload the package again to get the correct pid
      .assign("__pid_", .ta.getDefaultPID())
      .ta.warning("TDR_W1008", e[["message"]])
    })
 }
 
 # Function to get the Process ID of the current session
 #
 # Returns: pid if available, else default as returned by .ta.getDefaultPID()
 .ta.getPID <- function() {
  pid <- .get("__pid_")
  # if null then initialize the PID
  if (is.null(pid)) {
    .ta.initializePID()
    pid <- .get("__pid_")
  }
  return(.get("__pid_"))
 }
 
# Extract the PID suffix from a string as an integer
# Args:
#   x - A character vector usually of the format xyz.abc.<PID>.txt
#
# Returns:
#   An integer value of the suffix. Returns default PID if it is invalid
.ta.extractPIDSuffix <- function(x) {
  indexes <- gregexpr(".", x, fixed = TRUE)
  # this implies the file did not have any dots at all
  # this is unlikely because we only call this with a valid session file
  if (identical(length(indexes), 0L) || identical(length(indexes[[1]]), 1L))
    return(.ta.getDefaultPID())
  indexes <- indexes[[1]]
  indexLen <- length(indexes)
  pidStr <- substr(x,indexes[indexLen - 1] + 1, indexes[indexLen])
  pid <- suppressWarnings(as.integer(pidStr))
  # if the as.integer conversion was not successful then it will be NA
  if (is.na(pid))
    pid <- .ta.getDefaultPID()
  return(pid)
 }
 
# Specifies whether the given process PID is still active
# Args:
#   pid - An integer identifying the process id to be checked
#
# Returns:
#   True if the process identified by pid is active.

.ta.isProcessActive <- function(pid) {
  # invalid PID means inactive
  if (pid <= 0)
    return(FALSE)

  if (.ta.isPlatformWindows())
    return(.ta.isProcessActiveOnWindows(pid))
  else
    return(.ta.isProcessActiveOnPosix(pid))
}

# writing helper function for windows to enable debugging
# in addition the system command has different options on WIndows
.ta.isProcessActiveOnWindows <- function(pid) {
  cmd <- paste0('cmd.exe /c tasklist /FI "PID eq ',pid, '" | findstr ',pid)
  ret <- tryCatch({
            # The system command only prints a warning or message - never throws error
            # just precautionary try catch
            suppressWarnings(
              system(cmd, intern=FALSE, wait = TRUE,
                  ignore.stdout = TRUE, ignore.stderr = TRUE, show.output.on.console = FALSE))
          }, error = function(e) {
            if(getOption("td.debug.enable"))
              print(paste0("Could not execute: ", cmd, " Error: ", e[["message"]]))
            -1L
          })
  identical(ret, 0L)
}

# writing helper function for each platform to enable debugging
.ta.isProcessActiveOnPosix <- function(pid) {
  cmd <- paste0("ps -p ", pid)
  ret <- tryCatch({
            # The system command only prints a warning or message - never throws error
            # just precautionary try catch
            suppressWarnings(
              system(cmd, intern=FALSE, wait = TRUE,
                  ignore.stdout = TRUE, ignore.stderr = TRUE))
          }, error = function(e) {
            if(getOption("td.debug.enable"))
              print(paste0("Could not execute: ", cmd, " Error: ", e[["message"]]))
            -1L
          })
  identical(ret, 0L)
}
