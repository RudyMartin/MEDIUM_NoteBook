# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.13
# 
# ################################################################## 

# Description:
#   The CFilter function is a general-purpose collaborative filter.
# 
# Args:
#   data -
#     Required Argument.\cr
#     Specifies the name of the tbl_teradata that contains the data to 
#     filter.\cr
#   
#   input.columns -
#     Required Argument.\cr
#     Specifies the names of the input tbl_teradata columns that contain 
#     the data to filter.\cr
#     Types: character OR vector of Strings (character)
#   
#   join.columns -
#     Required Argument.\cr
#     Specifies the names of the input tbl_teradata columns to join.\cr
#     Types: character OR vector of Strings (character)
#   
#   add.columns -
#     Optional Argument.\cr
#     Specifies the names of the input columns to copy to the output table. 
#     The function partitions the input data and the output tbl_teradata on 
#     these columns. By default, the function treats the input data as 
#     belonging to one partition. Note: Specifying a column as both an 
#     add_column and a join_column causes incorrect counts in partitions.\cr
#     Types: character OR vector of Strings (character)
#   
#    partition.key -
#     Optional Argument.\cr
#     Specifies the names of the output column to use as the partition key. 
#     The default value is "col1_item1".\cr
#     Default Value: "col1_item1"\cr
#     Types: character
#   
#   max.itemset -
#     Optional Argument.\cr
#     Specifies the maximum size of the item set. \cr
#     Default Value: 100\cr
#     Types: integer
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_cfilter_mle" which is a named 
#   list containing objects of class "tbl_teradata".\cr
#   Named list members can be referenced directly with the "$" operator 
#   using the following names:\enumerate{\item output.table\item output}
# 
# 
#' @export
td_cfilter_mle <- function(
  data = NULL,
  input.columns = NULL,
  join.columns = NULL,
  add.columns = NULL,
  partition.key = "col1_item1",
  max.itemset = 100,
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("input.columns", input.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("join.columns", join.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("add.columns", add.columns, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("partition.key",  partition.key, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("max.itemset", max.itemset, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(input.columns)
  .validateTblHasArgumentColumns(input.columns, "input.columns", data, "data")
  
  .validateInputColumnsNotEmpty(join.columns)
  .validateTblHasArgumentColumns(join.columns, "join.columns", data, "data")
  
  .validateInputColumnsNotEmpty(add.columns)
  .validateTblHasArgumentColumns(add.columns, "add.columns", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  # Generate temp table names for output table parameters if any.
  output.tableTempTableName <- .teradataGenerateTempTableName("td_cfilter0_", use.default.database = TRUE, gc.onQuit = TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_cfilter_mle.internal)
  Call[["output.tableTempTableName"]] <- output.tableTempTableName
  
  retval <- NULL
  tryCatch({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_cfilter_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units = "secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_cfilter_mle.internal <- function(
  data = NULL,
  input.columns = NULL,
  join.columns = NULL,
  add.columns = NULL,
  partition.key = "col1_item1",
  max.itemset = 100,
  data.sequence.column = NULL,
  output.tableTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("OutputTable")
  funcOutputArgs <- c(output.tableTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(input.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "JoinColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(join.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  if (!is.null(add.columns)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PartitionColumns")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(add.columns,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null( partition.key) && !missing( partition.key)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PartitionKey")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector( partition.key, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(max.itemset) && !missing(max.itemset)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxDistinctItems")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(max.itemset, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "CFilter",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("CFilter", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["output.table"]] <- .createDataSetObject(.extractTableName(output.tableTempTableName), sourceType = "table", .extractDatabaseName(output.tableTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_cfilter <- td_cfilter_mle
