# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.9
# 
# ################################################################## 

# Description:
#   The GLMPredict function uses the model output by the function GLM to 
#   perform generalized linear model prediction on new input data.
# 
# Args:
#   modeldata -
#     Required Argument.\cr
#     Specifies the tbl_teradata containing the model data.\cr
#   
#   newdata -
#     Required Argument.\cr
#     Specifies the tbl_teradata containing the input data.\cr
#   
#   newdata.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "newdata".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   terms -
#     Optional Argument.\cr
#     Specifies the names of input tbl_teradata columns to copy to the 
#     output table.\cr
#     Types: character OR vector of Strings (character)
#   
#   family -
#     Optional Argument.\cr
#     Specifies the distribution exponential family. The default value is 
#     read from model table. If you specify this argument, you must give it 
#     the same value that you used for the Family argument of the function  
#     when you generated the model table.\cr
#     Permitted Values: LOGISTIC, BINOMIAL, POISSON, GAUSSIAN, GAMMA, 
#     INVERSE_GAUSSIAN, NEGATIVE_BINOMIAL\cr
#     Types: character
#   
#   linkfunction -
#     Optional Argument.\cr
#     The canonical link functions (default link functions) and the link 
#     functions that are allowed for each exponential family Note: Use the 
#     same value that you used for the Link argument of the function  when 
#     you generated the model table.\cr
#     Default Value: "CANONICAL"\cr
#     Permitted Values: CANONICAL, IDENTITY, INVERSE, LOG, 
#     COMPLEMENTARY_LOG_LOG, SQUARE_ROOT, INVERSE_MU_SQUARED, LOGIT, 
#     PROBIT, CAUCHIT\cr
#     Types: character
# 
# Returns:
#   Function returns an object of class "td_glm_predict_sqle" which is a 
#   named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_glm_predict_sqle <- function(
  modeldata = NULL,
  newdata = NULL,
  terms = NULL,
  family = NULL,
  linkfunction = "CANONICAL",
  newdata.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("modeldata", modeldata, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata", newdata, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata.order.column", newdata.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("terms", terms, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("family", family, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("linkfunction", linkfunction, TRUE, c("character",NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(newdata, NULL)
  .validateInputTableDataType(modeldata, "td_glm_mle")
  
  if (.isRefFuncOutput(modeldata, "td_glm_mle")) {
    modeldata <- modeldata[[1]]
  }
  
  # Check for permitted values
  familyPermittedValues <- list("LOGISTIC", "BINOMIAL", "POISSON", "GAUSSIAN", "GAMMA", "INVERSE_GAUSSIAN", "NEGATIVE_BINOMIAL")
  .validatePermittedValues(family, familyPermittedValues)
  
  linkfunctionPermittedValues <- list("CANONICAL", "IDENTITY", "INVERSE", "LOG", "COMPLEMENTARY_LOG_LOG", "SQUARE_ROOT", "INVERSE_MU_SQUARED", "LOGIT", "PROBIT", "CAUCHIT")
  .validatePermittedValues(linkfunction, linkfunctionPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(terms)
  .validateTblHasArgumentColumns(terms, "terms", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(newdata.order.column)
  .validateTblHasArgumentColumns(newdata.order.column, "newdata.order.column", newdata, "newdata")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  if (!is.null(terms)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(terms, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(family)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Family")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(family, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(linkfunction) && !missing(linkfunction)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "LinkFunction")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(linkfunction, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process newdata
  tableRef <- .teradataOnClauseFromDataFrame(newdata)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "ANY")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(newdata.order.column, "\""))
  
  # Process modeldata
  tableRef <- .teradataOnClauseFromDataFrame(modeldata)
  model.order.columns <- c('attribute', 'predictor', 'category', 'estimate')
  model.order.columns <- .teradataCollapseArgVector(model.order.columns, "\"")
  funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "model")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, model.order.columns)
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "GLMPredict",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_SQL")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("GLMPredict", engine = .getEngineName("ENGINE_SQL"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(newdata, modeldata)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_glm_predict_sqle", engine = .getEngineName("ENGINE_SQL"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_glm_predict <- td_glm_predict_sqle
