################################################################################
#
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: pankajvinod.purandare@teradata.com
# Secondary Owner:
#
# This file implements the core validation utilities those will be used by 
# Teradata Analytic Function wrappers.
#
################################################################################

#
# Function to check whether argument is empty string or not.
# Function must be passed argument with quote, for example:
#     .validateInputColumnsNotEmpty(quote(argument))
#
# Args:
#     argument -  Argument value (string) to be checked whether it is empty or 
#                 not.
#
# Returns: TRUE if successful, throws error and stops execution otherwise.
#
.validateInputColumnsNotEmpty <- function(argument) {
  argName <- deparse(substitute(argument))
  if (!is.null(argument) 
     && any(grepl("^$", argument), grepl("^\\s*$", argument)))
    .ta.stop("TDR_E3003", argName)
  return(TRUE)
}

#
# Function to check the permitted values for the argument.
# Function must be passed argument with quote, for example:
#     .validatePermittedValues(quote(argument), permittedValuesList)
#
# Arguments:
#     arg - Argument value (string) to be checked against permitted values 
#           from the list.
#     permittedValuesList - A list containing permitted values for the 
#                           argument.
#
# Returns: TRUE if successful, throws error and stops execution otherwise.
#
.validatePermittedValues <- function(arg, permittedValuesList) {
  argName <- deparse(substitute(arg))
  
  # Validate the argument type.
  if (!is.vector(permittedValuesList) || !is.list(permittedValuesList)) {
    .ta.stop("TDR_E3002", "permittedValuesList", "list")
  }
  
  # Validate whether argument has value from permitted values list or not.
  if (!is.null(arg) && !all(toupper(arg) %in% toupper(permittedValuesList))) {
    .ta.stop("TDR_E3004", argName, paste(permittedValuesList, collapse = "\",\""))
  }
  
  return(TRUE)
}

#
# Function to check to make sure table parameter objects type is of one of the
# classes returned by .getSupportedDatasetClasses(). Execution is stopped, 
# if the argument is of invalid type.
# Function must be passed argument with quote, for example:
#     .validateInputTableDataType(quote(argument), reference.function.name)
#
#
# Args:
#     arg - Argument whoes type needs to be checked.
#     reference.function.name - Reference class for the data.
#
# Returns: TRUE if successful, throws error and stops execution otherwise.
#
.validateInputTableDataType <- function(data = NULL, reference.function.name = NULL) {
  argName <- deparse(substitute(data))
  
  # check to make sure table parameters object type is one of the classes 
  # returned by .getSupportedDatasetClasses().
  if (!is.null(reference.function.name)) {
    if (!any(class(data) %in% .getSupportedDatasetClasses())) {
      #
      # Check whether input object class is same as reference function name or not.
      # If it is same, then we are good else stop the execution.
      #
      if (!inherits(data, reference.function.name))
        .ta.stop("TDR_E3002", argName, paste(
          paste0(.getSupportedDatasetClasses(), collapse = ", "), 
          " or ", reference.function.name, sep = ""))
      
      if (is.null(data[[1]]))
        .ta.stop("TDR_E3008", argName)
      
      #
      # If reference function is correct, which mean class of the input object
      # is same as reference function name, then let's go ahead and check
      # class of the first element in the object.
      # If class of the first element is not of type specified by
      # .getSupportedDatasetClasses(), stop and throw an error.
      #
      if (!is.null(data[[1]]) 
          && !any(class(data[[1]]) %in% .getSupportedDatasetClasses())) {
        .ta.stop("TDR_E3002", argName, paste(
          paste0(.getSupportedDatasetClasses(), collapse = ", "), 
          " or ", reference.function.name, sep = ""))
      }
    }
  } else {
    
    if (!is.null(data) && !any(class(data) %in% .getSupportedDatasetClasses())) {
      .ta.stop("TDR_E3002", argName, paste0(.getSupportedDatasetClasses(), collapse = ", "))
    }
  }
  
  return(TRUE);
}

#
# A wrapper around the existing '.teradataAllMissingArgsVector' to check the 
# whether the required arguments passed to the function are missing or not. 
# Only wrapper's are using this function.           
#
# Arguments:
#     argInfoMatrix - A list 
#                     The argument is expected to be an argInfoMatrix used by 
#                     end user functions such as ta.hist().
#                     An example input matrix will be:
#                     argInfoMatrix <- list()
#                     argInfoMatrix <- rbind(argInfoMatrix,
#                         list("ta_frame", ta_frame, FALSE, "ta.data.frame"))
#                     argInfoMatrix <- rbind(argInfoMatrix,
#                         list("data_column", data_column, FALSE, "character"))
#                     colnames(argInfoMatrix) <- c(
#                         "argName", "argValue", "isOptional", "argType")
#
# Returns: 
#   True if successful. 
#   If any arguments are missing throws error and stops the process.
#
.validateMissingRequiredArguments <- function(argInfoMatrix) {
  # Make sure that a non-NULL value has been supplied for all mandatory 
  # arguments
  missingRequiredArgs <- .teradataAllMissingArgsVector(argInfoMatrix)
  if (length(missingRequiredArgs) > 0) {
    .ta.stop("TDR_E3001", paste(missingRequiredArgs, sep = " ", collapse = ", "))
  }
  return(TRUE)
}

#
# Validate the data types for each argument passed to the function, except
# arguments returned by .getSupportedDatasetClasses() type.
#
# Arguments:
#     argInfoMatrix - A list 
#                     The argument is expected to be an argInfoMatrix used by 
#                     end user functions such as ta.hist().
#                     An example input matrix will be:
#                     argInfoMatrix <- list()
#                     argInfoMatrix <- rbind(argInfoMatrix,
#                         list("ta_frame", ta_frame, FALSE, "ta.data.frame"))
#                     argInfoMatrix <- rbind(argInfoMatrix,
#                         list("data_column", data_column, FALSE, "character"))
#                     colnames(argInfoMatrix) <- c(
#                         "argName", "argValue", "isOptional", "argType")
#
# Returns: 
#   True if successful. 
#   If any arguments are not of correct type throws error and 
#   stops the process.
#
.validateArgumentTypes <- function(argInfoMatrix) {
  type.mismatch <- unlist(apply(argInfoMatrix, MARGIN = 1, FUN = .teradataReportIncorrectType))
  all_inputs <- sapply(type.mismatch, function(x, argMat=argInfoMatrix) { 
    pos <- match(x, argInfoMatrix[,1])
    type <- argInfoMatrix[pos,]$argType
    return(.teradataReportIncorrectTypeError(argInfoMatrix[pos,]))
  })
  
  if (length(type.mismatch) > 0) {
    .ta.stop("TDR_E3005", paste(all_inputs, sep = " ", collapse = "\n\t"))
  }
  return(TRUE)
}

#
# For the given argument with invalid datatypes function creates 
# appropriate error message based on if the argument supports List or not.
#
# Arguments:
#     arg - argument which has invalid datatype in the function call.
#
# Returns: 
#   Error message to be displayed. 
# 
#' @importFrom stats na.omit
.teradataReportIncorrectTypeError <- function(arg) {
  errormessage <- ""
  # If argument allows list format then create message accordingly.
  if ('list' %in% arg$argType) {
    argtypes <- arg$argType[ arg$argType != 'list' ]
    errormessage <- paste0("Argument '", arg$argName, "' must be of '", 
                           paste(argtypes, collapse = " or "), "' datatype or a vector of '" , 
                           paste(argtypes, collapse = " or "), "' datatype(s).")
  } else if ('named list' %in% arg$argType) {
    argtypes <- arg$argType[ arg$argType != 'named list' ]
    errormessage <- paste0("Argument '", arg$argName, "' must be a named list of '" , 
                           paste(argtypes, collapse = " or "), "' datatype(s).")
  } else {
    argtypes <- na.omit(arg$argType)
    # Message for old wrappers.
    errormessage <- paste0("Argument '", arg$argName, "' must be of '", 
                           paste(argtypes, collapse = " or "), "' datatype.")
    # If argument type is a list. Add additional information to the message.
    if (length(arg$argType) > 1) {
      errormessage <- paste0(errormessage, " Multiple values are not supported.")
    } 
  }
  # Additional error message to handle integers.
  if ("integer" %in% arg$argType) {
    errormessage <- paste0(errormessage, 
                           " Integer values range between ", .get("minInteger"), " and ",
                           .get("maxInteger"), ", both bounds inclusive.")
  }
  return(errormessage)
}
  

#
# Function to check argument data type is of correct type or not.
# All variables data types are checked here, except tbl_teradata arguments.
#
# Args:
#   alist  - A list 
#                   An example 'alist' argument  given to this functions 
#                   would be:
#                     list("ta_frame", ta_frame, FALSE, "ta.data.frame")))
#
# Returns: 
#   NULL if data type is as required else argument name is returned. 
# 
.teradataReportIncorrectType <- function(alist) {
  if (!("ta.data.frame" %in% alist$argType) && !is.null(alist$argValue)) {
    if (length(alist$argType) > 1 &&
        !("list" %in% alist$argType || "named list" %in% alist$argType) &&
        length(alist$argValue) > 1) {
      return(alist$argName)
    }
    # Check for named list.
    else if ("named list" %in% alist$argType) {
      if (is.null(names(alist$argValue)))
        return(alist$argName)
    }
    # Checks for integer value first before going to check for numeric.
    else if (class(alist$argValue) == "numeric" &&  "integer" %in% alist$argType) {
      # Integer numbers range in [-2147483647, 2147483647]. Using `as.integer` on any value outside
      # this range throws error.
      if (all(alist$argValue >= .get("minInteger") && alist$argValue <= .get("maxInteger")) &&
          all(alist$argValue == as.integer(alist$argValue))) {
        return(NULL)
      } else if ("numeric" %in% alist$argType) {
        return(NULL)
      } else {
        # Invalid type of the values in the argument.
        return(alist$argName)
      }
    }
    # If not valid datatype add invalid_arg to dictionary and break
    # all() - to check if mulitple values are present
    else if (!all(class(alist$argValue) %in% alist$argType)) {
      return(alist$argName)
    }
    else
      return(NULL)
  } 
  else {
    return(NULL)
  }
}

#
# Function to check the list and based on the values passed in the list 
# arguments are validated to see if required areguments are missing or not.
# The argument is expeced to be a list which will correspond to the individual
# row elements of the argInfoMatrix used by the end user functions such as 
# ta.hist()
#
# Args:
#   argInfoMatrix  - A list 
#                   An example 'alist' argument  given to this functions 
#                   would be:
#                     list("ta_frame", ta_frame, FALSE, "ta.data.frame"))
#
# Returns:
#   The function will return "ta_frame" (1st element of the alist), if the 
#   2nd element of the the list is NULL and the argument is not optional 
#   (which is indicated by the 3rd element of the list).
#   It will return NULL in all other cases
#
.teradataReportMissingArg <- function(alist) {
  if (identical(alist$argType,"character")) {
    if (!alist$isOptional 
        && (is.null(alist$argValue) 
            || nchar(.ta.trimString(alist$argValue)) == 0)) {
      if (!is.null(alist$msg))
        return(alist$msg)
      else
        return(alist$argName)
    } else {
      return(NULL)
    }
  } else {
    if (!alist$isOptional && is.null(alist$argValue)) {
      if (!is.null(alist$msg))
        return(alist$msg)
      else
        return(alist$argName)
    } else {
      return(NULL)
    }
  }
}

#
# Function to check missing arguments in a list.
# Description:  Function to check miising arguments in a list.
#               The function return a vector containing names of all the 
#               mandatory arguments (column 1) for which the actual value 
#               (column 2) is NULL
#
# Args:
#   argInfoMatrix - A list 
#                   The argument is expected to be an argInfoMatrix used by 
#                   end user functions such as ta.hist().
#                   An example input matrix will be:
#                     argInfoMatrix <- list()
#                     argInfoMatrix <- rbind(argInfoMatrix,
#                         list("ta_frame", ta_frame, FALSE, "ta.data.frame"))
#                     argInfoMatrix <- rbind(argInfoMatrix,
#                         list("data_column", data_column, FALSE, "character"))
#                     colnames(argInfoMatrix) <- c(
#                         "argName", "argValue", "isOptional", "argType")
# Returns:
#   The function return a vector containing names of all the 
#   mandatory arguments (column 1) for which the actual value 
#   (column 2) is NULL.
#
.teradataAllMissingArgsVector <- function(argInfoMatrix) {
  # For the apply() function MARGIN is 1 because the argument argInfoMatrix
  # is a matrix.  apply() returns a list containing the argName for all the
  # the row elements where the argValue is NULL and the end user function
  # argument represented by the row is mandatory. It returns a NULL for all
  # the other elements.
  #
  # unlist() converts the list returned by apply() to a vector (eliminating
  # all the NULLs in the process)
  # This vector will not have any NULLs and will be suitable as an argument
  # to length() and paste() functions.
  unlist(apply(argInfoMatrix, MARGIN = 1, FUN = .teradataReportMissingArg))
}

#
# Function returns a vector for supported data set object class.
#
.getSupportedDatasetClasses <- function() {
  c("tbl_teradata")
}

#Function to check whether column(s) specified in given argument
#are present in associated tibble object or not.
.validateTblHasArgumentColumns <- function(columns, colArgName, data, dataArgName) {
  
  if (is.null(columns)) {
    return(TRUE)
  }
  if (is.null(data) &&  !is.null(columns)) {
    .ta.stop("TDR_E3101", colArgName, dataArgName, "specified")
  }
  if (is.null(colArgName) || is.null(dataArgName)) {
    .ta.stop(paste0("colArgName and dataArgName should be specified"))
  }
  if (class(columns) == "character") {
    columns <- as.list(columns)
  }
  # Get all the columns exists in the given tibble argument.
  columns_in_data <- .get_colnames(data)
  
  #check if the columns specified are present in the given tibble object.
  invalidColArguments <- c()
  
  for (col in columns) {
    if (!(col %in% columns_in_data)) {
      if (!(col %in% invalidColArguments)) {
         invalidColArguments <- append(invalidColArguments, col)
      }
    }
  }
  if (length(invalidColArguments) > 0) {
     .ta.stop("TDR_E3102", paste(invalidColArguments,collapse = ","), colArgName, dataArgName )
  }
  return(TRUE)
}

# This function verifies if the partition column argument does not have default 
# value. If TRUE, it signifies the column arguments need to be quoted and the 
# .validateTblHasArgumentColumns function is called for the partition column argument.
# If FALSE it signifies the opposite.
# 
# @param argName Partition column argument
# @param argDafaultValue Default value for the partition column argument (either "ANY" or "1")
# @return Boolean value
.isDefaultOrNot <- function(argName, argDefaultValue) {
  if (argDefaultValue != "ANY" && argDefaultValue != "1") {
    .ta.stop(paste0("Permitted values for argDefaultValue are '1' and 'ANY'"))
  }
  if (length(argName) > 1 || argName != argDefaultValue) {
    return(TRUE)
  }
  return(FALSE)
}


# Function to check if NULL is provided by the user, when default value is provided.
.validateNullValues <- function(arg, argValue) {
  if (is.null(argValue) || is.na(argValue)) {
    .ta.stop("TDR_E3411", arg)
  }
}

#
# Function to validate length of character string argument.
#
# Args:
#     argument   - Argument value (string) to be checked for its length.
#     arg.length - Length in characters to compare the argument length with.
#     op         - Type of comparison operator to use:
#                  * 'LT' - Less than; Check is argument length is less than
#                           "arg.len"
#                  * 'LE' - Less than or equal to; Check is argument length
#                           is less than or equal to "arg.len"
#                  * 'GT' - Greater than; Check is argument length is less than
#                           "arg.len"
#                  * 'GE' - Greater than or equal to; Check is argument length
#                           is less than "arg.len"
#                  * 'EQ' - Equal to; Check is argument length is equal to
#                           "arg.len"
#                  * 'NE' - Not equal to; Check is argument length is not equal
#                           to "arg.len"
#                  An error is thrown when these checks fail, or if an unsupported
#                  "op" is used.
#
# Returns: TRUE if successful, throws error and stops execution otherwise.
#
.validateArgValueLength <- function(argument, arg.len, op) {
  if (is.null(argument)) {
    return(TRUE)
  }
  argName <- deparse(substitute(argument))
  acceptableOp <- c("LT", "LE", "GT", "GE", "EQ", "NE")
  
  switch (toupper(op),
    LT = if (!(nchar(argument) < arg.len))  .ta.stop("TDR_E4007", argName, gettextf("be less than %s", arg.len)),
    LE = if (!(nchar(argument) <= arg.len)) .ta.stop("TDR_E4007", argName, gettextf("be less than or equal to %s", arg.len)),
    GT = if (!(nchar(argument) > arg.len))  .ta.stop("TDR_E4007", argName, gettextf("be greater than %s", arg.len)),
    GE = if (!(nchar(argument) >= arg.len)) .ta.stop("TDR_E4007", argName, gettextf("be greater than or equal to %s", arg.len)),
    EQ = if (!(nchar(argument) == arg.len)) .ta.stop("TDR_E4007", argName, gettextf("be equal to %s", arg.len)),
    NE = if (!(nchar(argument) != arg.len)) .ta.stop("TDR_E4007", argName, gettextf("not be equal to %s", arg.len)),
    .ta.stop("TDR_E3004", "op", paste(acceptableOp, collapse = "\",\""))
  )
  
  return(TRUE)
}