# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.7
# 
# ################################################################## 

# Description:
#   The RandomWalkSample function takes an input graph (which is typically
#   			large) and outputs a sample graph.
# 
# Args:
#   vertices.data -
#     Required Argument.\cr
#     Specifies the tbl_teradata containing the vertex data.\cr
#   
#   vertices.data.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "vertices.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   edges.data -
#     Required Argument.\cr
#     Specifies the tbl_teradata containing the edge data.\cr
#   
#   edges.data.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "edges.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   target.key -
#     Specifies the names of the columns in "edges.data" that identify the target
#     vertex of an edge. This set of columns must have the same schema as
#     "vertices.data.partition.column" and "edges.data.partition.column".\cr
#     Types: character OR vector of Strings (character)
#   
#   sample.rate -
#     Optional Argument.\cr
#     Specifies the sampling rate. This value must be in the range (0, 1.0).\cr
#     Default Value: 0.15\cr
#     Types: numeric
#   
#   flyback.rate -
#     Optional Argument.\cr
#     Specifies the chance, when visiting a vertex, of flying back to the
#     starting vertex. This value must be in the range (0, 1.0).\cr
#     Default Value: 0.15\cr
#     Types: numeric
#   
#   seed -
#     Optional Argument.\cr
#     Specifies the seed used to generate a series of random numbers for
#     "sample.rate", "flyback.rate", and any random number used internally.
#     Specifying this value along with "vertices.data.sequence.column" and
#     "edges.data.sequence.column" guarantees that the function result is
#     repeatable on a given Vantage system.\cr
#     Default Value: 1000\cr
#     Types: numeric
#   
#   accumulate -
#     Optional Argument.\cr
#     Specifies the names of columns in "vertices.data" to copy to the
#     "output.vertex.table" output tbl_teradata.\cr
#     Types: character OR vector of Strings (character)
#   
#   vertices.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "vertices.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   edges.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "edges.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_random_walk_sample_mle" which 
#   is a named list containing objects of class "tbl_teradata".\cr
#   Named list members can be referenced directly with the "$" operator 
#   using the following names:\enumerate{\item output.vertex.table\item 
#   output.edge.table\item output}
# 
# 
#' @export
td_random_walk_sample_mle <- function(
  vertices.data = NULL,
  edges.data = NULL,
  target.key = NULL,
  sample.rate = 0.15,
  flyback.rate = 0.15,
  seed = 1000,
  accumulate = NULL,
  vertices.data.sequence.column = NULL,
  edges.data.sequence.column = NULL,
  vertices.data.partition.column = NULL,
  edges.data.partition.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("vertices.data", vertices.data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("vertices.data.partition.column", vertices.data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("edges.data", edges.data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("edges.data.partition.column", edges.data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("target.key", target.key, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("sample.rate", sample.rate, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("flyback.rate", flyback.rate, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seed", seed, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("vertices.data.sequence.column", vertices.data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("edges.data.sequence.column", edges.data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(vertices.data, NULL)
  .validateInputTableDataType(edges.data, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(target.key)
  .validateTblHasArgumentColumns(target.key, "target.key", edges.data, "edges.data")
  
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", vertices.data, "vertices.data")
  
  .validateInputColumnsNotEmpty(vertices.data.sequence.column)
  .validateTblHasArgumentColumns(vertices.data.sequence.column, "vertices.data.sequence.column", vertices.data, "vertices.data")
  
  .validateInputColumnsNotEmpty(edges.data.sequence.column)
  .validateTblHasArgumentColumns(edges.data.sequence.column, "edges.data.sequence.column", edges.data, "edges.data")
  
  .validateInputColumnsNotEmpty(vertices.data.partition.column)
  .validateTblHasArgumentColumns(vertices.data.partition.column, "vertices.data.partition.column", vertices.data, "vertices.data")
  
  .validateInputColumnsNotEmpty(edges.data.partition.column)
  .validateTblHasArgumentColumns(edges.data.partition.column, "edges.data.partition.column", edges.data, "edges.data")
  
  # Generate temp table names for output table parameters if any.
  output.vertex.tableTempTableName <- .teradataGenerateTempTableName("td_random_walk_sample_mle0_", use.default.database=TRUE, gc.onQuit=TRUE)
  output.edge.tableTempTableName <- .teradataGenerateTempTableName("td_random_walk_sample_mle1_", use.default.database=TRUE, gc.onQuit=TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_random_walk_sample_mle.internal)
  Call[["output.vertex.tableTempTableName"]] <- output.vertex.tableTempTableName
  Call[["output.edge.tableTempTableName"]] <- output.edge.tableTempTableName
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_random_walk_sample_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_random_walk_sample_mle.internal <- function(
  vertices.data = NULL,
  edges.data = NULL,
  target.key = NULL,
  sample.rate = 0.15,
  flyback.rate = 0.15,
  seed = 1000,
  accumulate = NULL,
  vertices.data.sequence.column = NULL,
  edges.data.sequence.column = NULL,
  vertices.data.partition.column = NULL,
  edges.data.partition.column = NULL,
  output.vertex.tableTempTableName = NULL,
  output.edge.tableTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("VertexOutputTable", "EdgeOutputTable")
  funcOutputArgs <- c(output.vertex.tableTempTableName, output.edge.tableTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetKey")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(target.key,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(accumulate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(accumulate,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(sample.rate) && !missing(sample.rate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SampleRate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(sample.rate, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(flyback.rate) && !missing(flyback.rate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "FlybackRate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(flyback.rate, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(seed) && !missing(seed)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Seed")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(seed, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "LONG")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(vertices.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("vertices:", .teradataCollapseArgVector(vertices.data.sequence.column, "")))
  }
  
  if (!is.null(edges.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("edges:", .teradataCollapseArgVector(edges.data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process vertices.data
  vertices.data.partition.column <- .teradataCollapseArgVector(vertices.data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(vertices.data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "vertices")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, vertices.data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # Process edges.data
  edges.data.partition.column <- .teradataCollapseArgVector(edges.data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(edges.data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "edges")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, edges.data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "RandomWalkSample",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("RandomWalkSample", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(vertices.data, edges.data)
  
  # Return output table data frames.
  result <- list()
  result[["output.vertex.table"]] <- .createDataSetObject(.extractTableName(output.vertex.tableTempTableName), sourceType = "table", .extractDatabaseName(output.vertex.tableTempTableName), is_dplyr_input)
  result[["output.edge.table"]] <- .createDataSetObject(.extractTableName(output.edge.tableTempTableName), sourceType = "table", .extractDatabaseName(output.edge.tableTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_random_walk_sample <- td_random_walk_sample_mle
