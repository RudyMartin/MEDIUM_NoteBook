################################################################################
#
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: pankajvinod.purandare@teradata.com
# Secondary Owner:
#
# This file implements creation of a teradata tbl object.
#
################################################################################

# register as a formal class
#' @importFrom methods setOldClass
setOldClass(c("tbl_teradata"))
setOldClass(c("src_teradata"))


# We implememnt this function so we can create our own,
# source object from a given connection.
# This is not exported because we do not document users to create a src object
# This is internally used in our tbl creation
#' @importFrom dbplyr src_dbi
src_teradata <- function(con){
  # no error checking because it is internal and can only be invoked from
  # tbl.Teradata so con will always be of class Teradata
  src <- src_dbi(con)
  # We perform this check because dbplyr latest code might
  # already add the subclass for us.
  if (!inherits(src, "src_Teradata")) {
    # Note the Upper case 'T', this is because when dbplyr,
    # adds the sub class it is in the same case as class(con)
    class(src) <- c("src_Teradata", class(src))
  }
  src
}

#' @export
#' @importFrom dplyr tbl
tbl.Teradata <- function(src, from, ...) {
  # all the logic is in tbl.src_Teradata
  # this ensures that the tbl object created from src is the same as
  # tbl object created from connection
  tbl(src_teradata(src), from, ...)
}


# This method is required to handle scenarios where dplyr tries to
# create a tbl object using src, for example as below:
# t1 <- tbl(con, "table1")
# t2 <- tbl(t1$src, "table2") => This command invokes this method
# NOTE: This needs to be exported so that the S3 method is invoked
#' @export
tbl.src_Teradata <- function(src, from, ...) {
  res <- tbl_sql(c("teradata", "dbi"), src = src, from = from, ...)

  # This is a special case when ignore.metadata is set to TRUE we do not fetch
  # metadata (i.e column names and types), instead we store the con and from info inside the tbl
  if (isTRUE(list(...)$ignore.metadata)) {
    res <- .createLazyVars(res)
  } else {
    # Retrieve the column names and types here
    # This operation was originally performed in function: db_query_fields
    # Moving it here so that we make a single call to retrieve both
    # column names and types
    colInfo <- .ta.describe.columns.wrapper(src$con, from)
    # set ops$vars here instead of in db_query_fields
    res$ops$vars <- colInfo$names
    res$types <- colInfo$types
  }
  res
}


# Override S3 method op_vars in dbplyr.
# This is always invoked whenever any column name information is accessedd from a tbl
# Need to export this so it gets invoked via dbplyr code
#' @importFrom dbplyr op_vars
#' @export
op_vars.op_base_teradata <- function(op) {
  .populateLazyVars(op)
  op$vars <- .getVarsCached(op)
  NextMethod(op)
}
# Override S3 method op_grps in dbplyr.
# This is invoked by few of the lazy ops like distinct, summarize
# We override this to ensure that lazy variables are populated in case they were not for our subclass
#' @importFrom dbplyr op_grps
#' @export
op_grps.op_base_teradata <- function(op) {
  .populateLazyVars(op)
  NextMethod(op)
}

# A special sub-class to avoid calling op_vars from print method.
# Because in the print method we already get the column names via dbGetQuery
#' @importFrom dbplyr op_vars
#' @export
op_vars.op_ignore_teradata <- function(op) {
  ""
}

# A special sub-class to avoid calling op_grps from print method.
# Because in the print method we already get the column names via dbGetQuery
#' @importFrom dbplyr op_grps
#' @export
op_grps.op_ignore_teradata <- function(op) {
  ""
}

# This is our internal S3 generic to populare the metadata for our lazy tbl
# The reason this a S3 method is because we need to handle different classes of ops object
# It also makes it easy to traverse the ops tree.
.populateLazyVars <- function(op, ...) {
  UseMethod(".populateLazyVars")
}

# S3 for our op_base_teradata class - allows to collect metadata only for this subclass
# This function avoids re-populating the metadata unless it is required.
# So it checks if we already have types or vars populated
.populateLazyVars.op_base_teradata <- function(op, ...) {
  e <- op$td.ops.env
  args <- list(...)
  # if we already have types.cached then we dont need to update anything
  if (exists("types.cached", envir = e))
    return(NULL)
  # This means we dont have types cached but we may or may not have vars cached
  # In case vars cached is present then we go ahead and re-populate it only it is passed as argument
  if (exists("vars.cached", envir = e) && is.null(args$names))
    return(NULL)
  # we only retrieve the column metadata if its not passed in this function
  if (is.null(args$names)) {
    args <- .ta.describe.columns.wrapper(e$con.cached, e$from.cached)
  }
  assign("vars.cached", args$names, e)
  assign("types.cached", args$types, e)
  # At this point we atleast have vars.cached so we dont need the con info anynmore
  suppressWarnings(rm(list = c("con.cached", "from.cached"), envir = e))
}

# op is a super class of all ops and so we just traverse up the tree
.populateLazyVars.op <- function(op, ...) {
  .populateLazyVars(op$x, ...)
}

# This means we have reached the top most object without encountering
# our special op_base_teradata class so we dont have to populate anything.
.populateLazyVars.default <- function(op, ...) {
  # do nothing if anything else
}


# Internal S3 generic method is used to check if a given object extends
# from our op_base_teradata subclass by walking up the tree.
# The caller of this function is concerned about whether the tbl object
# corresponding to the ops was created with ignore metadata.
.is_ignore_metadata <- function(op) {
  UseMethod(".is_ignore_metadata")
}

.is_ignore_metadata.op <- function(op) {
  .is_ignore_metadata(op$x)
}

.is_ignore_metadata.op_base_teradata <- function(op) {
  TRUE
}

.is_ignore_metadata.default <- function(op) {
  FALSE
}

# This function converts a given tbl object into a teradata lazy tbl without metadata
#' @importFrom dbplyr remote_name
#' @importFrom dbplyr remote_con
.createLazyVars <- function(tbl.obj) {
  # The reason to create our own subclass of the ops object is because
  # we dont want to accidentally override any s3 method that dbplyr may have.
  opsClass <- class(tbl.obj$ops)
  subClass <- "op_base_teradata"
  class(tbl.obj$ops) <- c(subClass, opsClass)
  # set vars to null, it wont be used anyway since we override op_vars
  tbl.obj$ops$vars <- NULL
  tbl.obj$types <- NULL
  # create a environment inside our subclassed ops object
  # this stores the connection object, remote name of the original tbl object
   # to which this ops belongs to
  td.ops.env <- new.env(parent = emptyenv())
  assign("con.cached", remote_con(tbl.obj), td.ops.env)
  assign("from.cached", remote_name(tbl.obj), td.ops.env)
  tbl.obj$ops$td.ops.env <- td.ops.env
  return(tbl.obj)
}

# Helper function to get types from teradata lazy tbl
.getTypesCached <- function(op) {
  e <- op$td.ops.env
  if (!is.null(e))
    return(e$types.cached)
  return(NULL)
}

# Helper function to get vars from teradata lazy tbl
.getVarsCached <- function(op) {
  e <- op$td.ops.env
  if (!is.null(e))
    return(e$vars.cached)
  return(NULL)
}


# Internal function to create tbl from query.
#' @importFrom dplyr sql
.tbl_query <- function(conn, query, ignore.metadata = FALSE) {
  .tbl_table(conn, sql(query), ignore.metadata = ignore.metadata)
}

# Internal function to create tbl from table or query.
# params:
#   conn: Teradata connection
#   tableQuery: table name or view name
#   ignore.metadata: If True then no metadata is fetched. Creates a teradata lazy tbl
#
# returns:
#   A Teradata tbl object
#' @importFrom dplyr tbl
.tbl_table <- function(conn, tableQuery, ignore.metadata = FALSE) {
  tbl(conn, tableQuery, ignore.metadata = ignore.metadata)
}
