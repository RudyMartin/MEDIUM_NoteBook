# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Adithya Avvaru (adithya.avvaru@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.15
# 
# ################################################################## 

# Description:
#   The NaiveBayesPredict function uses the model output by the
#   			NaiveBayesReduce function to predict the outcomes for a test set
#   of data.
# 
# Args:
#   formula -
#     Optional Argument.
#     Required when the argument "modeldata" is not an object of 
#     td_naivebayes_mle class.
#     Specifies a string consisting of "formula" which was used to fit in 
#     model data. Only basic formula of the (col1 ~ col2 + col3 +...) form 
#     is supported and all variables must be from the same tbl_teradata  
#     object. The response should be column of type numeric or logical.
#   
#   modeldata -
#     Required Argument.
#     This tbl_teradata contains the model data.
#   
#   modeldata.order.column -
#     Optional Argument.
#     Specifies Order By columns for modeldata.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   newdata -
#     Required Argument.
#     This tbl_teradata defining the input test data.
#   
#   newdata.order.column -
#     Optional Argument.
#     Specifies Order By columns for newdata.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   id.col -
#     Required Argument.
#     Specify the name of the column that contains the ID that uniquely 
#     identifies the test input data.
#     Types: character
#   
#   output.prob -
#     Optional Argument.
#     Specifies whether to output probabilities.
#     Default Value: FALSE
#     Types: logical
#   
#   responses -
#     Optional Argument.
#     Specify a list of Responses to output.
#     Types: character OR vector of characters
#   
#   terms -
#     Optional Argument.
#     Specifies the names of input tbl_teradata columns to copy to the 
#     output table.
#     Types: character OR vector of Strings (character)
#   
#   newdata.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "newdata". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
#   
#   modeldata.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "modeldata". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_naivebayes_predict_mle" which 
#   is a named list containing Teradata tbl object.
#   Named list member can be referenced directly with the "$" operator 
#   using name: result.
# 
# 
#' @export
td_naivebayes_predict_mle <- function(
  formula = NULL,
  modeldata = NULL,
  newdata = NULL,
  id.col = NULL,
  output.prob = FALSE,
  responses = NULL,
  terms = NULL,
  newdata.sequence.column = NULL,
  modeldata.sequence.column = NULL,
  newdata.order.column = NULL,
  modeldata.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("formula", formula, TRUE, "formula"))
  argInfoMatrix <- rbind(argInfoMatrix, list("modeldata", modeldata, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("modeldata.order.column", modeldata.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata", newdata, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata.order.column", newdata.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("id.col", id.col, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.prob", output.prob, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("responses", responses, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("terms", terms, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata.sequence.column", newdata.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("modeldata.sequence.column", modeldata.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  if (.isRefFuncOutput(modeldata, "td_naivebayes_mle")) {
    formula <- modeldata$attributes$formula
    modeldata <- modeldata[[1]]
  }
  else if(is.null(formula)){
    .ta.stop("Formula is required when model is not of type td_naivebayes_mle")
  }
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(newdata, NULL)
  .validateInputTableDataType(modeldata, "td_naivebayes_mle")
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(id.col)
  .validateTblHasArgumentColumns(id.col, "id.col", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(terms)
  .validateTblHasArgumentColumns(terms, "terms", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(newdata.sequence.column)
  .validateTblHasArgumentColumns(newdata.sequence.column, "newdata.sequence.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(modeldata.sequence.column)
  .validateTblHasArgumentColumns(modeldata.sequence.column, "modeldata.sequence.column", modeldata, "modeldata")
  
  .validateInputColumnsNotEmpty(newdata.order.column)
  .validateTblHasArgumentColumns(newdata.order.column, "newdata.order.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(modeldata.order.column)
  .validateTblHasArgumentColumns(modeldata.order.column, "modeldata.order.column", modeldata, "modeldata")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IDColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(id.col,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(terms)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(terms,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(responses)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Responses")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(responses, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(output.prob) && !missing(output.prob)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputProb")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.prob, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(newdata.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(newdata.sequence.column, "")))
  }
  
  if (!is.null(modeldata.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("model:", .teradataCollapseArgVector(modeldata.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Let's process formula argument
  formula.terms.matrix <- .ta.parse.formula(formula, newdata)
  # Target Column
  mc.target.column <- formula.terms.matrix[1,1]
  # numerical input columns
  numerical_inputs <- .ta.getColumnsByType(formula.terms.matrix, newdata, "numerical")
  if (length(numerical_inputs) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NumericInputs")
    numericalColumnsList <- .teradataCollapseArgVector(.teradataQuoteArg(numerical_inputs,"\""), "'")
    funcOtherArgs <- c(funcOtherArgs, numericalColumnsList)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
    mc.sql.specific.attributes[["NumericInputs"]] <- numericalColumnsList
  }
  
  # categorical input columns
  categorical_inputs <- .ta.getColumnsByType(formula.terms.matrix, newdata, "categorical")
  if (length(categorical_inputs) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CategoricalInputs")
    categoricalColumnsList <- .teradataCollapseArgVector(.teradataQuoteArg(categorical_inputs,"\""), "'")
    funcOtherArgs <- c(funcOtherArgs, categoricalColumnsList)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
    mc.sql.specific.attributes[["CategoricalInputs"]] <- categoricalColumnsList
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process newdata
  tableRef <- .teradataOnClauseFromDataFrame(newdata)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "ANY")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(newdata.order.column, "\""))
  
  # Process modeldata
  tableRef <- .teradataOnClauseFromDataFrame(modeldata)
  funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "model")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(modeldata.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "NaiveBayesPredict",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("NaiveBayesPredict", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(newdata, modeldata)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_naivebayes_predict_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(endTime - startTime)
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}