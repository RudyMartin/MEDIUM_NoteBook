#
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: arun.kalyanasundaram@teradata.com
# Secondary Owner:
#
# Internal functions for Error handling
# 
###################################################################################
# Error Handling:
#   - Whenever we display an error, we should be able to display the package name as prefix
#   - We should have all error messages catalogued at a single place.
#   - This file should maintain a list of all error messages.
#   - Each error message should be associated with a error code. The protocol for writing
#     error codes is discussed below
#   - The resolution for each error code can be maintained in a seperate text file, since we may not 
#       have a resolution for each error code.
#
####################################################################################
# There are following major challenges here:
#   - How to support message format in error messages
#   - How do you avoid a developer accidentally overwriting an already existing error code
####################################################################################


# We create a wrapper around the native R list because it does not throw an error,
# if two keys are equal. Our error list is going to contain hundreds of error codes and
# messages, it is very likely that a developer could accidentally create a error code
# that already exists.
# Main purpose of .ta.errorList is it will throw error at BUILD time if it has duplicate error codes
.ta.errorList <- function(...) {
  argsList <- list(...)
  if (length(argsList) != length(as.environment(argsList)))
    stop ("FATAL ERROR: Duplicate error codes detected!", call. = FALSE)
  return(argsList)
}

# This is the catalog of all error codes and corresponding messages
# The purpose of error codes is that even if the underlying error message changes slightly,
# we will not have to modify our test cases
# This only contains error code and message, we can have a separate file with resolution for
# some of these error codes, that can be handed over to tech support.
# The convention for error codes are 1) Start with E for error and W for warning
# 2) All exported API errors start with 1000, non-exported internal APIs: 2000, analytic function APIs: 3000
.global__error__list__ <- .ta.errorList(
  TDR_E1000 = "Reserved: Exported functions API Error",
  TDR_E2000 = "Reserved: Non-exported internal functions Error",
  TDR_E3000 = "Reserved: SQLMR / Wrapper Analytic Function Error",
  
  TDR_W1000 = "Reserved: Exported functions API Warning",
  TDR_W2000 = "Reserved: Non-exported internal functions Warning",
  TDR_W3000 = "Reserved: SQLMR / Wrapper Analytic Function Warning",
  
  TDR_P1001 = "Missing argument: temp.database. Setting it to default database: %s",
  TDR_P1002 = "Context exists and matches the given connection object. Switching temp.database from %s to %s",
  TDR_P1003 = "Created connection using %s logon mechanism.",
  TDR_P1004 = "Using Vantage version '%s' based on the configuration option td.vantage.version.
  Please set the option td.vantage.version if the connection context is established
  using a Vantage version different from '%s'. Ignore otherwise.
  E.g.: options(td.vantage.version = 'vantage1.1')",
  
  TDR_W1002 = "Overwriting current context. Any non-persisted objects created using analytic functions will be removed.",
  TDR_W1003 = "The version of Advanced SQL Engine (%s) is not supported",
  TDR_W1004 = 'ODBC Connection with a DSN (Data source name) cannot be supported. Reason: Error loading library - %s: %s.
  Make sure the option: td.lib.IODBC is set to the full path of your IODBC library file.
  E.g.: options(td.lib.IODBC = "/usr/lib/libiodbc.dylib")',
  #TDR_W1005 = "Removing current context. To create a new context, see ?td_create_context / ?td_set_context",
  TDR_W1006 = "Both \"tdWalletString\" and \"pwd\" are specified. Ignoring \"pwd\"",
  TDR_W1007 = "Database: %s not found. Setting it to default database: %s. See ?td_set_context to change temp.database",
  TDR_W1008 = "Cound not retrieve Process ID: %s. Make sure to persist your model objects in other open R sessions.",
  TDR_W1009 = "ODBC Driver with tdplyr will be deprecated. Teradata recommends using Teradata SQL Driver for R when creating connection context.",
  
  # This is a default error code for messages that dont have any code
  # This message will not be displayed, instead display developer supplied message
  # This is also a fallback error if developer provides an invalid error code.
  # Make sure no call explicitly specifies this error code
  TDR_E1001 = "Default Error Code",
  # A few sample error codes for testing purposes
  TDR_E1002 = "Reserved: Sample argument: %s missing error",
  TDR_E1003 = "Reserved: Sample two arguments: %s, %s missing error",
  # We will use this to indicate that the errors are coming is coming from
  # an external source like the odbc driver.
  # So developers can use this by calling .ta.stop(msg, isExternal = TRUE)
  
  TDR_E1004 = "Teradata Context does not exist. See ?td_create_context / ?td_set_context",
  TDR_E1005 = "Invalid connection object",
  TDR_E10051 = "Invalid connection object or inactive connection",
  TDR_E1006 = "%s is not a class of %s.",
  TDR_E1007 = "Argument \"%s\" is missing, with no default",
  TDR_E1008 = "Argument \"%s\" has an invalid value: %s",
  TDR_E1014 = "Failed to retrieve column info for: %s\n%s",
  TDR_E1101 = "Connection must be made using %s",
  TDR_E1102 = "Invalid connection object. Class: \"Teradata\" not found.",
  TDR_E1103 = "Package: '%s' is required.",
  TDR_E1104 = "Invalid TDWallet String",
  TDR_E1107 = "Argument 'database' not supported with Teradata Native driver. Use the 'dbplyr::in_schema' function to access objects in a different database.",
  TDR_P1108 = 'Ignoring "%s", since it is not supported with the Native driver.',
  TDR_E1109 = "The %s should be present in %s argument when %s argument is %s.",
  TDR_E1110 = " %s in the %s argument should not be empty string.",
  
  
  TDR_E10001 = "External source: ",
  
  # SQL-MR Internal function errors.
  TDR_E2001 = "Prefix should not contain only spaces or tabs or newlines.",
  
  # Load Example Data
  TDR_E2101 = "The example file '%s' does not load the table(s) '%s'.",
  
  # Error codes for SQL-MR API's
  TDR_E3001 = "Following required arguments are missing: %s",
  TDR_E3002 = "Argument '%s' should be of %s type",
  TDR_E3003 = "Argument '%s' should not contain empty string.",
  TDR_E3004 = "Argument '%s' should be one of: \n\"%s\"",
  TDR_E3005 = "Invalid type of arguments passed to following: \n\t%s",
  TDR_E3006 = "Response/Dependent variable is not specified correctly in the formula.",
  TDR_E3007 = "%s variable %s is not present in %s",
  TDR_E3008 = "Argument '%s[[1]]' is NULL.",
  TDR_E3009 = "Provide either %s or %s.",
  TDR_E3100 = "Function %s failed.\n%s",
  TDR_E3101 = "'%s' argument can only be used when '%s' argument is %s.",
  TDR_E3102 = "Column(s) '%s' provided in '%s' argument does not exist in object specified in '%s' argument",
  TDR_E3103 = "The function '%s' is not supported for engine '%s' in Vantage '%s'.",
  TDR_E3104 = "Permitted values for the %s '%s' are: %s.",
  TDR_E3105 = "Duplicate function name %s found in file '%s'",
  TDR_E3106 = "Table/View '%s' cannot be created.\n %s",
  TDR_E3107 = "Table/View '%s' cannot be dropped.\n %s",  
  TDR_E3108 = "Column(s) in the argument '%s' is(are) of unsupported datatype : %s. Should be %s.",
  
  # Error codes for sample API
  TDR_E3200 = "Sample: Sum of list elements having proportion values %s in the argument '%s' is greater than 1.",
  TDR_E3201 = "Sample: Zero (0) is not allowed with the list elements having proportion values %s in the argument '%s'.",
  TDR_E3202 = "Sample: The argument '%s' specifies more than 16 samples in the list.",
  
  # Time series aggregate functions
  TDR_E3300 = "Time Series Aggregate function must be associated with group_by_time().%s",
  TDR_E3301 = "Incorrect use of '%s' aggregate function.%s",
  TDR_E3302 = "The function 'ts.delta_t' cannot be combined with any other aggregate function, including itself.",
  TDR_E3303 = "Unbounded timebucket duration (*) can be used only with the 'ts.delta_t' function.",
  TDR_E3304 = "The function 'ts.delta_t' cannot be used with 'fill' argument of 'group_by_time' function.",
  
  # Print messages for Fastload and copy_to
  TDR_P3400 = "%s will insert the data containing %s row(s) in %s batches with each batch having at least %s rows.",
  TDR_P3401 = "Note: This will drop existing table and recreate it with new schema.",
  
  # Warnings for copy_to and Fastload
  TDR_W1010 = "Table '%s' is a MULTISET table. Duplicate rows will not be loaded with Fastload.",
  TDR_W1011 = "Setting 'overwrite = TRUE' will drop existing table '%s' and recreate it with new schema.",
  TDR_W1012 = "'%s' already has '%s' column, ignoring row names of dataframe.",
  TDR_W1013 = "Argument(s) '%s' is/are ignored since the argument(s) %s is/are %s",
  TDR_W1014 = "Note: Ignoring the types provided for timecode column and sequence column for time series PTI tables.",
  
  # Error codes for Fastload and copy_to.
  TDR_E3400 = "Fastload: '%s' value is more than the number of rows in '%s'",
  TDR_E3401 = "%s: Table '%s' already exists. Set either 'overwrite' or 'append' argument to TRUE.",
  TDR_E3402 = "Fastload: '%s' must be a positive integer or real number between 0.1 and 0.9",
  TDR_E3403 = "Fastload: The number of errors is more than the '%s'. Please retry fastload after cleaning the data.",
  TDR_E3404 = "Length of '%s' argument does not match number of columns in data frame.",
  TDR_E3405 = "Fastload: '%s' works only with Teradata SQL Driver for R.",
  TDR_E3406 = "Incorrect specification for argument '%s'. Cannot be a mix of named and unnamed character vector.",
  TDR_E3407 = "Maximum number of columns in the dataframe should be %s. Found %s.",
  TDR_E3408 = "'%s' and '%s' both cannot be %s.",
  TDR_E3409 = "Cannot %s to '%s', as table structure does not match '%s'.",
  TDR_E3410 = "Could not create table without any columns.",
  TDR_E3411 = "NULL/NA is not supported for the argument '%s'.",
  TDR_E3412 = "'%s' is TRUE but remote table does not contain %s column.",
  TDR_E3413 = "%s argument(s) is/are not supported for %s.",
  TDR_E3414 = "A table cannot be appended to another table. Alternatively, use the as.data.frame() function to convert 'df' to an R data frame before appending.",
  TDR_E3415 = "Cannot overwrite table with itself.",
  TDR_E3416 = "The argument(s) '%s' is/are required when the argument '%s' is %s.",
  
  # Error codes for Model Cataloging API's
  TDR_E4001 = "Model with the name '%s' already exists.",
  TDR_E4002 = "Model Catalog not set up.",
  TDR_E4003 = "Cannot find tdplyr name for SQL name: %s.",
  TDR_E4004 = "No models found%s.",
  TDR_E4005 = "Model '%s' not found%s.",
  TDR_E4006 = "Failed to load JSON file for function: '%s', engine: '%s'.",
  TDR_E4007 = "Length of argument '%s' must %s character(s).",
  TDR_E4008 = "Model needs to be generated by calling an analytic function.",
  TDR_E4009 = "Unsupported model generating engine: %s.",

  ## Codes for STO.
  # Error codes.
  TDR_E5001 = "Input file '%s' not found. Please check the path mentioned in the argument %s.",
  # 1st argument: install/remove/replace; 2nd argument: file identifier or file name; 3rd argument - error message from Vantage.
  TDR_E5002 = "Failed to %s file '%s'.\n%s",
  TDR_E5003 = "The %s cannot be provided in the argument '%s'.",
  TDR_E5004 = "Sandbox container error: %s image not found. Please run '%s' function.",
  TDR_E5005 = "Sandbox container error: %s\n%s",
  TDR_E5006 = "Number of rows in the tbl_teradata is greater than %s. Either increase the limit on the number of rows in the argument '%s' or create a '%s' tbl_teradata with less than or equal to %s row(s).",
  TDR_E5007 = "Docker might not be installed or started. Please install and/or start docker in the machine.",
  TDR_E5008 = "Number of columns returned by the user script is %s the expected %s columns. Found: %s",

  # Print codes
  TDR_P5001 = "Procedure Call: %s"
)

# if developer does not specify any error code, we just use this one
.default__error__code__ <- "TDR_E1001"

.external__error__code__ <- "TDR_E10001"

.getDefaultErrorCode <- function () {
  .default__error__code__  
}

.getExternalErrorCode <- function () {
  .external__error__code__
}

#' @importFrom methods getPackageName
.ta.getPackageName <- function() {
  if (!.exists("packageName")) {
    # This is a API in base package (methods)
    # So we dont have to hard code package name
    .assign("packageName",getPackageName())
  }
  .get("packageName")
}

# A constructor for custom error object of type TaError
#  params:
#   erroCode:       A character vector specifying the error code
#   msg    : The error message
#   formatArgs  : a list of arguments for formatting the message
# return:
#   An object of type TaError: Contains 1) code = Error code and 2) msg = formatted error message
.ta.errorObject <- function(errorCode, msg, formatArgs, callStack) {
  structure(list(
    code = errorCode,
    msg = .ta.stringFormatter(msg, formatArgs),
    callStack = callStack
  ), class = "TaError")
}

.getPrefix <- function (addPrefix, packageName, code) {
  if (!addPrefix)
    return("")
  
  gettextf("[%s - (%s)] ", packageName, code)
}
# Implements the S3 str generic for TaError
#  params:
#   obj:     Instance of TaError
#   addPrefix: If set to TRUE, will add the package name prefix
# return:
#   An formatted string that can be displayed to the user
# Note: The package name prefix is a variable set using getPackageName() R API
str.TaError <- function(obj, addPrefix = TRUE, ...) {
  callStackStr <- ""
  # if we have any object to be displayed in the call stack.
  # We display it as "Error: In call1(): call2(): "
  if (length(obj$callStack) > 0)
    callStackStr <- "In "
  
  # if callStack is empty we will not display anything
  for (val in obj$callStack) {
    callStackStr <- paste0(callStackStr, val, ":\n")
  }
  prefix <- .getPrefix(addPrefix, .ta.getPackageName(), obj$code)
  # the collapse is required if the msg is a vector (for multi line)
  gettextf("%s%s%s", callStackStr, prefix, paste0(obj$msg, collapse="\n"))
}

# A helper function to create a error object.
#  params:
#   err:  Could be an error code or error message
#     if err is a valid error code then we fetch the corresponding message
#     if err not a valid code, then we set default error code and show err as message
#   isExternal: If the error message is generated by something outside our package.
#   showFunctionCall: If TRUE, show the name of the function which called this.
#   showStackTrace: If TRUE, show the entire stack trace of functions.
#                   If set, this will override showFunctionCall.
#   optArgs: arguments (if any) for formatting the error message
# return:
#      A object of type TaError
#      if err is not a error code, then we set a default error code
.ta.getErrorObject <- function(err, isExternal, showFunctionCall, showStackTrace, optArgs) {
  
  errorCode <- NULL
  if (isExternal) {
    errorCode <- .external__error__code__
    # Prepend the text to the error message
    err <- paste0(.global__error__list__[[errorCode]],err)
  } else {
    errorCode <- .ta.validateErrorCode(err)
    # err is a valid code, so fetch the message from global list
    if (identical(err, errorCode))
      err <- .global__error__list__[[errorCode]]
  }
  
  # sys.nframe() contains the total number of all the function calls
  # it is equal to 2 if we call .ta.stop from the global environment directly
  lastCall <- sys.nframe() - 2
  # if we are calling .ta.stop from globnal environment then
  # sys.frame will be 2. But it is unlikely since we always call from an API
  if (lastCall <= 0)
    lastCall = 1
  
  # if we want to show only the last function call, then startCall = lastCall
  startCall <- lastCall
  # if we want to show the entire stack trace then we start from 1
  if (showStackTrace)
    startCall <- 1
  
  # This will contain the list of all the function calls
  # in reverse order, starting from the lastCall all the way to the top most function
  callStack = c()
  if (showStackTrace || showFunctionCall) {
    j <- 1
    for (i in lastCall:startCall) {
      # cleaning up the function call, remove quotes and more blank spaces
      callStack[j] <- gsub("  ", "", gsub("\"","'",paste0(deparse(sys.calls()[[i]]), collapse="")))
      j <- j + 1
    }
  }
  # call Stack will be empty vector if showFunctionCall and showStackTrace are FALSE
  .ta.errorObject(errorCode, err, optArgs, callStack)
}

# An internal API to throw error messages
# Developers must use this API instead of the native stop()
# Note: Just replacing stop() with .ta.stop() will also work if you don't have an error code
#  params:
#   err:  Could be an error code or error message
#     if err is a valid error code then we fetch the corresponding message
#     if err not a valid code, then we set default error code and show err as message
#   ...: A list of arguments for formatting message. See examples below.
#   isExternal: If the error message is generated by something outside our package
#   showFunctionCall: If TRUE, show the name of the function which called this. Default TRUE.
#   showStackTrace: If TRUE, show the entire stack trace of functions. Default getOption("td.debug.enable")
#                   If set, this will override showFunctionCall.
# return:
#      An object of type simpleError. Terminates execution if not caught
# Example Usage of .ta.stop()
# Without any error code
#   .ta.stop("My error")
# With a error code (if invalid error code, automatically set to .default__error__code__)
#   .ta.stop("E1002")
# Specify formatting arguments without error code (argument can be string literal or variable)
#   arg1 <- "day"
#   .ta.stop("My %s error this %s", "some", arg1)
# The above will display ("My some error this day")
# Specify formatting args with error code
# See E1002 above requires only one argument
#   .ta.stop("E1002", "Arg1")
# Specify format arguments with a name
#   .ta.stop("My %s error %s", arg1 = "abc", "xyz")
# Following example shows using testthat to catch the error code
# testthat by default looks for a regex match with the specified string
#   expect_error(.ta.stop("E1003"), "(E1003)") => looks for (E1003) in the error message
#' @importFrom utils str
.ta.stop <- function(err, ..., isExternal = FALSE, showFunctionCall = TRUE,
                     showStackTrace = getOption("td.debug.enable")) {
  
  displayMsg <- .ta.getErrorObject(err, isExternal = isExternal, showFunctionCall = showFunctionCall,
                                   showStackTrace = showStackTrace, list(...))
  # This returns an object of type simpleError, ideally we would want
  # this to return TaError so that we can get the object in tryCatch. 
  # But that does not seem to be supported.
  stop(str(displayMsg), call. = FALSE)
}

# An internal API to display warning messages
# Developers must use this API instead of the native warning()
# Note: Just replacing warning() with .ta.warning() will also work if you don't have an error code
#  params:
#   err:  Could be a error code or warning message
#     if err is a valid error code then we fetch the corresponding message
#     if err not a valid code, then we set default error code and show err as message
#   ...: A list of arguments for formatting message. See examples below.
#         .ta.warning("This %s msg", "is")
#   isExternal: If the error message is generated by something outside our package
#   showFunctionCall: If TRUE, show the name of the function which called this. Default TRUE.
#   showStackTrace: If TRUE, show the entire stack trace of functions. Default FALSE.
#                   If set, this will override showFunctionCall.
#   showFunctionCall: If TRUE, show the name of the function which called this. Default TRUE.
#   showStackTrace: If TRUE, show the entire stack trace of functions. Default getOption("td.debug.enable")
#                   If set, this will override showFunctionCall.
# return:
#      An object of type simpleWarning.
# Example Usage: See .ta.stop
#' @importFrom utils str
.ta.warning <- function(err, ..., isExternal = FALSE, showFunctionCall = TRUE,
                        showStackTrace = getOption("td.debug.enable")) {
  
  displayMsg <- .ta.getErrorObject(err, isExternal = isExternal, showFunctionCall = showFunctionCall,
                                   showStackTrace = showStackTrace, list(...))
  warning(str(displayMsg), call. = FALSE)
}

# An internal API to display informative messages
# Developers can use this API instead of the native print()
# Note: Just replacing print() with .ta.print() will also work if you don't have an error code
#  params:
#    msg: A message or error code
#    ...: A list of arguments for formatting the message. Example:
#         .ta.print("This %s msg", "is")
#   addPrefix: If set to TRUE, then adds the package name and error code prefix to the message
#           By default, we wont add prefix for print messages
#' @importFrom utils str
.ta.print <- function(msg, ..., addPrefix = TRUE, showFunctionCall = FALSE,
                      showStackTrace = getOption("td.debug.enable")) {
  displayMsg <- .ta.getErrorObject(msg, isExternal = FALSE, showFunctionCall = showFunctionCall,
                                   showStackTrace = showStackTrace, list(...))
  cat(paste0(str(displayMsg, addPrefix = addPrefix), "\n"))
}

# This implements a text formatter for error messages.
# It calls gettextf with the msg and listofArgs as format arguments
# It is only used internally in .ta.errorObject.
#  params:
#   msg: An unformatted string
#   listOfArgs: A list of values to match the formatting in msg.
# return:
#   character vector which is formatted string after applying listOfArgs to msg
.ta.stringFormatter <- function(msg, listOfArgs) {
  Call <- match.call()
  # The idea is to invoke gettextf with the msg and optional argumenst
  # Directly calling gettextf(msg, listOfArgs) wont work, so we create a call object
  Call[[1]] <- quote(gettextf)
  i <- 3
  for (arg in listOfArgs) {
    Call[[i]] <-   arg
    i <- i + 1
  }
  # This check ensures that if there are no formatting arguments ,
  # We pass an empty string to gettextf as its second argument
  if (length(listOfArgs) == 0)
    Call[[3]] <- ""
  names(Call)[2] <- ""
  # This will invoke the gettextf function
  eval.parent(Call)
}

# Validates whether a given error code exists in the global list of error codes
# This is a helper function for .ta.getErrorObject
#  params:
#   errorCode: A string representing the error code
# return:
#    If the errorCode is invalid it returns .default__error__code__
#    If the errorCode is valid, it returns back the errorCode
.ta.validateErrorCode <- function(errorCode) {
  if (typeof(errorCode) != "character" || is.null(.global__error__list__[[paste0(errorCode, collapse="")]])) {
    # For debugging purposes in case an error code was passed and was not found
    if(getOption("td.debug.enable") && startsWith(as.character(errorCode), "TDR_"))
      print(gettextf("Could not find error code %s. Setting to default code: %s",
                     errorCode, .default__error__code__))
    return(.default__error__code__)
  }
  return(errorCode)
}