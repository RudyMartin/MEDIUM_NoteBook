# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# Secondary Owner: Jeris Alan Jawahar (jeris.jawahar@teradata.com)
# 
# Version: 1.2
# Function Version: 1.0
# 
# ################################################################## 

# Description:
#   The MovAvg function computes thee moving average of 
#   points in a series. The moving average is the unweighted mean 
#   of the previous n data points. For example, a 10-day moving 
#   average of closing price is the mean of closing prices for the 
#   previous 10 days.
# 
# Args:
#   data -
#     Required Argument.\cr
#     Specifies the name of the tbl_teradata that contains the columns\cr
#   
#   data.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   data.order.column -
#     Required Argument.\cr
#     Specifies Order By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   target.columns -
#     Optional Argument.\cr
#     Specifies the input column names for which the moving average is to 
#     be computed. If you omit this argument, then the function copies 
#     every input column to the output tbl_teradata but does not compute 
#     moving average.\cr
#     Types: character OR vector of Strings (character)
#   
#   alpha -
#     Optional Argument.\cr
#     Specifies the damping factor, a value in the range [0, 1], which 
#     represents a percentage in the range [0, 100]. For example, if alpha 
#     is 0.2, then the damping factor is 20%. A higher alpha discounts 
#     older observations faster. The default value is 0.1.\cr
#     Default Value: 0.1\cr
#     Types: numeric
#   
#   start.rows -
#     Optional Argument.\cr
#     Specifies the number of rows at the beginning of the time series that 
#     the function "skips" before it begins the calculation of the 
#     exponential moving average. The function uses the arithmetic average 
#     of these rows as the initial value of the exponential moving average. 
#     The value n must be an integer. The default value of n is 2.\cr
#     Default Value: 2\cr
#     Types: integer
#   
#   window.size -
#     Optional Argument.\cr
#     Specifies the number of previous values to include in the computation 
#     of the simple moving average. \cr
#     Default Value: 10\cr
#     Types: integer
#   
#   include.first -
#     Optional Argument.\cr
#     Specifies whether the first START_ROWS rows should be included in the 
#     output or not.\cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   mavgtype -
#     Optional Argument.\cr
#     Specify the moving average type that needs to be used for computing 
#     moving averages of TargetColumns.\cr
#     Default Value: "C"\cr
#     Permitted Values: C, S, M, W, E, T\cr
#     Types: character
# 
# Returns:
#   Function returns an object of class "td_moving_average_sqle" which is 
#   a named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_moving_average_sqle <- function(
  data = NULL,
  target.columns = NULL,
  alpha = 0.1,
  start.rows = 2,
  window.size = 10,
  include.first = FALSE,
  mavgtype = "C",
  data.partition.column = NULL,
  data.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.partition.column", data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("target.columns", target.columns, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("alpha", alpha, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("start.rows", start.rows, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("window.size", window.size, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("include.first", include.first, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("mavgtype", mavgtype, TRUE, c("character",NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check for permitted values
  mavgtypePermittedValues <- list("C", "S", "M", "W", "E", "T")
  .validatePermittedValues(mavgtype, mavgtypePermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(target.columns)
  .validateTblHasArgumentColumns(target.columns, "target.columns", data, "data")
  
  .validateInputColumnsNotEmpty(data.partition.column)
  .validateTblHasArgumentColumns(data.partition.column, "data.partition.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  if (!is.null(target.columns)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetColumns")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(target.columns, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(include.first) && !missing(include.first)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IncludeFirst")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(include.first, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(alpha) && !missing(alpha)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Alpha")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(alpha, ""))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE PRECISION")
  }
  
  if (!is.null(start.rows) && !missing(start.rows)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StartRows")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(start.rows, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(window.size) && !missing(window.size)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "WindowSize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(window.size, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(mavgtype) && !missing(mavgtype)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MavgType")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(mavgtype, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  data.partition.column <- .teradataCollapseArgVector(data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "MovingAverage",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_SQL")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("MovingAverage", engine = .getEngineName("ENGINE_SQL"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_moving_average_sqle", engine = .getEngineName("ENGINE_SQL"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_moving_average <- td_moving_average_sqle
