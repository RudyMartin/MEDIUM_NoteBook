#
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: Jeris Alan Jawahar (jeris.jawahar@teradata.com)
# Secondary Owner: Adithya Avvaru (adithya.avvaru@teradata.com)
#
# Overridden dplyr copy_to function
#
###################################################################################

#' Copy a local dataframe to a remote data source
#'
#' This function uploads a local dataframe or copies data from a tbl_teradata into a remote 
#' data source by creating the table definition. It can also be used to upload/copy data into time 
#' series Primary Time Index (PTI) tables.\cr
#' Note :
#' \enumerate{
#' \item When the connection is set up using Teradata SQL Driver for R, the function 
#' inserts data in batches of 16384 rows. To insert large number of rows, please refer to 
#' \code{td_fastload} function.
#' \item When the connection is set up using ODBC Driver,the function inserts data 
#' in batches of 1024 rows. Please refer to \href{https://github.com/r-dbi/odbc}{ODBC Driver} page
#' for more information.
#' }
#' @section  PTI Usage:
#' \enumerate{
#' \item PTI table creation is only supported with Teradata SQL Driver for R. 
#' \item When the argument \code{timecode.column.info} is specified, \code{copy_to} attempts to  
#' create a PTI table. This argument is not required when a non-PTI table is to be created. If 
#' this argument is specified, \code{primary.index} argument is ignored.
#' \item The arguments \code{pti.name}, \code{timezero.date}, \code{timebucket.duration},
#' \code{pti.columns}, \code{sequence.column}, \code{seq.max} are not required or used when the
#' table to be created is non-PTI table. These arguments are ignored if specified without the 
#' argument \code{timecode.column.info}.
#' \item Choose PTI related arguments that will identify each row to result in the most even 
#' distribution of time series data among the AMPs in the map used by the table. Include columns 
#' in the argument \code{pti.columns} that are frequently queried to speed data access for those 
#' queries.
#' \item For more information on PTI tables, please refer to the documentation 
#' \href{https://docs.teradata.com/}{Teradata Vantage Time Series Tables and Operations}.
#' }
#'
#' @param dest Required Argument.\cr
#'             Specifies the remote data source connection.
#' @param df Required Argument.\cr
#'           Specifies the local dataframe or tbl_teradata which contains the data to be 
#'           inserted.\cr
#'           Types : R dataframe OR tbl_teradata
#' @param name Optional Argument.\cr
#'             Specifies the name of new remote table.\cr
#'             Default : Name of the dataframe.\cr
#'             Types : character
#' @param overwrite Optional Argument.\cr
#'                  Specifies whether to overwrite existing table or not.\cr
#'                  \enumerate{
#'                  \item If `TRUE`, \code{copy_to} will overwrite an existing table with name 
#'                  `name`. The existing table will be dropped and new table schema will replace
#'                  the existing table. 
#'                  \item If `FALSE`, \code{copy_to} will throw an error if table already exists.
#'                  }
#'                  Default : FALSE\cr
#'                  Types : logical
#' @param types Optional Argument.\cr
#'              Specifies the SQL data types for the columns in remote table. This argument accepts 
#'              both named and unnamed character vectors. If it is NULL, the function uses data 
#'              types of the columns present in R dataframe to map to correct SQL data type.\cr
#'              While creating PTI table, the data types provided for the timecode and sequence columns
#'              are ignored as the columns are auto-generated during PTI table creation. This is 
#'              same for both named and unnamed types. However, for unnamed types, all the data types
#'              must be specified like that for non-PTI tables.\cr 
#'              Suppose a dataframe with columns 'col1' and 'col2' is to be loaded into the 
#'              remote data source.\cr
#'              \enumerate{
#'              \item When an unnamed character vector is specified, the data types of all the 
#'              columns must be specified.\cr
#'              Example:\cr
#'              If \code{types = c("FLOAT", "VARCHAR(10)")}, then the table is created with 2 
#'              columns, 'col1' and 'col2' with data types 'FLOAT' and 'VARCHAR(10)' respectively.
#'              \item If a named character vector is specified, then data types for only a subset of
#'              columns can be specified. If the names of the column data types do not match with
#'              any in the dataframe, then an error will be raised.\cr
#'              Examples:\cr
#'              \enumerate{
#'              \item If \code{types = c("col1" = "FLOAT", col2 = "VARCHAR(10)")}, then the table 
#'              is created with 2 columns, 'col1' and 'col2' with data types 'FLOAT' and 
#'              'VARCHAR(10)' respectively.
#'              \item If \code{types = c("col1" = "FLOAT")}, then the table is created with 2 
#'              columns - 'col1' with data type 'FLOAT' and 'col2' with data type of the column in 
#'              R dataframe.
#'              }
#'              }
#'              Default : NULL\cr
#'              Types : Named OR unnamed vector of characters
#' @param table.type Optional Argument.\cr
#'                   Specifies the type of remote table.\cr
#'                   Permitted Values : "PI" (Primary Index), "NOPI" (No Primary Index)\cr
#'                   Default : "PI"\cr
#'                   Types : character
#' @param primary.index Optional Argument.\cr
#'                      Specifies the name of the primary index column. You can provide multiple 
#'                      columns as a vector. When primary.index is not specified and table.type is 
#'                      "PI", the behavior is specified by the "PrimaryIndexDefault" field in DBS 
#'                      Control.\cr
#'                      Default : NULL\cr
#'                      Types : character OR vector of characters
#' @param row.names Optional Argument.\cr
#'                  Specifies whether to insert row names in remote table or not.\cr
#'                  If dataframe contains row_names column, regardless of row.names option, row 
#'                  names will be inserted in remote table. If TRUE and dataframe doesn't contain 
#'                  row_names column, row names are converted to a column named "row_names". If 
#'                  FALSE, row names are ignored.\cr
#'                  Default : FALSE\cr
#'                  Types : logical\cr
#'                  Note : This argument is ignored when PTI tables are created.
#' @param temporary Optional Argument.\cr
#'                  Specifies whether to create temporary(Teradata volatile) remote table or not.
#'                  Temporary tables are always created in the login user space, regardless of the 
#'                  current default database setting. If FALSE, a permanent table is created, that  
#'                  is available across all sessions. If TRUE, a temporary table is created that is  
#'                  not available in any other sessions.\cr
#'                  To use a temporary table, a tbl_teradata for the table should be created 
#'                  using the in_schema() function.\cr
#'                  Example: tbl(con, in_schema("username", "temporary table name")\cr
#'                  Default : FALSE\cr
#'                  Types : logical  
#' @param analyze Optional Argument.\cr
#'                Calls ANALYZE(collect statistics) on the target table after the creation.\cr
#'                If table.type is NOPI, it will collect statistics on first column of table, else 
#'                i.e. for PI table, it will collect statistics on primary index column of 
#'                the table.\cr
#'                To run analyze on multiple columns, directly call db_analyze function and pass 
#'                multiple columns as character vector. This option is not supported and hence 
#'                ignored when creating table from tbl_teradata.\cr
#'                Default : FALSE\cr
#'                Types : logical  
#' @param append Optional Argument.\cr
#'               Specifies if the dataframe needs to be appended to a table.\cr
#'               When appending data in 'df' to a PTI table, the argument 'timecode.column.info' is
#'               required. The SQL data type in the argument 'timecode.column.info' is ignored if
#'               the 'append' is set to TRUE. If the PTI table is sequenced, the argument
#'               'sequence.column' is also required.\cr
#'               Default : FALSE\cr
#'               Types : logical
#' @param pti.name Optional Argument.\cr
#'                 Used when 'df' is to be saved as a PTI table.\cr
#'                 Secifies the name of the Primary Time Index (PTI) when the table to be created
#'                 is a PTI table.\cr
#'                 Default : NULL\cr
#'                 Types : character
#' @param timecode.column.info Optional Argument.\cr
#'                             Required when the table to be created is PTI table.\cr
#'                             Specfies the column name (in the dataframe or tbl_teradata) and SQL 
#'                             data type of the column which contains timecode information as a  
#'                             named vector. This timecode column is TD_TIMECODE column in the table 
#'                             created. The SQL data type must be either of DATE, TIMESTAMP(n) or 
#'                             TIMESTAMP(n) WITH TIME ZONE where, n is the decimal precision of the 
#'                             fractional seconds in the timestamp. For more information on these 
#'                             data types, see \href{https://docs.teradata.com/}{Teradata Vantage 
#'                             Data Types and Literals}.\cr
#'                             Default : NULL\cr
#'                             Types : Named vector of column name and SQL type.\cr
#'                             Example :
#'                             \code{timecode.column.info = c("col1" = "TIMESTAMP(3) WITH TIME 
#'                             ZONE")} creates the column \code{TD_TIMECODE} of type 
#'                             \code{TIMESTAMP(3) WITH TIME ZONE}.\cr
#'                             Note : 
#'                             \enumerate{
#'                             \item This argument should be a named vector of length one. 
#'                             \item \code{copy_to()} creates a new column named TD_TIMECODE in the 
#'                             PTI table and inserts/appends the data in the column specified in  
#'                             this argument into TD_TIMECODE column of remote table.
#'                             }
#' @param timezero.date Optional Argument.\cr
#'                      Used when 'df' is to be saved as a PTI table.\cr
#'                      Specifies the earliest time series data that the PTI table will accept. In 
#'                      other words, it is the date that precedes the earliest date in the time 
#'                      series data. If it is not specified, Advanced SQL Engine creates
#'                      table with timezero as DATE '1970-01-01'.\cr
#'                      Default : NULL\cr
#'                      Types : Date in character format 'YYYY-MM-DD'\cr
#'                      Note : Although this argument is optional, Teradata recommends to specify a 
#'                      date near to the earliest timestamp in the time series data. 
#' @param timebucket.duration Optional Argument.\cr
#'                            Required if \code{pti.columns} is not specified.\cr
#'                            Used when 'df' is to be saved as a PTI table.\cr
#'                            Specifies the duration that serves to break up the time continuum in 
#'                            the time series data into discrete groups or buckets.\cr
#'                            This argument can be specified using any of the units of time
#'                            as shown below:
#'                            \tabular{lllll}{
#'                            ------------------------\tab-------------------------------\tab
#'                            ---------------------------------------------------------------------\cr
#'                            Time Unit \tab Formal Form Example \tab Shorthand Equivalents \cr
#'                            ------------------------\tab-------------------------------\tab
#'                            ---------------------------------------------------------------------\cr
#'                            Calendar Years \tab CAL_YEARS(N)\tab Ncy, Ncyear, Ncyears\cr
#'                            Calendar Months \tab CAL_MONTHS(N) \tab Ncm, Ncmonth, Ncmonths\cr
#'                            Calendar Days \tab CAL_DAYS(N) \tab Ncd, Ncday, Ncdays\cr
#'                            Weeks \tab WEEKS(N) \tab Nw, Nweek, Nweeks\cr
#'                            Days \tab DAYS(N) \tab Nd, Nday, Ndays\cr
#'                            Hours \tab HOURS(N) \tab Nh, Nhr, Nhrs, Nhour, Nhours\cr
#'                            Minutes \tab MINUTES(N) \tab Nm, Nmins, Nminute, Nminutes\cr
#'                            Seconds \tab SECONDS(N) \tab Ns, Nsec, Nsecs, Nsecond, 
#'                            Nseconds\cr
#'                            Milliseconds \tab MILLISECONDS(N) \tab Nms, Nmsec, Nmsecs, 
#'                            Nmillisecond, Nmilliseconds\cr
#'                            Microseconds \tab MICROSECONDS(N) \tab Nus, Nusec, Nusecs, 
#'                            Nmicrosecond, Nmicroseconds\cr
#'                            ------------------------\tab-------------------------------\tab
#'                            ---------------------------------------------------------------------
#'                            }
#'                            Where, N is a 16-bit positive integer with a maximum value of 
#'                            32767.\cr
#'                            Default : NULL\cr
#'                            Types: str\cr
#'                            Examples: 
#'                            \enumerate{
#'                            \item MINUTES(23) which is equal to 23 minutes
#'                            \item CAL_MONTHS(5) which is equal to 5 calendar months
#'                            }
#' @param pti.columns Optional Arugment.\cr
#'                    Required if \code{timebucket.duration} is not specified.\cr
#'                    Used when 'df' is to be saved as a PTI table.\cr
#'                    Specifies one or more PTI table column names. These columns are 
#'                    used, together with the PTI, to determine how rows are distributed among 
#'                    the AMPs.\cr
#'                    Default : NULL\cr
#'                    Types : character OR vector of characters
#' @param sequence.column Optional Argument.\cr
#'                        Used when 'df' is to be saved as a PTI table.\cr
#'                        Specifies the name of the column which contains the unique sequence 
#'                        numbers that differentiate the readings with the same timestamp. If this 
#'                        argument is provided, a SEQUENCED PTI table is created. Otherwise, a 
#'                        NONSEQUENCED PTI table is created. If the table is SEQUENCED PTI table, 
#'                        there can be multiple readings with the same timestamp from the same 
#'                        sensor. For nonsequenced data, there is one sensor reading per timestamp.
#'                        \cr
#'                        Default : NULL\cr
#'                        Types : character\cr
#'                        Note : 
#'                        \enumerate{
#'                        \item \code{copy_to()} creates a new column named TD_SEQNO in the PTI 
#'                        table and inserts the data in the column specified in this argument into 
#'                        TD_SEQ column of remote table.
#'                        \item Advanced SQL Engine orders the rows in a sequenced table 
#'                        based on the timestamp, and within a single timestamp value, orders the 
#'                        rows according to the sequence number.
#'                        }
#' @param seq.max Optional Argument.\cr
#'                Used only when the argument 'sequence.column' is specified and 'df' must be saved 
#'                as a PTI table.\cr
#'                Specifies the maximum number of data rows that can have the same timestamp.
#'                It takes a positive integer from 1 to 2147483647. If the argument is NULL, 
#'                Advanced SQL Engine creates the table with seq.max as 20000.\cr
#'                Default : NULL\cr
#'                Types : numeric
#' @param ...     Other parameters passed to methods.
#' @seealso \code{td_fastload}, \code{collect} function in the dplyr package, which downloads
#' the data from a remote tbl into a local tbl.
#' @return A `tbl` object with a multiset PTI/non-PTI table present in the remote database.
#' @examples
#' \donttest{
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#' 
#' # Examples 1 through 16 demonstrates how to create non-PTI table.
#' 
#' # Create a dataframe.
#' df <- data.frame(column1 = c(1,2,3), column2 = c('teradata','vantage','release'),
#'                  column3 = c(TRUE,FALSE,TRUE))
#' 
#' # Example 1: Create table from R dataframe "df" and collect statistics.
#' copy_to(con, df, name = "test_table", analyze = TRUE, overwrite = TRUE)
#' 
#' # Example 2: Append dataframe to an already created table.
#' copy_to(con, df, name = "test_table", append = TRUE)
#' 
#' # Example 3: Append to a non-existent table. A new table will be created.
#' copy_to(con, df, name = "test_table_append", append = TRUE)
#' 
#' # Example 4: Overwrite existing table "test_table" table.
#' copy_to(con, df, name = "test_table", overwrite = TRUE)
#'
#' # Example 5: Create table in a different database using dbplyr::in_schema.
#' copy_to(con, df, name = dbplyr::in_schema(td_get_context()$temp.database, "table_in_schema"))
#' 
#' # Example 6: Create temporary(Teradata volatile) table.
#' copy_to(con, df, name = "table_temp", temporary = TRUE)
#' 
#' # Example 7: Creating PI table.
#' copy_to(con, df, name = "table_PI", table.type = "PI", primary.index = c("column1","column2"))
#' 
#' # Example 8: Create NOPI table.
#' copy_to(con, df, name = "table_NOPI", table.type = "NOPI")
#' 
#' # Example 9: Create table with row_names of dataframe.
#' copy_to(con, df, name = "table_row_names", row.names = TRUE)
#' 
#' # Example 10: Create table by specifying column types as unnamed character vector.
#' copy_to(con, df, name = "table_coltypes", types = c("integer","varchar(10)","integer"))
#' 
#' # Example 11: Create table by specifying column types as named character vector.
#' copy_to(con, df, name = "table_coltypes1", types = c(column1="integer", column3="byteint"))
#' 
#' # Get the tbl_teradata whose data is to be copied to new table.
#' test_table <- tbl(con,"test_table")
#' 
#' # Example 12: Create table from tbl_teradata.
#' copy_to(con, test_table, name = "table_tbl")
#' 
#' # Example 13: Create NOPI table from tbl_teradata.
#' copy_to(con, test_table, name = "table_tbl_nopi", table.type = "NOPI")
#' 
#' # Example 14: Create PI table from tbl_teradata - primary.index uses the first column 
#' # by default.
#' copy_to(con, test_table, name = "table_tbl_pi", table.type = "PI")
#' 
#' # Example 15: Create temporary(Teradata volatile) table from tbl_teradata.
#' copy_to(con, test_table, name = "table_tbl_temp", temporary = TRUE)
#' 
#' # Example 16: Create table using "%>%" operator.
#' # This creates a temporay table with a randomly generated name, and the table will be dropped
#' # when the current session ends.
#' test_table_temp <- test_table %>% copy_to(con,df = .)
#' 
#' ## Working on PTI tables.
#' 
#' loadExampleData("sessionize_example", "sessionize_table")
#' df_tbl <- tbl(con, "sessionize_table")
#' df1 <- as.data.frame(df_tbl)
#' 
#' # Example 17 : Using R dataframe to create a non-PTI table. Note that the argument 
#' # 'timecode.column.info' is not used here. Other PTI related arguments are ignored.
#' copy_to(con, df1, name = "df_to_nonpti_table", timebucket.duration = "2h", 
#'         timezero.date = "2008-01-01", sequence.column = "adid", seq.max = 200)
#'
#' # Example 18 : Using R dataframe to create a SEQUENCED PTI table with column 'clicktime' 
#' # (TIMESTAMP type) having timecode information and column 'adid' having sequence information. 
#' # Without seq.max, largest value that sequence column can hold is 20000 (by default).
#' copy_to(con, df1, name = "df_to_pti_table", overwrite = TRUE, timebucket.duration = "2h", 
#'         timecode.column.info = c("clicktime" = "TIMESTAMP(3)"), timezero.date = "2008-01-01", 
#'         sequence.column = "adid")
#'
#' # Example 19 : Using R dataframe to create a NONSEQUENCED TEMPORARY PTI table with column 
#' # 'clicktime' (TIMESTAMP type) having timecode information. By providing 'types' argument, the
#' # column 'partition_id' is created with BIGINT datatype. The argument 'sequence.column' should
#' # not be provided for creating non-sequenced PTI tables.
#' copy_to(con, df1, name = "df_to_temp_pti_table", timebucket.duration = "2h", temporary = TRUE,
#'         timecode.column.info = c("clicktime" = "TIMESTAMP(6)"), timezero.date = "2008-01-01",
#'         types = c("partition_id" = "BIGINT"))
#' 
#' # Append to the same table using types argument.
#' copy_to(con, df1, name = "df_to_temp_pti_table", types = c("partition_id" = "BIGINT"), 
#' timecode.column.info = c("clicktime" = "TIMESTAMP(6)"), append = TRUE)
#' 
#' 
#' # Example 20 : Using non-PTI tbl_teradata to create a SEQUENCED PTI table with column 
#' # 'clicktime' (TIMESTAMP type) having timecode information and with sequence column taking
#' # largest value of 1000.
#' copy_to(con, df_tbl, name = "dftbl_to_seq_pti_table", timebucket.duration = "2h", 
#'         timecode.column.info = c("clicktime" = "TIMESTAMP(6)"), sequence.column = "adid", 
#'         seq.max = 1000)
#' 
#' # Example 21 : Create a non-PTI table using PTI tbl_teradata. Note that there are no PTI
#' # related arguments specified.
#' 
#' # Load sequenced PTI table, if not exists.
#' loadExampleData("time_series_example", "ocean_buoys_seq")
#' 
#' # Create tbl_teradata from PTI table.
#' df2 <- tbl(con, "ocean_buoys_seq")
#' 
#' # Copies data of PTI table to non-PTI table.
#' copy_to(con, df2, "pti_to_nonpti_table")
#' 
#' # Example 22 : Create a non-sequenced PTI table from sequenced PTI table with modified 
#' # time series specifications. The source PTI table is sequenced, has time zero of 
#' # DATE '2012-01-01' and timebucket duration of HOURS(1). The target PTI table is non-sequenced
#' # (the column of TD_SEQNO of source table is no longer generated column), has time zero of 
#' # DATE '2010-01-01' and timebucket duration of HOURS(2). Note that the TD_TIMECODE column's
#' # timestamp precision cannot be increased/decreased, i.e., the SQL type of TD_TIMECODE column 
#' # cannotbe modified. When the PTI related arguments of target table are same as that of source  
#' # PTI table, then target PTI table is exact same copy as that of source PTI table.
#' copy_to(con, df2, "pti_to_modified_pti_table", timebucket.duration = "2h", 
#'         timecode.column.info = c("TD_TIMECODE" = "TIMESTAMP(6)"), timezero.date = "2010-01-01")
#' }

# Note: copy_to with custom column type "number" can only support integer values

#' @importFrom dplyr copy_to
#' @importFrom dplyr db_write_table
#' @importFrom dbplyr ident_q
#' @importFrom DBI dbExecute
#' @importFrom dplyr db_has_table
#' @importFrom dplyr db_analyze
#' @importFrom dplyr compute
#' @importFrom dplyr db_drop_table
#' @importFrom dplyr rename
#' @importFrom dplyr select
#' @export
#' @rdname copy_to
#' @aliases copy_to
copy_to.Teradata <- function(dest, df, name = deparse(substitute(df)),
                             overwrite = FALSE, types = NULL, table.type = "PI",
                             primary.index = NULL, row.names = FALSE, temporary = FALSE, 
                             analyze = FALSE, append = FALSE, pti.name = NULL, 
                             timecode.column.info = NULL, timezero.date = NULL, 
                             timebucket.duration = NULL, pti.columns = NULL,
                             sequence.column = NULL, seq.max = NULL, ...) {
  
  if (!inherits(dest, "Teradata")) {
    .ta.stop("TDR_E10051")
  }
  # Determine if the table to be created is to be PTI table or not.
  # If the argument 'timecode.column.info' is specified, then we create a PTI table. In this case,
  # the argument 'primary.index' is ignored.
  # Otherwise, all argument related to PTI tables are ignored.
  is.pti <- FALSE
  if (!is.null(timecode.column.info)) {
    if (!identical(.get_driver_name(dest), "Teradata Native Driver")) {
      .ta.stop("TDR_E1101", "Teradata SQL driver for creating PTI tables.")
    }
    is.pti <- TRUE
    ignored.args <- c()
    # Ignoring row.names, if the table is PTI table.
    if (isTRUE(row.names)) {
      ignored.args <- c(ignored.args, "row.names")
      row.names <- FALSE
    }
    ignored.args <- .add_to_ignored_if_not_null(ignored.args, primary.index, "primary.index")
    if (length(ignored.args) > 0) {
      .ta.warning("TDR_W1013", paste0(ignored.args, collapse = ", "), "timecode.column.info", 
                  "specified. A PTI table creation will be attempted.")
    }
  } else {
    ignored.args <- c()
    ignored.args <- .add_to_ignored_if_not_null(ignored.args, pti.name, "pti.name")
    ignored.args <- .add_to_ignored_if_not_null(ignored.args, timezero.date, "timezero.date")
    ignored.args <- .add_to_ignored_if_not_null(ignored.args, timebucket.duration, "timebucket.duration")
    ignored.args <- .add_to_ignored_if_not_null(ignored.args, pti.columns, "pti.columns")
    ignored.args <- .add_to_ignored_if_not_null(ignored.args, sequence.column, "sequence.column")
    ignored.args <- .add_to_ignored_if_not_null(ignored.args, seq.max, "seq.max")
    if (length(ignored.args) > 0) {
      .ta.warning("TDR_W1013", paste0(ignored.args, collapse = ", "), "timecode.column.info", 
                  "missing. A non-PTI table creation will be attempted.")
    }
  }
  
  .validate.copy.arguments(df, name, overwrite, types, table.type, primary.index, row.names, 
                          temporary, analyze, append)

  # Validate PTI related arguments, only if the table to be created is PTI table.
  if (is.pti) {
    .validate.pti.related.arguments(df, pti.name, timecode.column.info, timezero.date, 
                                    timebucket.duration, pti.columns, sequence.column, seq.max, 
                                    append)
  }
  
  if (row.names && "row_names" %in% names(df)) {
    .ta.warning("TDR_W1012", "df", "row_names")
    # To insert row_names, dbWriteTable expect row.names as FALSE
    row.names = FALSE
  }

  if (name == ".")
    name <- ident_q(.teradataGenerateTempTableName("td_copy_to_",
                                                   use.default.database = TRUE, gc.onQuit = TRUE))
  
  # If the argument 'df' contains a tbl object, copy data from one table to another.
  if (inherits(df, "tbl_sql")) {
    if (!is.null(types) ||  isTRUE(row.names))
      .ta.stop("TDR_E3413", "types and row.names", "tbl_teradata")
    if (isTRUE(append)) {
      .ta.stop("TDR_E3414")
    }
    if (isTRUE(overwrite) && db_has_table(dest, name)) {
      # If you try overwriting the table with itself, then throw error.
      # If you dont do this, table is dropped when overwriting and when you try copying something
      # that does not exist, it should not allow it to happen.
      if (.get_source_definition(df) == name) {
        .ta.stop("TDR_E3415")
      }
      db_drop_table(dest, name)
    }
    # Create PTI clause if the table to be created is PTI table.
    pti_clause <- NULL
    if (is.pti) {
      pti_clause <- .generate_pti_clause( timecode.column.info = timecode.column.info, 
                                          timezero.date = timezero.date, 
                                          timebucket.duration = timebucket.duration, 
                                          pti.columns = pti.columns, 
                                          sequence.column = sequence.column, 
                                          seq.max = seq.max)
      
      # Rearrange and rename columns of tbl_teradata.
      if (!is.null(sequence.column)) {
        df <- df %>% rename("TD_TIMECODE" = names(timecode.column.info), "TD_SEQNO" = sequence.column)
        all_cols <- colnames(df)
        # Rearrange using select.
        df <- df %>% select(.get("timecodeColumn"), .get("sequenceColumn"), 
                            all_cols[!all_cols %in% c(.get("timecodeColumn"), .get("sequenceColumn"))])
      } else {
        df <- df %>% rename("TD_TIMECODE" = names(timecode.column.info))
        all_cols <- colnames(df)
        # Rearrange using select.
        df <- df %>% select(.get("timecodeColumn"), 
                            all_cols[!all_cols %in% c(.get("timecodeColumn"))])
      }
    }
    out <- compute( df, name = name, temporary = temporary, table.type = table.type,
                    primary.index = primary.index, analyze = FALSE, pti.clause = pti_clause, 
                    pti.name = pti.name)
    return(invisible(out))
  }

  ## Processing dataframe df and types arguments if the table is PTI table.
  pti_type <- NULL
  
  if (is.pti) {
    all_cols <- names(df)
    timecode_column <- names(timecode.column.info)
    # Rearranging insert order - TIMECODE column as 1st column and SEQ column as 2nd column.
    if (!is.null(sequence.column)) {
      pti_type <- "SEQ"
      df <- df %>% select(timecode_column, sequence.column, 
                          all_cols[!all_cols %in% c(timecode_column, sequence.column)])
    } else {
      pti_type <- "NON_SEQ"
      df <- df %>% select(timecode_column, 
                          all_cols[!all_cols %in% c(timecode_column)])
    }
    
    # Updating the names of the timecode and sequence columns.
    names(df)[1] <- .get("timecodeColumn")
    if (!is.null(sequence.column)) {
      names(df)[2] <- .get("sequenceColumn")
    }

    # Processing the 'types' argument, if provided.
    if (!is.null(types)) {
      types_len <- length(types)
      if (!is.null(names(types))) {
        # If 'types' is a named vector.
        types <- types[!names(types) %in% c(names(timecode.column.info), sequence.column)]
      } else {
        new_cols <- all_cols
        
        # Removing timecode column type from 'types' argument.
        timecode_col_idx <- which(new_cols == names(timecode.column.info))
        types <- types[-c(timecode_col_idx)]
        new_cols <- new_cols[-c(timecode_col_idx)]
        
        # Removing sequence column (if provided) type from 'types' argument.
        if (!is.null(sequence.column)) {
          seq_col_idx <- which(new_cols == sequence.column)
          types <- types[-c(seq_col_idx)]
          new_cols <- new_cols[-c(seq_col_idx)]
        }
        
        # Changing unnamed vector of 'types' to named vector for easy processing.
        named_types <- c()
        for (i in 1:length(new_cols)) {
          named_types[new_cols[i]] <- types[i]
        }
        types <- named_types
      }
      # Print message - ignoring types of timecode and sequence columns.
      if (types_len != length(types)) {
        .ta.warning("TDR_W1014")
      }
    }
  }

  ## Validating table and dataframe based on the arguments 'append' and 'overwrite'.
  is_table_present <- db_has_table(dest, name)
  if (is_table_present) {
    is_table_present <- TRUE
    # If overwrite is TRUE, then drop table before overwriting.
    # When we overwrite a table, we will not check if the metadata matches. This is to keep it 
    # consistent with https://github.com/tidyverse/dbplyr/blob/master/R/verb-copy-to.R
    if (isTRUE(overwrite)) {  
      .ta.print("TDR_P3401")
      db_drop_table(dest, name)
      is_table_present <- FALSE
    }
    # If compareMetadata returns false when append is set to TRUE, throw error.
    if (isTRUE(is_table_present) && isTRUE(append) && 
        !.compareMetadata(dest, df, name, row.names, types, timecode.column.info, sequence.column)) {
      .ta.stop("TDR_E3409", "append", name, "df")
    }
    # If table exists and neither append or overwrite are set, then display error.
    if (!append && !overwrite) {
      .ta.stop("TDR_E3401", "copy_to", name)
    }
  }
  
  # Now if we have reached up to this point, we have to create table.
  if (!is_table_present) { 
    # If table does not exist, then create a table
    if (!is.pti) {
      .createTableInDB(dest, df, name, table.type = table.type, primary.index = primary.index, 
                       row.names = row.names, types = types, temporary = temporary, 
                       is.pti = is.pti)
    } else {
      pti_clause <- .generate_pti_clause(timecode.column.info = timecode.column.info, 
                                         timezero.date = timezero.date, 
                                         timebucket.duration = timebucket.duration, 
                                         pti.columns = pti.columns, 
                                         sequence.column = sequence.column, 
                                         seq.max = seq.max)
      .createTableInDB(dest, df, name, table.type = NULL, primary.index = NULL, 
                       row.names = NULL, types = types, temporary = temporary, is.pti = is.pti, 
                       pti.clause = pti_clause, pti.type = pti_type, pti.name = pti.name)
    }
  }

  ## Insert dataframe contents into DB table.
  id <- name # Store a copy of the table name.
  # If table name is of in_schema format, then extract the schema and table and pass as a 
  # DBI::Id object.
  if (inherits(name, "ident_q")) {
    id <- DBI::Id(schema = .extractDatabaseNameQuoted(name), table = .extractTableNameQuoted(name))
  }
  
  .insertDataInDBandAnalyzeTable( dest, df, id, table.type, primary.index, row.names, 
                                  types = types, analyze)
  
  invisible(tbl(dest, name))
  
  # Not working as expected. It displays schema names again under the select schema names.
  # Same behaviour is there with ODBC driver.
  # I have kept this change commented for reviewers to know this case.
  # I will remove this file before I commit.
  # observer <- getOption("connectionObserver")
  # if (!is.null(observer)){
  #  observer$connectionUpdated("tdplyr", DBI::dbGetInfo(con)$host, hint = name)
  # }
}

# This function generates PTI clause for time series PTI tables.
# The arguments' descriptions are same as that of copy_to.
.generate_pti_clause <- function(timecode.column.info, timezero.date, timebucket.duration, 
                                 pti.columns, sequence.column, seq.max) {
  # PTI clause starts with timecode type.
  pti.clause <- timecode.column.info[[1]]
  if (!is.null(timezero.date)) {
    pti.clause <- gettextf("%s, DATE '%s'", pti.clause, timezero.date)
  }
  if (!is.null(timebucket.duration)) {
    pti.clause <- gettextf("%s, %s", pti.clause, timebucket.duration)
  }
  if (length(pti.columns) > 0) {
    cols <- lapply(pti.columns, function(x) {
           .teradataQuoteArg(x, quote = "\"", callFromWrapper = FALSE)
    })
    pti.clause <- gettextf("%s, COLUMNS(%s)", pti.clause, paste0(cols, collapse = ", "))
  }
  if (!is.null(sequence.column)) {
    pti.clause <- gettextf("%s, %s", pti.clause, "SEQUENCED")
    if (!is.null(seq.max)) {
      pti.clause <- gettextf("%s (%s)", pti.clause, as.integer(seq.max))
    }
  }
  return(pti.clause)
}

# This function compares the meta data of R dataframe and table present in remote database.
# Parameters:
#   con       : Specifies the remote data source connection.
#   df        : Specifies the R dataframe.
#   name      : Specifies the table name present in remote data source.
#   row.names : Determines whether to include row_names column or not.
#   types     : Specifies the custom data types for table.
# Returns:
#   value   : Returns true if meta data matches between R dataframe and remote table, else FALSE.
.compareMetadata <- function(con, df, name, row.names = FALSE, types, 
                             timecode.column.info = NULL, sequence.column = NULL) {
  # Get metadata from the remote table.
  table_desc <- .ta.describe.columns.wrapper(con, name, return.vector = TRUE)
  df_types <- c()

  # The arguments timecode.column.info and sequence.column (if sequenced) are mandatory for 
  # appending data to PTI tables.
  req_args <- c()
  if (!is.na(table_desc$time_series_types[[1]]) && is.null(timecode.column.info)) {
    req_args <- c(req_args, "timecode.column.info")
  }
  if (length(table_desc$time_series_types) > 1 && !is.na(table_desc$time_series_types[[2]]) && 
      is.null(sequence.column)) {
    req_args <- c(req_args, "sequence.column")
  }
  if (length(req_args) > 0) {
    .ta.stop("TDR_E3416", paste0(req_args, collapse = ", "), "append", "set to TRUE for PTI tables")
  }

  # Here we populate the data types of the dataframe to compare with existing table metadata.
  df_names <- sapply(names(df), tolower)
  
  # Process the argument 'row.names'.
  # If row_names column is not present (when append = TRUE) in remote table.
  if (row.names && !("row_names" %in% table_desc$names))
    .ta.stop("TDR_E3412", "row_names", "row_names")
  # If row_names column is present in dataframe columns, ignore row.names argument.
  if (row.names == TRUE && "row_names" %in% df_names)
    row.names <- FALSE
  
  i <- 0 # i = 1 if the column 'row_names' is present in remote table.
  if (row.names) {
    if (table_desc$names[1] != "row_names")
      return(FALSE)
    if (.compareType(table_desc$types[1],.getSQLDataType(con, row.names(df))))
      return(FALSE)
    i <- 1
  }
  
  # If number of columns in df and the remote table doesn't match.
  if (ncol(df) + i != length(table_desc$names))
    return(FALSE)
  
  # Get the dataframe types based on the argument 'types'.
  if (is.null(types)) {
    # If there is no 'types' argument, get the SQL data types using mappings.
    df_types <- sapply(df, .getSQLDataType, con = con)

    # If the timecode column is present in 'df_types', which is not of type 'date', assign the type
    # of the timecode column as timestamp. Currently, the function getSQLDataType returns 'varchar'
    # for timecode columns
    timecode_column <- .get("timecodeColumn")
    if (timecode_column %in% names(df_types) && df_types[timecode_column] != "date") {
      df_types[timecode_column] <- "timestamp"
    }
  } else {
    # The argument 'types' can be named or unnamed vector.
    nm_types <- names(types)
    
    if (is.null(nm_types)) {
      # If user specifies an unnamed vector.
      df_types <- types
    } else { 
      # If user specifies a named vector.
      for (idx in (i + 1):length(table_desc$names)) {
        # Find the position of the df column in specified types.
        pos = match(tolower(table_desc$names[idx]), tolower(nm_types), 0L)

        # If type has been specified for a column name, then use that type, 
        # else use from table description, if it is non-PTI table. If the table is PTI
        # table, check for the timecode column and assign its type to 'timestamp'.
        if (pos != 0) {
          df_types <- c(df_types, types[pos])

        } else if (tolower(table_desc$names[idx]) == "td_timecode" && 
                   .getSQLDataType(con, df[,idx]) != "date") {
         df_types <- c(df_types, "timestamp")
        } else {
          # dataframe df doesn't contain row_names column, hence (idx - i).
          df_types <- c(df_types, .getSQLDataType(con = con, df[,idx - i]))
        }
      }
    }
  }

  for (j in 1:ncol(df)) {
    # Comparing the names and types of the columns in the df and the remote table.
    # Convert the table names to lower case because the column name from backend
    # is not always in lower case.
    if (df_names[j] == tolower(table_desc$names[j + i]) && 
        (.compareType(table_desc$types[j + i], tolower(.stripSize(df_types[j])))))
      next
    else
      return(FALSE)
  }
  return(TRUE)
}

# This function strips the size value from the type.
# Parameters:
#   type  : Specifies the datatype.For example, varchar(1024), timestamp(6).
#
# Returns:
#   Size value stripped type. For example, varchar, timestamp for the above type examples.
.stripSize <- function(type) {
  i <-  gregexpr("(", type, fixed = TRUE)[[1]][1]
  if (i == -1L)
    return(type)
  substr(type, 1, i - 1)
}

# This function returns the first column based on row.names argument.
# Parameters:
#   df_names  : Specifies the names of the columns in R dataframe.
#   row.names : Specifies whether the column 'row_names' should be considered as first column.
#   row_names : Specifies the row.names column name.
#
# Returns:
#   The column 'row_names' if row.names is TRUE and the column 'row_names' is not present in
#   df columns. Otherwise, the function returns the first column name in the dataframe df.
.getFirstColumn <- function(df_names, row.names, row_names = "row_names") {
  if (row.names && !(row_names %in%  df_names))
    return(row_names)
  df_names[1]
}

# This function converts complex and raw to character.
# Parameters:
#   df  : Specifies the R dataframe.
#
# Returns:
#   The converted dataframe.
.coerceToCharacter <- function(df) {
  for (name in names(df)) {
    if (is.complex(df[[name]]) || is.raw(df[[name]]))
      df[[name]] <- as.character(df[[name]])
  }
  return(df)
}

# This function determines if the type in the argument 'datatype' is present in the array of types.
# Parameters:
#   arr       : Specifies the array of data types.
#   datatype  : Specifies the datatype which need to the checked in the array of data types.
#
# Returns:
#   TRUE, if present; FALSE otherwise.
.compareType <- function(arr, datatype) {
  for (x in arr) {
    if (datatype %in% x)
      return(TRUE)
  }
  return(FALSE)
}

#' @importFrom DBI dbExecute
# This function creates a new table for a dataframe in the DB by issuing/executing a SQL statement.
# The arguments' descriptions are same as that of copy_to.
.createTableInDB <- function(dest, df, name, table.type = NULL, primary.index = NULL, 
                             row.names = NULL, types = NULL, temporary = NULL,
                             is.pti = FALSE, pti.clause = NULL, pti.type = NULL, pti.name = NULL){
  tryCatch({
    # Construct the CREATE TABLE QUERY.
    createTableStmnt <- .ta.constructCreateTableSQL(dest, df, table.name = name, types = types, 
                                                    table.type = table.type, row.names = row.names,
                                                    primary.index = primary.index,
                                                    temporary = temporary, pti_clause = pti.clause, 
                                                    pti_type = pti.type, pti_name = pti.name)

    if (isTRUE(getOption("td.debug.enable"))) {
      .ta.print(createTableStmnt)
    }
    # Execute the CREATE TABLE QUERY.
    dbExecute(dest, createTableStmnt)
  },
  error = function(e){
    .ta.stop(e)
  })  
}

#' @importFrom dplyr db_write_table
#' @importFrom dplyr db_analyze
# This function is used to insert dataframe contents into a DB table.
# The arguments' descriptions are same as that of copy_to.
.insertDataInDBandAnalyzeTable <- function(dest, df, name, table.type, primary.index, row.names, 
                                           types, analyze){
  tryCatch({
    # This converts raw and complex data types to character
    df <- .coerceToCharacter(df)
    
    if ("Teradata Native Driver" %in% .get_driver_name(dest)) {
      #check if any columns needs to be updated. Example logical - convert TRUE - 1, FALSE - 0
      df <- updateColumnsForNativeDriver(df)
    }

    # Insert data into the table in database
    table <- db_write_table(dest, name, types = types, values = df,
                            append = TRUE, temporary = FALSE, row.names = row.names)
    
    # Perform db_analyze
    if (analyze) {
      if (tolower(table.type) == "nopi" || is.null(primary.index))
        db_analyze(dest, name, .getFirstColumn(names(df), row.names))
      else
        db_analyze(dest, name, primary.index)
    }
  },
  error = function(e){
    .ta.stop(e)
  })
}

# This function is used only for native driver when any of the column
# contains logical columns. In that case TRUE/FALSE will be converted into
# 1/0 to store into byteint column in the  database.
# Parameters :
#   df - A tbl_teradata or dataframe object.
# Returns:
#   A tbl_teradata or dataframe object.
updateColumnsForNativeDriver <- function(df){
  column_names <- colnames(df)
  for (cnt in 1:length(column_names)) {
    if ("logical" == typeof(df[[column_names[cnt]]])) {
      df[[column_names[cnt]]] <- as.numeric(df[[column_names[cnt]]])
    }
  }
  return(df)
}

# This function verifies if the input provided in the argument 'types' is a 
# named and unnamed vector. If the input provided is an unnamed vector, then the 
# function verifies the types provided in the 'types' argument against data 
# types of all the columns. If the input is a named vector, the columns are 
# verified against the dataframe's column names. Based on the validations, 
# specific errors are raised.
# Parameters:
#   df        : Specifies the R dataframe.
#   types     : Specifies the custom data types for table.
# Returns:
#   Nothing
# Raises:
#   Appropriate exceptions based on the arguments.
.verifyDataTypes <- function(df, types){
  if (!is.null(types)) {
    df_names <- tolower(names(df))
    nmTypes <- names(types)
    
    if (!inherits(types, "character")) {
      .ta.stop("TDR_E3104", "argument", "types", "named or unnamed character vector")
    }
    
    # Case where an item in types vector may be an empty string.
    if ("" %in% types)
      .ta.stop("TDR_E3003","types")
    
    if (is.null(nmTypes)) {
      # Handle case where types <- c("integer", "varchar(10)") and df has 3 columns.
      if (!is.null(types) && length(types) < length(df_names)) {
        .ta.stop("TDR_E3404", "types")
      }
    } else {
      nmTypes <- nmTypes[nmTypes != ""]
      
      # Check if columns provided in types match the column names of dataframe.
      # Handle case where types <- c(col1 = "byteint") and df does not have column 'col1'.
      if (FALSE %in% (tolower(nmTypes) %in% df_names)) {
        missing_cols <- setdiff(tolower(nmTypes), df_names)
        .ta.stop("TDR_E3102", paste(missing_cols,collapse = ","), "types", "df")
      }
      # Handle specification where user enter a mix of named columns and unnamed columns for types.
      # Handles case where types <- c(col1 = "integer", "byteint")
      if (length(types) != length(nmTypes)) {
        .ta.stop("TDR_E3406", "types")
      }
    }
  }
}

# This function validates the arguments of PTI related arguments of copy_to.
# The arguments' descriptions are same as that of copy_to.
.validate.pti.related.arguments <- function(df, pti.name, timecode.column.info, timezero.date, 
                                            timebucket.duration, pti.columns, sequence.column,
                                            seq.max, append) {
  
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("pti.name", pti.name, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("timecode.column.info", timecode.column.info, TRUE, c("character", "list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("timezero.date", timezero.date, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("timebucket.duration", timebucket.duration, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("pti.columns", pti.columns, TRUE, c("character", "list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("sequence.column", sequence.column, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seq.max", seq.max, TRUE, c("numeric", NA)))
  
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied correct type of argument.
  # Ignoring type validations for timecode.column.info argument as manual validations
  # are done for them below.
  .validateArgumentTypes(argInfoMatrix[c(-2),])
  
  # Checks if the argument is empty string, if not NULL.
  .validateInputColumnsNotEmpty(pti.name)
  .validateInputColumnsNotEmpty(timezero.date)
  .validateInputColumnsNotEmpty(pti.columns)
  .validateInputColumnsNotEmpty(sequence.column)
  
  ## Validations for the timecode.column.info argument.
  # Check if the argument is a named vector of length 1.
  if (length(timecode.column.info) != 1 || is.null(names(timecode.column.info))) {
    .ta.stop("TDR_E3104", "argument", "timecode.column.info", "named vector of length 1")
  }
  
  # Checks if the columns in the arguments are present in the dataframe df.
  .validateTblHasArgumentColumns(names(timecode.column.info), "timecode.column.info", df, "df")
  .validateTblHasArgumentColumns(pti.columns, "pti.columns", df, "df")
  .validateTblHasArgumentColumns(sequence.column, "sequence.column", df, "df")
  
  # Checks if the values of the argument is either timestamp or date.
  if (!grepl("^TIMESTAMP\\([0-6])$", x = timecode.column.info[[1]], ignore.case = TRUE) &&
      !grepl("^TIMESTAMP\\([0-6])(\\s+)WITH(\\s+)TIME(\\s+)ZONE$", x = timecode.column.info[[1]], 
             ignore.case = TRUE) &&
      !grepl("^DATE$", x = timecode.column.info[[1]], ignore.case = TRUE)) {
    .ta.stop("TDR_E3104", "'values' of the argument", "timecode.column.info", 
             "TIMESTAMP(n), TIMESTAMP(n) WITH TIME ZONE and DATE with n taking values from 0 through 6 inclusive")
  }

  # Validate the timezero.date argument.
  if (!is.null(timezero.date) && 
      !grepl("^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$", x = timezero.date)) {
    .ta.stop("TDR_E3104", "argument", "timezero.date", "Date in character YYYY-MM-DD format")
  }
  
  if (is.null(timebucket.duration) && is.null(pti.columns) && !isTRUE(append)) {
    # Append doesn't require both timebucket.duration and pti.columns
    .ta.stop("TDR_E3009", "timebucket.duration", "pti.columns")
  }
  
  # Validate the timebucket.duration argument.
  .validate_time_bucket_duration(timebucket.duration)
  
  # Validate sequence.column and seq.max arguments.
  if (is.null(sequence.column) && !is.null(seq.max)) {
    .ta.stop("TDR_E3101", "seq.max", "sequence.column", "specified")
  }
  if (!is.null(seq.max)) {
    if (!.validate_integer_bounds(seq.max, lbound = 1, ubound = 2147483647) || seq.max %% 1 != 0) {
      .ta.stop("TDR_E3104", "argument", "seq.max", "A positive integer from 1 through 2147483647")
    }
  }
}

# This function validates the arguments of regular copy_to without PTI arguments.
# The arguments' descriptions are same as that of copy_to.
.validate.copy.arguments <- function(df, name, overwrite, types, table.type, primary.index, 
                                     row.names, temporary, analyze, append) {
  
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("df", df, FALSE, c("data.frame", "ta.data.frame", "tbl_teradata", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("name", name, TRUE, c("character", "ident_q", "ident", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("overwrite", overwrite, TRUE, c("logical", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("types", types, TRUE, c("character", "list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("table.type", table.type, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("primary.index", primary.index, TRUE, c("character", "list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("row.names", row.names, TRUE, c("logical", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("temporary", temporary, TRUE, c("logical", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("analyze", analyze, TRUE, c("logical", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("append", append, TRUE, c("logical", NA)))
  
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument.
  # Ignoring type validations for df and types arguments as manual validations
  # are done for them below.
  .validateArgumentTypes(argInfoMatrix[c(-1, -4),])
  
  # The below arguments should not take NULL values as there is default type for them.
  # There can be cases when user can give NULL values to these and these are not
  # caught in .validateArgumentTypes function.
  .validateNullValues("name", name)
  .validateNullValues("overwrite", overwrite)
  .validateNullValues("table.type", table.type)
  .validateNullValues("row.names", row.names)
  .validateNullValues("temporary", temporary)
  .validateNullValues("analyze", analyze)
  .validateNullValues("append", append)
  
  ## Validations for dataframe 'df'.
  if (!is.data.frame(df) && !inherits(df, "tbl_teradata")) {
    # If 'df' is of invalid type.
    .ta.stop("TDR_E1006", "df", "data.frame or tbl_teradata")
  }
  if (length(names(df)) == 0L) {
    # If there are no columns in the dataframe
    .ta.stop("TDR_E3410")
  }
  if (ncol(df) > .get("maxNumberOfColumns")) {
    # If number of columns in the dataframe > max number of columns allowed by Teradata.
    .ta.stop("TDR_E3407", .get("maxNumberOfColumns"), ncol(df))
  }
  
  # Checks if the argument is empty string, if not NULL.
  .validateInputColumnsNotEmpty(name)
  .validateInputColumnsNotEmpty(primary.index)
  
  # Checks if the columns in the arguments are present in the dataframe df.
  .validateTblHasArgumentColumns(primary.index, "primary.index", df, "df")
  
  # Check the argument 'types'.
  if (!inherits(df, "tbl_sql")) {
    # Types is not valid argument for tbl_teradata.
    .verifyDataTypes(df, types)
  }
  
  # Validations for the argument 'table.type'.
  # Checking permitted values for the argument table.type
  table.type.permitted.values <- list("NOPI", "PI")
  .validatePermittedValues(table.type, table.type.permitted.values)
  
  if (isTRUE(append) &&  isTRUE(overwrite)) {
    .ta.stop("TDR_E3408", "append", "overwrite", "set to TRUE")
  }
}

# This is an utility function which add the argument to vector of ignored arguments if the argument
# is not null.
.add_to_ignored_if_not_null <- function(ignored_args, arg_value, arg_name) {
  if (!is.null(arg_value)) {
    ignored_args <- c(ignored_args, arg_name)
  }
  return(ignored_args)
}