# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

##################################################
# Connection related Getters
#####################################################

# driver name
.get_driver_name <- function(con){
  UseMethod('.get_driver_name')
}

.get_driver_name.DBIConnection <- function(con) {
  .ta.stop("TDR_E1005")
}

#
# Getter's for getting the driver version
# Args:
#   con - A connection object
# Returns:
#   driver version of con
#
.get_driver_version <- function(con) {
  UseMethod(".get_driver_version")
}

.get_driver_version.DBIConnection <- function(con) {
  .ta.stop("TDR_E1005")
}

# user
.get_username <- function(con) {
  UseMethod(".get_username")
}

.get_username.DBIConnection <- function(con) {
  .ta.stop("TDR_E1005")
}

# db version
.get_version <- function(con) {
  UseMethod(".get_version")
}

.get_version.DBIConnection <- function(con) {
  .ta.stop("TDR_E1005")
}

#
# Getter's for getting database name attribute
# Args:
#   con - A connection object
# Returns:
#   Default database associated with connection
#
.get_dbname <- function(con, ...) {
  UseMethod(".get_dbname")
}

# We only support odbc connection because
# other connection objects will not have the same structure
.get_dbname.DBIConnection <- function() {
  # Throws Invalid Connection object error
  .ta.stop("TDR_E1005")
}

#
# Getter's for getting port attribute
# Args:
#   con - A connection object
# Returns:
#   port attribute of con
#
.get_port <- function(con) {
  UseMethod(".get_port")
}

.get_port.DBIConnection <- function() {
  .ta.stop("TDR_E1005")
}

#
# Getter's for getting servername attribute
# Args:
#   con - A connection object
# Returns:
#   servername or dbcName associated with the connection object
#
.get_servername <- function(con) {
  UseMethod(".get_servername")
}

# We only support odbc connection because
# other connection objects will not have the same structure
.get_servername.DBIConnection <- function() {
  # Throws Invalid Connection object error
  .ta.stop("TDR_E1005")
}

#
# Getter for getting transaction mode for the connection
# 
# Returns:
#   transaction mode associated with the connection object
#
.get_transaction_mode <- function() {
  con <- .taConnection()
  tmode <- NULL
  
  # Use native driver escape clause to get required information.
  if (.get_driver_name(con) == "Teradata Native Driver") {
    tmode <- dbGetQuery(con, "{fn teradata_nativesql}{fn teradata_provide(transaction_mode)}")[[1]]
    tmode <- if (tmode == "TERA") "T" else "A"
  } else {
    tmode <- dbGetQuery(con, "select transaction_mode from dbc.sessioninfov where sessionno=SESSION")[[1]]
  }
  
  return(tmode)
}

##################################################
# Connection related Getters for ODBC
#####################################################

.get_driver_name.OdbcConnection <- function(con){
  'Teradata ODBC'
}

.get_driver_version.OdbcConnection <- function(con) {
  con@info$driver.version
}

.get_username.OdbcConnection <- function(con) {
  toupper(con@info$username)
}

.get_version.OdbcConnection <- function(con) {
  arr <- unlist(strsplit(con@info$db.version, " "))
  if (length(arr) > 1)
    arr[length(arr)]
  else
    arr[1]
}

.get_dbname.OdbcConnection <- function(con) {
  toupper(con@info$dbname)
}


.get_port.OdbcConnection <- function(con) {
  con@info$port
}

.get_servername.OdbcConnection <- function(con) {
  toupper(con@info$servername)
}


##################################################
# Connection related Getters for NATIVE Driver
# TODO: All these getters must be fixed once dbGtInfo is verified: ELE-1398
#####################################################

.get_driver_name.TeradataConnection <- function(con){
  'Teradata Native Driver'
}

#' @importFrom utils packageVersion
.get_driver_version.TeradataConnection <- function(con) {
  # Use dbGetInfo
  packageVersion("teradatasql")
}

.get_username.TeradataConnection <- function(con) {
  # TODO replace with dbGetInfo if Native driver provides it
  dbGetQuery(con, "select user")[[1]]
}

#' @importFrom DBI dbGetInfo
.get_version.TeradataConnection <- function(con) {
  # Use dbGetInfo
  dbGetInfo(con)$db.version
}

#' @importFrom DBI dbGetInfo
.get_dbname.TeradataConnection <- function(con) {
  dbGetInfo(con)$dbname
}

#' @importFrom DBI dbGetInfo
.get_port.TeradataConnection <- function(con) {
  # Use dbGetInfo
  dbGetInfo(con)$port
}

#' @importFrom DBI dbGetInfo
.get_servername.TeradataConnection <- function(con) {
  # Use dbGetInfo
  dbGetInfo(con)$host
}
