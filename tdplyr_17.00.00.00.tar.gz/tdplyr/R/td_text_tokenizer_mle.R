# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 3.10
# 
# ################################################################## 

# Description:
#   The TextTokenizer function extracts English, Chinese, or Japanese 
#   tokens
#   			from text. Examples of tokens are words, punctuation marks, and 
#   numbers. Tokenization is
#   			the first step of many types of text analysis.
# 
# Args:
#   data -
#     Required Argument.\cr
#     The relation contains the text to be scanned\cr
#   
#   data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   dict.data -
#     Optional Argument.\cr
#     The relation that contains the dictionary for segementing words.\cr
#   
#   dict.data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "dict.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   text.column -
#     Required Argument.\cr
#     Specifies the name of the input tbl_teradata column that contains the 
#     text to tokenize\cr
#     Types: character
#   
#   language -
#     Optional Argument.\cr
#     Specifies the language of the text in text_column:  en (English, the 
#     default),  zh_CN (Simplified Chinese),  zh_TW (Traditional Chinese),  
#     jp (Japanese)\cr
#     Default Value: "en"\cr
#     Permitted Values: en, zh_CN, zh_TW, jp\cr
#     Types: character
#   
#   model -
#     Optional Argument.\cr
#     Specifies the name of model file that the function uses for 
#     tokenizing. The model must be a conditional random-fields model and 
#     model_file must already be installed on the database. If you omit 
#     this argument, or if model_file is not installed on the database, 
#     then the function uses white spaces to separate English words and an 
#     embedded dictionary to tokenize Chinese text. Note: If you specify 
#     Language("jp"), the function ignores this argument.\cr
#     Types: character
#   
#   output.delimiter -
#     Optional Argument.\cr
#     Specifies the delimiter for separating tokens in the output. The 
#     default value is slash (/).\cr
#     Default Value: "/"\cr
#     Types: character
#   
#   output.byword -
#     Optional Argument.\cr
#     Specifies whether to output one token in each row. (output one line 
#     of text in each row).\cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   user.dictionary -
#     Optional Argument.\cr
#     Specifies the name of the user dictionary to use to correct results 
#     specified by the model. If you specify both this argument and a 
#     dictionary tbl_teradata (dict), then the function uses the union of 
#     user_dictionary_file and dict as its dictionary. That describes the 
#     format of user_dictionary_file and dict. Note: If the function finds 
#     more than one matched term, it selects the longest term for the first 
#     match.\cr
#     Types: character
#   
#   accumulate -
#     Optional Argument.\cr
#      Specifies the names of the input tbl_teradata columns to copy to the 
#     output table.\cr
#     Types: character OR vector of Strings (character)
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   dict.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "dict.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_text_tokenizer_mle" which is 
#   a named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_text_tokenizer_mle <- function(
  data = NULL,
  dict.data = NULL,
  text.column = NULL,
  language = "en",
  model = NULL,
  output.delimiter = "/",
  output.byword = FALSE,
  user.dictionary = NULL,
  accumulate = NULL,
  data.sequence.column = NULL,
  dict.data.sequence.column = NULL,
  data.order.column = NULL,
  dict.data.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("dict.data", dict.data, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("dict.data.order.column", dict.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("text.column", text.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("language", language, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("model", model, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.delimiter", output.delimiter, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.byword", output.byword, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("user.dictionary", user.dictionary, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("dict.data.sequence.column", dict.data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  .validateInputTableDataType(dict.data, NULL)
  
  # Check for permitted values
  languagePermittedValues <- list("EN", "ZH_CN", "ZH_TW", "JP")
  .validatePermittedValues(language, languagePermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(text.column)
  .validateTblHasArgumentColumns(text.column, "text.column", data, "data")
  
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(dict.data.sequence.column)
  .validateTblHasArgumentColumns(dict.data.sequence.column, "dict.data.sequence.column", dict.data, "dict.data")
  
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  .validateInputColumnsNotEmpty(dict.data.order.column)
  .validateTblHasArgumentColumns(dict.data.order.column, "dict.data.order.column", dict.data, "dict.data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TextColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(text.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(accumulate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(accumulate,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(language) && !missing(language)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "InputLanguage")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(language, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(output.delimiter) && !missing(output.delimiter)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputDelimiter")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.delimiter, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(output.byword) && !missing(output.byword)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputByWord")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.byword, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(user.dictionary)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "userDictionaryFile")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(user.dictionary, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(model)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ModelFile")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(model, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (!is.null(dict.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("dict:", .teradataCollapseArgVector(dict.data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "ANY")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # Process dict.data
  if (!is.null(dict.data)) {
    tableRef <- .teradataOnClauseFromDataFrame(dict.data)
    funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "dict")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(dict.data.order.column, "\""))
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "TextTokenizer",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("TextTokenizer", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data, dict.data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_text_tokenizer_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_text_tokenizer <- td_text_tokenizer_mle
