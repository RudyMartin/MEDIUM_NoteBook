# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Adithya Avvaru (adithya.avvaru@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.14
# 
# ################################################################## 

# Description:
#   VARMAX (Vector Autoregressive Moving Average model with eXogenous 
#   variables) extends the ARMA/ARIMA model in two ways:\cr
#     1. To work with time series with multiple response variables 
#        (vector time series).\cr
#     2. To work with exogenous variables, or variables that are 
#       independent of the other variables.
#      in the system.\cr
# 
# Args:
#   data -
#     Required Argument.\cr
#     The tbl_teradata or view stores the input sequence.\cr
#   
#   data.partition.column -
#     Optional Argument\cr
#     Specifies Partition By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Default Value: 1\cr
#     Types: character OR vector of Strings (character)
#   
#   data.order.column -
#     Required Argument.\cr
#     Specifies Order By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   response.columns -
#     Required Argument.\cr
#     Specifies the columns containing the response data. Null values are 
#     acceptable at the end of the series. If step.ahead is specified, the 
#     function will report predicted values for the missing values, taking 
#     into account values from the predictor columns for those time 
#     periods.\cr
#     Types: character OR vector of Strings (character)
#   
#   exogenous.columns -
#     Optional Argument.\cr
#     Specifies the columns containing the independent (exogenous) 
#     predictors. If not specified, the model will be calculated without 
#     exogenous vectors.\cr
#     Types: character OR vector of Strings (character)
#   
#   partition.columns -
#     Optional Argument.\cr
#     Specifies the partition columns that will be passed to the output. If 
#     not specified, the output will not contain partition columns.\cr
#     Types: character OR vector of Strings (character)
#   
#   orders -
#     Optional Argument.\cr
#     Specify the parameters p, d, q for VARMA model. This argument 
#     consists of 3 non-negative int values separated by commas. It should 
#     be three non-negative int values separated by commas. The p and q 
#     must be an integer between 0 and 10, inclusive. The d must be between 
#     0 and 1, inclusive.\cr
#     Types: character
#   
#   seasonal.orders -
#     Optional Argument.\cr
#     Specify seasonal parameters sp, sd, sq for VARMA model. This argument 
#     consists of 3 non-negative integer values separated by commas. The sp 
#     and sq must be an integer between 0 and 10, inclusive. The sd must be 
#     between 0 and 3, inclusive If not specified, the model will be 
#     treated as a non-seasonal model.If the seasonal.orders argument is 
#     used, the period argument should also be present.\cr
#     Types: character
#   
#   period -
#     Optional Argument.\cr
#     Specifies the period of each season. Must be a positive integer 
#     value. If the period argument is used, the seasonal.orders argument 
#     must also be present. If not specified, the model will be treated as 
#     a non-seasonal model. \cr
#     Types: integer
#   
#   exogenous.order -
#     Optional Argument.\cr
#     Specifies the order of exogenous variables. If the current time is t 
#     and exogenous.order isb, the following values of the exogenous time 
#     series will be used in calculating the response: Xt Xt-1 ... Xt-b+1. 
#     If not specified, the model will be calculated without exogenous 
#     vectors. \cr
#     Types: integer
#   
#   lag -
#     Optional Argument.\cr
#     Specifies the lag in the effect of the exogenous variables on the 
#     response variables. For example, if lag = 3, and exogenous.order is 
#     b, Yi will be predicted based on Xi-3 to Xi-b-2. \cr
#     Default Value: 0\cr
#     Types: integer
#   
#   include.mean -
#     Optional Argument.\cr
#     Specify whether mean vector of the response data series (constant c 
#     in the formula) is added in the VARMA model. Note that if this 
#     argument is True, the difference parameters d (in the orders 
#     argument) and sd (in the seasonal.orders argument) should be 0.\cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   max.iter.num -
#     Optional Argument.\cr
#     A positive integer value. The maximum number of iterations performed. 
#     \cr
#     Default Value: 100\cr
#     Types: integer
#   
#   step.ahead -
#     Optional Argument.\cr
#     A positive integer value. The number of steps to forecast after the 
#     end of the time series. If not provided, no forecast values are 
#     calculated.\cr
#     Types: integer
#   
#   method -
#     Optional Argument.\cr
#     Specifies the method for fitting the model parameters: SSE (Default): 
#     Sum of squared error. ML: Maximum likelihood\cr
#     Default Value: "SSE"\cr
#     Permitted Values: SSE, ML\cr
#     Types: character
#   
#   data.orders -
#     Optional Argument.\cr
#     It is the output tbl_teradata from TimeSeriesParameters.\cr
#   
#   data.orders.partition.column -
#     Optional Argument\cr
#     Specifies Partition By columns for "data.orders".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Default Value: 1\cr
#     Types: character OR vector of Strings (character)
#   
#   data.orders.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "data.orders".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   include.drift -
#     Optional Argument.\cr
#     Specify whether drift term is included in the VARMAX model. Note that 
#     this argument can only be True when d is non-zero and less than 2. \cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   order.p -
#     Optional Argument.\cr
#     The p value of the non-seasonal order parameter. The p value must be 
#     an integer between 0 and 10, inclusive. \cr
#     Types: integer
#   
#   order.d -
#     Optional Argument.\cr
#     The d value of the non-seasonal order parameter. The d value must be 
#     an integer between 0 and 1, inclusive. \cr
#     Types: integer
#   
#   order.q -
#     Optional Argument.\cr
#     The q value of the non-seasonal order parameter. The q value must be 
#     an integer between 0 and 10, inclusive. \cr
#     Types: integer
#   
#   seasonal.order.p -
#     Optional Argument.\cr
#     The sp value of the seasonal order parameter. The sp value must be an 
#     integer between 0 and 10, inclusive. \cr
#     Types: integer
#   
#   seasonal.order.d -
#     Optional Argument.\cr
#     The sd value of the seasonal order parameter. The sd value must be an 
#     integer between 0 and 3, inclusive. \cr
#     Types: integer
#   
#   seasonal.order.q -
#     Optional Argument.\cr
#     The sq value of the seasonal order parameter. The sq value must be an 
#     integer between 0 and 10, inclusive. \cr
#     Types: integer
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   data.orders.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data.orders". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_varmax_mle" which is a named 
#   list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_varmax_mle <- function(
  data = NULL,
  response.columns = NULL,
  exogenous.columns = NULL,
  partition.columns = NULL,
  orders = NULL,
  seasonal.orders = NULL,
  period = NULL,
  exogenous.order = NULL,
  lag = 0,
  include.mean = FALSE,
  max.iter.num = 100,
  step.ahead = NULL,
  method = "SSE",
  data.orders = NULL,
  include.drift = FALSE,
  order.p = NULL,
  order.d = NULL,
  order.q = NULL,
  seasonal.order.p = NULL,
  seasonal.order.d = NULL,
  seasonal.order.q = NULL,
  data.sequence.column = NULL,
  data.orders.sequence.column = NULL,
  data.partition.column = "1",
  data.orders.partition.column = "1",
  data.order.column = NULL,
  data.orders.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.partition.column", data.partition.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("response.columns", response.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("exogenous.columns", exogenous.columns, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("partition.columns", partition.columns, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("orders", orders, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seasonal.orders", seasonal.orders, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("period", period, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("exogenous.order", exogenous.order, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("lag", lag, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("include.mean", include.mean, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("max.iter.num", max.iter.num, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("step.ahead", step.ahead, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("method", method, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.orders", data.orders, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.orders.partition.column", data.orders.partition.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.orders.order.column", data.orders.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("include.drift", include.drift, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("order.p", order.p, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("order.d", order.d, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("order.q", order.q, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seasonal.order.p", seasonal.order.p, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seasonal.order.d", seasonal.order.d, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seasonal.order.q", seasonal.order.q, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.orders.sequence.column", data.orders.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  .validateInputTableDataType(data.orders, NULL)
  
  # Check for permitted values
  methodPermittedValues <- list("SSE", "ML")
  .validatePermittedValues(method, methodPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(response.columns)
  .validateTblHasArgumentColumns(response.columns, "response.columns", data, "data")
  
  .validateInputColumnsNotEmpty(exogenous.columns)
  .validateTblHasArgumentColumns(exogenous.columns, "exogenous.columns", data, "data")
  
  .validateInputColumnsNotEmpty(partition.columns)
  .validateTblHasArgumentColumns(partition.columns, "partition.columns", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.orders.sequence.column)
  .validateTblHasArgumentColumns(data.orders.sequence.column, "data.orders.sequence.column", data.orders, "data.orders")
  
  .validateInputColumnsNotEmpty(data.partition.column)
  if (.isDefaultOrNot(data.partition.column, "1")) {
    .validateTblHasArgumentColumns(data.partition.column, "data.partition.column", data, "data")
  }
  .validateInputColumnsNotEmpty(data.orders.partition.column)
  if (.isDefaultOrNot(data.orders.partition.column, "1")) {
    .validateTblHasArgumentColumns(data.orders.partition.column, "data.orders.partition.column", data.orders, "data.orders")
  }
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.orders.order.column)
  .validateTblHasArgumentColumns(data.orders.order.column, "data.orders.order.column", data.orders, "data.orders")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ResponseColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(response.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(exogenous.columns)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ExogenousColumns")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(exogenous.columns,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(partition.columns)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PartitionColumns")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(partition.columns,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(orders)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PDQ")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(orders, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(method) && !missing(method)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Method")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(method, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(seasonal.orders)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SeasonalPDQ")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(seasonal.orders, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(period)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Period")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(period, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(exogenous.order)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ExogenousOrder")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(exogenous.order, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(include.mean) && !missing(include.mean)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IncludeMean")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(include.mean, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(include.drift) && !missing(include.drift)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IncludeDrift")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(include.drift, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(lag) && !missing(lag)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Lag")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(lag, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(max.iter.num) && !missing(max.iter.num)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxIterNum")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(max.iter.num, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(step.ahead)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StepAhead")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(step.ahead, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(order.p)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OrderP")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(order.p, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(order.d)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OrderD")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(order.d, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(order.q)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OrderQ")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(order.q, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(seasonal.order.p)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SeasonalOrderP")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(seasonal.order.p, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(seasonal.order.d)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SeasonalOrderD")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(seasonal.order.d, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(seasonal.order.q)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SeasonalOrderQ")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(seasonal.order.q, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("data:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (!is.null(data.orders.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("orders:", .teradataCollapseArgVector(data.orders.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  if (.isDefaultOrNot(data.partition.column, "1")) {
    data.partition.column <- .teradataCollapseArgVector(data.partition.column, "\"")
  }
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "data")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # Process data.orders
  if (.isDefaultOrNot(data.orders.partition.column, "1")) {
    data.orders.partition.column <- .teradataCollapseArgVector(data.orders.partition.column, "\"")
  }
  if (!is.null(data.orders)) {
    tableRef <- .teradataOnClauseFromDataFrame(data.orders)
    funcInputDistribution <- c(funcInputDistribution, "FACT")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "orders")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, data.orders.partition.column)
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.orders.order.column, "\""))
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "VARMAX",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("VARMAX", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data, data.orders)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_varmax_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_varmax <- td_varmax_mle
