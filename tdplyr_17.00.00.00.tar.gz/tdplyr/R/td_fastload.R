# Copyright 2019 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: Adithya Avvaru (adithya.avvaru@teradata.com)
# Secondary Owner: Mounika Kotha (mounika.kotha@teradata.com)
#
#
################################################################################
#' Copy a local dataframe to a remote data source using fastload protocol
#'
#' This function loads data from a local dataframe into a remote data source  
#' using the fastload protocol. A MULTISET table will be created if it is not 
#' present in the Teradata SQL Engine.\cr 
#' \cr
#' Usage Notes:
#' \enumerate{
#' \item \code{td_fastload} function cannot be used with ODBC driver.
#' \item \code{td_fastload} function cannot load duplicate rows of the dataframe
#' even if the table is a MULTISET table.
#' \item Only use \code{td_fastload} function to load many rows (at least 
#' 100,000 rows) so that the row-loading performance exceeds the overhead of  
#' opening additional connections. To insert small amount of data, please use 
#' \code{copy_to} for better performance.
#' \item \code{td_fastload} function does not support all Teradata SQL data 
#' types. For example, dataframe having BLOB and CLOB data type columns cannot  
#' be loaded.
#' \item If there are any incorrect rows, fastload protocol ignores those 
#' rows and inserts all valid rows. Failed rows are categorised into errors and 
#' warnings by fastload protocol and these errors and warnings are returned by 
#' the \code{td_fastload} function.
#' \item For additional information about fastload protocol through teradatasql
#' driver, please refer the FASTLOAD section of 
#' \href{https://github.com/Teradata/r-driver#FastLoad}{terdatasql driver documentation}.
#' }
#'
#' @param conn Required Argument.\cr
#'             Specifies the remote data source connection.
#' @param df Required Argument.\cr
#'           Specifies the dataframe which contains the data to be inserted.\cr
#'           Types : data.frame
#' @param table.name Required Argument.\cr
#'                   Specifies the name of the destination remote table.\cr
#'                   Types : character
#' @param overwrite Optional Argument.\cr
#'                  Specifies whether to overwrite an existing table or not. 
#'                  If TRUE, will overwrite an existing table with name 
#'                  `table.name`. If FALSE, will throw an error if table with 
#'                  `table.name` already exists.\cr 
#'                  Default : FALSE\cr
#'                  Types : logical\cr
#'                  Note : The existing table will be dropped and new table 
#'                  schema will replace the existing table.
#' @param types Optional Argument.\cr
#'              Specifies the data types for the columns in remote table. This 
#'              argument accepts both named and unnamed character vectors.
#'              If it is NULL, the function will use data types of the columns  
#'              present in R dataframe.\cr
#'              Suppose the dataframe with columns 'col1' and 'col2' is to be 
#'              loaded into the remote data source.\cr
#'              \enumerate{
#'              \item When an unnamed character vector is specified, the data 
#'              types of all the columns must be specified.\cr
#'              Example:\cr
#'              If \code{types = c("FLOAT", "VARCHAR(10)")}, then the 
#'              table is created with 2 columns, 'col1' and 'col2' with data  
#'              types 'FLOAT' and 'VARCHAR(10)' respectively.
#'              \item If a named character vector is specified,
#'              then data types for only a subset of columns can be 
#'              specified. If the names of the column data types do not match 
#'              with any in the dataframe, then an error will be raised.\cr
#'              Examples:\cr
#'              \enumerate{
#'              \item If \code{types = c("col1" = "FLOAT", col2 = "VARCHAR(10)")}, 
#'              then the table is created with 2 columns, 'col1' and 'col2' with 
#'              data types 'FLOAT' and 'VARCHAR(10)' respectively.
#'              \item If \code{types = c("col1" = "FLOAT")}, then the table is 
#'              created with 2 columns - 'col1' with data type 'FLOAT' and 
#'              'col2' with data type of the column in R dataframe.
#'              }
#'              }
#'              Default : NULL\cr
#'              Types : Named or unnamed vector of characters
#' @param append Optional Argument.\cr
#'               Specifies if the dataframe needs to be appended to a table.\cr
#'               Default : FALSE\cr
#'               Types : logical
#' @param save.errors Optional Argument.\cr
#'                    Specifies whether to persist the errors and warnings 
#'                    information in Teradata SQL Engine or not. If this argument 
#'                    is set to TRUE, the error and warnings information are
#'                    presisted and names of error and warning tables are
#'                    returned by \code{td_fastload} function. Otherwise, the 
#'                    function return NULL for the names of the tables.\cr
#'                    Default : FALSE\cr
#'                    Types : logical\cr
#'                    Note : Persisting of the error and warning messages have
#'                    performance impact on \code{td_fastload} in terms of 
#'                    time, based on the number of error and warning messages. 
#'                    However, the errors and warnings are returned as R 
#'                    dataframes by \code{td_fastload} which can then be 
#'                    persisted, if needed.
#' @param batch.size Optional Argument.\cr
#'                   Specifies the number of rows to be inserted per batch using 
#'                   fastload. For better performance, Teradata recommend the 
#'                   batch size to be at least 100,000 rows. batch.size takes 
#'                   positive integers.\cr
#'                   If this argument is NULL, there are two cases based on the
#'                   number of rows (say N) in the dataframe 'df' as explained 
#'                   below:
#'                   \enumerate{
#'                   \item If N is greater than 100,000, the rows are 
#'                   divided into batches of equal size with each batch having 
#'                   at least 100,000 rows (except the last batch which might 
#'                   have more rows).
#'                   \item If N is less than 100,000, the rows are inserted in 
#'                   one batch after notifying the user that insertion happens 
#'                   with degradation of performance.
#'                   }
#'                   If this argument is specified, the rows are inserted in 
#'                   batches, each batch with size given in this argument, 
#'                   irrespective of the recommended batch size. Last batch will 
#'                   have rows less than the batch size specified, if the number
#'                   of rows is not in integral multiples of the argument
#'                   batch.size.\cr
#'                   Default : NULL\cr
#'                   Types : numeric\cr
#'                   Note : This argument is especially useful when there are  
#'                   memory constraints in client machines, in which case user 
#'                   can use smaller batch size.\cr
#'                   Examples:\cr
#'                   \enumerate{
#'                   \item If \code{batch.size = 170,000}, the rows are inserted
#'                   in the batches of size given in this argument.
#'                   \item If \code{batch.size = NULL} and number of rows is
#'                   52,300, the rows are inserted in one batch with 52,300 
#'                   rows.
#'                   \item If \code{batch.size = NULL} and number of rows is
#'                   200,500, the rows are inserted in two batches, each 
#'                   inserting 100,250 rows.
#'                   \item If \code{batch.size = NULL} and number of rows is
#'                   300,521, there will be three batches, of which two batches
#'                   inserting 100,173 rows and one batch inserting 100,175 
#'                   rows.
#'                   }
#' @return A named list containing attributes:\cr
#' \enumerate{
#' \item \code{errors.dataframe} : Has the error messages thrown by fastload 
#' protocol. It has an empty dataframe if there are no error messages.
#' \item \code{warnings.dataframe} : Has the warning messages thrown by fastload
#' protocol. It has an empty dataframe if there are no warning messages.
#' \item \code{errors.table} : Has the table name of error messages. This is 
#' NULL if the argument \code{save.errors} is FALSE.
#' \item \code{warnings.table} : Has the table name of warning messages. This is
#' NULL if the argument \code{save.errors} is FALSE.
#' }
#' @seealso \code{copy_to}
#' @examples 
#' \donttest{
#' # Get remote data source connection
#' con <- td_get_context()$connection
#' 
#' # Install the "nycflights13" package on your R client, if it is not already
#' # installed and load the library.
#' install.packages('nycflights13', repos='https://cloud.r-project.org', quiet = TRUE)
#' library(nycflights13)
#' 
#' # Create a dataframe.
#' flights_df <- as.data.frame(nycflights13::flights)
#' 
#' # Example 1: Using td_fastload to load data from dataframe.
#' fl_list <- td_fastload(con, flights_df, table.name = "flights_fl")
#' 
#' # Prints the loaded table.
#' tbl(con, "flights_fl")
#' 
#' # Example 2: Using td_fastload to overwrite existing "flights_fl" table.
#' fl_list <- td_fastload(con, flights_df, table.name = "flights_fl", 
#'                        overwrite = TRUE)
#' 
#' # Prints the loaded table.
#' tbl(con, "flights_fl")
#' 
#' # Example 3: Using td_fastload to append dataframe to an already available 
#' # table.
#' df1 <- head(flights_df, n = 200000)
#' df2 <- tail(flights_df, n = 136776)
#' fl_list1 <- td_fastload(con, df1, table.name = "flights_fl_append")
#' fl_list2 <- td_fastload(con, df2, table.name = "flights_fl_append", 
#'                         append = TRUE)
#' 
#' # Prints the loaded table.
#' tbl(con, "flights_fl_append")
#' 
#' # Example 4: Using td_fastload specifying column types as unnamed character 
#' #vector.
#' fl_list <- td_fastload(con, flights_df, table.name = "flights_fl_coltypes", 
#'            types = c("INTEGER", "INTEGER", "INTEGER", "INTEGER", "INTEGER", 
#'            "FLOAT", "INTEGER", "INTEGER", "FLOAT", "VARCHAR(50)", "INTEGER", 
#'            "VARCHAR(100)", "VARCHAR(50)", "VARCHAR(50)","FLOAT","FLOAT","FLOAT",
#'            "FLOAT","TIMESTAMP(6)"))
#' 
#' # Prints the loaded table.
#' tbl(con, "flights_fl_coltypes")
#' 
#' # Example 5: Using td_fastload specifying column types as named character 
#' #vector.
#' fl_list <- td_fastload(con, flights_df, table.name = "flights_fl_coltypes1", 
#'             types = c(tailnum = "varchar(100)", dest = "varchar(50)"))
#' 
#' # Prints the loaded table.
#' tbl(con, "flights_fl_coltypes1")
#' 
#' # Read erroneous data using td_fastload into R dataframe.
#' file_name <- system.file("extdata", "LargeErreneousData.csv", package="tdplyr")
#' df_err <- read.csv(file_name, header = TRUE,  stringsAsFactors = FALSE)
#' 
#' # Example 6: Using td_fastload to insert the data with duplicate rows and
#' # invalid columns. Note that errors and warnings are not persisted.
#' 
#' fl_list <- td_fastload(con, df_err, table.name = "invalid_rows")
#' 
#' # Prints errors dataframe.
#' fl_list$errors.dataframe
#' 
#' # Prints warnings dataframe.
#' fl_list$warnings.dataframe
#' 
#' # Prints the loaded table.
#' tbl(con, "invalid_rows")
#' 
#' # Example 7: Using td_fastload to insert the data with duplicate rows and
#' # invalid type columns and save the errors and warnings information.
#' 
#' fl_list <- td_fastload(con, df_err, table.name = "invalid_saved_rows",
#'                        save.errors = TRUE)
#'
#' # Prints errors table; will be NULL, if there are no errors.
#' fl_list$errors.table
#' 
#' # Prints warnings table; will be NULL, if there are no warnings.
#' fl_list$warnings.table 
#' 
#' # Prints the loaded table.
#' tbl(con, "invalid_saved_rows")
#' }
#'
#' @importFrom dplyr db_has_table
#' @importFrom DBI dbExecute
#' @importFrom DBI dbGetQuery
#' @importFrom DBI Id
#' @export
td_fastload <- function(conn, df = NULL, table.name = NULL, overwrite = FALSE, 
                        types = NULL, append = FALSE, save.errors = FALSE, 
                        batch.size = NULL) {
  
  if (!inherits(conn, "Teradata") || is.null(td_get_context())) {
    .ta.stop("TDR_E10051")
  }
  
  # Fastload works only with native driver
  if (td_get_context()$driver.type != "Teradata Native Driver") {
    .ta.stop("TDR_E3405", "td_fastload()")
  }
  
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("df", df, FALSE, "data.frame"))
  argInfoMatrix <- rbind(argInfoMatrix, list("table.name", table.name, FALSE, c("character", "ident_q", "ident", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("overwrite", overwrite, TRUE, c("logical", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("types", types, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("append", append, TRUE, c("logical", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("save.errors", save.errors, TRUE, c("logical", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("batch.size", batch.size, TRUE, c("numeric", NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Validate input argument datatypes.
  # Ignoring type validations for df and types arguments as manual validations
  # are done for them below.
  .validateArgumentTypes(argInfoMatrix[c(-1, -4),]) 
  
  if (!is.data.frame(df)) {
    .ta.stop("TDR_E1006", "df", "data.frame")
  }
  
  # .validateTypesArgument(types)
  
  # Number of rows in dataframe.
  num.row <- nrow(df)
  
  row.names <- FALSE
  
  # Check number of columns
  if (ncol(df) > .get("maxNumberOfColumns")){
    .ta.stop("TDR_E3407", .get("maxNumberOfColumns"), ncol(df))
  }
  
  if (isTRUE(append) &&  isTRUE(overwrite)) {
    .ta.stop("TDR_E3408", "append", "overwrite", "set to TRUE")
  }
  
  # Validate the argument 'types'.
  .verifyDataTypes(df, types = types)
  
  # If batch.size is NULL, we determine the batch size.
  if (is.null(batch.size)) {
    batch.size <- .getBatchSize(num.row)
  } else {
    if (batch.size <= 0 || batch.size %% 1 != 0) {
      .ta.stop("TDR_E3104", "argument", "batch.size", "positive integers")
    }
  }
  
  is_table_present <- FALSE
  
  if (db_has_table(conn, table.name)) {
    is_table_present <- TRUE
    
    # If overwrite is TRUE, then drop table before overwriting.
    # When we overwrite a table, we will not check if the metadata matches.
    if (isTRUE(overwrite)) {
      .ta.warning("TDR_W1011", table.name)
      db_drop_table(conn, table.name)
      is_table_present <- FALSE
    } else {
      # If table exists, irrespective of no of rows, we throw an error.
      if (! isTRUE(append)) {
        .ta.stop("TDR_E3401", "Fastload", table.name)
      }
    }
    
    # Compare metadata before appending the data to the existing table. If the 
    # metadata does not match, throw error. If the metadata matches create a 
    # staging table, insert data using fastload to the staging table. Once the 
    # loading is done copy data from staging table to target table and drop the 
    # staging table.
    if (isTRUE(append)) {
      if (!.compareMetadata(conn, df, table.name, FALSE, types))
        .ta.stop("TDR_E3409", "append", table.name, "df")
    }
  }
  
  return_list <- list()
  if (isTRUE(is_table_present)) {
    # If table is MULTISET table, throw warning that duplicate rows will be 
    # eliminated.
    check_table_type <- dbGetQuery(conn, paste0("show table ", table.name))[[1]]
    if (grepl("MULTISET", check_table_type, ignore.case = TRUE))
      .ta.warning("TDR_W1010", table.name)
    
    # If table is present:
    # If append is TRUE and contains data, then load data using staging table.
    # If append is TRUE and no rows in table ,  OR
    # If no rows and append is FALSE, then insert data directly.
    if (isTRUE(append)) {
      return_list <- .load_with_staging_table(conn, df, table.name, num.row, 
                                              batch.size, save.errors)
    }
  } else {
    # Create table and insert data if table is not present.
    id <- table.name
    # If table does not exist, then create a table
    if (inherits(table.name, "ident_q")) {
      id <- Id(schema = .extractDatabaseNameQuoted(table.name), 
                    table = .extractTableNameQuoted(table.name))
    }
    .createTableInDB(conn, df, id, "PI", NULL, row.names, types, FALSE)
    # Insert data into the destination table with fastload.
    return_list <- .insertWithFastload(conn, df, table.name, num.row, 
                                       batch.size, save.errors)
  }
  
  return(return_list)
}

# This function creates a staging table with same data definition of target table. 
# The data is loaded into the staging table using Fastload. Once Fastload ends  
# the data is copied to the target table. The staging table will be dropped once
# the data is loaded to target table.
# Parameters :
#  con          : Specifies the connection object.
#  df           : Specifies the dataframe containing data that is to be 
#                 inserted.
#  table.name   : Specifies the table name that is to be created.
#  num.row      : Specifies the number of rows of the dataframe.
#  batch.size   : Specifies the size of the batch inserts.
#  save.errors  : Specifies whether to persists error and warning information.
#' @importFrom utils head
#' @importFrom DBI dbExecute
.load_with_staging_table <- function(con, df, table.name, num.row, batch.size, save.errors){
  # Create staging table.
  staging_tab_name <- .teradataGenerateTempTableName(prefix = "fl_staging", 
                                                     gc.onQuit = TRUE)
  create_stage_tab <- paste0("CREATE MULTISET TABLE ", staging_tab_name, 
                             " AS (SELECT * FROM  ", table.name, ") WITH NO DATA");
  
  return_list <- list()
  tryCatch({
    dbExecute(con, create_stage_tab)
    
    # Insert data into staging table using Fastload
    return_list <- .insertWithFastload(con, df, staging_tab_name, num.row, batch.size, save.errors)
    
    # Copy data from staging table into target table.
    sel_copy <- paste0("INSERT INTO ", table.name, " SELECT * FROM ", staging_tab_name)
    dbExecute (con, sel_copy)
    }, error = function(e) { 
      .ta.stop(e)
    }, finally = {
      db_drop_table(con = con, table = staging_tab_name)
    }
  )
  
  return(return_list)
}

# This function loads data into the target table using Fastload. In this 
# function, the data is divided into batches of `batch.size` rows each. The data 
# is sent in batches to the Fastload protocol. Any warnings or error messages 
# encountered are saved to tables in Teradata SQL Engine.
# Parameters :
#  con          : Specifies the connection object.
#  df           : Specifies the dataframe containing data that is to be 
#                 inserted.
#  table.name   : Specifies the table name that is to be created.
#  num.row      : Specifies the number of rows of the dataframe.
#  batch.size   : Specifies the size of the batch inserts.
#  save.errors  : Specifies whether to persists error and warning information.
#' @importFrom DBI dbWriteTable
#' @importFrom DBI dbExecute
#' @importFrom DBI dbBegin
#' @importFrom DBI dbCommit
#' @importFrom DBI dbRollback
#' @importFrom DBI dbGetQuery
.insertWithFastload <- function(con, df, table.name, num.row, batch.size, save.errors){

  # Check number of parameters required to create a parameterized insert statement.
  num_cols <- ncol(df)
  num_params <- paste0(replicate(num_cols, "?"), collapse = ",")

  ## Create a parameterized insert statement by prefixing fastload escape 
  ## function to it.
  # {fn teradata_require_fastload} requires FastLoad for the INSERT statement, 
  # and fails with an error when the INSERT is not compatible with FastLoad.
  # The insert statement must be prefixed with the insert escape function.
  insert_stmt <- paste0("{fn teradata_require_fastload}INSERT INTO ", table.name, " (", num_params,")")
  
  logon_seq_no <- NULL
  
  # Variables to be returned
  error_df <- data.frame()
  warnings_df <- data.frame()
  error.tablename <- NULL
  warn.tablename <- NULL
  
  # Number of batches
  num_batches <- num.row %/% batch.size
  
  .ta.print("TDR_P3400", "td_fastload()", num.row, num_batches, batch.size)
  
  # Batch parameters
  batch <- 1  # Batch Index
  i <- 1      # Row Index of the dataframe
  tryCatch({
    tryCatch({
      dbBegin(con)
      while (batch <= num_batches) {
        # First element in each batch
        first <- i 
        if (batch != num_batches) {
          # Last element in each batch
          last <- i + batch.size - 1
        } else {
          # For the last batch, last element of batch will be the last element 
          # of the dataframe.
          last <- num.row
        }
        
        # Number of elements in each batch. Varies for last batch.
        batch_count <- last - first + 1

        # Insert data
        dbExecute(con, insert_stmt, df[first:last,])  
        
        # Generate error and warning table name with logon sequence number (LSN)
        # as suffix. The LSN can be retrieved only after the execution of insert 
        # statement and only if auto commit is off. If the auto commit is on, then 
        # the connection will be closed after insert statement and LSN will not be 
        # available.
        if (is.null(logon_seq_no)) {
          # {fn teradata_logon_sequence_number} returns the string form of an 
          # integer representing the Logon Sequence Number (LSN) for the FastLoad. 
          # Returns an empty string if the request is not a FastLoad.
          # The function must be appended to escape function 
          # {fn teradata_nativesql}.
          logon_seq_no <- dbGetQuery(con, paste0("{fn teradata_nativesql}{fn teradata_logon_sequence_number}", insert_stmt))
        }
        
        # Get warnings after each batch
        get_warn <- .getErrorsWarnings(con, insert_stmt, "warning", batch)
        if (nrow(get_warn) != 0)
          warnings_df <- rbind(warnings_df, get_warn)
        
        # Get errors after each batch
        get_error <- .getErrorsWarnings(con, insert_stmt, "error", batch)
        if (nrow(get_error) != 0)
          error_df <- rbind(error_df, get_error)
        
        i <- i + batch.size # Increment row index by batch size
        batch <- batch + 1  # Increment batch index by 1
        
        cat(sprintf("Fastload: Processed %s rows in batch %s.\n", batch_count, batch - 1 ))
      }
      
    },error = function(e) {
      .ta.stop(e)
    }, finally = {
      dbCommit(con)
    })
    
    # After commit Warnings
    get_warn <- .getErrorsWarnings(con, insert_stmt, "warning", "summary")
    if (nrow(get_warn) != 0)
      warnings_df <- rbind(warnings_df, get_warn)
    
    # After commit Errors
    get_error <- .getErrorsWarnings(con, insert_stmt, "error", "summary")
    if (nrow(get_error) != 0)
      error_df <- rbind(error_df, get_error)

    # Load errors and warnings into Vantage if save.errors = TRUE
    if (isTRUE(save.errors)) {
      # Create errors table and load errors only if there are errors.
      err_no <- nrow(error_df)
      if (err_no > 0) {
        error.tablename <- paste0("td_fl_", table.name, "_err_", logon_seq_no)
        dbWriteTable(conn = con, name = error.tablename, value = error_df)
        .ta.print(paste0("Persisted all ", err_no, " fastload error(s) to table '", 
                         error.tablename, "'...!"))
      }
      
      # Create warnings table and load warnings only if there are warnings.
      warn_no <- nrow(warnings_df)
      if (warn_no > 0) {
        warn.tablename <- paste0("td_fl_", table.name, "_warn_", logon_seq_no)
        dbWriteTable(conn = con, name = warn.tablename, value = warnings_df)
        .ta.print(paste0("Persisted all ",warn_no ," fastload warning(s) to table '", 
                         warn.tablename, "'...!"))
      }
    }
  }, error = function(e) {
    dbRollback(con) # Rollback if there are any other failures.
    .ta.stop(e)
  })
  
  return_list <- list("errors.dataframe" = error_df,
                      "warnings.dataframe" = warnings_df, 
                      "errors.table" = error.tablename,
                      "warnings.table" = warn.tablename)

  return(return_list)
}

# This function parses error and warning messages by extracting only the required
# message and removing the unnecessary traceback in the retrieved error or warning 
# message.
# Parameters :
#  err_or_warn : Specifies the error or warning message.
.parseErrorWarnings <- function(err_or_warn){
  version_info <- paste0("[Version ",.get_driver_version(.taConnection()),"]")
  # Splitting by version_info
  messages <- strsplit(err_or_warn[[1]], split = version_info, fixed = TRUE)
  messages <- messages[[1]][2:length(messages[[1]])]
  parse_value <- lapply(messages, function(x) {
    strsplit(x, split = " at ", fixed = TRUE)[[1]][1]
  })
  parse_value <- gsub("[\n]", '', parse_value)
  
  # Adding version_info again to actual error msg as splitting will remove it.
  parse_value <- paste0(version_info, parse_value)
  return(parse_value)
}

# This function extracts errors and warnings for the corresponding batch insert 
# statements.
# Parameters :
#  con          : Specifies the connection object.
#  insert_stmt  : Specifies the parameterised insert statement prepended to 
#                 the fastload escape function.
#  message_type : Specifies whether the message is an error or warning.
#  batch_num    : Specifies the batch number of the data being inserted.
.getErrorsWarnings <- function(con, insert_stmt, message_type, batch_num){
  # The SQL request containing the escape clause {fn teradata_nativesql} is replaced  
  # in the SQL request text, and the modified SQL request text is returned to the 
  # application as a result set containing a single row and a single VARCHAR column. 
  # {fn teradata_get_errors} and {fn teradata_get_warnings} must be used with 
  # {fn teradata_nativesql} to retrieve the error and warning messages from the 
  # error tables created during Fastload.
  
  if (message_type == "error") {
    # Get errors for the corresponding inserted batch.
    # {fn teradata_nativesql}{fn teradata_get_errors} returns in one string all 
    # data errors observed by FastLoad for the most recent batch.
    get_err_or_warn <- paste0("{fn teradata_nativesql}{fn teradata_get_errors}", insert_stmt)
  } else {
    # Get warnings for the corresponding inserted batch.
    # {fn teradata_nativesql}{fn teradata_get_warnings} returns in one string 
    # all warnings generated by FastLoad for the request.
    get_err_or_warn <- paste0("{fn teradata_nativesql}{fn teradata_get_warnings}", insert_stmt)
  }

  errs_warns <- dbGetQuery(con, get_err_or_warn)

  batch_err_or_warn <- data.frame()
  if (errs_warns[[1]] != '') {
    # If there are errors or warning
    errors_warns <- .parseErrorWarnings(errs_warns)
    batch_nums <- replicate(length(errors_warns), paste0("batch_",batch_num))
    if (message_type == "error") {
      batch_err_or_warn <- data.frame(batch_num = batch_nums, 
                                    error_message = errors_warns)
    } else {
      batch_err_or_warn <- data.frame(batch_num = batch_nums, 
                                      warning_message = errors_warns)
    }
  }
  return(batch_err_or_warn)
}

# This function calculates the batch size based on the number of rows in the
# dataframe. If number of rows is less than the minimum batch size for fastload, 
# then batch size will be the number of rows. Otherwise, the number of rows are 
# divided equally among the batches with each batch having at least 100,000 
# rows. Note the last batch might have rows more than that of the calculated 
# batch size.
# Parameters :
#  num.rows   : Specifies the number of rows of the dataframe.
.getBatchSize <- function(num.rows) {
  min.batch.size <- .get("minBatchSizeForFastload")
  batch.size <- 0
  if (num.rows <= min.batch.size) {
    batch.size <- num.rows
  } else {
    num.batches <- num.rows %/% min.batch.size
    batch.size <- num.rows / num.batches
    batch.size <- floor(batch.size)
  }
  return(batch.size)
}
