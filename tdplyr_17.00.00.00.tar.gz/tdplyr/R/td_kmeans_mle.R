# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.16
# 
# ################################################################## 

# Description:
#   The KMeans function takes a data set and outputs the centroids of its 
#   clusters and, optionally, the clusters themselves. The algorithm 
#   groups a set of observations into k clusters with each observation 
#   assigned to the cluster with the nearest centroid, or mean.
#   The algorithm minimizes an objective function; in the KMeans 
#   function, the objective function is the total Euclidean distance of 
#   all data points from the center of the cluster to which they are 
#   assigned.
# 
# Args:
#   data -
#     Required Argument.\cr
#     Specifies the tbl_teradata containing the list of features by which we
#     are clustering the data.\cr
#   
#   centers -
#     Optional Argument.\cr
#     Specifies the number of clusters to generate from the data.\cr
#     Note: With "centers", the function uses a nondeterministic algorithm and
#           the function supports up to 1543 dimensions.\cr
#     Types: integer
#   
#   iter.max -
#     Optional Argument.\cr
#     Specifies the maximum number of iterations that the algorithm runs 
#     before quitting if the convergence threshold has not been met.\cr
#     Default Value: 10\cr
#     Types: integer
#   
#   initial.seeds -
#     Optional Argument.\cr
#     Specifies the initial seed means as strings of underscore-delimited 
#     numeric values. For example, this clause initializes eight clusters
#     in eight-dimensional space: Means("50_50_50_50_50_50_50_50",
#     "150_150_150_150_150_150_150_150", "250_250_250_250_250_250_250_250", 
#     "350_350_350_350_350_350_350_350", "450_450_450_450_450_450_450_450", 
#     "550_550_550_550_550_550_550_550", "650_650_650_650_650_650_650_650", 
#     "750_750_750_750_750_750_750_750"). The dimensionality of the means 
#     must match the dimensionality of the data (that is, each mean must 
#     have n numbers in it, where n is the number of input columns minus 
#     one). By default, the algorithm chooses the initial seed means 
#     randomly.\cr
#     Note: With "initial.seeds", the function uses a deterministic algorithm
#           and the function supports up to 1596 dimensions.\cr
#     Types: character OR vector of characters
#   
#   seed -
#     Optional Argument.\cr
#     Specifies a random seed for the algorithm.\cr
#     Types: integer
#   
#   unpack.columns -
#     Optional Argument.\cr
#     Specifies whether the means for each centroid appear unpacked (that 
#     is, in separate columns) in the "clusters.centroids" output tbl_teradata.
#     By default, the function concatenates the means for the centroids
#     and outputs the result in a single VARCHAR column.\cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   centroids.table -
#     Optional Argument.\cr
#     Specifies the tbl_teradata that contains the initial seed means for the
#     clusters. The schema of the "centroids.table" tbl_teradata depends on the
#     value of the "unpack.columns" argument.\cr
#     Note: With "centroids.table", the function uses a deterministic algorithm
#           and the function supports up to 1596 dimensions.\cr
#   
#   threshold -
#     Optional Argument.\cr
#     Specifies the convergence threshold. When the centroids move by less 
#     than this amount, the algorithm has converged. \cr
#     Default Value: 0.0395\cr
#     Types: numeric
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   centroids.table.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "centroids.table". The argument is used to 
#     ensure deterministic results for functions which produce results that 
#     vary from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_kmeans_mle" which is a named 
#   list containing objects of class "tbl_teradata".\cr
#   Named list members can be referenced directly with the "$" operator 
#   using the following names:\enumerate{\item clusters.centroids\item 
#   clustered.output\item output}
# 
# 
#' @export
td_kmeans_mle <- function(
  data = NULL,
  centers = NULL,
  iter.max = 10,
  initial.seeds = NULL,
  seed = NULL,
  unpack.columns = FALSE,
  centroids.table = NULL,
  threshold = 0.0395,
  data.sequence.column = NULL,
  centroids.table.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("iter.max", iter.max, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("initial.seeds", initial.seeds, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("seed", seed, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("unpack.columns", unpack.columns, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("centroids.table", centroids.table, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("threshold", threshold, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("centroids.table.sequence.column", centroids.table.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  .validateInputTableDataType(centroids.table, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(centroids.table.sequence.column)
  .validateTblHasArgumentColumns(centroids.table.sequence.column, "centroids.table.sequence.column", centroids.table, "centroids.table")
  
  # Generate temp table names for output table parameters if any.
  clusters.centroidsTempTableName <- .teradataGenerateTempTableName("td_kmeans_mle0_", use.default.database=TRUE, gc.onQuit=TRUE)
  clustered.outputTempTableName <- .teradataGenerateTempTableName("td_kmeans_mle1_", use.default.database=TRUE, gc.onQuit=TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_kmeans_mle.internal)
  Call[["clusters.centroidsTempTableName"]] <- clusters.centroidsTempTableName
  Call[["clustered.outputTempTableName"]] <- clustered.outputTempTableName
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_kmeans_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_kmeans_mle.internal <- function(
  data = NULL,
  centers = NULL,
  iter.max = 10,
  initial.seeds = NULL,
  seed = NULL,
  unpack.columns = FALSE,
  centroids.table = NULL,
  threshold = 0.0395,
  data.sequence.column = NULL,
  centroids.table.sequence.column = NULL,
  clusters.centroidsTempTableName = NULL,
  clustered.outputTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("OutputTable", "ClusteredOutput")
  funcOutputArgs <- c(clusters.centroidsTempTableName, clustered.outputTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  if (!is.null(initial.seeds)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "InitialSeeds")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(initial.seeds, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(centers)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NumClusters")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(centers, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(threshold) && !missing(threshold)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StopThreshold")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(threshold, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(iter.max)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxIterNum")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(iter.max, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(unpack.columns) && !missing(unpack.columns)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "UnpackColumns")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(unpack.columns, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(seed)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Seed")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(seed, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (!is.null(centroids.table.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("CentroidsTable:", .teradataCollapseArgVector(centroids.table.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # Process centroids.table
  if (!is.null(centroids.table)) {
    tableRef <- .teradataOnClauseFromDataFrame(centroids.table)
    funcInputDistribution <- c(funcInputDistribution, "NONE")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "CentroidsTable")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "KMeans",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("KMeans", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data, centroids.table)
  
  # Return output table data frames.
  result <- list()
  result[["clusters.centroids"]] <- .createDataSetObject(.extractTableName(clusters.centroidsTempTableName), sourceType = "table", .extractDatabaseName(clusters.centroidsTempTableName), is_dplyr_input)
  result[["clustered.output"]] <- .createDataSetObject(.extractTableName(clustered.outputTempTableName), sourceType = "table", .extractDatabaseName(clustered.outputTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_kmeans <- td_kmeans_mle
