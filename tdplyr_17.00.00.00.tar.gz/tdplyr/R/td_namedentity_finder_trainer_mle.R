# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Adithya Avvaru (adithya.avvaru@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.7
# 
# ################################################################## 

# Description:
#   The TrainNamedEntityFinder function takes training data and outputs a 
#   Max
#   			Entropy data model. The function is based on OpenNLP, and follows 
#   its annotation. For
#   			more information on OpenNLP, see .
# 
# Args:
#   data -
#     Required Argument.
#     The input tbl_teradata containing text column to train.
#   
#   text.column -
#     Required Argument.
#     Specifies the name of the input tbl_teradata column that contains the 
#     text to analyze.
#     Types: character
#   
#   entity.type -
#     Required Argument.
#     Specifies the entity type to be trained (for example, PERSON). The 
#     input training documents must contain the same tag.
#     Types: character
#   
#   model.file -
#     Required Argument.
#     Specifies the name of the data model file to be generated.
#     Types: character
#   
#   iter.num -
#     Optional Argument.
#     Specifies the iterator number for training (an openNLP training 
#     parameter). 
#     Default Value: 100
#     Types: integer
#   
#   cutoff -
#     Optional Argument.
#     Specifies the cutoff number for training (an openNLP training 
#     parameter). 
#     Default Value: 5
#     Types: integer
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class 
#   "td_namedentity_finder_trainer_mle" which is a named list containing 
#   Teradata tbl object.
#   Named list member can be referenced directly with the "$" operator 
#   using name: result.
# 
# 
#' @export
td_namedentity_finder_trainer_mle <- function(
  data = NULL,
  text.column = NULL,
  entity.type = NULL,
  model.file = NULL,
  iter.num = 100,
  cutoff = 5,
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("text.column", text.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("entity.type", entity.type, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("model.file", model.file, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("iter.num", iter.num, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("cutoff", cutoff, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(text.column)
  .validateTblHasArgumentColumns(text.column, "text.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_namedentity_finder_trainer_mle.internal)
  
  retval <- NULL
  tryCatch({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 0) {
    attr(retval, "class") <- .getSQLMRClass("td_namedentity_finder_trainer_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(endTime - startTime)
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}


#' @importFrom dbplyr in_schema
#' @importFrom dplyr copy_to
.td_namedentity_finder_trainer_mle.internal <- function(
  data = NULL,
  text.column = NULL,
  entity.type = NULL,
  model.file = NULL,
  iter.num = 100,
  cutoff = 5,
  data.sequence.column = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TextColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(text.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "EntityType")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(entity.type, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Model")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(model.file, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  if (!is.null(iter.num) && !missing(iter.num)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IterNum")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(iter.num, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(cutoff) && !missing(cutoff)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Cutoff")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(cutoff, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "1")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
                                     "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "TrainNamedEntityFinder",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("TrainNamedEntityFinder", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  # Note: Commenting this because we want to append some info to std out table	
  # sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # Storing the database name and table name for use below	
  stdout.db <- .extractDatabaseName(sql.stdout)
  stdout.table <- .extractTableName(sql.stdout)
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
    # Note: since the stdout does not have model file name information,
    # We append it and create the output table
    # This is the reason to create the stdout table using copy_to
    expr <- rbind(expr, paste0("File name: ", model.file))
    expr <- rbind(expr, paste0("Entity type: ", entity.type))
    # Create the output table using copy to
    # maximum length of file name is probably ony 30 characters
    copy_to(.taConnection(), df = expr, name = in_schema(stdout.db, stdout.table),
            types = "VARCHAR(512)")
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  # Note: Only the std out is captured here, as the output argument.
  result[["output"]] <- .createDataSetObject(stdout.table, sourceType = "table", stdout.db, is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 0) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_namedentity_finder_trainer <- td_namedentity_finder_trainer_mle
