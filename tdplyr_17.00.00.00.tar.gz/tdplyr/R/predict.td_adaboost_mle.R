# Copyright 2020 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' @export
predict.td_adaboost_mle <- function(object = NULL,
                                    newdata = NULL,
                                    attr.groupby.columns = NULL,
                                    attr.pid.columns = NULL,
                                    attr.val.column = NULL,
                                    output.response.probdist = FALSE,
                                    accumulate = NULL,
                                    output.responses = NULL,
                                    newdata.sequence.column = NULL,
                                    object.sequence.column = NULL,
                                    newdata.partition.column = NULL,
                                    newdata.order.column = NULL,
                                    object.order.column = NULL
) {
  Call <- match.call()
  Call[[1]] <- quote(tdplyr::td_adaboost_predict_mle)
  eval.parent(Call)
}