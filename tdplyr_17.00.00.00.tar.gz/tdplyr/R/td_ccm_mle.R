# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Jeris Alan Jawahar (jeris.jawahar@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.6
# 
# ################################################################## 

# Description:
#   The CCM function takes two or more time series as input and evaluates 
#   potential cause-effect relationships between them. Each time series 
#   column can be a single, long time series or a set of shorter 
#   subsequences that represent the same process. The function returns an 
#   effect size for each cause-effect pair.
# 
# Args:
#   data -
#     Required Argument.\cr
#     tbl_teradata containing the input data.\cr
#   
#   sequence.id.column -
#     Required Argument.\cr
#     Column containing the sequence ids. A sequence is a sample of the 
#     time series.\cr
#     Types: character
#   
#   time.column -
#     Required Argument.\cr
#     Column containing the timestamps.\cr
#     Types: character
#   
#   cause.columns -
#     Required Argument.\cr
#     Columns to be evaluated as potential causes.\cr
#     Types: character OR vector of Strings (character)
#   
#   effect.columns -
#     Required Argument.\cr
#     Columns to be evaluated as potential effects.\cr
#     Types: character OR vector of Strings (character)
#   
#   library.size -
#     Optional Argument.\cr
#     The CCM algorithm works by using "libraries" of randomly selected 
#     points along the potential effect time series to predict values of 
#     the cause time series. A causal relationship is said to exist if the 
#     correlation between the predicted values of the cause time series and 
#     the actual values increases as the size of the library increases. 
#     Each input value must be greater than 0. \cr
#     Default Value: [100]\cr
#     Types: integer OR vector of integers
#   
#   embedding.dimension -
#     Optional Argument.\cr
#     The embedding dimension is an estimate of the number of past values 
#     to use when predicting a given value of the time series. The input 
#     value must be greater than 0. The\cr
#     Default Value: [2]\cr
#     Types: integer OR vector of integers
#   
#   time.step -
#     Optional Argument.\cr
#     The time.step parameter indicates the number of time steps between 
#     past values to use when predicting a given value of the time series. 
#     The input value must be greater than 0. \cr
#     Default Value: 1\cr
#     Types: integer
#   
#   bootstrap.iterations -
#     Optional Argument.\cr
#     The number of bootstrap iterations used to predict. The bootstrap 
#     process is used to estimate the uncertainty associated with the 
#     predicted values. The input value must be greater than 0. \cr
#     Default Value: 100\cr
#     Types: integer
#   
#   predict.step -
#     Optional Argument.\cr
#      If the best embedding dimension is needed to choose, the predict 
#     step is used for specify the number of time steps into the future to 
#     make predictions from past observations.\cr
#     Default Value: 1\cr
#     Types: integer
#   
#   self.predict -
#     Optional Argument.\cr
#     If self.predict is set to true, the ta.ccm function will attempt to 
#     predict each attribute using the attribute itself. If an attribute 
#     can predict its own time series well, the signal-to-noise ratio is 
#     too low for the ta.ccm algorithm to work effectively. \cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   seed -
#     Optional Argument.\cr
#     Specifies the random seed used to initialize the algorithm.\cr
#     Types: numeric
#   
#   point.select.rule -
#     Optional Argument.\cr
#      The rules to select nearest points if the best embedding dimension 
#     is needed to choose. Two options are provided. One is 
#     DistanceAndTime. The other one is DistanceOnly. The default value is 
#     DistanceOnly.\cr
#     Default Value: "DistanceOnly"\cr
#     Permitted Values: DistanceAndTime, DistanceOnly\cr
#     Types: character
#   
#   mode -
#     Optional Argument.\cr
#     Specifies the execution mode. CCM can be executed in single mode and 
#     distribute node. The default value is single mode.\cr
#     Default Value: "Single"\cr
#     Permitted Values: Single, Distribute\cr
#     Types: character
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_ccm_mle" which is a named 
#   list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_ccm_mle <- function(
  data = NULL,
  sequence.id.column = NULL,
  time.column = NULL,
  cause.columns = NULL,
  effect.columns = NULL,
  library.size = 100,
  embedding.dimension = 2,
  time.step = 1,
  bootstrap.iterations = 100,
  predict.step = 1,
  self.predict = FALSE,
  seed = NULL,
  point.select.rule = "DistanceOnly",
  mode = "Single",
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("sequence.id.column", sequence.id.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("time.column", time.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("cause.columns", cause.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("effect.columns", effect.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("library.size", library.size, TRUE, c("integer","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("embedding.dimension", embedding.dimension, TRUE, c("integer","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("time.step", time.step, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("bootstrap.iterations", bootstrap.iterations, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("predict.step", predict.step, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("self.predict", self.predict, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seed", seed, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("point.select.rule", point.select.rule, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("mode", mode, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check for permitted values
  point.select.rulePermittedValues <- list("DISTANCEANDTIME", "DISTANCEONLY")
  .validatePermittedValues(point.select.rule, point.select.rulePermittedValues)
  
  modePermittedValues <- list("SINGLE", "DISTRIBUTE")
  .validatePermittedValues(mode, modePermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(sequence.id.column)
  .validateTblHasArgumentColumns(sequence.id.column, "sequence.id.column", data, "data")
  
  .validateInputColumnsNotEmpty(time.column)
  .validateTblHasArgumentColumns(time.column, "time.column", data, "data")
  
  .validateInputColumnsNotEmpty(cause.columns)
  .validateTblHasArgumentColumns(cause.columns, "cause.columns", data, "data")
  
  .validateInputColumnsNotEmpty(effect.columns)
  .validateTblHasArgumentColumns(effect.columns, "effect.columns", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceIdColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(sequence.id.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TimeColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(time.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CauseColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(cause.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "EffectColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(effect.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  if (!is.null(library.size) && !missing(library.size)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "LibrarySize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(library.size, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(embedding.dimension) && !missing(embedding.dimension)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "EmbeddingDimensions")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(embedding.dimension, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(time.step) && !missing(time.step)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TimeStep")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(time.step, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(bootstrap.iterations) && !missing(bootstrap.iterations)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "BootstrapIterations")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(bootstrap.iterations, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(predict.step) && !missing(predict.step)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PredictStep")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(predict.step, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(self.predict) && !missing(self.predict)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SelfPredict")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(self.predict, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(point.select.rule) && !missing(point.select.rule)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PointSelectRule")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(point.select.rule, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(mode) && !missing(mode)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ExecutionMode")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(mode, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(seed)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Seed")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(seed, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "LONG")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "CCM",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("CCM", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_ccm_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_ccm <- td_ccm_mle
