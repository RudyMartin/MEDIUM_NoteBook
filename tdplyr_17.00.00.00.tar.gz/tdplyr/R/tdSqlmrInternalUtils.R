################################################################################
#
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: pankajvinod.purandare@teradata.com
# Secondary Owner:
#
# This file implements the core utilities those will be used by the Teradata
# Analytic Function wrappers.
#
################################################################################
#
# Function quote a string/variable 
# 
# Description: Returns the argument with the give quote character(s)
#              By default single quotes the given argument
# Args: 
#   varToQuote: Variable to be quoted.
#   quote: Type of quote to be used for quoting. Default is single quote (').
#
# Returns:
#   Quoted string. In NULL is passed returns NULL, if NA is passed returns NA.
#
.teradataQuoteArg <- function(varToQuote, quote = "'", callFromWrapper = TRUE) {
  if (is.null(varToQuote))
    return("NA_character_");
  
  if ((length(varToQuote) > 1 && (NA %in% varToQuote)) || is.na(varToQuote))
    return(NA);
  
  # if the function .teradataQuoteArg is called from any anlytic function wrapper and
  # check if option td.column.casesensitive.handler is not set to TRUE then do not
  # add double quotes to column names.
  # If the option is set we will keep the quotes as it is.
  if (callFromWrapper) {
    if (is.null(getOption("td.column.casesensitive.handler")) || identical(getOption("td.column.casesensitive.handler"), FALSE)) {
      quote <- ""
    }
  }
  
  return(paste0(quote, varToQuote, quote))
}

#
# Given a vector as an argument this will single quote all the
# vector elements and combine them into a single string separated by
# commas.
#
# Args: 
#   argVector: Vector containing string/s to be quoted.
#   quote: Type of quote to be used for quoting. Default is single quote (').
#
# Returns:
#   Single string separated by commas.
#
.teradataCollapseArgVector <- function(argVector, quote = "'") {
  if (is.null(argVector[1]))
    return("NA_character_");
  
  if (is.na(argVector[1]))
    return(NA);
  
  return(paste0(sapply(argVector, .teradataQuoteArg, quote, FALSE), collapse = ","))
}

# 
# Function generates a unique string which will be used as temporary table name.
# Temp table name is generated using following factors:
#   1. Prefix passed to the function.
#   2. Use current time to aid random numeric generation.
#   3. Make use of user name or temp Database name.
#
# Args:
#   prefix - Prefix to be used to generate table name.
#   use.default.database - Whether to use temp Database name and user name in generated name or not.
#   gc.onQuit - A logical variable to identify, whether to perform garbage collection or not.
#   table.type - view/table
#
# Returns: A string, which will be used as table name.
#
.teradataGenerateTempTableName <- function(prefix, use.default.database=FALSE, 
                                           gc.onQuit=TRUE, table.type = "table") {
  if (any(grepl("^\\s*$", prefix))) {
    .ta.stop("TDR_E2001")
  }
  
  ts <- as.numeric(Sys.time())
  if (use.default.database) {
    # Use database name in the generated name, to make it much more unique.
    obj <- paste(.teradataQuoteArg(.ta.getTempDatabase(), "\"", FALSE), ".r__t__", prefix, 
                 floor(ts %/% 1000000), floor(ts %% 1000000 * 1000000) ,sep = "")
  } else {
    # Just generate the random name with the help of provided prefix.
    obj <- paste("r_t__", prefix, "_", floor(ts %/% 1000000), 
                 floor(ts %% 1000000 * 1000000) ,sep = "")
  }

  # Add the table name to the garbage collector.
  # TODO We need to specify the fully qualified obj name when we call addTempObject
  # This is to handle if user switches default database between connections.
  if (gc.onQuit)
    .ta.addTempObject(obj, table.type)
  
  
  return(obj)
}

# Function to return list of function names which use multi level nested queries to compute
# final results. So far predict functions with map/reduce train function below belong to this
# category of function.
.getMultiLevelNestedFunctions <- function() {
  c("td_naivebayes_textclassifier_predict_sqle", "td_naivebayes_textclassifier_predict",
    "td_naivebayes_predict_sqle" , "td_naivebayes_predict", 
    "td_linreg_predict_mle", "td_linreg_predict")
}

#
# Function to check data frame to retrieve the type of data frame and
# corresponding reference to table/view/query.
#
# Args:
#   ta_frame - tbl_teradata object
#
# Returns:
#   A list containing reference in tbl_teradata and reference type 
#
.teradataOnClauseFromDataFrame <- function(ta_frame) {
  
  if (.ta.isTableOrView(ta_frame)) {
    tableRef <- .get_object(ta_frame)
    tableRefType <- "TABLE"
  } else {
    tableRef <- .get_base_query(ta_frame)
    tableRefType <- "QUERY"

    # Three level nested query fails with timeout on Vantage 1.0 MU2. However, this is fixed in
    # Vantage 1.1.
    # Persisting the table as a workaround as tdplyr supports Vantage versions >= 1.0 MU2.
    if (identical(getOption("td.vantage.version"), "vantage1.0")) {
      index <- length(sys.calls())
      fn_name <- as.character(sys.calls()[[index - 1]])[1]
      if (fn_name %in% .getMultiLevelNestedFunctions()) {
        fn_name <- gsub("_predict", "", fn_name)
        table_name <- ident_q(.teradataGenerateTempTableName(prefix = paste0(fn_name, "_"),
                                                             use.default.database = TRUE,
                                                             gc.onQuit = TRUE))
        ta_frame <- copy_to(.taConnection(), df = ta_frame, name = table_name, table.type = 'NOPI')
        tableRef <- .get_object(ta_frame)
        tableRefType <- "TABLE"
      }
    }
  }
  return(list(ref = tableRef,refType = tableRefType))
}

#
# Function to convert tbl_teradata object to native data frame.
#
# Args:
#   tadf - tbl_teradata object
#
# Returns:
#   Native data frame.
#
.ta.get.native.data.frame <- function(tadf) {
  cols <- colnames(tadf)
  res <- as.data.frame(matrix(vector(), 0, length(cols)),
                       stringsAsFactors = FALSE, 
                       row.names = FALSE)
  names(res) <- cols
  res
}

#
# Parse formula in context of argument tadf. 
#
# Args:
#   formula - formula passed by the user
#   tadf - TA data frame concerning the formula.
#
# Returns: 
#     A list of vector where each element of list is a vector of length two. 
#     The first element of vector is column name and second element is data 
#     type. If it is not an existing column of table, then second element 
#     will be empty string. The first element of the list returned by 
#     function will always be response variable.
#
#' @importFrom stats terms
.ta.parse.formula <- function(formula, tadf) {
  # Make sure formula is not empty
  if (nchar(.ta.trimString(paste0(as.character(formula),collapse = ""))) == 0)
    .ta.stop("TDR_E3003", "formula")
  
  # Copy tadf and cast to data.frame so as we can use
  # built-in formula.terms
  temp <- .ta.get.native.data.frame(tadf)
  
  # Create formula object
  f1 <- formula(formula)
  
  # Expand formula to get terms
  all.terms <- terms(f1, data = temp, keep.order = TRUE)
  
  # Get all independent variables from terms
  independent <- attr(all.terms, "term.labels")
  
  # Check response variable
  if (as.numeric(attr(all.terms,"response")) == 0)
    .ta.stop("TDR_E3006")
  
  dependent <- rownames(attr(all.terms,"factors"))[attr(all.terms,"response")]
  vars <- c(dependent,independent)
  
  # This code is to handle special characters in the formula
  vars <- lapply(vars, function(x) { gsub("\\`", "", x) })
  vars <- unlist(vars)
  
  matrix.vars <- sapply(vars, function(x, df = tadf) {
    pos <- match(x, .get_colnames(df), nomatch = 0);
    if (pos == 0) {
      if (x %in% dependent) 
        .ta.stop("TDR_E3007", "Response/Dependent", x, class(df)[[1]])
      else
        .ta.stop("TDR_E3007", "Independent", x, class(df)[[1]])
    }
    return(list(x, .get_column_datatypes(df)[[pos]]));
  })
  
  return(matrix.vars)
}

#
# Function to generate and return vector of column names which are of a 
# specific type.
#
# Args:
#   formula.terms.matrix -  formula matrix generated by processing formula 
#                           argument passed by the user. This argument must be 
#                           output of .ta.parse.formula function.
#   ta_frame - TA data frame concerning the formula.
#   type -  Type of columns to be needed.
#
# Returns: 
#     A list of vector of column names.
#
.ta.getColumnsByType <- function(formula.terms.matrix, ta_frame, type) {
  if (!is.matrix(formula.terms.matrix))
    .ta.stop("TDR_E3002", "formula.term.matrix", "matrix")
  
  if (type == "categorical") {
    #all categorical inputs
    categorical_inputs <- sapply(formula.terms.matrix[-1], function(x, df=ta_frame) { 
      pos <- match(x[1], .get_colnames(df), nomatch = 0)
      type <- .get_column_datatypes(df)[pos]
      if (TRUE %in% (type %in% .getCategoricalDatatypes()))
        return(x[1])
      else
        return("")
    })
    categorical_inputs <- categorical_inputs[nchar(categorical_inputs) > 0]
    return(categorical_inputs)
  }
  
  if (type == "numerical") {
    #all numerical inputs
    numeric_inputs <- sapply(formula.terms.matrix[-1], function(x, df=ta_frame) { 
      pos <- match(x[1], .get_colnames(df), nomatch = 0)
      type <- .get_column_datatypes(df)[pos]
      if (TRUE %in% (type %in% .getNumericDatatypes()))
        return(x[1])
      else
        return("")
    })
    numeric_inputs <- numeric_inputs[nchar(numeric_inputs) > 0]
    return(numeric_inputs)
  }
  
  if (type == "all") {
    #all numerical inputs
    all_inputs <- sapply(formula.terms.matrix, function(x, df=ta_frame) { 
      pos <- match(x[1], .get_colnames(df), nomatch = 0)
      type <- .get_column_datatypes(df)[pos]
      if (TRUE %in% (type %in% .getAllDatatypes()))
        return(x[1])
      else
        return("")
    })
    all_inputs <- all_inputs[nchar(all_inputs) > 0]
    return(all_inputs)
  }
  
  return(NULL)
}

#
# This function helps to create tbl object .
# This decision is taken based on is.dplyr.input variable.
# Args:
#   tableName - Name of the table or query.
#   sourceType - Type of tbl object to be created.
#   databaseName - Database name (For future purpose).
#   is_dplyr_input - For future purpose.
#   ignore.metadata - Ignore collecting metadata of the tbl. Currently only used if sourceType is query
#
# Returns:
#   A dataset object of type tbl_teradata.
#' @importFrom dbplyr in_schema
.createDataSetObject <- function(tableOrQuery, sourceType, databaseName = NULL, 
                                 is_dplyr_input = TRUE, ignore.metadata = TRUE) {
  con <- .taConnection()
  if (sourceType == "query")
    .tbl_query(con, tableOrQuery, ignore.metadata = ignore.metadata)
  else {
    if (is.null(databaseName))
      return(.tbl_table(con, tableOrQuery))
    .tbl_table(con, in_schema(databaseName, tableOrQuery))
  }
}

#
# This functions checkes whether any of the input object has tbl or not.
# Currently, this returns just TRUE. 
# This is for future purpose.
#
# Returns:
#   If any of the input has tbl_teradata object returns TRUE, else false.
#
.hasTblInput <- function(...) {
  tblObjs <- list(...)
  for (i in 1:length(tblObjs)) {
    if (!is.null(tblObjs[[i]]) && !inherits(tblObjs[[i]], "ta.data.frame"))
      return(TRUE)
  }
  return(TRUE)
}

#
# A function to check whether the input table is of reference function type or not.
#
# Args:
#   modeldata - Input data set object.
#   refFunctionClass - Class name
#
# Returns:
#   TRUE, if the class name is same as that of class of modeldata.
#   Else FALSE.
#
.isRefFuncOutput <- function(modeldata, refFunctionClass) {
  if (refFunctionClass %in% class(modeldata))
    return(TRUE)
  FALSE
}

#
# Function to print sqlmr/analytical function query, if the required option
# "print.sqlmr.query" is TRUE.
#
# Args:
#   sqlmrQuery - Query to be printed on STDOUT
#
.printSqlmrQuery <- function(sqlmrQuery) {
  if (isTRUE(getOption("print.sqlmr.query"))) {
    cat("SQL-MR Query :\n", sqlmrQuery, "\n")
  }
}

.getEngineName <- function(engineName) {
  return(.get("supportedEngines")[[engineName]]$name)
}

#
# Function to extract the alias name for the given analytic function.
# Default mlengine alias name will be returned.
#
# Args: 
#     functionName - Name of the analytics function.
#     engine       - engine type for which alias name needs to be extracted. (sql, mlengine etc)
#
# Returns: alias (function mapping) for the given analytic function.
#    
.getAliasNameForFunction <- function(functionName, engine = .getEngineName("ENGINE_ML"),
                                     call.from.wrapper = FALSE){
  supportedVantageVersions <- .get("supportedVantageVersions")
  vantageVersion <- getOption("td.vantage.version")
  
  # Verify if the given option for vantage version is valid or not.
  if (!tolower(vantageVersion) %in% names(supportedVantageVersions))
    .ta.stop("TDR_E3104", "option", "td.vantage.version", 
              paste0( "\"", paste(names(supportedVantageVersions), collapse = "\", \""), "\""))

  # Extract tdplyr function name (from traceback) to use in error message.

  # If the call to '.getAliasNameForFunction' is from 'taSqlmrInternalBase.R', the function name
  # is present in a function call 7 step before the current call.
  index_to_go_back <- 7
  if (isTRUE(call.from.wrapper)) {
    # If call is not from 'taSqlmrInternalBase.R', the call is from the wrapper itself for model
    # cataloging.
    index_to_go_back <- 1
  }

  r_function_call <- deparse(sys.calls()[[sys.nframe() - index_to_go_back]])
  r_function_name <- strsplit(r_function_call, "(", fixed = TRUE)[[1]][[1]]
  # For driver functions, the call is made by the function of type
  # 'tdplyr:::.td_fn_name_mle.internal'
  if (grepl(pattern = ".internal", r_function_name, fixed = TRUE)) {
    r_function_name <- strsplit(x = r_function_name, split = ".", fixed = TRUE)[[1]][[2]]
  }
  
  functionMappings <- .get('functionAliasMappings')

  # Check if valid engine is specified for which aliases are loaded.
  if (!tolower(engine) %in% names(functionMappings[[vantageVersion]])) {
    .ta.stop("Engine %s specified is not valid.", engine)
  }

  aliasname <- functionMappings[[vantageVersion]][[tolower(engine)]][[tolower(functionName)]]
  
  if (is.null(aliasname)) {
    .ta.stop('TDR_E3103', r_function_name , engine, supportedVantageVersions[[vantageVersion]])
  }
  return(aliasname)
}

#
# Function to provide the correct analytic class hierarchy for a given object
#
# Args: 
#     className - The class name of the object which should be the lowest sub class
#     engine    - engine type for which alias name needs to be extracted. Default: ml
#
# Returns: Class hierarchy for the given className and engine
#
.getSQLMRClass <- function(className , engine = .getEngineName("ENGINE_ML")) {
  # Note: We preserve the list class to enable users to use our object on List specific S3 methods
  # Also maintain S3 class names in lower case
  c(tolower(className), paste0("td_analytics_",tolower(engine)), "td_analytics", "list")
}

# This function is used to populate the attributes of any analytic function to a named list.
# It is used by the model cataloging APIs to save a copy of the attributes along with metadata.
# 
# Arguments: 
# attributes - list - List of arguments passed to the wrapper function.
#
# Returns: Named list consisting the model attribute name and attribute value.
.ta.populateModelAttributes <- function(attributes = NULL){
  if (is.null(attributes)) {
    .ta.stop("Attributes cannot be null")
  }
  if (typeof(attributes) != "list") {
    .ta.stop("Incorrect type specified for attributes object.")
  }
  
  # The first item in attributes list is the function name which is not required.
  attributes <- attributes[-1]
  
  # Evaluate all attributes to resolve symbols, if any, to actual values,
  # and also avoid issues like with formula parsing,
  # looking at two levels of parent environments.
  # We assign a NULL value is for any reason we are not able to fetch or
  # evaluate the value.
  for (i in 1:length(attributes)) {
    attributes[[i]] <- tryCatch({
      eval(attributes[[i]], envir = parent.frame(2))
    }, error = function(e) {
      return(NULL)
    })
  }
  
  return(attributes)
}

# Function to return prediction type for the given analytic function object.
#
# Args:
#     analytic.function.object - Required argument.
#                                The analytic function object to get the
#                                prediction type for.
#     input.data               - Optional argument.
#                                Required when the prediction type is dependent
#                                on the inputs to the function.
#                                The tbl_teradata input to the analytic
#                                function which the formula argument to the
#                                function refers to.
#
# Returns: The prediction type for the analytic function.
#
.getFunctionPredictionType <- function(analytic.function.object,
                                       input.data = NULL) {
  # Validate the required input
  if (is.null(analytic.function.object)) {
    .ta.stop("TDR_E3001", "analytic.function.object")
  }
  
  # If model is not of td_analytics class, then throw an error
  if (!inherits(analytic.function.object, "td_analytics")) {
    .ta.stop("TDR_E3002", "analytic.function.object", "td_analytics")
  }
  
  # Mapper to map class name added as attribute by the function to it's
  # prediction type.
  functionPredictionTypeMapper <- .get("functionPredictionTypeMapper")
  functionClass <- attr(analytic.function.object, "class")[1]
  
  predictionType <- functionPredictionTypeMapper[[functionClass]]
  
  if (is.null(predictionType)) {
    # The prediciton type could be NULL because the function class is not found
    # in the mapper above. We now need to check if it is based on the input.
    predictionType <- .getInputDependentPredictionType(
      analytic.function.object, input.data)
  }
  
  return(predictionType)
}

# Function to return prediction type based on the inputs for the given analytic
# function object.
#
# Args:
#     analytic.function.object - Required argument.
#                                The analytic function object to get the
#                                prediction type for.
#     input.data               - Required argument.
#                                The tbl_teradata input to the analytic
#                                function which the formula argument to the
#                                function refers to.
#
# Returns: The prediction type for the analytic function.
#
.getInputDependentPredictionType <- function(analytic.function.object,
                                             input.data) {
  # Check if the class name for the function is in the vector
  inputDependentPredictionTypeFunctionList <- .get(
    "inputDependentPredictionTypeFunctionList")
  
  # If the function is not found in the list above, then let's default the
  # prediciton type to OTHER.
  functionClass <- attr(analytic.function.object, "class")[1]
  predictionTypes <- .get("predictionTypes")
  if (!is.element(functionClass, inputDependentPredictionTypeFunctionList)) {
    return(predictionTypes$other)
  }
  
  # Validate the required input
  if (is.null(input.data)) {
    .ta.stop("TDR_E3001", "input.data")
  }
  
  # Validate the type of the function's input dataframe
  .validateInputTableDataType(input.data, NULL)
  
  # Currently only one function has the prediciton type dependent on it's
  # inputs.
  if (functionClass == "td_decision_forest_mle") {
    # If tree.type argument was used for the function call, then we can use
    # it as is.
    if (!is.null(analytic.function.object$attributes$tree.type)) {
      return(toupper(analytic.function.object$attributes$tree.type))
    } else {
      # Since tree.type was not used, we will have to check the type of
      # the response column used with formula.
      formula <- analytic.function.object$attributes$formula
      formula.terms.matrix <- .ta.parse.formula(formula, input.data)

      # response variable type
      responseType <- formula.terms.matrix[2,1]
      responseType <- responseType[[names(responseType)]]

      # If the response column is numeric type, then the prediction types is
      # REGRESSION. It is CLASSIFICATION otherwise.
      if (is.element(responseType, .getNumericDatatypes())) {
        return(predictionTypes$regression)
      } else {
        return(predictionTypes$classification)
      }
    }
  }
}

#
# Function that will automatically be dispatched when print() is called for
# objects of class td_analytics.
#
# Args:
#     x - Required argument.
#         The analytic function object of class "td_analytics" to print.
#
# Returns: NULL
#
#' @title Printing tdplyr Analytic Function Objects
#' @name print.td_analytics
#' 
#' @description Print an object of class "td_analytics".
#' @details This function will automatically be dispatched when the generic function
#'          \code{print} is invoked to print a specified input object of class "td_analytics".\cr
#'          It calls \code{print} on the elements of class "tbl_teradata" from the specified
#'          input object.
#' @param x Required Argument.\cr
#'          Specifies a tdplyr analytic function object of class "td_analytics" to print.
#' @param ... Optional Arguments.\cr
#'            Specifies further optional arguments to the \code{print} method.
#' @examples
#' \donttest{
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#' 
#' # Load example data.
#' loadExampleData("glm_example", "admissions_train")
#' 
#' # Create object of class "tbl_teradata" to use as input.
#' admissions_train <- tbl(con, "admissions_train")
#' 
#' # Create the GLM model.
#' td_glm_out <- td_glm_mle(formula = (admitted ~ stats + masters + gpa + programming),
#'                          family = "LOGISTIC",
#'                          linkfunction = "LOGIT",
#'                          data = admissions_train,
#'                          weights = "1",
#'                          threshold = 0.01,
#'                          maxit = 25,
#'                          step = FALSE,
#'                          intercept = TRUE
#' )
#' 
#' # Print the result which is an object of class "td_analytics".
#' print(td_glm_out)
#' }
#' @export print.td_analytics
#' @export
print.td_analytics <- function(x, ...) {
  for (name in names(x)) {
    # Print only if it is a tbl object.
    if (inherits(x[[name]], "tbl_teradata")) {
      cat(paste0("############ ", name, " ############\n\n"))
      print(x[[name]], ...)
      cat("\n\n\n")
    }
  }
}
