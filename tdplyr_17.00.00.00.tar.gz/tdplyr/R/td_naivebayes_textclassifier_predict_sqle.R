# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.0
# 
# ################################################################## 

# Description:
#   The NaiveBayesTextClassifierPredict function uses the model 
#   tbl_teradata output by the NaiveBayesTextClassifierTrainer function 
#   to predict outcomes for test data.
# 
# Args:
#   object -
#     Required Argument.\cr
#     The tbl_teradata defining tbl_teradata classification model.\cr
#   
#   object.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "object".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   newdata -
#     Required Argument.\cr
#     The tbl_teradata defining the token tbl_teradata for prediction.\cr
#   
#   newdata.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "newdata".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   newdata.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "newdata".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   input.token.column -
#     Required Argument.\cr
#     Specifies the name of the input_table column that contains the 
#     tokens.\cr
#     Types: character
#   
#   doc.id.columns -
#     Required Argument.\cr
#     Specifies the names of the input_table columns that contain the 
#     document identifier.\cr
#     Types: character OR vector of Strings (character)
#   
#   model.type -
#     Optional Argument.\cr
#     Specifies the model type of the text classifier. \cr
#     Default Value: "MULTINOMIAL"\cr
#     Permitted Values: MULTINOMIAL, BERNOULLI\cr
#     Types: character
#   
#   top.k -
#     Optional Argument.\cr
#     Specifies the number of most likely prediction categories to output 
#     with their loglikelihood values (for example, the top 10 most likely 
#     prediction categories). The default is all prediction categories.\cr
#     Types: integer
#   
#   model.token.column -
#     Optional Argument.\cr
#     Specifies the name of the model_table column that contains the 
#     tokens. The default value is the first column of model_table.\cr
#     Types: character
#   
#   model.category.column -
#     Optional Argument.\cr
#     Specifies the name of the model_table column that contains the 
#     prediction categories. The default value is the second column of 
#     model_table.\cr
#     Types: character
#   
#   model.prob.column -
#     Optional Argument.\cr
#     Specifies the name of the model_table column that contains the token 
#     counts. The default value is the third column of model_table.\cr
#     Types: character
# 
# Returns:
#   Function returns an object of class 
#   "td_naivebayes_textclassifier_predict_sqle" which is a named list 
#   containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_naivebayes_textclassifier_predict_sqle <- function(
  object = NULL,
  newdata = NULL,
  input.token.column = NULL,
  doc.id.columns = NULL,
  model.type = "MULTINOMIAL",
  top.k = NULL,
  model.token.column = NULL,
  model.category.column = NULL,
  model.prob.column = NULL,
  newdata.partition.column = NULL,
  newdata.order.column = NULL,
  object.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("object", object, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("object.order.column", object.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata", newdata, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata.partition.column", newdata.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata.order.column", newdata.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("input.token.column", input.token.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("doc.id.columns", doc.id.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("model.type", model.type, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("top.k", top.k, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("model.token.column", model.token.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("model.category.column", model.category.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("model.prob.column", model.prob.column, TRUE, c("character",NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(newdata, NULL)
  .validateInputTableDataType(object, "td_naivebayes_textclassifier_mle")
  
  if (.isRefFuncOutput(object, "td_naivebayes_textclassifier_mle")) {
    object <- object[[1]]
  }
  
  # Check for permitted values
  model.typePermittedValues <- list("MULTINOMIAL", "BERNOULLI")
  .validatePermittedValues(model.type, model.typePermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(input.token.column)
  .validateTblHasArgumentColumns(input.token.column, "input.token.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(doc.id.columns)
  .validateTblHasArgumentColumns(doc.id.columns, "doc.id.columns", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(model.token.column)
  .validateTblHasArgumentColumns(model.token.column, "model.token.column", object, "object")
  
  .validateInputColumnsNotEmpty(model.category.column)
  .validateTblHasArgumentColumns(model.category.column, "model.category.column", object, "object")
  
  .validateInputColumnsNotEmpty(model.prob.column)
  .validateTblHasArgumentColumns(model.prob.column, "model.prob.column", object, "object")
  
  .validateInputColumnsNotEmpty(newdata.partition.column)
  .validateTblHasArgumentColumns(newdata.partition.column, "newdata.partition.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(newdata.order.column)
  .validateTblHasArgumentColumns(newdata.order.column, "newdata.order.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(object.order.column)
  .validateTblHasArgumentColumns(object.order.column, "object.order.column", object, "object")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "InputTokenColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(input.token.column, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "DocIdColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(doc.id.columns, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(model.token.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ModelTokenColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(model.token.column, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(model.category.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ModelCategoryColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(model.category.column, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(model.prob.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ModelProbColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(model.prob.column, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(model.type) && !missing(model.type)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ModelType")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(model.type, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(top.k)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TopK")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(top.k, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process newdata
  newdata.partition.column <- .teradataCollapseArgVector(newdata.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(newdata)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "predicts")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, newdata.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(newdata.order.column, "\""))
  
  # Process object
  tableRef <- .teradataOnClauseFromDataFrame(object)
  funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "model")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(object.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "NaiveBayesTextClassifierPredict",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_SQL")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("NaiveBayesTextClassifierPredict", engine = .getEngineName("ENGINE_SQL"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(newdata, object)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_naivebayes_textclassifier_predict_sqle", engine = .getEngineName("ENGINE_SQL"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_naivebayes_textclassifier_predict <- td_naivebayes_textclassifier_predict_sqle
