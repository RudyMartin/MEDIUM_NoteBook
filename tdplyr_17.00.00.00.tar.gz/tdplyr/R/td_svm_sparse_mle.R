# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.5
# 
# ################################################################## 

# Description:
#   The SVMSparse function takes training data (in sparse format) and
#   outputs a predictive model in binary format, which is input to the
#   functions SVMSparsePredict and SVMSparseSummary.
# 
# Args:
#   data -
#     Required Argument.
#     Specifies the name of the tbl_teradata that contains the 
#     training samples.
#   
#   sample.id.column -
#     Required Argument.
#     Specifies the name of the input column that contains the 
#     identifiers of the training samples.
#     Types: character
#   
#   attribute.column -
#     Required Argument.
#     Specifies the name of the input column that contains the 
#     attributes of the samples.
#     Types: character
#   
#   value.column -
#     Optional Argument.
#     Specifies the name of the input column that contains the 
#     attribute values. By default, each attribute has the value 1.
#     Types: character
#   
#   label.column -
#     Required Argument.
#     Specifies the name of the input column that contains the 
#     classes of the samples.
#     Types: character
#   
#   cost -
#     Optional Argument.
#     Specifies the regularization parameter in the SVM soft-margin loss
#     function. The cost must be greater than 0.0.
#     Default Value: 1.0
#     Types: numeric
#   
#   bias -
#     Optional Argument.
#     Specifies a non-negative value. If the value is greater than zero,
#     each sample x in the training set will be converted to (x, b);
#     that is, it will add another dimension containing the bias value b.
#     This argument addresses situations where not all samples center at 0.
#     Default Value: 0.0
#     Types: numeric
#   
#   hash -
#     Optional Argument.
#     Specifies whether to use hash projection on attributes. Hash 
#     projection can accelerate processing speed but can slightly decrease 
#     accuracy. 
#     Note: You must use hash projection if the dataset has more 
#           features than fit into memory.
#     Default Value: FALSE
#     Types: logical
#   
#   hash.buckets -
#     Optional Argument.
#     Valid only if hash is TRUE. Specifies the number of buckets for 
#     hash projection. In most cases, the function can determine the 
#     appropriate number of buckets from the scale of the input data set. 
#     However, if the dataset has a very large number of features, you 
#     might have to specify number of buckets to accelerate the function.
#     Types: integer
#   
#   class.weights -
#     Optional Argument.
#     Specifies the weights for different classes. The format is: 
#     "classlabel m:weight m, classlabel n:weight n". If weight for a class 
#     is given, the cost parameter for this class is weight * cost. A 
#     weight larger than 1 often increases the accuracy of the 
#     corresponding class; however, it may decrease global accuracy. 
#     Classes not assigned a weight in this argument are assigned a weight 
#     of 1.0.
#     Types: character OR vector of characters
#   
#   max.step -
#     Optional Argument.
#     A positive integer value that specifies the maximum number of 
#     iterations of the training process. One step means that each sample 
#     is seen once by the trainer. The input value must be in the range (0, 
#     10000]. 
#     Default Value: 100
#     Types: integer
#   
#   epsilon -
#     Optional Argument.
#     Specifies the termination criterion.
#     When the difference between the values of the loss function in two
#     sequential iterations is less than this number, the function stops.
#     epsilon must be greater than 0.0.
#     Default Value: 0.01
#     Types: numeric
#   
#   seed -
#     Optional Argument.
#     Specifies a long integer value used to order the training set randomly
#     and consistently. This value can be used to ensure that the same model 
#     will be generated if the function is run multiple times in a given 
#     database with the same arguments. The input value must be in the 
#     range [0, 9223372036854775807].
#     Default Value: 0
#     Types: numeric
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_svm_sparse_mle" which is a 
#   named list containing Teradata tbl objects.
#   Named list members can be referenced directly with the "$" operator 
#   using following names:\enumerate{\item model.table\item output}
# 
# 
#' @export
td_svm_sparse_mle <- function(
  data = NULL,
  sample.id.column = NULL,
  attribute.column = NULL,
  value.column = NULL,
  label.column = NULL,
  cost = 1.0,
  bias = 0.0,
  hash = FALSE,
  hash.buckets = NULL,
  class.weights = NULL,
  max.step = 100,
  epsilon = 0.01,
  seed = 0,
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  # The requirement of the argument "value.column" is enforced to make sure
  # the user doesn't run into the issue reported via ANLY-10087.
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("sample.id.column", sample.id.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("attribute.column", attribute.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("value.column", value.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("label.column", label.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("cost", cost, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("bias", bias, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("hash", hash, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("hash.buckets", hash.buckets, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("class.weights", class.weights, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("max.step", max.step, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("epsilon", epsilon, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seed", seed, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(sample.id.column)
  .validateTblHasArgumentColumns(sample.id.column, "sample.id.column", data, "data")
  
  .validateInputColumnsNotEmpty(attribute.column)
  .validateTblHasArgumentColumns(attribute.column, "attribute.column", data, "data")
  
  .validateInputColumnsNotEmpty(label.column)
  .validateTblHasArgumentColumns(label.column, "label.column", data, "data")
  
  .validateInputColumnsNotEmpty(value.column)
  .validateTblHasArgumentColumns(value.column, "value.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  # Generate temp table names for output table parameters if any.
  model.tableTempTableName <- .teradataGenerateTempTableName("td_svm_sparse_mle0_", use.default.database=TRUE, gc.onQuit=TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_svm_sparse_mle.internal)
  Call[["model.tableTempTableName"]] <- model.tableTempTableName
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_svm_sparse_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_svm_sparse_mle.internal <- function(
  data = NULL,
  sample.id.column = NULL,
  attribute.column = NULL,
  value.column = NULL,
  label.column = NULL,
  cost = 1.0,
  bias = 0.0,
  hash = FALSE,
  hash.buckets = NULL,
  class.weights = NULL,
  max.step = 100,
  epsilon = 0.01,
  seed = 0,
  data.sequence.column = NULL,
  model.tableTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("ModelTable")
  funcOutputArgs <- c(model.tableTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IDColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(sample.id.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AttributeNameColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(attribute.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ResponseColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(label.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  if (!is.null(value.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AttributeValueColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(value.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(hash) && !missing(hash)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "HashProjection")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(hash, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(hash.buckets)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "HashBuckets")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(hash.buckets, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(cost) && !missing(cost)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Cost")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(cost, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(bias) && !missing(bias)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Bias")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(bias, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(class.weights)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ClassWeights")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(class.weights, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(max.step) && !missing(max.step)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxStep")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(max.step, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(epsilon) && !missing(epsilon)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Epsilon")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(epsilon, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(seed) && !missing(seed)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Seed")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(seed, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "LONG")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "SparseSVMTrainer",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("SparseSVMTrainer", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["model.table"]] <- .createDataSetObject(.extractTableName(model.tableTempTableName), sourceType = "table", .extractDatabaseName(model.tableTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_svm_sparse <- td_svm_sparse_mle
