# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# Secondary Owner: Arun kalyanasundaram (arun.kalyanasundaram@teradata.com)
# 
# Version: 1.2
# Function Version: 2.5
# 
# ################################################################## 

# Description:
#   The Burst function bursts (splits) a time interval into a series of
#   shorter "burst" intervals that can be analyzed independently.
# 
# Args:
#   data -
#     Required Argument.\cr
#     Specifies the tbl_teradata name which contains time series\cr
#   
#   data.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   time.data -
#     Optional Argument.\cr
#     Specifies the tbl_teradata name which contains time.\cr
#   
#   time.data.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "time.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   time.data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "time.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   time.column -
#     Required Argument.\cr
#     Specifies the names of the input_table columns that contain the start 
#     and end times of the time interval to be burst.\cr
#     Types: character OR vector of Strings (character)
#   
#   value.columns -
#     Required Argument.\cr
#     Specifies the names of input_table columns to copy to the output 
#     table.\cr
#     Types: character OR vector of Strings (character)
#   
#   time.interval -
#     Optional Argument.\cr
#     Specifies the length of each burst time interval. This value must be 
#     either integer or numeric. Note: Specify exactly one of time_table, 
#     time.interval, or num.points.\cr
#     Types: numeric
#   
#   time.datatype -
#     Optional Argument.\cr
#     Specifies the data type of the output columns that correspond to the 
#     input tbl_teradata columns that time.column specifies 
#     (start_time_column and end_time_column). If you omit this argument, 
#     then the function infers the data type of start_time_column and 
#     end_time_column from the input tbl_teradata and uses the inferred 
#     data type for the corresponding output tbl_teradata columns. If you 
#     specify this argument, then the function can transform the input data 
#     to the specified output data type only if both the input column data 
#     type and the specified output column data type are in this list: 
#     integer, BIGINT, SMALLINT, numeric, DECIMAL(n,n), DECIMAL, NUMERIC, 
#     NUMERIC(n,n)\cr
#     Types: character
#   
#   value.datatype -
#     Optional Argument.\cr
#     Specifies the data types of the output columns that correspond to the 
#     input tbl_teradata columns that value.columns specifies. If you omit 
#     this argument, then the function infers the data type of each 
#     value_column from the input tbl_teradata and uses the inferred data 
#     type for the corresponding output tbl_teradata column. If you specify 
#     value.data.type, then it must be the same size as value.columns. That 
#     is, if value.columns specifies n columns, then value.datatype must 
#     specify n data types. For i in [1, n], value_column_i has 
#     value_type_i. However, value_type_i can be empty; for example: 
#     value.columns (c1, c2, c3), value.datatype (integer, ,VARCHAR) If you 
#     specify this argument, then the function can transform the input data 
#     to the specified output data type only if both the input column data 
#     type and the specified output column data type are in this list: 
#     integer, BIGINT, SMALLINT, numeric, DECIMAL(n,n), DECIMAL, NUMERIC, 
#     NUMERIC(n,n)\cr
#     Types: character OR vector of characters
#   
#   start.time -
#     Optional Argument.\cr
#     Specifies the start time for the time interval to be burst. The 
#     default is the value in start_time_column.\cr
#     Types: character
#   
#   end.time -
#     Optional Argument.\cr
#     Specifies the end time for the time interval to be burst. The default 
#     is the value in end_time_column.\cr
#     Types: character
#   
#   num.points -
#     Optional Argument.\cr
#     Specifies the number of data points in each burst time interval.This 
#     value must be an integer. Note: Specify exactly one of time_table, 
#     time.interval, or num.points.\cr
#     Types: integer
#   
#   values.before.first -
#     Optional Argument.\cr
#     Specifies the values to use if start_time is before 
#     start_time_column. Each of these values must have the same data type 
#     as its corresponding value_column. Values of data typeVARCHAR are 
#     case-insensitive. If you specify values.before.first, then it must be 
#     the same size as ValueColumns. That is, if value.columns specifies n 
#     columns, then values.before.first must specify n values. For i in [1, 
#     n], value_column_i has the value before_first_value_i. However, 
#     before_first_value_i can be empty; for example: value.columns (c1, 
#     c2, c3), values.before.first (1, ,"abc") If before_first_value_i is 
#     empty, then value_column_i has the value NULL. If you do not specify 
#     values.before.first, then value_column_i has the value NULL for i in 
#     [1, n].\cr
#     Types: character OR vector of characters
#   
#   values.after.last -
#     Optional Argument.\cr
#     Specifies the values to use if end_time is after end_time_column. 
#     Each of these values must have the same data type as its 
#     corresponding value_column. Values of data type VARCHAR are 
#     case-insensitive. If you specify ValuesAfterLast, then it must be the 
#     same size as value.columns. That is, if value.columns specifies n 
#     columns, then ValuesAfterLast must specify n values. For i in [1, n], 
#     value_column_i has the value after_last_value_i. However, 
#     after_last_value_i can be empty; for example:value.columns (c1, c2, 
#     c3), values.after.last (1, ,"abc") If after_last_value_i is empty, 
#     then value_column_i has the value NULL. If you do not specify 
#     Values_After_Last, then value_column_i has the value NULL for i in 
#     [1, n].\cr
#     Types: character OR vector of characters
#   
#   split.criteria -
#     Optional Argument.\cr
#     Specifies the Split criteria of the Value Columns\cr
#     Default Value: "nosplit"\cr
#     Permitted Values: nosplit, proportional, random, gaussian, poisson\cr
#     Types: character
#   
#   seed -
#     Optional Argument.\cr
#     Specifies the seed for the random number generator.\cr
#     Types: integer
#   
#   accumulate -
#     Optional Argument.\cr
#     Specifies the names of input_table columns (other than those 
#     specified by time.column and value.columns) to copy to the output 
#     table. By default, the function copies to the output tbl_teradata 
#     only the columns specified by time.column and value.columns.\cr
#     Types: character OR vector of Strings (character)
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   time.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "time.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_burst_mle" which is a named 
#   list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_burst_mle <- function(
  data = NULL,
  time.data = NULL,
  time.column = NULL,
  value.columns = NULL,
  time.interval = NULL,
  time.datatype = NULL,
  value.datatype = NULL,
  start.time = NULL,
  end.time = NULL,
  num.points = NULL,
  values.before.first = NULL,
  values.after.last = NULL,
  split.criteria = "nosplit",
  seed = NULL,
  accumulate = NULL,
  data.sequence.column = NULL,
  time.data.sequence.column = NULL,
  data.partition.column = NULL,
  time.data.partition.column = NULL,
  data.order.column = NULL,
  time.data.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.partition.column", data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("time.data", time.data, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("time.data.partition.column", time.data.partition.column, is.null(time.data), c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("time.data.order.column", time.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("time.column", time.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("value.columns", value.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("time.interval", time.interval, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("time.datatype", time.datatype, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("value.datatype", value.datatype, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("start.time", start.time, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("end.time", end.time, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("num.points", num.points, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("values.before.first", values.before.first, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("values.after.last", values.after.last, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("split.criteria", split.criteria, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seed", seed, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("time.data.sequence.column", time.data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  .validateInputTableDataType(time.data, NULL)
  
  # Check for permitted values
  split.criteriaPermittedValues <- list("NOSPLIT", "PROPORTIONAL", "RANDOM", "GAUSSIAN", "POISSON")
  .validatePermittedValues(split.criteria, split.criteriaPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(time.column)
  .validateTblHasArgumentColumns(time.column, "time.column", data, "data")
  
  .validateInputColumnsNotEmpty(value.columns)
  .validateTblHasArgumentColumns(value.columns, "value.columns", data, "data")
  
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(time.data.sequence.column)
  .validateTblHasArgumentColumns(time.data.sequence.column, "time.data.sequence.column", time.data, "time.data")
  
  .validateInputColumnsNotEmpty(data.partition.column)
  .validateTblHasArgumentColumns(data.partition.column, "data.partition.column", data, "data")
  
  .validateInputColumnsNotEmpty(time.data.partition.column)
  .validateTblHasArgumentColumns(time.data.partition.column, "time.data.partition.column", time.data, "time.data")
  
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  .validateInputColumnsNotEmpty(time.data.order.column)
  .validateTblHasArgumentColumns(time.data.order.column, "time.data.order.column", time.data, "time.data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TimeColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(time.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(value.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(accumulate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(accumulate,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(time.interval)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TimeInterval")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(time.interval, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(time.datatype)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TimeDataType")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(time.datatype, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(value.datatype)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ValueDataType")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(value.datatype, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(start.time)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StartTime")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(start.time, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(end.time)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "EndTime")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(end.time, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(split.criteria) && !missing(split.criteria)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SplitCriteria")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(split.criteria, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(num.points)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NumPoints")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(num.points, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(seed)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Seed")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(seed, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(values.before.first)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ValuesBeforeFirst")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(values.before.first, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(values.after.last)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ValuesAfterLast")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(values.after.last, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input_table:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (!is.null(time.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("time_table:", .teradataCollapseArgVector(time.data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  data.partition.column <- .teradataCollapseArgVector(data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input_table")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # Process time.data
  time.data.partition.column <- .teradataCollapseArgVector(time.data.partition.column, "\"")
  if (!is.null(time.data)) {
    tableRef <- .teradataOnClauseFromDataFrame(time.data)
    funcInputDistribution <- c(funcInputDistribution, "FACT")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "time_table")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, time.data.partition.column)
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(time.data.order.column, "\""))
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "Burst",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("Burst", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data, time.data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_burst_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_burst <- td_burst_mle
