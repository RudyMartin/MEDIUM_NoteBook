# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: PavansaiKumar Alladi(pavansaikumar.alladi@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.11
# 
# ################################################################## 

# Description:
#   The Path Summarizer function takes output of the function Path 
#   Generator and returns, for each prefix in the input table, the parent 
#   and children and number of times each of its subsequences was 
#   traveled. This output can be input to the function Path Start.
# 
# Args:
#   object -
#     Required Argument.\cr
#     The name of the tbl_teradata containing the input data.\cr
#   
#   object.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "object".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   object.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "object".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   count.column -
#     Optional Argument.\cr
#     Specifies the name of the input tbl_teradata column that contains the 
#     number of times a path was traveled.\cr
#     Types: character
#   
#   delimiter -
#     Optional Argument.\cr
#     Specifies the single-character delimiter that separates symbols in 
#     the path string. The default value is comma (","). Note: Do not use 
#     any of the following characters as delimiter (they cause the function 
#     to fail):  Asterisk (*), Plus (+), Left parenthesis ((), Right 
#     parenthesis ()), Single quotation mark ("), Escaped single quotation 
#     mark ("), Backslash ("")\cr
#     Default Value: ","\cr
#     Types: character
#   
#   seq.column -
#     Required Argument.\cr
#     Specifies the name of the input tbl_teradata column that contains the 
#     paths.\cr
#     Types: character
#   
#   partition.names -
#     Required Argument.\cr
#     Lists the names of the columns that the partition.columns clause 
#     specifies. The function uses these names for output tbl_teradata 
#     columns. This argument and the partition.columns clause must specify 
#     the same names in the same order.\cr
#     Types: character OR vector of characters
#   
#   hash -
#     Optional Argument.\cr
#     Specifies whether to include the hash code of the node in the output 
#     table. \cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   prefix.column -
#     Required Argument.\cr
#     Specifies the name of the input column that contains the node 
#     prefixes.\cr
#     Types: character
#   
#   object.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "object". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_path_summarizer_mle" which is 
#   a named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_path_summarizer_mle <- function(
   object = NULL,
   object.partition.column = NULL,
   seq.column = NULL,
   partition.names = NULL,
   count.column = NULL,
   delimiter = ",",
   hash = FALSE,
   prefix.column = NULL,
   object.order.column = NULL,
   object.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("object", object, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("object.partition.column", object.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("object.order.column", object.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("count.column", count.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("delimiter", delimiter, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seq.column", seq.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("partition.names", partition.names, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("hash", hash, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("prefix.column", prefix.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("object.sequence.column", object.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(object, "td_path_generator_mle")
  
  # moving this line above the column name checks.
  if (.isRefFuncOutput(object, "td_path_generator_mle")) {
    object <- object[[1]]
  }

  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(seq.column)
  .validateTblHasArgumentColumns(seq.column, "seq.column", object, "object")
  
  .validateInputColumnsNotEmpty(prefix.column)
  .validateTblHasArgumentColumns(prefix.column, "prefix.column", object, "object")
  
  .validateInputColumnsNotEmpty(count.column)
  .validateTblHasArgumentColumns(count.column, "count.column", object, "object")
  
  .validateInputColumnsNotEmpty(object.sequence.column)
  .validateTblHasArgumentColumns(object.sequence.column, "object.sequence.column", object, "object")
  
  .validateInputColumnsNotEmpty(object.partition.column)
  .validateTblHasArgumentColumns(object.partition.column, "object.partition.column", object, "object")
  
  .validateInputColumnsNotEmpty(object.order.column)
  .validateTblHasArgumentColumns(object.order.column, "object.order.column", object, "object")
  
  # Validate that value passed to the output column argument is not empty.
  .validateInputColumnsNotEmpty(partition.names)
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SeqColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(seq.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PrefixColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(prefix.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(count.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CountColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(count.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PartitionNames")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(partition.names, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  if (!is.null(hash) && !missing(hash)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "HashCode")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(hash, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(delimiter) && !missing(delimiter)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Delimiter")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(delimiter, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(object.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(object.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process object
  object.partition.column <- .teradataCollapseArgVector(object.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(object)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, object.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(object.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "path_summarizer",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("path_summarizer", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(object)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_path_summarizer_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units = "secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_path_summarizer <- td_path_summarizer_mle
