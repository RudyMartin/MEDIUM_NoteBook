# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.6
# 
# ################################################################## 

# Description:
#   The DWT2D function implements the Mallat algorithm (an iterate 
#   algorithm in the Discrete Wavelet Transform field) on 2-dimensional 
#   matrices and applies wavelet transform on multiple sequences 
#   simultaneously.
# 
# Args:
#   data -
#     Required Argument.
#     Specifies the name of the tbl_teradata or view that contains the 
#     sequences to be transformed
#   
#   input.columns -
#     Required Argument.
#     Specifies the names of the columns in the input tbl_teradata or view 
#     that contain the data to be transformed. These columns must contain 
#     numeric values between -1e308 and 1e308. The function treats NULL as 
#     0.
#     Types: character OR vector of Strings (character)
#   
#   index.columns -
#     Required Argument.
#     Specifies the columns that contain the indexes of the input 
#     sequences. For a matrix,  indexy_column contains the y coordinates 
#     and indexx_column contains the x coordinates.
#     Types: character OR vector of Strings (character)
#   
#   range -
#     Optional Argument.
#     Specifies the start and end indexes of the input data, all of which 
#     must be integers. The default values for each sequence are: * starty: 
#     minimum y index * startx: minimum x index * endy: maximum y index *
#     endx: maximum x index. The function treats any NULL value as 0. The 
#     range can specify a maximum of 1,000,000 cells.
#     Types: character
#   
#   wavelet -
#     Optional Argument.
#     Specifies a wavelet filter name
#     Types: character
#   
#   wavelet.filter -
#     Optional Argument.
#     Specifies the name of the tbl_teradata that contains the coefficients 
#     of the wave filters.
#   
#   level -
#     Required Argument.
#     Specifies the wavelet transform level. The value 
#     WaveletTransformLevel must be an integer in the range [1, 1000].
#     Types: integer
#   
#   extension.mode -
#     Optional Argument.
#      Specifies the method for handling border distortion, an 
#     extension_mode from tbl_teradata 3 - 104. 
#     Default Value: "sym"
#     Permitted Values: sym, zpd, ppd
#     Types: character
#   
#   compact.output -
#     Optional Argument.
#     Specifies whether to ignore (not output) rows in which all 
#     coefficient values are very small (having an absolute value less than 
#     1e-12). For a sparse input matrix, ignoring such rows reduces the 
#     output tbl_teradata size.
#     Default Value: TRUE
#     Types: logical
#   
#   partition.columns -
#     Optional Argument.
#     Specifies the names of the partition.columns, which identify the 
#     sequences. Rows with the same partition.columns values belong to the 
#     same sequence. If you specify multiple partition.columns, then the 
#     function treats the first one as the distribute key of the output and 
#     meta tables. By default, all rows belong to one sequence, and the 
#     function generates a distribute key column named dwt_idrandom_name in 
#     both the output tbl_teradata and the meta table. In both tables, 
#     every cell of dwt_idrandom_name has the value 1.
#     Types: character OR vector of Strings (character)
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
#   
#   wavelet.filter.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "wavelet.filter". The argument is used to 
#     ensure deterministic results for functions which produce results that 
#     vary from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_dwt2d_mle" which is a named 
#   list containing Teradata tbl objects.
#   Named list members can be referenced directly with the "$" operator 
#   using following names:\enumerate{\item coefficient\item 
#   meta.table\item output}
# 
# 
#' @export
td_dwt2d_mle <- function(
  data = NULL,
  input.columns = NULL,
  index.columns = NULL,
  range = NULL,
  wavelet = NULL,
  wavelet.filter = NULL,
  level = NULL,
  extension.mode = "sym",
  compact.output = TRUE,
  partition.columns = NULL,
  data.sequence.column = NULL,
  wavelet.filter.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("input.columns", input.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("index.columns", index.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("range", range, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("wavelet", wavelet, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("wavelet.filter", wavelet.filter, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("level", level, FALSE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("extension.mode", extension.mode, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("compact.output", compact.output, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("partition.columns", partition.columns, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("wavelet.filter.sequence.column", wavelet.filter.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")

  # Make sure that either wavelet.filter or wavelet is provided
  if((is.null(wavelet) && is.null(wavelet.filter)) || (!is.null(wavelet) && !is.null(wavelet.filter))){
    .ta.stop("TDR_E3009", "wavelet", "wavelet.filter")
  }
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  .validateInputTableDataType(wavelet.filter, NULL)
  
  # Check for permitted values
  extension.modePermittedValues <- list("SYM", "ZPD", "PPD")
  .validatePermittedValues(extension.mode, extension.modePermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(index.columns)
  .validateTblHasArgumentColumns(index.columns, "index.columns", data, "data")
  
  .validateInputColumnsNotEmpty(input.columns)
  .validateTblHasArgumentColumns(input.columns, "input.columns", data, "data")
  
  .validateInputColumnsNotEmpty(partition.columns)
  .validateTblHasArgumentColumns(partition.columns, "partition.columns", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(wavelet.filter.sequence.column)
  .validateTblHasArgumentColumns(wavelet.filter.sequence.column, "wavelet.filter.sequence.column", wavelet.filter, "wavelet.filter")
  
  # Generate temp table names for output table parameters if any.
  coefficientTempTableName <- .teradataGenerateTempTableName("td_dwt2d_mle0_", use.default.database=TRUE, gc.onQuit=TRUE)
  meta.tableTempTableName <- .teradataGenerateTempTableName("td_dwt2d_mle1_", use.default.database=TRUE, gc.onQuit=TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_dwt2d_mle.internal)
  Call[["coefficientTempTableName"]] <- coefficientTempTableName
  Call[["meta.tableTempTableName"]] <- meta.tableTempTableName
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_dwt2d_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_dwt2d_mle.internal <- function(
  data = NULL,
  input.columns = NULL,
  index.columns = NULL,
  range = NULL,
  wavelet = NULL,
  wavelet.filter = NULL,
  level = NULL,
  extension.mode = "sym",
  compact.output = TRUE,
  partition.columns = NULL,
  data.sequence.column = NULL,
  wavelet.filter.sequence.column = NULL,
  coefficientTempTableName = NULL,
  meta.tableTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("OutputTable", "MetaTable")
  funcOutputArgs <- c(coefficientTempTableName, meta.tableTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IndexColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(index.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(input.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  if (!is.null(partition.columns)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PartitionColumns")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(partition.columns,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "WaveletTransformLevel")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(level, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  
  if (!is.null(range)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Range")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(range, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(compact.output) && !missing(compact.output)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CompactOutput")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(compact.output, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(wavelet)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Wavelet")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(wavelet, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(extension.mode) && !missing(extension.mode)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ExtensionMode")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(extension.mode, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (!is.null(wavelet.filter.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("WaveletFilterTable:", .teradataCollapseArgVector(wavelet.filter.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # Process wavelet.filter
  if (!is.null(wavelet.filter)) {
    tableRef <- .teradataOnClauseFromDataFrame(wavelet.filter)
    funcInputDistribution <- c(funcInputDistribution, "NONE")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "WaveletFilterTable")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "DWT2D",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("DWT2D", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data, wavelet.filter)
  
  # Return output table data frames.
  result <- list()
  result[["coefficient"]] <- .createDataSetObject(.extractTableName(coefficientTempTableName), sourceType = "table", .extractDatabaseName(coefficientTempTableName), is_dplyr_input)
  result[["meta.table"]] <- .createDataSetObject(.extractTableName(meta.tableTempTableName), sourceType = "table", .extractDatabaseName(meta.tableTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_dwt2d <- td_dwt2d_mle
