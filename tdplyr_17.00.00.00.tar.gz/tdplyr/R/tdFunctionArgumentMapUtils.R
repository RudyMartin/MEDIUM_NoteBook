################################################################################
#
# Copyright 2020 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: rohit.khurd@teradata.com
# Secondary Owner:
#
# This file implements the function argument map and related utilities that
# will be used by Model Cataloging for cross platform save/retrieve
# compatibility.
#
################################################################################
#
# Function to load, and return the function argument map for the requested
# analytic function.
#
# Args:
#     engine        - Required argument.
#                     The name of the engine.
#     function.name - Required argument.
#                     The name of the analytic function from the engine to get
#                     the function argument map for.
#
# Returns: The named list corresponding to the function argument map for the
#          given engine and function.
# 
#' @importFrom jsonlite fromJSON
.getFunctionArgMapper <- function(engine, function.name) {
  # Validate the arguments.
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("engine", engine, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("function.name", function.name, FALSE, c("character",NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments.
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument.
  .validateArgumentTypes(argInfoMatrix)
  
  # Check whether the input passed to the argument are not empty.
  .validateInputColumnsNotEmpty(engine)
  .validateInputColumnsNotEmpty(function.name)
  
  # Check for permitted values
  enginePermittedValues <- list(.get(".mc.modelEngineML"), .get(".mc.modelEngineAdvSQL"))
  .validatePermittedValues(engine, enginePermittedValues)
  
  functionArgumentMap <- .get("functionArgumentMap")
  
  # Let's use lower case for function.name.
  function.name <- tolower(function.name)
  
  # TODO - This will need change when more engines are included.
  fileName <- function.name
  if (tolower(engine) == tolower(.get(".mc.modelEngineML"))) {
    fileName <- paste0("mle/", paste0(fileName, "_mle.json"))
    engine <- .get(".mc.modelEngineML")
  } else if (tolower(engine) == tolower(.get(".mc.modelEngineAdvSQL"))) {
    fileName <- paste0("sqle/", paste0(fileName, "_sqle.json"))
    engine <- .get(".mc.modelEngineAdvSQL")
  }
  
  mapUpdated <- FALSE
  
  # Map not initialized.
  if (is.null(functionArgumentMap)) {
    con <- .taConnection()
    functionArgumentMap <- list()
    functionArgumentMap[["vantageVersion"]] <- .ta.getVantageVersion(con)
    mapUpdated <- TRUE
  }
  
  if (!(engine %in% names(functionArgumentMap))) {
    # Update map with required Engine as key.
    functionArgumentMap[[engine]] <- list()
    mapUpdated <- TRUE
  }
  
  # Load function argument map.
  if (!(function.name %in% names(functionArgumentMap[[engine]]))) {
    vantageVersion <- functionArgumentMap[["vantageVersion"]]
    
    # Read function JSON and load map.
    funcJSON <- tryCatch({
      jsonlite::fromJSON(system.file("json", fileName, package = "tdplyr"))
    }, error = function(err) {
      # We will end up here only if the file is for some reason missing or corrupt.
      # This is rare and highly unlikely as the file is a part of the package.
      .ta.stop("TDR_E4006", function.name, engine)
    })
    functionMap <- list()
    functionArgs <- funcJSON$argument_clauses
    functionInputs <- funcJSON$input_tables
    functionOutputs <- funcJSON$output_tables
    function_tdplyr_name <- funcJSON$function_tdplyr_name
    functionMap[[.get(".fam.functionTdplyrName")]] <- function_tdplyr_name
    
    # Let's get the globals to use as keys in the function argument map.
    famInputs <- .get(".fam.inputs")
    famOutputs <- .get(".fam.outputs")
    famArguments <- .get(".fam.arguments")
    famTdplyrToSql <- .get(".fam.tdplyrToSql")
    famSqlToTdplyr <- .get(".fam.sqlToTdplyr")
    famTdplyrName <- .get(".fam.tdplyrName")
    famDefaultOutput <- .get(".fam.defaultOuput")
    famDefaultOutputTdplyrNameSingle <- .get(".fam.defaultOutputTdplyrNameSingle")
    famDefaultOutputTdplyrNameMultiple <- .get(".fam.defaultOutputTdplyrNameMultiple")
    famRFormulaUsage <- .get(".fam.rFormulaUsage")
    famROrderNum <- .get(".fam.rOrderNum")
    famDataype <- .get(".fam.datatype")
    famAllowsList <- .get(".fam.allowsLists")
    
    # Let's create the mapping for the inputs.
    functionMap[[famInputs]] <- list()
    functionMap[[famInputs]][[famSqlToTdplyr]] <- list()
    functionMap[[famInputs]][[famTdplyrToSql]] <- list()
    functionMap <- .addFunctionInputOutputEntries(famInputs, functionInputs, functionMap, vantageVersion)
    
    # Let's create the mapping for the outputs.
    functionMap[[famOutputs]] <- list()
    functionMap[[famOutputs]][[famSqlToTdplyr]] <- list()
    functionMap[[famOutputs]][[famTdplyrToSql]] <- list()
    functionMap[[famOutputs]][[famROrderNum]] <- list()
    
    # Only default output.
    famDefaultOutputTdplyrName <- .getCustomOutputName(function_tdplyr_name,
                                                       famDefaultOutputTdplyrNameSingle)
    if (!is.null(functionOutputs)) {
      # Default output when multiple outputs.
      functionMap <- .addFunctionInputOutputEntries(famOutputs, functionOutputs, functionMap, vantageVersion)
      famDefaultOutputTdplyrName <- .getCustomOutputName(function_tdplyr_name,
                                                         famDefaultOutputTdplyrNameMultiple)
    }
    functionMap[[famOutputs]][[famSqlToTdplyr]][[famDefaultOutput]] <- famDefaultOutputTdplyrName
    functionMap[[famOutputs]][[famTdplyrToSql]][[famDefaultOutputTdplyrName]] <- famDefaultOutput
    functionMap[[famOutputs]][[famROrderNum]][[famDefaultOutputTdplyrName]] <- NA
    
    # Let's create the mapping for the arguments.
    functionMap[[famArguments]] <- list()
    functionMap[[famArguments]][[famSqlToTdplyr]] <- list()
    functionMap[[famArguments]][[famTdplyrToSql]] <- list()
    
    formulaArgs <- list()
    sequenceArg <- NULL
    
    # Process argument information available, if any.
    if (is.data.frame(functionArgs) && nrow(functionArgs) > 0)
      for (i in  1:nrow(functionArgs)) {
        arg <- list()
        arg$name <- functionArgs$name[[i]]
        arg$rName <- functionArgs$rName[[i]]
        arg[[famRFormulaUsage]] <- functionArgs[[famRFormulaUsage]][[i]]
        arg[[famROrderNum]] <- functionArgs[[famROrderNum]][[i]]
        arg[[famDataype]] <- functionArgs[[famDataype]][[i]]
        arg[[famAllowsList]] <- functionArgs[[famAllowsList]][[i]]
        arg[["useInR"]] <- functionArgs[["useInR"]][[i]]
        
        
        # Handle formula related arguments separately.
        if (isTRUE(arg[[famRFormulaUsage]])) {
          formulaArgs[[arg$name[1]]] <- arg
          next
        }
        
        argName <- arg$name
        tdplyrName <- arg$rName
        sqlNameToUse <- tolower(.resolveName(argName, vantageVersion))
        
        # Handle sequence input related arguments separately.
        if (tdplyrName == "sequence.column") {
          sequenceArg <- arg
          next
        }
      
        # Handle all other arguments.
        # This will add entries as shown below:
        # list(
        #   arguments = list(
        #     sql_to_tdplyr = list(
        #       weight = list(
        #         tdplyr_name = "weights",
        #         tdplyr_type = "character"
        #       ),
        #       weightcolumn = list(
        #         alternate_to = "weight"
        #       )
        #     ),
        #     tdplyr_to_sql = list(
        #       weights = "weight"
        #     )
        #   )
        # )
        tdplyrType <- .resolveSQLTypeToTdplyrType(arg)
        
        if (is.list(argName)) {
          for (name in names(argName)) {
            for (i in 1:length(argName[[name]])) {
              if (i == 1) {
                functionMap <- .addSqlToTdplyrEntry(functionmap = functionMap,
                                                    sqlname = argName[[name]][i],
                                                    tdplyrname = tdplyrName,
                                                    tdplyrtype = tdplyrType)
                
                functionMap[[famArguments]][[famTdplyrToSql]][[tdplyrName]] <- sqlNameToUse
              } else {
                functionMap <- .addSqlToTdplyrEntry(functionmap = functionMap,
                                                    sqlname = argName[[name]][i],
                                                    sqlnametouse = sqlNameToUse,
                                                    alternateto = TRUE)
              }
            }
          }
        } else {
          for (i in 1:length(argName)) {
            if (i == 1) {
              functionMap <- .addSqlToTdplyrEntry(functionmap = functionMap,
                                                  sqlname = argName[i],
                                                  tdplyrname = tdplyrName,
                                                  tdplyrtype = tdplyrType)
              functionMap[[famArguments]][[famTdplyrToSql]][[tdplyrName]] <- sqlNameToUse
            } else {
              functionMap <- .addSqlToTdplyrEntry(functionmap = functionMap,
                                                  sqlname = argName[i],
                                                  sqlnametouse = sqlNameToUse,
                                                  alternateto = TRUE)
            }
          }
        }
      }
    
    # Now let's handle the formula related arguments.
    if (length(formulaArgs) > 0)
      functionMap <- .resolveFormulaArgs(functionMap, formulaArgs, vantageVersion)
    
    # Now let's handle the sequence input related arguments.
    if (!is.null(sequenceArg))
      functionMap <- .resolveSequenceInputArgs(functionMap, sequenceArg, vantageVersion)
    
    functionArgumentMap[[engine]][[function.name]] <- functionMap
    mapUpdated <- TRUE
  }
  
  if (isTRUE(mapUpdated)) {
    .assign("functionArgumentMap", functionArgumentMap)
  }
  
  return(functionArgumentMap[[engine]][[function.name]])
}

# Function to return the R datatype corresponding to the acceptable SQL
# datatype for an argument.
#
# Arguments:
# arg - A list related to the function argument from the function argument map.
# 
# Returns:
# R type for argument specified.
#
.resolveSQLTypeToTdplyrType <- function(arg) {
  allowsLists <- FALSE
  if (.get(".fam.allowsLists") %in% names(arg))
    allowsLists <- arg[[.get(".fam.allowsLists")]]

  dataType <- .get(".fam.datatype")
  
  rType <- .get(".fam.tdplyrCharacterType")
  if (arg[[dataType]] == .get(".fam.boolType"))
    rType <- .get(".fam.tdplyrBoolType")
  else if (arg[[dataType]] %in% .get(".fam.numericType"))
    rType <- .get(".fam.tdplyrNumericType")
  else if (arg[[dataType]] == .get(".fam.intType"))
    rType <- .get(".fam.tdplyrIntegerType")
  
  # We let the consumer know that vectors are an acceptable type too.
  if (isTRUE(allowsLists))
    rType <- c(rType, .get(".fam.tdplyrList"))
  
  return(rType)
}

# Function to return the SQL name to use in the function argument map.
#
# Arguments:
# arg - A name from the input, output, or argument from the function JSON to get
#       name to use for.
# vantage.version - The version of Vantage connected to.
# 
# Returns:
# The String representing the SQL name to use.
#
.resolveName <- function(arg, vantage.version) {
  # If 'arg' is a named list like
  #    list(<vantage.version1> = c(name1, name2),
  #         <vantage.version2> = c(name1, name2]))
  # then we should get the information associated with the required Vantage version.
  if (is.list(arg)) {
    arg <- arg[[vantage.version]]
  }
  
  # If 'arg' is a vector like
  #    c(name1, name2)
  # then get the first name in the list for the
  # current Vantage version.
  if (length(arg) > 1)
    arg <- arg[1]
  
  return(arg)
}

# Function to update the function argument map with entries for it's input
# or output information.
#
# Arguments:
# field - A string respresenting whether to update the "inputs" or "outputs"
#         section.
# function.input.ouput - A list from the JSON corresponding to the section
#                        being updated.
# function.map - The function map to update with the information.
# vantage.version - The version of Vantage connected to.
# 
# Returns:
# The updated function map list.
# 
#     Example: The 'inputs' section for the GLM function map's is updated
#              with the following:
#              
#              list(
#                inputs = list(
#                  sql_to_tdplyr = list(
#                    inputtable = "data"
#                  ),
#                  tdplyr_to_sql = list(
#                    data = "inputtable"
#                  )
#                )
#              )
# 
#              The 'outputs' section for the GLM function map's is updated
#              with the following:
#
#              list(
#                outputs = list(
#                  sql_to_tdplyr = list(
#                    outputtable = "coefficients"
#                  ),
#                  tdplyr_to_sql = list(
#                    coefficients = "outputtable"
#                  )
#                )
#              )
#
.addFunctionInputOutputEntries <- function(field, function.input.ouput, function.map, vantage.version) {
  # Return if there is no input/output information available.
  if (nrow(function.input.ouput) < 1)
    return(function.map)
  
  # Let's get the globals to use as keys in the function argument map.
  famTdplyrToSql <- .get(".fam.tdplyrToSql")
  famSqlToTdplyr <- .get(".fam.sqlToTdplyr")
  famROrderNum <- .get(".fam.rOrderNum")
  
  functionTdplyrName <- function.map[[.get(".fam.functionTdplyrName")]]
  
  for (i in 1:nrow(function.input.ouput)) {
    sqlName <- function.input.ouput$name[[i]]
    tdplyrName <- .getCustomOutputName(functionTdplyrName, function.input.ouput$rName[[i]])
    sqlNameToUse <- tolower(.resolveName(sqlName, vantage.version))

    if (is.list(sqlName)) {
      # If 'sqlName' is a named list like
      #    list(<vantage.version1> = c(name1, name2),
      #         <vantage.version2> = c(name1, name2))
      # then all of these name1, name2, etc. should map to the rName,
      # and the rName should be mapped to the first name in the list for the
      # current Vantage version.
      for (name in names(sqlName)) {
        for (namei in name) {
          function.map[[field]][[famSqlToTdplyr]][[tolower(namei)]] <- tdplyrName
        }
      }
      
      # Add rOrderNum information for ordering the output in the result named list.
      # Required only for outputs.
      if (field == .get(".fam.outputs")) {
        rOrderNum <- function.input.ouput[[famROrderNum]][[i]]
        function.map[[field]][[famROrderNum]][[tdplyrName]] <- rOrderNum
      }
      
      function.map[[field]][[famTdplyrToSql]][[tdplyrName]] <- sqlNameToUse
    } else {
      # If 'sqlName' is a vector like
      #    c(name1, name2)
      # then all of these name1, name2, etc. should map to the rName,
      # and the rName should be mapped to the first name in the list for the
      # current Vantage version.
      for (name in sqlName) {
        function.map[[field]][[famSqlToTdplyr]][[tolower(name)]] <- tdplyrName
      }
      
      # Add rOrderNum information for ordering the output in the result named list.
      # Required only for outputs.
      if (field == .get(".fam.outputs")) {
        rOrderNum <- function.input.ouput[[famROrderNum]][[i]]
        function.map[[field]][[famROrderNum]][[tdplyrName]] <- rOrderNum
      }
      
      function.map[[field]][[famTdplyrToSql]][[tdplyrName]] <- sqlNameToUse
    }
  }
  
  return(function.map)
}

# Function to update the function argument map SQL to tdplyr mapping entries
# for it's argument information.
#
# Arguments:
# functionmap    - Required Argument.
#                  The function map to update with the information.
# sqlname        - Required Argument.
#                  The SQL name of the argument to add entry for in the
#                  function argument map.
# tdplyrname     - Optional Argument.
#                  The tdplyr name for the argument corresponding to the
#                  SQL name provided.
# tdplyrtype     - Optional Argument.
#                  The acceptable R data type(s) for the argument.
# sqlnametouse   - Optional Argument.
#                  The tdplyr name to use in case there are alternate names.
# alternateto    - Optional Argument.
#                  Specifies whether the sqlname is alternate to another SQL
#                  name to be primarily used for mapping.
#                  Default Value: FALSE
# 
# Returns:
# The updated function map list.
#
.addSqlToTdplyrEntry <- function(functionmap, sqlname, tdplyrname = NULL,
                                 tdplyrtype = NULL, sqlnametouse = NULL,
                                 alternateto = FALSE) {
  
  # Let's get the globals to use as keys in the function argument map.
  famArguments <- .get(".fam.arguments")
  famAlternateTo <- .get(".fam.alternateTo")
  famTdplyrName <- .get(".fam.tdplyrName")
  famTdplyrType <- .get(".fam.tdplyrType")
  famSqlToTdplyr <- .get(".fam.sqlToTdplyr")
  
  # Check if the SQL Name is an alternate name or not,
  # and take action accordingly.
  if (!isTRUE(alternateto)) {
    functionmap[[famArguments]][[famSqlToTdplyr]][[tolower(sqlname)]] <- list()
    functionmap[[famArguments]][[famSqlToTdplyr]][[tolower(sqlname)]][[famTdplyrName]] <- tdplyrname
    functionmap[[famArguments]][[famSqlToTdplyr]][[tolower(sqlname)]][[famTdplyrType]] <- tdplyrtype
  } else {
    functionmap[[famArguments]][[famSqlToTdplyr]][[tolower(sqlname)]] <- list()
    functionmap[[famArguments]][[famSqlToTdplyr]][[tolower(sqlname)]][[famAlternateTo]] <- sqlnametouse
  }
  
  return(functionmap)
}

# Function to add entries related to formula arguments to the function
# argument map.
#
# Arguments:
# function.map    - Required Argument.
#                   The function map to update with the information.
# formula.args    - Required Argument.
#                   The list containing the formula retaled argument entries
#                   from the JSON.
# vantage.version - Required Argument.
#                   The vantage version of the Vantage system connected to.
# 
# Returns:
# The updated function map list.
#
#     Example: The 'arguments' section for the GLM function map's is updated
#              with the following:
#              
#              list(
#                arguments = list(
#                  sql_to_tdplyr = list(
#                    inputcolumns = list(
#                      tdplyr_name = "formula",
#                      tdplyr_type = "character",
#                      used_in_formula = TRUE
#                    ),
#                    targetcolumns = list(
#                      alternate_to = "inputcolumns"
#                    ),
#                    categoricalcolumns = list(
#                      tdplyr_name = "formula",
#                      tdplyr_type = "character",
#                      used_in_formula = TRUE
#                    )
#                  ),
#                  tdplyr_to_sql = list(
#                    formula = c(inputcolumns, categoricalcolumns)
#                  )
#                )
#              )
#
.resolveFormulaArgs <- function(function.map, formula.args, vantage.version) {
  foundDependent <- FALSE
  
  # Check if formula explicitly uses a response column
  for (arg in formula.args) {
    if (arg$rOrderNum == 0) {
      foundDependent <- TRUE
      break
    }
  }
  
  # Let's get the globals to use as keys in the function argument map.
  tdplyrType <- .get(".fam.tdplyrCharacterType")
  tdplyrName <- .get(".fam.tdplyrFormulaName")
  famUsedInFormula <- .get(".fam.usedInFormula")
  famArguments <- .get(".fam.arguments")
  famTdplyrToSql <- .get(".fam.tdplyrToSql")
  famSqlToTdplyr <- .get(".fam.sqlToTdplyr")
  
  argCounter <- 0
  
  for (arg in formula.args) {
    argCounter <- argCounter + 1
    
    if (arg$rOrderNum == 0) {
      usedInFormula <- .get(".fam.dependentAttr")
    } else {
      if (isTRUE(foundDependent)) {
        usedInFormula <- .get(".fam.independentAttr")
      } else {
        usedInFormula <- TRUE
      }
    }
    
    argName <- arg[[.get(".fam.name")]]
    sqlNameToUse <- tolower(.resolveName(argName, vantage.version))
    
    if (is.list(argName)) {
      for (arg in names(argName)) {
        for (i in 1:length(arg)) {
          if (i == 1) {
            function.map <- .addSqlToTdplyrEntry(functionmap = function.map,
                                                 sqlname = argName[[arg]][i],
                                                 tdplyrname = tdplyrName,
                                                 tdplyrtype = tdplyrType)
            function.map[[famArguments]][[famSqlToTdplyr]][[tolower(argName[[arg]][i])]][[famUsedInFormula]] <- usedInFormula
            if (argCounter > 1)
              function.map[[famArguments]][[famTdplyrToSql]][[tdplyrName]] <- append(function.map[[famArguments]][[famTdplyrToSql]][[tdplyrName]],
                                                                                    sqlNameToUse)
            else
              function.map[[famArguments]][[famTdplyrToSql]][[tdplyrName]] <- sqlNameToUse
          } else {
            function.map <- .addSqlToTdplyrEntry(functionmap = function.map,
                                                 sqlname = argName[[arg]][i],
                                                 sqlnametouse = sqlNameToUse,
                                                 alternateto = TRUE)
          }
        }
      }
    } else {
      for (i in 1:length(argName)) {
        if (i == 1) {
          function.map <- .addSqlToTdplyrEntry(functionmap = function.map,
                                               sqlname = argName[i],
                                               tdplyrname = tdplyrName,
                                               tdplyrtype = tdplyrType)
          function.map[[famArguments]][[famSqlToTdplyr]][[tolower(argName[i])]][[famUsedInFormula]] <- usedInFormula
          if (argCounter > 1) {
            function.map[[famArguments]][[famTdplyrToSql]][[tdplyrName]] <- append(function.map[[famArguments]][[famTdplyrToSql]][[tdplyrName]],
                                                                                  sqlNameToUse)
          } else {
            function.map[[famArguments]][[famTdplyrToSql]][[tdplyrName]] <- sqlNameToUse
          }
        } else {
          function.map <- .addSqlToTdplyrEntry(functionmap = function.map,
                                               sqlname = argName[i],
                                               sqlnametouse = sqlNameToUse,
                                               alternateto = TRUE)
        }
      }
    }
  }
  
  return(function.map)
}

# Function to add entries related to sequence.column arguments to the function
# argument map.
#
# Arguments:
# function.map    - Required Argument.
#                   The function map to update with the information.
# sequence.arg    - Required Argument.
#                   The list containing the sequence related argument entries
#                   from the JSON.
# vantage.version - Required Argument.
#                   The vantage version of the Vantage system connected to.
# 
# Returns:
# The updated function map list.
#
#     Example: The 'arguments' section for the GLM function map's is updated
#              with the following:
#              
#              list(
#                arguments = list(
#                  tdplyr_to_sql = list(
#                    data.sequence.column = "sequenceinputby"),
#                  sql_to_tdplyr = list(
#                    sequenceinputby = list(
#                      tdplyr_name = c("data.sequence.column"),
#                      tdplyr_type = c("character", "list"),
#                      used_in_sequence_by = TRUE),
#                    uniqueid = list(alternate_to = "sequenceinputby")
#                  )
#                )
#              )
# 
.resolveSequenceInputArgs <- function(function.map, sequence.arg, vantage.version) {
  sequenceArgRName <- sequence.arg$rName
  argName <- sequence.arg$name
  inputTdplyrNames <- character()
  tdplyrNames <- character()
  
  # Let's get the globals to use as keys in the function argument map.
  famInputs <- .get(".fam.inputs")
  famTdplyrToSql <- .get(".fam.tdplyrToSql")
  tdplyrType <- c(.get(".fam.tdplyrCharacterType"), .get(".fam.tdplyrList"))
  famUsedInSequenceInputBy <- .get(".fam.usedInSequenceInputBy")
  famArguments <- .get(".fam.arguments")
  famSqlToTdplyr <- .get(".fam.sqlToTdplyr")
  
  for (key in names(function.map[[famInputs]][[famTdplyrToSql]])) {
    inputTdplyrNames <- c(inputTdplyrNames, key)
    tdplyrNames <- c(tdplyrNames, paste0(key, ".", sequenceArgRName))
  }
  
  tdplyrNames <- unique(tdplyrNames)

  argName <- sequence.arg[[.get(".fam.name")]]
  sqlNameToUse <- tolower(.resolveName(argName, vantage.version))
  
  if (is.list(argName)) {
    for (arg in names(argName)) {
      for (i in 1:length(arg)) {
        if (i == 1) {
          function.map <- .addSqlToTdplyrEntry(functionmap = function.map,
                                               sqlname = argName[[arg]][i],
                                               tdplyrname = tdplyrNames,
                                               tdplyrtype = tdplyrType)
          function.map[[famArguments]][[famSqlToTdplyr]][[tolower(argName[[arg]][i])]][[famUsedInSequenceInputBy]] <- TRUE
          for (name in tdplyrNames) {
            function.map[[famArguments]][[famTdplyrToSql]][[name]] <- sqlNameToUse
          }
        } else {
          function.map <- .addSqlToTdplyrEntry(functionmap = function.map,
                                               sqlname = argName[[arg]][i],
                                               sqlnametouse = sqlNameToUse,
                                               alternateto = TRUE)
        }
      }
    }
  } else {
    for (i in 1:length(argName)) {
      if (i == 1) {
        function.map <- .addSqlToTdplyrEntry(functionmap = function.map,
                                             sqlname = argName[i],
                                             tdplyrname = tdplyrNames,
                                             tdplyrtype = tdplyrType)
        function.map[[famArguments]][[famSqlToTdplyr]][[tolower(argName[i])]][[famUsedInSequenceInputBy]] <- TRUE
        for (name in tdplyrNames) {
          function.map[[famArguments]][[famTdplyrToSql]][[name]] <- sqlNameToUse
        }
      } else {
        function.map <- .addSqlToTdplyrEntry(functionmap = function.map,
                                             sqlname = argName[i],
                                             sqlnametouse = sqlNameToUse,
                                             alternateto = TRUE)
      }
    }
  }
  
  return(function.map)
}

#
# Function to get non-standard output names for functions that are known to
# have it.
# 
# Arguments:
# function.tdplyr.name    - Required Argument.
#                           The name of the tdplyr class corresponding to the
#                           function.
# default.output.name     - Required Argument.
#                           The default name for the output based on which we
#                           lookup for a custom, if any.
# 
# Returns:
# The string representing the output name as expected by the function, one of
# the default or custom names.
# 
.getCustomOutputName <- function(function.tdplyr.name, default.output.name) {
  # Get the custom output mapper
  customOutputs <- .get(".fam.customOuputNames")
  
  if (function.tdplyr.name %in% names(customOutputs))
    if (default.output.name %in% names(customOutputs[[function.tdplyr.name]]))
      return(customOutputs[[function.tdplyr.name]][[default.output.name]])
  
  return(default.output.name)
}
