# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' @export
predict.td_decision_forest_mle <- function(object = NULL,
                                     newdata = NULL,
                                     id.column = NULL,
                                     detailed = FALSE,
                                     terms = NULL,
                                     newdata.order.column = NULL,
                                     object.order.column = NULL
                                     ) {
  td_decision_forest_predict_sqle(object = object,
                           newdata = newdata,
                           id.column = id.column,
                           detailed = detailed,
                           terms = terms,
                           newdata.order.column = newdata.order.column,
                           object.order.column = object.order.column)
}
