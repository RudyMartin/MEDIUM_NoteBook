# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# Secondary Owner: Arun kalyanasundaram (arun.kalyanasundaram@teradata.com)
# 
# Version: 1.2
# Function Version: 1.3
# 
# ################################################################## 

# Description:
#   The ChangePointDetection function detects change points in a 
#   stochastic process or time series, using retrospective change-point 
#   detection, implemented with these algorithms:
# 
# Args:
#   data -
#     Required Argument.\cr
#     This tbl_teradata defining the input time series data.\cr
#   
#   data.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   data.order.column -
#     Required Argument.\cr
#     Specifies Order By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   value.column -
#     Required Argument.\cr
#     Specifies the name of the input tbl_teradata column that contains the 
#     time series data.\cr
#     Types: character
#   
#   accumulate -
#     Required Argument.\cr
#     Specifies the names of the input tbl_teradata columns to copy to the 
#     output table. Tip: To identify change points in the output table, 
#     specify the columns that appear in partition_exp and order_by_exp.\cr
#     Types: character OR vector of Strings (character)
#   
#   segmentation.method -
#     Optional Argument.\cr
#     Specifies one of these segmentation methods:"normal_distribution" 
#     (default): In each segment, the data is in a normal distribution, 
#     "linear_regression": In each segment, the data is in linear 
#     regression.\cr
#     Default Value: "normal_distribution"\cr
#     Permitted Values: normal_distribution, linear_regression\cr
#     Types: character
#   
#   search.method -
#     Optional Argument.\cr
#     Specifies the search method, binary segmentation. This is the default 
#     and only possible value.\cr
#     Default Value: "binary"\cr
#     Permitted Values: binary\cr
#     Types: character
#   
#   max.change.num -
#     Optional Argument.\cr
#     Specifies the maximum number of change points to detect. \cr
#     Default Value: 10\cr
#     Types: integer
#   
#   penalty -
#     Optional Argument.\cr
#     Specifies the penalty function, which is used to avoid over-fitting. 
#     Possible values are: "BIC" (default), "AIC", threshold, a numeric 
#     valueFor BIC, the condition for the existence of a change point is: 
#     ln(L1)?ln(L0) > (p1-p0)*ln(n)/2 For normal distribution and linear 
#     regression, the condition is: (p1-p0)*ln(n)/2 = ln(n) For AIC, the 
#     condition for the existence of a change point is: ln(L1)?ln(L0) > 
#     p1-p0 For normal distribution and linear regression, the condition 
#     is: p1-p0 = 2 For threshold, the specified value is compared to: 
#     ln(L1)?ln(L0) L1 and L2 are the maximum likelihood estimation of 
#     hypotheses H1 and H0. For normal distribution, the definition of 
#     Log(L1 ) and Log(L0) are in "Background". p is the number of 
#     additional parameters introduced by adding a change point. p is used 
#     in the information criterion BIC or AIC. p1 and p0 represent this 
#     parameter in hypotheses H1 and H0 separately\cr
#     Default Value: "BIC"\cr
#     Types: character
#   
#   output.option -
#     Optional Argument.\cr
#     Specifies the output tbl_teradata columns. Refer to "Output. \cr
#     Default Value: "changepoint"\cr
#     Permitted Values: changepoint, segment, verbose\cr
#     Types: character
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_changepoint_detection_mle" 
#   which is a named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_changepoint_detection_mle <- function(
  data = NULL,
  data.partition.column = NULL,
  data.order.column = NULL,
  value.column = NULL,
  accumulate = NULL,
  segmentation.method = "normal_distribution",
  search.method = "binary",
  max.change.num = 10,
  penalty = "BIC",
  output.option = "changepoint",
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.partition.column", data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("value.column", value.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("segmentation.method", segmentation.method, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("search.method", search.method, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("max.change.num", max.change.num, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("penalty", penalty, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.option", output.option, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check for permitted values
  segmentation.methodPermittedValues <- list("NORMAL_DISTRIBUTION", "LINEAR_REGRESSION")
  .validatePermittedValues(segmentation.method, segmentation.methodPermittedValues)
  
  search.methodPermittedValues <- list("BINARY")
  .validatePermittedValues(search.method, search.methodPermittedValues)
  
  output.optionPermittedValues <- list("CHANGEPOINT", "SEGMENT", "VERBOSE")
  .validatePermittedValues(output.option, output.optionPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(value.column)
  .validateTblHasArgumentColumns(value.column, "value.column", data, "data")
  
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.partition.column)
  .validateTblHasArgumentColumns(data.partition.column, "data.partition.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ValueColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(value.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(accumulate,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(segmentation.method) && !missing(segmentation.method)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SegmentationMethod")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(segmentation.method, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(search.method) && !missing(search.method)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SearchMethod")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(search.method, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(max.change.num) && !missing(max.change.num)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MaxChangeNum")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(max.change.num, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(penalty) && !missing(penalty)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Penalty")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(penalty, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(output.option) && !missing(output.option)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputOption")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.option, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  data.partition.column <- .teradataCollapseArgVector(data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "ChangePointDetection",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("ChangePointDetection", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_changepoint_detection_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_changepoint_detection <- td_changepoint_detection_mle
