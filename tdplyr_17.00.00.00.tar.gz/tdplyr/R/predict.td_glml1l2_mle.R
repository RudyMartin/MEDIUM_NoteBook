# Copyright 2019 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' @export
predict.td_glml1l2_mle <- function(modeldata = NULL,
                                   newdata = NULL,
                                   accumulate = NULL,
                                   output.prob = FALSE,
                                   output.responses = NULL,
                                   newdata.sequence.column = NULL,
                                   modeldata.sequence.column = NULL,
                                   newdata.order.column = NULL,
                                   modeldata.order.column = NULL
) {
  td_glml1l2_predict_mle(modeldata = modeldata,
                         newdata = newdata,
                         accumulate = accumulate,
                         output.prob = output.prob,
                         output.responses = output.responses,
                         newdata.sequence.column = newdata.sequence.column,
                         modeldata.sequence.column = modeldata.sequence.column,
                         newdata.order.column = newdata.order.column,
                         modeldata.order.column = modeldata.order.column
                        )
}
