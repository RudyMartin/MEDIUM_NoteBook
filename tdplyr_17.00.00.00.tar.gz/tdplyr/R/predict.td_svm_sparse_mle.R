# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' @export
predict.td_svm_sparse_mle <- function(object = NULL,
                            newdata = NULL,
                            sample.id.column = NULL,
                            attribute.column = NULL,
                            value.column = NULL,
                            accumulate.label = NULL,
                            output.class.num = 1,
                            newdata.partition.column = NULL,
                            newdata.order.column = NULL,
                            object.order.column = NULL) {
   td_svm_sparse_predict_sqle(object = object,
                          newdata = newdata,
                          sample.id.column = sample.id.column,
                          attribute.column = attribute.column,
                          value.column = value.column,
                          accumulate.label = accumulate.label,
                          output.class.num = output.class.num,
                          newdata.partition.column = newdata.partition.column,
                          newdata.order.column = newdata.order.column,
                          object.order.column = object.order.column
                          )
 }
