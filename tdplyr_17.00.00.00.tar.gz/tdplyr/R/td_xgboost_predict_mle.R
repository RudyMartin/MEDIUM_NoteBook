# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 2.8
# 
# ################################################################## 

# Description:
#   The XGBoost Predict function applies the model output by the XGBoost 
#   DriveExample of XGBoost Drive function that uses binary 
#   classification.Input for example of XGBoost Drive function that uses 
#   binary classification.SQL-MapReduce call for example of XGBoost Drive 
#   function that uses binary classification.Output for example of 
#   XGBoost Drive function that uses binary classification.Example of 
#   XGBoost Drive function that uses multiple-class classification.Input 
#   for example of XGBoost Drive function that uses multiple-class 
#   classification.SQL-MapReduce for example of XGBoost Drive function 
#   that uses multiple-class classification.Output for example of XGBoost 
#   Drive function that uses multiple-class classification. function to a 
#   new data set.
# 
# Args:
#   object -
#     Required Argument.
#     Specifies the tbl_teradata containing the model data.
#   
#   object.order.column -
#     Required Argument.
#     Specifies Order By columns for object.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   newdata -
#     Required Argument.
#     Specifies the tbl_teradata containing the input test data.
#   
#   newdata.partition.column -
#     Optional Argument
#     Specifies Partition By columns for newdata.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.
#     Default Value: ANY
#     Types: character OR vector of Strings (character)
#   
#   newdata.order.column -
#     Optional Argument.
#     Specifies Order By columns for newdata.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   id.column -
#     Optional Argument.
#     Specifies a column containing a unique identifier for each test point 
#     in the test set
#     Types: character
#   
#   terms -
#     Optional Argument.
#     Specifies the names of the input columns to copy to the output table.
#     Types: character OR vector of Strings (character)
#   
#   iter.num -
#     Optional Argument.
#     Specifies the number of iterations for each boosted tree to use for 
#     prediction. The number must an integer. The lower bound is 1. If this 
#     argument is not specified, the value is the same as used for training 
#     model. The number of iterations used is upperbounded by the number of 
#     iterations used during training.
#     Types: integer
#   
#   num.boosted.trees -
#     Optional Argument.
#     Specifies the number of boosted trees to be used for prediction. If 
#     this argument is not specified, the value is the same as used for 
#     training model. The number of boosted trees used for prediciton is 
#     upper bounded by the number of boosted trees used during training.
#     Types: integer
#   
#   attribute.name.column -
#     Optional Argument.
#     Required for sparse data format, if the data set is in sparse format, 
#     this argument indicates the column containing the attributes in the 
#     input table
#     Types: character
#   
#   attribute.value.column -
#     Optional Argument.
#     If the data is in the sparse format, this argument indicates the 
#     column containing the attribute values in the input table
#     Types: character
#   
#   output.response.probdist -
#     Optional Argument.
#     Specifies whether to output probabilities.
#     Default Value: FALSE
#     Types: logical
#   
#   output.responses -
#     Optional Argument.
#     Specifies responses in input table.
#     Types: character OR vector of characters
#   
#   newdata.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "newdata". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
#   
#   object.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "object". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_xgboost_predict_mle" which is 
#   a named list containing Teradata tbl object.
#   Named list member can be referenced directly with the "$" operator 
#   using name: result.
# 
# 
#' @export
td_xgboost_predict_mle <- function(
  object = NULL,
  object.order.column = NULL,
  newdata = NULL,
  newdata.partition.column = "ANY",
  newdata.order.column = NULL,
  id.column = NULL,
  terms = NULL,
  iter.num = NULL,
  num.boosted.trees = NULL,
  attribute.name.column = NULL,
  attribute.value.column = NULL,
  output.response.probdist = FALSE,
  output.responses = NULL,
  newdata.sequence.column = NULL,
  object.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("object", object, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("object.order.column", object.order.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata", newdata, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata.partition.column", newdata.partition.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata.order.column", newdata.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("id.column", id.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("terms", terms, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("iter.num", iter.num, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("num.boosted.trees", num.boosted.trees, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("attribute.name.column", attribute.name.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("attribute.value.column", attribute.value.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.response.probdist", output.response.probdist, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.responses", output.responses, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("newdata.sequence.column", newdata.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("object.sequence.column", object.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  if (.isRefFuncOutput(object, "td_xgboost_mle")) {
    object <- object[[1]]
  }
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(newdata, NULL)
  .validateInputTableDataType(object, "td_xgboost_mle")
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(id.column)
  .validateTblHasArgumentColumns(id.column, "id.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(terms)
  .validateTblHasArgumentColumns(terms, "terms", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(attribute.name.column)
  .validateTblHasArgumentColumns(attribute.name.column, "attribute.name.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(attribute.value.column)
  .validateTblHasArgumentColumns(attribute.value.column, "attribute.value.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(newdata.sequence.column)
  .validateTblHasArgumentColumns(newdata.sequence.column, "newdata.sequence.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(object.sequence.column)
  .validateTblHasArgumentColumns(object.sequence.column, "object.sequence.column", object, "object")
  
  .validateInputColumnsNotEmpty(newdata.partition.column)
  if (.isDefaultOrNot(newdata.partition.column, "ANY")) {
    .validateTblHasArgumentColumns(newdata.partition.column, "newdata.partition.column", newdata, "newdata")
  }
  .validateInputColumnsNotEmpty(newdata.order.column)
  .validateTblHasArgumentColumns(newdata.order.column, "newdata.order.column", newdata, "newdata")
  
  .validateInputColumnsNotEmpty(object.order.column)
  .validateTblHasArgumentColumns(object.order.column, "object.order.column", object, "object")
  
  # The argument 'output.response.probdist' must be set to TRUE to use the 
  # argument 'output.responses'.
  if (!isTRUE(output.response.probdist) && !is.null(output.responses)) {
    .ta.stop("TDR_E3101", "output.responses", "output.response.probdist", "set to TRUE")
  }
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  if (!is.null(id.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IdColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(id.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(terms)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(terms,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(attribute.name.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AttributeNameColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(attribute.name.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(attribute.value.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AttributeValueColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(attribute.value.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(iter.num)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IterNum")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(iter.num, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(num.boosted.trees)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NumBoostedTrees")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(num.boosted.trees, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(output.response.probdist) && !missing(output.response.probdist)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputProb")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.response.probdist, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(output.responses)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Responses")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.responses, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(newdata.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(newdata.sequence.column, "")))
  }
  
  if (!is.null(object.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("ModelTable:", .teradataCollapseArgVector(object.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process newdata
  if (.isDefaultOrNot(newdata.partition.column, "ANY")) {
    newdata.partition.column <- .teradataCollapseArgVector(newdata.partition.column, "\"")
  }
  
  tableRef <- .teradataOnClauseFromDataFrame(newdata)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, newdata.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(newdata.order.column, "\""))
  
  # Process object
  tableRef <- .teradataOnClauseFromDataFrame(object)
  funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "ModelTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(object.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "XGBoostPredict",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("XGBoostPredict", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(newdata, object)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_xgboost_predict_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units = "secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_xgboost_predict <- td_xgboost_predict_mle
