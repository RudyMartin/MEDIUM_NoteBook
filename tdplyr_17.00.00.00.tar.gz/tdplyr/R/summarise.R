################################################################################
#
# Copyright 2019 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: Adithya Avvaru (adithya.avvaru@teradata.com)
# Secondary Owner:
#
# This file has:
#   1.  Overridden summarise function which works for time series grouping and
#       regular grouping.
#   2.  sql_build function which builds SQL for aggregation on time series
#       grouped tibbles.
#   3.  op_vars function which returns the column names that are returned after
#       summarise operation.
#   4.  op_grps function which returns the grouping columns after summarise
#       operation.
#
################################################################################

#' Summarise a grouped or ungrouped column
#'
#' Creates one or more columns summarizing the columns of tbl_teradata.
#' Tibbles with groups created by `group_by()` and `group_by_time()` will result
#' in one or more rows in the output for each group based on the aggregate
#' operation used in summarise. Tibbles without groups will result in one or
#' more rows in the output based on the aggregate operation.
#'
#' @param .data Required Argument.\cr
#'              Specifies the tbl_teradata which contains the columns on
#'              which aggregate operations are to be performed.
#' @param ... Name-value pairs of summary functions. The name specifies the
#'            name of the column in the result tbl_teradata. The value
#'            specifies an expression that returns a single value like
#'            `min(x)`, `n()`, or `sum(is.na(y))` where 'x' and 'y' are the
#'            column names.
#' @seealso \code{\link{summarise}} function in the dplyr package for some other
#' examples of summarise.
#' @return A `tbl_teradata` object.
#' @examples
#' \donttest{
#'
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#'
#' # Load the required tables.
#' loadExampleData("time_series_example", "ocean_buoys_seq")
#'
#' # Create object of class "tbl_teradata".
#' df_seq <- tbl(con, "ocean_buoys_seq")
#'
#' # Example 1: Get the minimum of the column 'temperature', grouped by timebucket
#' #            timebucket duration of 30 minutes and the column 'buoyid'.
#'
#' # Grouping by timebucket duration of 30 minutes and 'buoyid'.
#' seq_group1 <- df_seq %>% group_by_time(timebucket.duration = "30m",
#'                                        value.expression = "buoyid")
#'
#' # Applying min() aggregation on grouped tbl object.
#' seq_group1 %>% summarise(min_temp = min(temperature))
#'
#' # Example 2: Get the minimum of the column 'temperature' grouped by the
#' #            column 'buoyid'.
#'
#' # Grouping by column 'buoyid'.
#' seq_group2 <- df_seq %>% group_by(buoyid)
#'
#' # Applying min() aggregation on grouped tbl object.
#' seq_group2 %>% summarise(min_temp = min(temperature))
#'
#' }

#' @export
#' @importFrom dplyr summarise
#' @importFrom rlang quos
#' @importFrom rlang new_quosure
#' @importFrom rlang get_expr
#' @importFrom rlang get_env
#' @importFrom dbplyr partial_eval
#' @importFrom dbplyr add_op_single
#' @rdname summarise
#' @aliases summarise
summarise.tbl_teradata <- function(.data, ...) {
  dots <- quos(..., .named = TRUE)
  dots <- partial_eval_dots(dots, vars = op_vars(.data))
  check_summarise_vars(dots)
  if (inherits(.data$ops, "op_group_by_time")) {
    .validate_delta_t_conditions(.data$ops$args, dots = dots)
    add_op_single("summarise_group_by_time", .data, dots = dots,
                  args = .get_args_for_describe(dots))
  } else {
    # Without the below check, the query generated will have SQL clauses like
    # `MAX("temperature") AS "Maximum(temperature)" AS "desc_t1"` when we call `ts.describe`
    # without `group_by_time`. This leads to syntax error that confuses the user.
    # Infact, `describe` is not a valid regular aggregate operation in SQL.
    describe_ops <- .get_args_for_describe(dots)
    if (length(describe_ops[["describe_idx"]]) > 0) {
      .ta.stop("TDR_E3300", "\nPlease check vignettes and documentation for correct usage.")
    }
    # For group_by summarise and summarise without group_by
    add_op_single("summarise", .data, dots = dots)
  }
}

#' @export
#' @importFrom dbplyr sql_build
#' @importFrom dbplyr translate_sql_
sql_build.op_summarise_group_by_time <- function(op, con, ...) {
  group_by_time_clause <- op$x$args[["group_by_time_expr"]]
  value_expressions <- op$x$args[["value_expression"]]

  select_variables <- translate_sql_(op$dots, con, window = FALSE,
                                     context = list(clause = "SELECT"))

  timecode_range <- paste0("$TD_TIMECODE_RANGE AS TIMECODE_RANGE")
  time_bucket_duration <- op$x$args[["time_bucket_duration"]]
  grp_by_time_col <- paste0("$TD_GROUP_BY_TIME AS \"GROUP BY TIME(", time_bucket_duration,")\"")

  select_variables <- c(sql(timecode_range), sql(grp_by_time_col), sql(value_expressions),
                        select_variables)

  # start_idx - Index where describe's first SQL clause start.
  # end_idx - Index where describe's last SQL clause end.
  describe_ops <- .get_args_for_describe(op$dots)
  is_describe <- isTRUE(length(describe_ops[["describe_idx"]]) > 0)

  if (isTRUE(is_describe)) {

    start_indices <- op$args[["describe_idx"]]

    # Because 2 more expressions (timecode_range, grp_by_time_col) are added before select_variables
    # along with value_epressions, if not NULL.
    offset_idx <- 2
    if (!is.null(value_expressions)) {
      # value_expressions may contain multiple column names which are added to SQL clauses.
      offset_idx <- offset_idx + length(value_expressions)
    }

    # Adjusting start and end indices for describe SQL clauses.
    start_indices <- start_indices + offset_idx

    # select_variables will be of the form `MIN(temperature) AS Minimum(temperature) AS desc_temp1`,
    # `MAX(temperature) AS Maximum(temperature) AS desc_temp2`, ... when there is a call to
    # ts.describe as `desc_temp = ts.describe(temperature)`.
    # Such select_variables are trimmed to `MIN(temperature) AS Minimum(temperature)`.
    for (j in 1:length(start_indices)) {
      # Start indices increase by 9 for every new index.
      # Multiplying by 8 because start index already holds `max` (1st one of describe expression).
      start_idx <- start_indices[j] + (j - 1) * 8
      # Currently, start_idx is already at `max`, first aggregate of ts.describe()
      # 8 additional columns (min, avg, stddev, median, mode and 3 percentiles) need to be processed.
      # Processing only those select_variables which are generated due to ts.describe().
      for (i in start_idx:(start_idx + 8)) {
          split_select <- unlist(strsplit(select_variables[i][[1]], " AS "))
          # There is at least one alias ie 'AS' in this 'select' clause.
          # If there are multiple aliases, we take only the first alias and ignore remaining.
          if (length(split_select) > 1) {
            select_variables[i] <- paste0(split_select[1:2], collapse = " AS ")
          }
      }
    }
  }

  for (i in 1:length(select_variables)) {
    # Integers are converted to decimals, i.e., bottom(2, col_name) -> bottom(2.0, col_name).
    # Removing .0 in the SQL expression.
    select_variables[i] <- gsub(x = select_variables[i], pattern = "(\\()([0-9]+)*.0, \"",
                                replacement = "\\1\\2, \"")
    select_variables[i] <- gsub(x = select_variables[i], pattern = "`", replacement = "\"")
  }

  select_query_time_series(sql_build(op$x, con), group_by_time = group_by_time_clause,
               select = select_variables)
}

#' @export
op_grps.op_summarise_group_by_time <- function(op) {
  # No specific grouping done like regular group_by.
  character()
}

#' @export
op_vars.op_summarise_group_by_time <- function(op) {
  # Group by time column which contains timebucket number should also be added into the
  # list of column names along with group_by_time grouping columns and summarise named columns.
  time_bucket_duration <- op$x$args[["time_bucket_duration"]]
  grp_by_time_col <- paste0("GROUP BY TIME(", time_bucket_duration,")")
  vars <- c(op_grps(op$x), .get_column_names_summarise(op$dots))
  vars <- append(vars, grp_by_time_col, after = 1)
  vars
}

# This function validates if the unbounded time bucket duration is used only with DELTA_T
# time series function.
#' @importFrom rlang as_label
.validate_delta_t_conditions <- function(args, dots) {
  # Checking if 'ts.delta_t' is called in any of the calls in summarise.
  timebucket.value <- args["time_bucket_duration"]
  group_by_time_value <- args['group_by_time_expr']
  is.delta.t.present <- FALSE
  for (dot in dots) {
    if (grepl("ts.delta_t", as_label(dot), fixed = TRUE)) {
      is.delta.t.present <- TRUE
      break
    }
  }

  # DELTA_T cannot be clubbed with any other aggregate function.
  if (isTRUE(is.delta.t.present) && length(dots) > 1) {
    .ta.stop("TDR_E3302")
  }

  # Unbounded time bucket duration can be used only for DELTA_T.
  if (!isTRUE(is.delta.t.present) && trimws(timebucket.value) == "*") {
    .ta.stop("TDR_E3303")
  }

  if (isTRUE(is.delta.t.present) && grepl("FILL", group_by_time_value, fixed = TRUE)) {
    .ta.stop("TDR_E3304")
  }

  return(TRUE)
}

# This function returns a named list containing indices where ts.describe is present.
# For example, list("describe_idx" = idx),
# where describe_idx holds the vector of start indices of ts.describe, if there are multiple
# ts.describe calls.
#' @importFrom rlang quo_name
.get_args_for_describe <- function(dots) {
  desc_indices <- c()
  i <- 1
  for (dot in dots) {
    func <- quo_name(dot)
    if (grepl("ts.describe", func)) {
      desc_indices <- c(desc_indices, i)
    }
    i <- i + 1
  }
  return(list("describe_idx" = desc_indices))
}

# This function returns the column names from the quosure to be used in op_vars.
#' @importFrom rlang quo_name
.get_column_names_summarise <- function(dots) {
  column_names <- c()
  i <- 1
  for (dot in dots) {

    # The variable 'func' will be the function call in STRING notation. For example
    #   1. "min(temperature)"
    #   2. "ts.describe(value.expression = temperature)"
    func <- quo_name(dot)

    if (grepl("ts.describe", func)) {

      # Extracting the actual column name present in 'value.expression' argument.
      actual_col_name <- gsub(pattern = "^ts\\.describe*\\((value.expression = )?(.*)\\)$",
                         replacement = "\\2",
                         x = func)
      # Removing additional characters not part of column name
      actual_col_name <- gsub(pattern = "sql|\\(|\\)|`|\"", replacement = "",
                              x = actual_col_name)
      actual_col_name <- trimws(actual_col_name)

      is_distinct <- FALSE
      # If current `actual_col_name` is `distinct("column_name")`, then updating it to 'column_name'.
      if (grepl(pattern = "^distinct", actual_col_name, ignore.case = TRUE)) {
        actual_col_name <- sub(pattern = "^distinct(.*)$", replacement = "\\1",
                               x = actual_col_name, ignore.case = TRUE)
        is_distinct <- TRUE
      }

      ## Generate all required column names.
      col_names <- c("Maximum", "Minimum", "Average", "STDDEV_SAMP", "MEDIAN")

      # Appending the "actual_col_name" to all aggregates in the variable 'col_names'.
      if (isTRUE(is_distinct)) {
        col_names <- paste0(col_names, paste0("(Distinct(", actual_col_name, "))"))
      } else {
        col_names <- paste0(col_names, paste0("(", actual_col_name, ")"))
      }

      # Distinct is not allowed on MODE, hence, it is not dependent on `is_distinct`.
      mode_col <- paste0("MODE(", actual_col_name, ")")

      percent_cols <- c("25", "50", "75")
      if (isTRUE(is_distinct)) {
        percent_cols <- paste0("PERCENTILE(Distinct(",actual_col_name,", ", percent_cols, ", LINEAR))")
      } else{
        percent_cols <- paste0("PERCENTILE(",actual_col_name,", ", percent_cols, ", LINEAR)")
      }

      column_names <- c(column_names, col_names, mode_col, percent_cols)

    } else {
      # If the aggregate function is not 'ts.describe', then column name is same as that of the name
      # of the quosure expression.
      column_names <- c(column_names, names(dots)[[i]])
    }
    i <- i + 1
  }
  return(column_names)
}