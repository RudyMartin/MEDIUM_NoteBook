# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET


#' Remove the current context and close the corresponding connection to Teradata Vantage
#'
#' Use the \code{td_remove_context} function to remove an existing context created using the 
#' \code{td_create_context} or the \code{td_set_context} or
#' \code{dbConnect(tdplyr::NativeDriver(), ...)} function.
#' This performs removal (garbage collection) of all non-persistent work tables created by the 
#' analytic functions. This closes the corresponding connection object.\cr
#' Note: If \code{DBI::dbDisconnect} is invoked on the connection object in the current context 
#' before calling the \code{td_remove_context} function, then a warning is displayed and garbage 
#' collection is not performed.
#' @return Returns NULL invisibly
#' @rdname td_remove_context
#' @seealso \code{td_create_context}, \code{td_set_context}, \code{td_get_context},
#' \code{dbConnect}
#' @export
#' @examples
#' \donttest{
#' # Example 1: Remove the connection that is established using td_create_context().
#' td_create_context(dsn = "TeradataDSN")
#' # The nonpersistent work tables are garbage collected and the connection is disconnected
#' td_remove_context()
#'
#' # Example 2: Remove the connection that is established using td_set_context().
#' # Establish connection to Teradata Vantage using the dbConnect API
#' con <- DBI::dbConnect(odbc::odbc(), dsn = "TeradataDSN")
#'
#' # Use td_set_context to initialize a context with a given connection object.
#' td_set_context(con = con)
#' td_remove_context()
#'
#' }
td_remove_context <- function() {
  # Check if context exists and throw error appropriately
  con <- .taConnection(silent = FALSE)
  
  # Display a warning that context is being removed? 
  # .ta.warning("TDR_W1005")
  
  .ta.removeContext()
}