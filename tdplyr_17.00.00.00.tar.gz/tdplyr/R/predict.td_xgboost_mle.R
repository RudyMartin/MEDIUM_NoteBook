# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' @export
predict.td_xgboost_mle <- function(
  object = NULL,
  object.order.column = NULL,
  newdata = NULL,
  newdata.partition.column = "ANY",
  newdata.order.column = NULL,
  id.column = NULL,
  terms = NULL,
  iter.num = NULL,
  num.boosted.trees = NULL,
  attribute.name.column = NULL,
  attribute.value.column = NULL,
  output.response.probdist = FALSE,
  output.responses = NULL,
  newdata.sequence.column = NULL,
  object.sequence.column = NULL
) {
  td_xgboost_predict_mle(object = object,
                         object.order.column = object.order.column,
                         newdata = newdata,
                         newdata.partition.column = newdata.partition.column,
                         newdata.order.column = newdata.order.column,
                         id.column = id.column,
                         terms = terms,
                         iter.num = iter.num,
                         num.boosted.trees = num.boosted.trees,
                         attribute.name.column = attribute.name.column,
                         attribute.value.column = attribute.value.column,
                         output.response.probdist = output.response.probdist,
                         output.responses = output.responses,
                         newdata.sequence.column = newdata.sequence.column,
                         object.sequence.column = object.sequence.column
                     )
}
