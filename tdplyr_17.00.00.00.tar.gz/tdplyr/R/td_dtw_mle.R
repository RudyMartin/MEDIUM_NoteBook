# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# Secondary Owner: Arun Kalyanasundaram (Arun.Kalyanasundaram@teradata.com)
# 
# Version: 1.2
# Function Version: 1.6
# 
# ################################################################## 

# Description:
#   The DTW function performs dynamic time warping (DTW), which measures 
#   the similarity (warp distance) between two time series that vary in 
#   time or speed. You can use DTW to analyze any data that can be 
#   represented linearly for example, video, audio, and graphics.
# 
# Args:
#   data -
#     Required Argument.
#     the tbl_teradata contains the time series information
#   
#   data.partition.column -
#     Required Argument.
#     Specifies Partition By columns for data.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.
#     Types: character OR vector of Strings (character)
#   
#   data.order.column -
#     Required Argument.
#     Specifies Order By columns for data.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   template.data -
#     Required Argument.
#     the tbl_teradata contains the template information
#   
#   template.data.order.column -
#     Required Argument.
#     Specifies Order By columns for template.data.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   mapping.data -
#     Required Argument.
#     the tbl_teradata contains the mapping between the rows in the 
#     inputTable and the rows in the templateTable
#   
#   mapping.data.partition.column -
#     Required Argument.
#     Specifies Partition By columns for mapping.data.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.
#     Types: character OR vector of Strings (character)
#   
#   mapping.data.order.column -
#     Optional Argument.
#     Specifies Order By columns for mapping.data.
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.
#     Types: character OR vector of Strings (character)
#   
#   input.columns -
#     Required Argument.
#     Specifies the names of the data columns that contain the values and 
#     timestamps of the time series. Note that the input.columns argument 
#     has the alternate name input.columns. Note: If these columns contain 
#     NaN or infinity values, then use a WHERE clause to remove them.
#     Types: character OR vector of Strings (character)
#   
#   template.columns -
#     Required Argument.
#     Specifies the names of the template_table columns that contain the 
#     values and timestamps of the time series. Note that the 
#     template.columns argument has the alternate name template.columns. 
#     Note: If these columns contain NaN or infinity values, then use a 
#     WHERE clause to remove them.
#     Types: character OR vector of Strings (character)
#   
#   timeseries.id -
#     Required Argument.
#     Specifies the names of the columns by which the input_table is 
#     partitioned. These columns comprise the unique ID for a time series 
#     in input_table.
#     Types: character
#   
#   template.id -
#     Required Argument.
#     Specifies the names of the columns by which the template_table is 
#     ordered. These columns comprise the unique ID for a time series in 
#     template_table.
#     Types: character
#   
#   radius -
#     Optional Argument.
#      Specifies the integer value that determines the projected warp path 
#     from a previous resolution. 
#     Default Value: 10
#     Types: integer
#   
#   dist.method -
#     Optional Argument.
#     Specifies the DistMethod for computing the warping distance. The 
#     supported values of distance_method, which are case-sensitive, are: 
#     "EuclideanDistance" (default),"ManhattanDistance", 
#     "BinaryDistance".contract Note that the DistanceMethod argument has 
#     the alternate name DistMethod.
#     Default Value: "EuclideanDistance"
#     Permitted Values: EuclideanDistance, BinaryDistance, ManhattanDistance
#     Types: character
#   
#   warp.path -
#     Optional Argument.
#     Determines whether to output the warping path. 
#     Default Value: FALSE
#     Types: logical
#   
#   data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
#   
#   template.data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "template.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
#   
#   mapping.data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "mapping.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_dtw_mle" which is a named 
#   list containing Teradata tbl object.
#   Named list member can be referenced directly with the "$" operator 
#   using name: result.
# 
# 
#' @export
td_dtw_mle <- function(
  data = NULL,
  template.data = NULL,
  mapping.data = NULL,
  input.columns = NULL,
  template.columns = NULL,
  timeseries.id = NULL,
  template.id = NULL,
  radius = 10,
  dist.method = "EuclideanDistance",
  warp.path = FALSE,
  data.sequence.column = NULL,
  template.data.sequence.column = NULL,
  mapping.data.sequence.column = NULL,
  data.partition.column = NULL,
  mapping.data.partition.column = NULL,
  data.order.column = NULL,
  template.data.order.column = NULL,
  mapping.data.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.partition.column", data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("template.data", template.data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("template.data.order.column", template.data.order.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("mapping.data", mapping.data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("mapping.data.partition.column", mapping.data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("mapping.data.order.column", mapping.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("input.columns", input.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("template.columns", template.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("timeseries.id", timeseries.id, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("template.id", template.id, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("radius", radius, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("dist.method", dist.method, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("warp.path", warp.path, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("template.data.sequence.column", template.data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("mapping.data.sequence.column", mapping.data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  .validateInputTableDataType(template.data, NULL)
  .validateInputTableDataType(mapping.data, NULL)
  
  # Check for permitted values
  dist.methodPermittedValues <- list("EUCLIDEANDISTANCE", "BINARYDISTANCE", "MANHATTANDISTANCE")
  .validatePermittedValues(dist.method, dist.methodPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(input.columns)
  .validateTblHasArgumentColumns(input.columns, "input.columns", data, "data")
  
  .validateInputColumnsNotEmpty(template.columns)
  .validateTblHasArgumentColumns(template.columns, "template.columns", template.data, "template.data")
  
  .validateInputColumnsNotEmpty(timeseries.id)
  .validateTblHasArgumentColumns(timeseries.id, "timeseries.id", data, "data")
  
  .validateInputColumnsNotEmpty(template.id)
  .validateTblHasArgumentColumns(template.id, "template.id", template.data, "template.data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(template.data.sequence.column)
  .validateTblHasArgumentColumns(template.data.sequence.column, "template.data.sequence.column", template.data, "template.data")
  
  .validateInputColumnsNotEmpty(mapping.data.sequence.column)
  .validateTblHasArgumentColumns(mapping.data.sequence.column, "mapping.data.sequence.column", mapping.data, "mapping.data")
  
  .validateInputColumnsNotEmpty(data.partition.column)
  .validateTblHasArgumentColumns(data.partition.column, "data.partition.column", data, "data")
  
  .validateInputColumnsNotEmpty(mapping.data.partition.column)
  .validateTblHasArgumentColumns(mapping.data.partition.column, "mapping.data.partition.column", mapping.data, "mapping.data")
  
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  .validateInputColumnsNotEmpty(template.data.order.column)
  .validateTblHasArgumentColumns(template.data.order.column, "template.data.order.column", template.data, "template.data")
  
  .validateInputColumnsNotEmpty(mapping.data.order.column)
  .validateTblHasArgumentColumns(mapping.data.order.column, "mapping.data.order.column", mapping.data, "mapping.data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(input.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TemplateColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(template.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TimeseriesId")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(timeseries.id,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TemplateId")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(template.id,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(radius) && !missing(radius)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Radius")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(radius, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(dist.method) && !missing(dist.method)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "DistanceMethod")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(dist.method, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(warp.path) && !missing(warp.path)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "WarpPath")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(warp.path, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("inputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (!is.null(template.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("templateTable:", .teradataCollapseArgVector(template.data.sequence.column, "")))
  }
  
  if (!is.null(mapping.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("mappingTable:", .teradataCollapseArgVector(mapping.data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  data.partition.column <- .teradataCollapseArgVector(data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "inputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # Process template.data
  tableRef <- .teradataOnClauseFromDataFrame(template.data)
  funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "templateTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(template.data.order.column, "\""))
  
  # Process mapping.data
  mapping.data.partition.column <- .teradataCollapseArgVector(mapping.data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(mapping.data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "mappingTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, mapping.data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(mapping.data.order.column, "\""))
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "DTW",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("DTW", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data, template.data, mapping.data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_dtw_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_dtw <- td_dtw_mle
