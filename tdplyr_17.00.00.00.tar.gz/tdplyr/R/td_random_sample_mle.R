# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Mounika Kotha (mounika.kotha@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.5
# 
# ################################################################## 

# Description:
#   The RandomSample function takes a data set and uses a specified 
#   sampling method to output one or more random samples. Each sample has 
#   exactly the number of rows specified.
# 
# Args:
#   data -
#     Required Argument.\cr
#     Specifies the name of the tbl_teradata that contains the data set 
#     from which to take samples.\cr
#   
#   num.sample -
#     Required Argument.\cr
#     Specifies both the number of samples and their sizes. For each 
#     sample_size (an integer value), the function selects a sample that 
#     has sample_size rows.\cr
#     Types: integer OR vector of integers
#   
#   weight.column -
#     Optional Argument.\cr
#     Specifies the name of the input_table column that contains weights 
#     for weighted sampling. The weight_column must have a numeric SQL data 
#     type. By default, rows have equal weight.\cr
#     Types: character
#   
#   sampling.mode -
#     Optional Argument.\cr
#     Specifies the sampling mode: "basic" (default): Each input_table row 
#     has a probability of being selected that is proportional to its 
#     weight. The weight of each row is in weight_column.  "kmeans++": One 
#     row is selected in each of k iterations, where k is the number of 
#     desired output rows. The first row is selected randomly. In 
#     subsequent iterations, the probability of a row being selected is 
#     proportional to the value in the weight.column multiplied by the 
#     distance from the nearest row in the set of selected rows. The 
#     distance is calculated using the methods specified by the distance 
#     and categorical.distance arguments.  "kmeans||": Enhanced version of 
#     ta.kmeans++ that exploits parallel architecture to accelerate the 
#     sampling process. The algorithm is described in the paper Scalable 
#     ta.kmeans++ by Bahmani et al 
#     (http://theory.stanford.edu/~sergei/papers/vldb12-kmpar.pdf). 
#     Briefly, at each iteration, the probability that a row is selected is 
#     proportional to the value in the weight.column multiplied by the 
#     distance from the nearest row in the set of selected rows (as in 
#     ta.kmeans++). However, the ta.kmeans|| algorithm oversamples at each 
#     iteration, significantly reducing the required number of iterations; 
#     therefore, the resulting set of rows might have more than k data 
#     points. Each row in the resulting set is then weighted by the number 
#     of rows in the tbl_teradata that are closer to that row than to any 
#     other selected row, and the rows are clustered to produce exactly k 
#     rows. Tip: For optimal performance, use "kmeans++" when the desired 
#     sample size is less than 15 and "kmeans||" otherwise.\cr
#     Default Value: "Basic"\cr
#     Permitted Values: Basic, KMeans++, KMeans||\cr
#     Types: character
#   
#   distance -
#     Optional Argument.\cr
#     For ta.kmeans++ and ta.kmeans|| sampling, specifies the function for 
#     computing the distance between numerical variables:  "euclidean" 
#     (default): The distance between two variables is defined in 
#     "Euclidean Distance", "manhattan": The distance beween two variables 
#     is defined in "Manhattan Distance"  \cr
#     Default Value: "EUCLIDEAN"\cr
#     Permitted Values: MANHATTAN, EUCLIDEAN\cr
#     Types: character
#   
#   input.columns -
#     Optional Argument.\cr
#     For ta.kmeans++ and ta.kmeans|| sampling, specifies the names of the 
#     input_table columns to use to calculate the distance between 
#     numerical variables.\cr
#     Types: character OR vector of Strings (character)
#   
#   as.categories -
#     Optional Argument.\cr
#     For ta.kmeans++ and ta.kmeans|| sampling, specifies the names of the 
#     input_table columns that contain numerical variables to treat as 
#     categorical variables.\cr
#     Types: character OR vector of Strings (character)
#   
#   category.weights -
#     Optional Argument.\cr
#     For ta.kmeans++ and ta.kmeans|| sampling, specifies the weights 
#     (numeric values) of the categorical variables, including those that 
#     the as.categories argument specifies. Specify the weights in the 
#     order (from left to right) that the variables appear in the input 
#     table. When calculating the distance between two rows, distances 
#     between categorical values are scaled by these weights.\cr
#     Types: numeric OR vector of numerics
#   
#   categorical.distance -
#     Optional Argument.\cr
#     For ta.kmeans++ and ta.kmeans|| sampling, specifies the function for 
#     computing the distance between categorical variables:  "overlap" 
#     (default): The distance between two variables is 0 if they are the 
#     same and 1 if they are different.  "hamming": The distance beween two 
#     variables is the Hamming distance between thestrings that represent 
#     them. The strings must have equal length.\cr
#     Default Value: "OVERLAP"\cr
#     Permitted Values: OVERLAP, HAMMING\cr
#     Types: character
#   
#   seed -
#     Optional Argument.\cr
#     Specifies the random seed with which to initialize the algorithm (a 
#     numeric value). If you specify Seed, you must also specify 
#     SeedColumn.\cr
#     Types: numeric
#   
#   seed.column -
#     Optional Argument.\cr
#      Specifies the names of the input_table columns by which to partition 
#     the input. Function calls that use the same input data, seed, and 
#     seed_column output the same result. If you specify seed.column, you 
#     must also specify seed. Note: Ideally, the number of distinct values 
#     in the seed_column is the same as the number of workers in the 
#     cluster. A very large number of distinct values in the seed_column 
#     degrades function performance.\cr
#     Types: character OR vector of Strings (character)
#   
#   over.sampling.rate -
#     Optional Argument.\cr
#     For ta.kmeans|| sampling, specifies the oversampling rate (a numeric 
#     value greater than 0.0). The function multiplies rate by sample_size 
#     (for each sample_size). The default rate is 1.0.\cr
#     Default Value: 1.0\cr
#     Types: numeric
#   
#   iteration.num -
#     Optional Argument.\cr
#     For ta.kmeans|| sampling, specifies the number of iterations (an 
#     integer value greater than 0). The default number_of_iterations is 
#     5.\cr
#     Default Value: 5\cr
#     Types: integer
#   
#   setid.as.first.column -
#     Optional Argument.\cr
#     Specifies whether the generated set_id values to be included as first 
#     column in output. \cr
#     Default Value: TRUE\cr
#     Types: logical
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_random_sample_mle" which is a 
#   named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_random_sample_mle <- function(
  data = NULL,
  num.sample = NULL,
  weight.column = NULL,
  sampling.mode = "Basic",
  distance = "EUCLIDEAN",
  input.columns = NULL,
  as.categories = NULL,
  category.weights = NULL,
  categorical.distance = "OVERLAP",
  seed.column = NULL,
  seed = NULL,
  over.sampling.rate = 1.0,
  iteration.num = 5,
  setid.as.first.column = TRUE,
  data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("num.sample", num.sample, FALSE, c("integer","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("weight.column", weight.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("sampling.mode", sampling.mode, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("distance", distance, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("input.columns", input.columns, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("as.categories", as.categories, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("category.weights", category.weights, TRUE, c("numeric","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("categorical.distance", categorical.distance, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seed", seed, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("seed.column", seed.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("over.sampling.rate", over.sampling.rate, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("iteration.num", iteration.num, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("setid.as.first.column", setid.as.first.column, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  
  # Check for permitted values
  sampling.modePermittedValues <- list("BASIC", "KMEANS++", "KMEANS||")
  .validatePermittedValues(sampling.mode, sampling.modePermittedValues)
  
  distancePermittedValues <- list("MANHATTAN", "EUCLIDEAN")
  .validatePermittedValues(distance, distancePermittedValues)
  
  categorical.distancePermittedValues <- list("OVERLAP", "HAMMING")
  .validatePermittedValues(categorical.distance, categorical.distancePermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(weight.column)
  .validateTblHasArgumentColumns(weight.column, "weight.column", data, "data")
  
  .validateInputColumnsNotEmpty(input.columns)
  .validateTblHasArgumentColumns(input.columns, "input.columns", data, "data")
  
  .validateInputColumnsNotEmpty(as.categories)
  .validateTblHasArgumentColumns(as.categories, "as.categories", data, "data")
  
  .validateInputColumnsNotEmpty(seed.column)
  .validateTblHasArgumentColumns(seed.column, "seed.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  if (!is.null(weight.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "WeightColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(weight.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(input.columns)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "InputColumns")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(input.columns,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(as.categories)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AsCategories")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(as.categories,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(seed.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SeedColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(seed.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NumSample")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(num.sample, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  
  if (!is.null(sampling.mode) && !missing(sampling.mode)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SamplingMode")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(sampling.mode, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(distance) && !missing(distance)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Distance")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(distance, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(categorical.distance) && !missing(categorical.distance)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CategoricalDistance")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(categorical.distance, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(category.weights)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CategoryWeights")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(category.weights, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(seed)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Seed")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(seed, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "LONG")
  }
  
  if (!is.null(over.sampling.rate) && !missing(over.sampling.rate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OverSamplingRate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(over.sampling.rate, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(iteration.num) && !missing(iteration.num)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IterationNum")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(iteration.num, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(setid.as.first.column) && !missing(setid.as.first.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SetIdAsFirstColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(setid.as.first.column, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("InputTable:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "InputTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "RandomSample",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("RandomSample", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_random_sample_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_random_sample <- td_random_sample_mle
