# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.0
# 
# ################################################################## 

# Description:
#   The Attribution function is used in web page analysis, where it allows
#   companies to assign weights to pages before certain events, such as buying
#   a product.\cr
# 
# Args:
#   data -
#     Required Argument.\cr
#     Contains the click stream data, which the function uses to compute 
#     attributions.\cr
#   
#   data.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   data.order.column -
#     Required Argument.\cr
#     Specifies Order By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   data.optional -
#     Optional Argument.\cr
#     Contains the click stream data, which the function uses to compute 
#     attributions.\cr
#   
#   data.optional.partition.column -
#     Optional Argument.\cr
#     Specifies Partition By columns for "data.optional".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#
#   data.optional.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "data.optional".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   conversion.data -
#     Required Argument.\cr
#     Contains one varchar column (conversion_events) containing conversion 
#     event values.\cr
#   
#   conversion.data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "conversion.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   excluding.data -
#     Optional Argument.\cr
#     Contains one varchar column (excluding_events) containing excluding 
#     cause event values.\cr
#   
#   excluding.data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "excluding.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   optional.data -
#     Optional Argument.\cr
#     Contains one varchar column (optional_events) containing optional 
#     cause event values.\cr
#   
#   optional.data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "optional.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   model1.type -
#     Required Argument.\cr
#     Defines the type and specification of the first model. For example: 
#     model1.data ("EVENT_REGULAR", "email:0.19:LAST_CLICK:NA", 
#     "impression:0.81:WEIGHTED:0.4,0.3,0.2,0.1")\cr
#   
#   model1.type.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "model1.type".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   model2.type -
#     Optional Argument.\cr
#     Defines the type and distributions of the second model. For example: 
#     model2.data ("EVENT_OPTIONAL", "OrganicSearch:0.5:UNIFORM:NA", 
#     "Direct:0.3:UNIFORM:NA", "Referral:0.2:UNIFORM:NA")\cr
#   
#   model2.type.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "model2.type".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   event.column -
#     Required Argument.\cr
#     Specifies the name of the input column that contains the clickstream 
#     events.\cr
#     Types: character
#   
#   timestamp.column -
#     Required Argument.\cr
#     Specifies the name of the input column that contains the timestamps 
#     of the clickstream events.\cr
#     Types: character
#   
#   window.size -
#     Required Argument.
#     Specifies how to determine the maximum window size for the 
#     attribution calculation: rows:K: Consider the maximum number of 
#     events to be attributed, excluding events of types specified in 
#     excluding_event_table, which means assigning attributions to at most 
#     K effective events before the current impact event.seconds:K: 
#     Consider the maximum time difference between the current impact event 
#     and the earliest effective event to be attributed. rows:K&seconds:K2: 
#     Consider both constraints and comply with the stricter one.
#     Types: character
# 
# Returns:
#   Function returns an object of class "td_attribution_sqle" which is a 
#   named list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_attribution_sqle <- function(
  data = NULL,
  data.optional = NULL,
  conversion.data = NULL,
  excluding.data = NULL,
  optional.data = NULL,
  model1.type = NULL,
  model2.type = NULL,
  event.column = NULL,
  timestamp.column = NULL,
  window.size = NULL,
  data.partition.column = NULL,
  data.optional.partition.column = NULL,
  data.order.column = NULL,
  data.optional.order.column = NULL,
  conversion.data.order.column = NULL,
  excluding.data.order.column = NULL,
  optional.data.order.column = NULL,
  model1.type.order.column = NULL,
  model2.type.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.partition.column", data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.optional", data.optional, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.optional.partition.column", data.optional.partition.column, is.null(data.optional), c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.optional.order.column", data.optional.order.column, is.null(data.optional), c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("conversion.data", conversion.data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("conversion.data.order.column", conversion.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("excluding.data", excluding.data, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("excluding.data.order.column", excluding.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("optional.data", optional.data, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("optional.data.order.column", optional.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("model1.type", model1.type, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("model1.type.order.column", model1.type.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("model2.type", model2.type, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("model2.type.order.column", model2.type.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("event.column", event.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("timestamp.column", timestamp.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("window.size", window.size, FALSE, c("character",NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  .validateInputTableDataType(data.optional, NULL)
  .validateInputTableDataType(conversion.data, NULL)
  .validateInputTableDataType(excluding.data, NULL)
  .validateInputTableDataType(optional.data, NULL)
  .validateInputTableDataType(model1.type, NULL)
  .validateInputTableDataType(model2.type, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(event.column)
  .validateTblHasArgumentColumns(event.column, "event.column", data, "data")
  
  .validateInputColumnsNotEmpty(timestamp.column)
  .validateTblHasArgumentColumns(timestamp.column, "timestamp.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.partition.column)
  .validateTblHasArgumentColumns(data.partition.column, "data.partition.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.optional.partition.column)
  .validateTblHasArgumentColumns(data.optional.partition.column, "data.optional.partition.column", data.optional, "data.optional")
  
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  .validateInputColumnsNotEmpty(data.optional.order.column)
  .validateTblHasArgumentColumns(data.optional.order.column, "data.optional.order.column", data.optional, "data.optional")
  
  .validateInputColumnsNotEmpty(conversion.data.order.column)
  .validateTblHasArgumentColumns(conversion.data.order.column, "conversion.data.order.column", conversion.data, "conversion.data")
  
  .validateInputColumnsNotEmpty(excluding.data.order.column)
  .validateTblHasArgumentColumns(excluding.data.order.column, "excluding.data.order.column", excluding.data, "excluding.data")
  
  .validateInputColumnsNotEmpty(optional.data.order.column)
  .validateTblHasArgumentColumns(optional.data.order.column, "optional.data.order.column", optional.data, "optional.data")
  
  .validateInputColumnsNotEmpty(model1.type.order.column)
  .validateTblHasArgumentColumns(model1.type.order.column, "model1.type.order.column", model1.type, "model1.type")
  
  .validateInputColumnsNotEmpty(model2.type.order.column)
  .validateTblHasArgumentColumns(model2.type.order.column, "model2.type.order.column", model2.type, "model2.type")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "EventColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(event.column, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TimestampColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(timestamp.column, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "WindowSize")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(window.size, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  data.partition.column <- .teradataCollapseArgVector(data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # Process data.optional
  if (!is.null(data.optional)) {
    data.optional.partition.column <- .teradataCollapseArgVector(data.optional.partition.column, "\"")
    tableRef <- .teradataOnClauseFromDataFrame(data.optional)
    funcInputDistribution <- c(funcInputDistribution, "FACT")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "input2")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, data.optional.partition.column)
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.optional.order.column, "\""))
  }
  
  # Process conversion.data
  tableRef <- .teradataOnClauseFromDataFrame(conversion.data)
  funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "conversion")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(conversion.data.order.column, "\""))
  
  # Process excluding.data
  if (!is.null(excluding.data)) {
    tableRef <- .teradataOnClauseFromDataFrame(excluding.data)
    funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "excluding")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(excluding.data.order.column, "\""))
  }
  
  # Process optional.data
  if (!is.null(optional.data)) {
    tableRef <- .teradataOnClauseFromDataFrame(optional.data)
    funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "optional")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(optional.data.order.column, "\""))
  }
  
  # Process model1.type
  tableRef <- .teradataOnClauseFromDataFrame(model1.type)
  funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "model1")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(model1.type.order.column, "\""))
  
  # Process model2.type
  if (!is.null(model2.type)) {
    tableRef <- .teradataOnClauseFromDataFrame(model2.type)
    funcInputDistribution <- c(funcInputDistribution, "DIMENSION")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "model2")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(model2.type.order.column, "\""))
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "Attribution",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_SQL")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("Attribution", engine = .getEngineName("ENGINE_SQL"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Converting the wrapper from lazy to non-lazy, i.e., outputting a tbl_teradata object of type "table"
  # instead of "query" to get past the issue noted on ELE-2507, and TDAF-1355.
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("td_attribution_sqle0_", use.default.database = TRUE, gc.onQuit = TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # Get expr.
  tryCatch({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data, data.optional, conversion.data, excluding.data, optional.data, model1.type, model2.type)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table",
                                             .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_attribution_sqle", engine = .getEngineName("ENGINE_SQL"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_attribution <- td_attribution_sqle
