# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' @export
predict.td_lin_reg_mle <- function(
  object = NULL,
  newdata = NULL,
  accumulate = NULL,
  input.columns = NULL,
  newdata.sequence.column = NULL,
  object.sequence.column = NULL,
  newdata.order.column = NULL,
  object.order.column = NULL
) {
  td_linreg_predict_mle(object = object,
                    newdata = newdata,
                    accumulate = accumulate,
                    input.columns = input.columns,
                    newdata.sequence.column = newdata.sequence.column,
                    object.sequence.column = object.sequence.column,
                    newdata.order.column = newdata.order.column,
                    object.order.column = object.order.column
                   )
}
