# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' SQL Translation Extensions
#'
#' An important feature that `dbplyr` provides is the ability
#' to take expressions in R and map them to corresponding
#' expressions in SQL. \link{tdplyr} maps certain window, aggregate,
#' and scalar functions to SQL expressions when \code{summarize}, \code{mutate},
#' or \code{filter} is used.
#'
#' See \code{vignette('sql-translation', package = 'tdplyr')} for a list of all the mappings.
#' Note that functions not explicitly mapped above will be translated to sql literally.
#'
#' @name sql-translation 
#' @aliases sdp distinct varp
#' @examples
#' \donttest{
#'   translate_sql(mean(x, na.rm = TRUE), window = FALSE, con = dbplyr::simulate_teradata())
#'   translate_sql(sdp(distinct(x), na.rm = TRUE), window = FALSE, con = dbplyr::simulate_teradata())
#'
#'   translate_sql(mean(x, na.rm = TRUE), con = dbplyr::simulate_teradata())
#'   translate_sql(sdp(x, na.rm = TRUE), con = dbplyr::simulate_teradata())
#'
#'   # The DISTINCT clause is not permitted in window aggregate functions
#'   tryCatch({
#'     translate_sql(sum(distinct(x), na.rm = TRUE), con = dbplyr::simulate_teradata())
#'   },error=function(e) {
#'     geterrmessage()
#'   })
#' 
#'   # The DISTINCT clause is allowed in aggregate functions
#'   translate_sql(sdp(distinct(x), na.rm = TRUE), window = FALSE, con = dbplyr::simulate_teradata())
#' }
NULL

# Extensions for the SQL translation layer

# We override the sql_translate_env.Teradata S3 method in dbplyr.
# See: https://github.com/tidyverse/dbplyr/blob/master/R/db-odbc-teradata.R

# The implementation builds off of the implementation in the link above.
# This strategy entails taking updates from the open source implementation of 
# sql_translate_env.Teradata. See zzz.R.

# See the following for extensions:
#  - sql-translation-scalar.R
#  - sql-translation-agg.R
#  - sql-translation-window.R

# An alternative implementation is to use the exported environments 
# from dbplyr to add our extensions.
# We can use the odbc variants of the environments below to add our extensions.
# The Teradata class currently inherits from these environments.
#  dbplyr::base_scalar
#  dbplyr::base_win
#  dbplyr::base_agg
# This would allow changes in the Teradata sql variant to be inherited into
# our package as well but it would take precedence over our mapping to the 
# base_odbc_* environments.

# Since only the Teradata connection class is expected to be used
# sql translation is dispatched based on the kind of DBIConnection
# subclass.

#' @importFrom dplyr sql_translate_env
#' @importFrom dbplyr sql_variant
#' @method sql_translate_env Teradata
#' @export
sql_translate_env.Teradata <- function(con){
  sql_variant(
    .td_sql_scalar(),
    .td_sql_agg(),
    .td_sql_window()
  )
}
