################################################################################
#
# Copyright 2019 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: Adithya Avvaru (adithya.avvaru@teradata.com)
# Secondary Owner:
#
# This file has:
#   1.  select_query function for time series grouping which 
#       contains group_by_time argument.
#   2.  sql_render function for time series grouping to be 
#       used when summarise is applied on group_by_time.
#
################################################################################

# This is a function similar to dbplyr select_query with addition of 
# 'group_by_time' argument.
select_query_time_series <- function(from,
                                     select = sql("*"),
                                     where = character(),
                                     group_by = character(),
                                     group_by_time = character(),
                                     having = character(),
                                     order_by = character(),
                                     limit = NULL,
                                     distinct = FALSE) {

  stopifnot(is.character(select))
  stopifnot(is.character(where))
  stopifnot(is.character(group_by))
  stopifnot(is.character(group_by_time))
  stopifnot(is.character(having))
  stopifnot(is.character(order_by))
  stopifnot(is.null(limit) || (is.numeric(limit) && length(limit) == 1L))
  stopifnot(is.logical(distinct), length(distinct) == 1L)

  aa <- structure(
    list(
      from = from,
      select = select,
      where = where,
      group_by = group_by,
      group_by_time = group_by_time,
      having = having,
      order_by = order_by,
      distinct = distinct,
      limit = limit
    ),
    class = c("td_select_query", "query")
  )
}

# sql_render function for time series grouping to be used when summarise is 
# applied on group_by_time.
#' @export
sql_render.td_select_query <- function(query, con, ..., 
                                       bare_identifier_ok = FALSE) {
  from <- sql_subquery(con,
                       sql_render(query$from, con, ..., 
                                  bare_identifier_ok = TRUE),
                       name = NULL
  )
  
  sql_select(
    con, query$select, from,
    where = query$where,
    group_by = query$group_by,
    group_by_time = query$group_by_time,
    having = query$having,
    order_by = query$order_by,
    limit = query$limit,
    distinct = query$distinct,
    ...,
    bare_identifier_ok = bare_identifier_ok
  )
}