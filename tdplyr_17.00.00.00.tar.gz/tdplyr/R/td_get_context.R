# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' Get the current context
#'
#' Returns a named list of attributes in an existing Teradata context.
#'
#' @return A named list containing attributes to the current context.
#' NULL if a context does not exist.
#' @seealso \code{td_create_context }, \code{td_set_context}
#' @examples
#' \donttest{
#' td_create_context(dsn = "TeradataDSN")
#' context <- td_get_context()
#'
#' # To retrieve the connection in the current context, use
#' td_get_context()$connection
#'
#' # To retrieve the temorary database in the current context, use
#' td_get_context()$temp.database
#'
#' # To retrieve the default database in the current context, use
#' td_get_context()$database
#'
#' td_remove_context()
#' }
#' @export
#' @rdname td_get_context
td_get_context <- function(){
  # One approach is to create a context object (e.g. a list) and store
  # the connection, temp_database and default_database in this list
  # But it incurrs significant overhead, so this approach to compose
  # the context object using all the information is better

  # The connection always represents the context so check it
  con <- .taConnection(silent = TRUE)
  if (is.null(con))
    return(NULL)
  list(
    connection = con,
    temp.database = .ta.getTempDatabase(),
    default.database = .ta.getDefaultDatabase(),
    driver.type = .get_driver_name(con)
    )
}
