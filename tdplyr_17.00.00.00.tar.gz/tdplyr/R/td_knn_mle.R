# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# Secondary Owner: Jeris Alan Jawahar (jeris.jawahar@teradata.com)
# 
# Version: 1.2
# Function Version: 2.3
# 
# ################################################################## 

# Description:
#   The KNN function uses training data objects to map test data objects 
#   to categories. The function is optimized for both small and large 
#   training sets. The function supports user-defined distance metrics 
#   and distance-weighted voting.
# 
# Args:
#   train -
#     Required Argument.\cr
#     Specifies the name of the tbl_teradata that contains the training 
#     data. Each row represents a classified data object.\cr
#   
#   test -
#     Required Argument.\cr
#     Specifies the name of the tbl_teradata that contains the test data to 
#     be classified by the ta.knn algorithm. Each row represents a test 
#     data object.\cr
#   
#   k -
#     Required Argument.\cr
#     Specifies the number of nearest neighbors to use for classifying the 
#     test data.\cr
#     Types: integer
#   
#   response.column -
#     Required Argument.\cr
#     Specifies the name of the training tbl_teradata column that contains 
#     the class label or classification of the classified data objects.\cr
#     Types: character
#   
#   id.column -
#     Required Argument.\cr
#     Specifies the name of the testing tbl_teradata column that uniquely 
#     identifies a data object.\cr
#     Types: character
#   
#   distance.features -
#     Required Argument.\cr
#     Specifies the names of the training tbl_teradata columns that the 
#     function uses to compute the distance between a test object and the 
#     training objects. The test tbl_teradata must also have these 
#     columns\cr
#     Types: character OR vector of Strings (character)
#   
#   voting.weight -
#     Optional Argument.\cr
#     Specifies the voting weight of the distance between a test object and 
#     the training objects. The voting_weight must be a nonnegative 
#     integer. The default value is 0. The function calculates 
#     distance-weighted voting, w, with this equation: w = 
#     1/POWER(distance, voting_weight) Where distance is the distance 
#     between the test object and the training object.\cr
#     Default Value: 0\cr
#     Types: numeric
#   
#   customized.distance -
#     Optional Argument.\cr
#     Specifies the distance function. The parameter jar is the name of the 
#     JAR file that contains the distance metric class. The parameter 
#     distance_class is the distance metric class defined in the jar file. 
#     The ta.knn function installs the JAR file on the Aster Database 
#     server. The default distance function is Euclidean distance.\cr
#     Types: character OR vector of characters
#   
#   force.mapreduce -
#     Optional Argument.\cr
#      Specifies whether to partition the training data. which causes the 
#     ta.knn function to load all training data into memory and use only 
#     the row function. If you specify "true", the ta.knn function 
#     partitions the training data and uses the map-and reduce function.\cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   parblock.size -
#     Optional Argument.\cr
#     Specifies the partition block size to use with force.mapreduce 
#     ("true"). The recommended value depends on training data size and 
#     number of vworkers. For example, if your training data size is 10 
#     billion and you have 10 vworkers, the recommended 
#     partition.block.size is 1/n billion, where n is an integer that 
#     corresponds to your vworker nodes" memory. Omitting this argument or 
#     specifying an inappropriate partition.block.size can degrade 
#     performance.\cr
#     Types: integer
#   
#   partition.key -
#     Optional Argument.\cr
#     Specifies the name of the training tbl_teradata column that partition 
#     data in parallel model. The default value is the first column of 
#     DistanceFeatures\cr
#     Types: character
#   
#   accumulate -
#     Optional Argument.\cr
#     Specifies the names of test tbl_teradata columns to copy to the 
#     output table.\cr
#     Types: character OR vector of Strings (character)
#   
#   output.prob -
#     Optional Argument.\cr
#     Specifies whether to display output probability for the predicted 
#     category. \cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   train.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "train". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   test.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "test". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_knn_mle" which is a named 
#   list containing objects of class "tbl_teradata".\cr
#   Named list members can be referenced directly with the "$" operator 
#   using the following names:\enumerate{\item output.table\item output}
# 
# 
#' @export
td_knn_mle <- function(
  train = NULL,
  test = NULL,
  k = NULL,
  response.column = NULL,
  id.column = NULL,
  distance.features = NULL,
  voting.weight = 0,
  customized.distance = NULL,
  force.mapreduce = FALSE,
  parblock.size = NULL,
  partition.key = NULL,
  accumulate = NULL,
  output.prob = FALSE,
  train.sequence.column = NULL,
  test.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("train", train, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("test", test, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("k", k, FALSE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("response.column", response.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("id.column", id.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("distance.features", distance.features, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("voting.weight", voting.weight, TRUE, c("numeric",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("customized.distance", customized.distance, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("force.mapreduce", force.mapreduce, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("parblock.size", parblock.size, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("partition.key", partition.key, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.prob", output.prob, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("train.sequence.column", train.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("test.sequence.column", test.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(train, NULL)
  .validateInputTableDataType(test, NULL)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(response.column)
  .validateTblHasArgumentColumns(response.column, "response.column", train, "train")
  
  .validateInputColumnsNotEmpty(id.column)
  .validateTblHasArgumentColumns(id.column, "id.column", test, "test")
  
  .validateInputColumnsNotEmpty(distance.features)
  .validateTblHasArgumentColumns(distance.features, "distance.features", train, "train")
  
  .validateInputColumnsNotEmpty(partition.key)
  .validateTblHasArgumentColumns(partition.key, "partition.key", train, "train")
  
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", test, "test")
  
  .validateInputColumnsNotEmpty(train.sequence.column)
  .validateTblHasArgumentColumns(train.sequence.column, "train.sequence.column", train, "train")
  
  .validateInputColumnsNotEmpty(test.sequence.column)
  .validateTblHasArgumentColumns(test.sequence.column, "test.sequence.column", test, "test")
  
  # Generate temp table names for output table parameters if any.
  output.tableTempTableName <- .teradataGenerateTempTableName("td_knn_mle0_", use.default.database=TRUE, gc.onQuit=TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_knn_mle.internal)
  Call[["output.tableTempTableName"]] <- output.tableTempTableName
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_knn_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_knn_mle.internal <- function(
  train = NULL,
  test = NULL,
  k = NULL,
  response.column = NULL,
  id.column = NULL,
  distance.features = NULL,
  voting.weight = 0,
  customized.distance = NULL,
  force.mapreduce = FALSE,
  parblock.size = NULL,
  partition.key = NULL,
  accumulate = NULL,
  output.prob = FALSE,
  train.sequence.column = NULL,
  test.sequence.column = NULL,
  output.tableTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("OutputTable")
  funcOutputArgs <- c(output.tableTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ResponseColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(response.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IdColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(id.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "DistanceFeatures")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(distance.features,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  if (!is.null(partition.key)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PartitionColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(partition.key,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  if (!is.null(accumulate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(accumulate,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  }
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "K")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(k, "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  
  if (!is.null(parblock.size)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PartitionBlockSize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(parblock.size, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(force.mapreduce) && !missing(force.mapreduce)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ForceMapreduce")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(force.mapreduce, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(customized.distance)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CustomizedDistance")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(customized.distance, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(voting.weight) && !missing(voting.weight)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "VotingWeight")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(voting.weight, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(output.prob) && !missing(output.prob)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputProb")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.prob, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(train.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("TrainingTable:", .teradataCollapseArgVector(train.sequence.column, "")))
  }
  
  if (!is.null(test.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("TestTable:", .teradataCollapseArgVector(test.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process train
  tableRef <- .teradataOnClauseFromDataFrame(train)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "TrainingTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # Process test
  tableRef <- .teradataOnClauseFromDataFrame(test)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "TestTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "KNN",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("KNN", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database=TRUE, gc.onQuit=TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch ({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(train, test)
  
  # Return output table data frames.
  result <- list()
  result[["output.table"]] <- .createDataSetObject(.extractTableName(output.tableTempTableName), sourceType = "table", .extractDatabaseName(output.tableTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
#' @export
td_knn <- td_knn_mle
