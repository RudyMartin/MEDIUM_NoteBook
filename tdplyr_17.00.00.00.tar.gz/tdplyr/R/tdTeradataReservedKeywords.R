#############################################################################
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: pankajvinod.purandare@teradata.com
# Secondary Owner:
#
# A vector containing Teradata SQL specific keywords, which can be used in
# SQL-MR query generation, for escaping those words with quotes.
# This is being done, because, with alias feature and SQL-MR argument names
# clash with Teradata reserved keywords. If we run query with those keywords, a 
# syntax error is observed, hence we need to keep a list of such words and 
# skip those as and when needed.
#
#############################################################################
# Below global vector contains Teradata specific keywords, which will be 
# used in SQL-MR alias.
.teradataReservedKeywords <- c("INPUT",
                               "THRESHOLD",
                               "CHECK",
                               "SUMMARY",
                               "HASH",
                               "METHOD")


.processVectorForTeradataKeyword <- function(keyVector) {
  #
  # Function which takes in a vector as input, process the vector to check
  # whether it contains any Teradata keyword or not. If it contains the
  # keyword, then processes the same to add double quotes to it.
  #
  # Args:
  #   keyVector - A vector to be processed for finding keyword.
  #
  # Returns:
  #   A processed vector.
  #
  vec <- lapply(keyVector, function(x) {
    if(toupper(x) %in% .teradataReservedKeywords)
      return(.teradataQuoteArg(x, "\"", FALSE))
    else
      return(x)
  })
  return(vec)
}

.processFactorForTeradataKeyword <- function(var) {
  #
  # Function which takes in a factor as input, process the factor to check
  # whether it contains any Teradata keyword or not. If it contains the
  # keyword, then processes the same to add double quotes to it.
  #
  # Args:
  #   var - A factor to be processed for finding keyword.
  #
  # Returns:
  #   A processed factor.
  #
  if(toupper(var) %in% .teradataReservedKeywords)
    return(.teradataQuoteArg(var, "\"", FALSE))
  else
    return(var)
}
