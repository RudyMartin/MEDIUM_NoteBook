# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Mounika Kotha (mounika.kotha@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.31
# 
# ################################################################## 

# Description:
#   The AdaBoost Drive function takes a training data set and a single 
#   decision tree
#   			and uses adaptive boosting to produce a strong classifying model 
#   that can be input to
#   			the function AdaBoost Predict.
# 
# Args:
#   attribute.data -
#     Required Argument.
#     Specifies the name of the tbl_teradata that contains the attributes 
#     and values of the data.
#   
#   attribute.name.columns -
#     Required Argument.
#     Specifies the names of attribute tbl_teradata columns that contain 
#     the data attributes.
#     Types: character OR vector of Strings (character)
#   
#   attribute.value.column -
#     Required Argument.
#     Specifies the names of attribute tbl_teradata columns that contain 
#     the data values.
#     Types: character
#   
#   categorical.attribute.data -
#     Optional Argument.
#     Specifies the name of the tbl_teradata that contains the names of the 
#     categorical attributes.
#   
#   response.data -
#     Required Argument.
#     Specifies the name of the tbl_teradata that contains the responses 
#     (labels) of the data.
#   
#   id.columns -
#     Required Argument.
#     Specifies the names of the columns in the response and attribute 
#     tables that specify the identifier of the instance.
#     Types: character OR vector of Strings (character)
#   
#   response.column -
#     Required Argument.
#     Specifies the name of the response tbl_teradata column that contains 
#     the responses (labels) of the data.
#     Types: character
#   
#   iter.num -
#     Optional Argument.
#     Specifies the number of iterations to boost the weak classifiers, 
#     which is also the number of weak classifiers in the ensemble (T). The 
#     iterations must an integer in the range [2, 200]. 
#     Default Value: 20
#     Types: integer
#   
#   num.splits -
#     Optional Argument.
#     Specifies the number of splits to try for each attribute in the node 
#     splitting. The splits must an integer. 
#     Default Value: 10
#     Types: integer
#   
#   approx.splits -
#     Optional Argument.
#     Specifies whether to use approximate percentiles. 
#     Default Value: TRUE
#     Types: logical
#   
#   split.measure -
#     Optional Argument.
#     Specifies the type of measure to use in node splitting. 
#     Default Value: "gini"
#     Permitted Values: GINI, ENTROPY
#     Types: character
#   
#   max.depth -
#     Optional Argument.
#     Specifies the maximum depth of the tree. The max_depth must an 
#     integer in the range [1, 10]. 
#     Default Value: 3
#     Types: integer
#   
#   min.node.size -
#     Optional Argument.
#     Specifies the minimum size of any particular node within each 
#     decision tree. The min_node_size must an integer. 
#     Default Value: 100
#     Types: integer
#   
#   output.response.probdist -
#     Optional Argument.
#     Switch to enable/disable output of probability distribution for 
#     output labels.
#     Default Value: FALSE
#     Types: logical
#   
#   categorical.encoding -
#     Optional Argument.
#     Specifies which encoding method is used for categorical variables.
#     Default Value: "graycode"
#     Permitted Values: graycode, hashing
#     Types: character
#   
#   attribute.data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "attribute.data". The argument is used to 
#     ensure deterministic results for functions which produce results that 
#     vary from run to run.
#     Types: character OR vector of Strings (character)
#   
#   response.data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "response.data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.
#     Types: character OR vector of Strings (character)
#   
#   categorical.attribute.data.sequence.column -
#     Optional Argument.
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "categorical.attribute.data". The argument is 
#     used to ensure deterministic results for functions which produce 
#     results that vary from run to run.
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_adaboost_mle" which is a 
#   named list containing Teradata tbl objects.
#   Named list members can be referenced directly with the "$" operator 
#   using following names:\enumerate{\item model.table\item output}
# 
# 
#' @export
td_adaboost_mle <- function(
  attribute.data = NULL,
  attribute.name.columns = NULL,
  attribute.value.column = NULL,
  categorical.attribute.data = NULL,
  response.data = NULL,
  id.columns = NULL,
  response.column = NULL,
  iter.num = 20,
  num.splits = 10,
  approx.splits = TRUE,
  split.measure = "gini",
  max.depth = 3,
  min.node.size = 100,
  output.response.probdist = FALSE,
  categorical.encoding = "graycode",
  attribute.data.sequence.column = NULL,
  response.data.sequence.column = NULL,
  categorical.attribute.data.sequence.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("attribute.data", attribute.data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("attribute.name.columns", attribute.name.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("attribute.value.column", attribute.value.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("categorical.attribute.data", categorical.attribute.data, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("response.data", response.data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("id.columns", id.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("response.column", response.column, FALSE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("iter.num", iter.num, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("num.splits", num.splits, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("approx.splits", approx.splits, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("split.measure", split.measure, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("max.depth", max.depth, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("min.node.size", min.node.size, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.response.probdist", output.response.probdist, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("categorical.encoding", categorical.encoding, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("attribute.data.sequence.column", attribute.data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("response.data.sequence.column", response.data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("categorical.attribute.data.sequence.column", categorical.attribute.data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(attribute.data, NULL)
  .validateInputTableDataType(response.data, NULL)
  .validateInputTableDataType(categorical.attribute.data, NULL)
  
  # Check for permitted values
  split.measurePermittedValues <- list("GINI", "ENTROPY")
  .validatePermittedValues(split.measure, split.measurePermittedValues)
  
  categorical.encodingPermittedValues <- list("GRAYCODE", "HASHING")
  .validatePermittedValues(categorical.encoding, categorical.encodingPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(id.columns)
  .validateTblHasArgumentColumns(id.columns, "id.columns", attribute.data, "attribute.data")
  
  .validateInputColumnsNotEmpty(attribute.name.columns)
  .validateTblHasArgumentColumns(attribute.name.columns, "attribute.name.columns", attribute.data, "attribute.data")
  
  .validateInputColumnsNotEmpty(attribute.value.column)
  .validateTblHasArgumentColumns(attribute.value.column, "attribute.value.column", attribute.data, "attribute.data")
  
  .validateInputColumnsNotEmpty(response.column)
  .validateTblHasArgumentColumns(response.column, "response.column", response.data, "response.data")
  
  .validateInputColumnsNotEmpty(attribute.data.sequence.column)
  .validateTblHasArgumentColumns(attribute.data.sequence.column, "attribute.data.sequence.column", attribute.data, "attribute.data")
  
  .validateInputColumnsNotEmpty(response.data.sequence.column)
  .validateTblHasArgumentColumns(response.data.sequence.column, "response.data.sequence.column", response.data, "response.data")
  
  .validateInputColumnsNotEmpty(categorical.attribute.data.sequence.column)
  .validateTblHasArgumentColumns(categorical.attribute.data.sequence.column, "categorical.attribute.data.sequence.column", categorical.attribute.data, "categorical.attribute.data")
  
  # Generate temp table names for output table parameters if any.
  model.tableTempTableName <- .teradataGenerateTempTableName("td_adaboost_mle0_", use.default.database = TRUE, gc.onQuit = TRUE)
  
  # Get the list of arguments passed to the function and add output table parameters to R call.
  Call <- match.call()
  Call[[1]] <- quote(tdplyr:::.td_adaboost_mle.internal)
  Call[["model.tableTempTableName"]] <- model.tableTempTableName
  
  retval <- NULL
  tryCatch ({
    retval <- eval.parent(Call)
  }, finally = {
    
  })
  if (class(retval) == "list" && length(retval) > 1) {
    attr(retval, "class") <- .getSQLMRClass("td_adaboost_mle", engine = .getEngineName("ENGINE_ML"))
  }
  retval[["attributes"]]  <- .ta.populateModelAttributes(as.list(match.call()))
  # End the timer to get the build time
  endTime <- Sys.time()
  
  # Calculate the build time
  mc.build.time <- as.integer(endTime - startTime)
  
  attr(retval, "mc.build.time") <- mc.build.time
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(retval)
  
  attr(retval, "mc.prediction.type") <- mc.prediction.type
  return(retval)
  
}



.td_adaboost_mle.internal <- function(
  attribute.data = NULL,
  attribute.name.columns = NULL,
  attribute.value.column = NULL,
  categorical.attribute.data = NULL,
  response.data = NULL,
  id.columns = NULL,
  response.column = NULL,
  iter.num = 20,
  num.splits = 10,
  approx.splits = TRUE,
  split.measure = "gini",
  max.depth = 3,
  min.node.size = 100,
  output.response.probdist = FALSE,
  categorical.encoding = "graycode",
  attribute.data.sequence.column = NULL,
  response.data.sequence.column = NULL,
  categorical.attribute.data.sequence.column = NULL,
  model.tableTempTableName = NULL
) {
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgsSqlNames <- c("OutputTable")
  funcOutputArgs <- c(model.tableTempTableName)
  names(funcOutputArgs) <- funcOutputArgsSqlNames
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IdColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(id.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AttributeNameColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(attribute.name.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AttributeValueColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(attribute.value.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ResponseColumn")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(response.column,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMN_NAMES")
  
  if (!is.null(iter.num) && !missing(iter.num)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "IterNum")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(iter.num, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(num.splits) && !missing(num.splits)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "NumSplits")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(num.splits, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(approx.splits) && !missing(approx.splits)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "ApproxSplits")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(approx.splits, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(split.measure) && !missing(split.measure)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SplitMeasure")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(split.measure, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(max.depth) && !missing(max.depth)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "maxDepth")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(max.depth, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(min.node.size) && !missing(min.node.size)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "MinNodeSize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(min.node.size, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(output.response.probdist) && !missing(output.response.probdist)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputResponseProbDist")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.response.probdist, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  if (!is.null(categorical.encoding) && !missing(categorical.encoding)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "CategoricalEncoding")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(categorical.encoding, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(attribute.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("AttributeTable:", .teradataCollapseArgVector(attribute.data.sequence.column, "")))
  }
  
  if (!is.null(response.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("ResponseTable:", .teradataCollapseArgVector(response.data.sequence.column, "")))
  }
  
  if (!is.null(categorical.attribute.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("CategoricalAttributeTable:", .teradataCollapseArgVector(categorical.attribute.data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process attribute.data
  tableRef <- .teradataOnClauseFromDataFrame(attribute.data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "AttributeTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # Process response.data
  tableRef <- .teradataOnClauseFromDataFrame(response.data)
  funcInputDistribution <- c(funcInputDistribution, "NONE")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "ResponseTable")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
  funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  
  # Process categorical.attribute.data
  if (!is.null(categorical.attribute.data)) {
    tableRef <- .teradataOnClauseFromDataFrame(categorical.attribute.data)
    funcInputDistribution <- c(funcInputDistribution, "NONE")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "CategoricalAttributeTable")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, "NA_character_")
    funcInputOrderByCols <- c(funcInputOrderByCols, "NA_character_")
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
                                     "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "AdaBoost_Drive",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("AdaBoost_Drive", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Capture standard output into a database table.
  sql.stdout  <- .teradataGenerateTempTableName("sqlmr_stdout_", use.default.database = TRUE, gc.onQuit = TRUE)
  sqlmrQuery  <-  paste0("CREATE MULTISET TABLE ", sql.stdout, " AS (", sqlmrQuery, ") WITH DATA NO PRIMARY INDEX")
  
  # get expr
  tryCatch({
    expr  <-  taQuery(sqlmrQuery)
  }, error = function(emsg){
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-10]])[1], emsg[["message"]], showFunctionCall = FALSE)
  })
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(attribute.data, response.data, categorical.attribute.data)
  
  # Return output table data frames.
  result <- list()
  result[["model.table"]] <- .createDataSetObject(.extractTableName(model.tableTempTableName), sourceType = "table", .extractDatabaseName(model.tableTempTableName), is_dplyr_input)
  result[["output"]] <- .createDataSetObject(.extractTableName(sql.stdout), sourceType = "table", .extractDatabaseName(sql.stdout), is_dplyr_input)
  
  if (class(result) == "list" && length(result) > 1) {
    attr(result, "mc.target.column") <- mc.target.column
    attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
    attr(result, "mc.algorithm.name") <- mc.algorithm.name
    return(result)
  } else {
    # Let's get the calling analytics function name to put in the error message.
    # Function name is extracted from the sys.calls() [A stack]
    index <- length(sys.calls())
    .ta.stop("TDR_E3100", as.character(sys.calls()[[index-6]])[1], "", showFunctionCall = FALSE)
  }
  
}
