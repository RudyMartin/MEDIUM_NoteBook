# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

###############################################################################

#
# Event handlers for tdplyr package
#
###############################################################################
# This line is no longer required as the native code is being dynamically linked.
# Also, the native right now is only required for MAC os, and can be patched before build.
# @useDynLib tdplyr, .registration = TRUE, .fixes = "C_"

#
# Event for loading package
#
#' @importFrom utils globalVariables
.onLoad <- function(libname, pkgname) {

  .initializeOptions()

  # Create a new package environment to store all new package specific global variables
  # make sure it inherits from an empty env instead of the global env
  assign(".TAEnv", new.env(parent = emptyenv()), parent.env(environment()))

  # This path is used to load dynamic libraries (currently only used for MAC os)
  # In future the same variable can be used for loading AED library
  .assign("library__path__",paste0(libname))

  # Initialize all package level global variables
  .initPkgGlobals()

  # Initialize the TD SQL mappings
  .initSQLMap()

  # Load this by default since we are only supporting odbc
  # The warnings are suppressed ONLY when package loads,
  # to avoid displaying it if the user only has the native driver
  suppressWarnings(.loadIODBC())
  
  # Load alias definations for the analytic functions.
  .loadFunctionAliases()

  # Add all variables that are used in the package as assignment with dplyr verbs.
  # E.g. summarize(cnt = count()) is used in td_path_analyzer_mle
  # This is required to avoid the check command to print a NOTE.
  globalVariables(c("cnt"))

  # This specifies that disconnect will be called when session ends
  reg.finalizer(baseenv(), function(e) {
                          try(.ta.removeContext(),
                                  silent = TRUE)},
                          onexit = TRUE)
}

# Set default options
# Make sure all options have td. prefix
.initializeOptions <- function() {
  # Set the default values of options for first time loading
  # TODO rename prefix to tdplyr.
  if (is.null(getOption("td.debug.enable")))
    options(td.debug.enable = FALSE)

  # the td.db_desc.output option is a list of 3 elements
  # db      - shows the Database version
  # driver  - shows the driver name and version
  # machine - shows the host name, servername, port, database
  # all are shown by default
  options(td.db_desc.output = list(db = TRUE, machine = TRUE, driver = TRUE))

  # Default threshold is 1, so we always persist session objects
  # If this is set to 0, then we never persist except when session ends
  # TODO rename predix to tdplyr.
  if (is.null(getOption("td.tmpobject.sync.threshold")))
    options(td.tmpobject.sync.threshold  = 1)

  # NOTE: The options td.load.IODBC and td.lib.IODBC are only required form MACOS
  # Since loading IODBC is risky, we can provide an option to turn it on as needed
  if (is.null(getOption("td.load.IODBC"))) {
    # Set this true for now but change it in future
    options(td.load.IODBC = TRUE)
  }
  # this option is provided so user can change the path / file libiodbc library
  if (is.null(getOption("td.lib.IODBC"))) {
    # The full path is hardcoded to avoid any issues with setting R_LD_LIBRARY_PATH
    # User is free to change this option as needed
    options(td.lib.IODBC = "/usr/lib/libiodbc.dylib")
  }

  # Vantage version is set to vantage1.1 by default.
  if (is.null(getOption("td.vantage.version"))) {
    options(td.vantage.version = "vantage1.1")
  }

  # sandbox image name; setting it to 'rstosandbox' by default.
  if (is.null(getOption("docker.image.name"))) {
    options(docker.image.name = "rstosandbox")
  }

  # sandbox image tag; setting it to '1.0' by default.
  if (is.null(getOption("docker.image.tag"))) {
    options(docker.image.tag = "1.0")
  }

}

# Initialize all Pkg level global variables and constants here.
# Variables should only be stored within package namespace
# Storing variables in global environment is not recommended
# unless there is very important reason.
.initPkgGlobals <- function() {
  # Set the lowest version of Teradata DB we will support
  # use this variable in connect and throw warning as necessary
  # If we need we must add minor versions
  .assign("lowestSupportedVersion", "16.20")
  # Set the max number of columns supported by TERADATA
  .assign("maxNumberOfColumns", 2048)
  # Set the min batch size for fastload inserts
  .assign("minBatchSizeForFastload", 100000)
  
  # Set the minimum and maximum possible integer value.
  .assign("minInteger", -2147483647)
  .assign("maxInteger", 2147483647)
  
  # Set the engine names supported by Teradata and corresponding config file names which contains
  # aliases to be used to execute the functions on Teradata.
  supportedEngines <- list(ENGINE_ML = list(file = 'mlengine_alias_definitions', name = 'ml'), 
                           ENGINE_SQL = list(file = 'sqlengine_alias_definitions', name = 'sql'))
  
  .assign("supportedEngines", supportedEngines)
  
  # List of supported Vantage versions
  supportedVantageVersions <-  list("vantage1.0" = "v1.0", "vantage1.1" = "v1.1")
  .assign("supportedVantageVersions", supportedVantageVersions)
  
  # Adding constants for time series PTI tables.
  .assign("timecodeColumn", "TD_TIMECODE")
  .assign("sequenceColumn", "TD_SEQNO")
  
  # Adding the supported prediciton types for Model Cataloging
  .assign("predictionTypes", list(classification = "CLASSIFICATION",
                                  regression = "REGRESSION",
                                  clustering = "CLUSTERING",
                                  other = "OTHER"))

  # Adding mapping from function to it's prediction type
  .assign("inputDependentPredictionTypeFunctionList", c("td_decision_forest_mle"))
  predictionTypes <- .get("predictionTypes")
  .assign("functionPredictionTypeMapper", list(
    td_adaboost_mle = predictionTypes$classification,
    td_adaboost_predict_mle = predictionTypes$classification,
    td_arima_mle = predictionTypes$regression,
    td_arima_predict_mle = predictionTypes$regression,
    td_coxph_mle = predictionTypes$regression,
    td_cox_hazard_ratio_mle = predictionTypes$regression,
    td_cox_survival_mle = predictionTypes$regression,
    td_decision_tree_mle = predictionTypes$classification,
    td_decision_tree_predict_mle = predictionTypes$classification,
    td_decision_tree_predict_sqle = predictionTypes$classification,
    td_glml1l2_mle = predictionTypes$regression,
    td_glml1l2_predict_mle = predictionTypes$regression,
    td_glm_mle = predictionTypes$regression,
    td_glm_predict_mle = predictionTypes$regression,
    td_glm_predict_sqle = predictionTypes$regression,
    td_kmeans_mle = predictionTypes$clustering,
    td_knn_mle = predictionTypes$classification,
    td_lar_mle = predictionTypes$regression,
    td_lar_predict_mle = predictionTypes$regression,
    td_lda_inference_mle = predictionTypes$classification,
    td_lda_mle = predictionTypes$classification,
    td_lda_topic_summary_mle = predictionTypes$classification,
    td_linreg_predict_mle = predictionTypes$regression,
    td_lin_reg_mle = predictionTypes$regression,
    td_minhash_mle = predictionTypes$clustering,
    td_naivebayes_mle = predictionTypes$classification,
    td_naivebayes_predict_mle = predictionTypes$classification,
    td_naivebayes_predict_sqle = predictionTypes$classification,
    td_naivebayes_textclassifier_mle = predictionTypes$classification,
    td_naivebayes_textclassifier_predict_mle = predictionTypes$classification,
    td_naivebayes_textclassifier_predict_sqle = predictionTypes$classification,
    td_svm_dense_mle = predictionTypes$classification,
    td_svm_dense_predict_mle = predictionTypes$classification,
    td_svm_dense_summary_mle = predictionTypes$classification,
    td_svm_sparse_mle = predictionTypes$classification,
    td_svm_sparse_predict_mle = predictionTypes$classification,
    td_svm_sparse_predict_sqle = predictionTypes$classification,
    td_svm_sparse_summary_mle = predictionTypes$classification,
    td_text_classifier_evaluator_mle = predictionTypes$classification,
    td_text_classifier_mle = predictionTypes$classification,
    td_text_classifier_trainer_mle = predictionTypes$classification,
    td_varmax_mle = predictionTypes$regression,
    td_xgboost_mle = predictionTypes$classification,
    td_xgboost_predict_mle = predictionTypes$classification
  ))
  
  # Adding constants for function argument mapper
  .assign("functionArgumentMap", NULL)
  # Mapper related
  .assign(".fam.sqlToTdplyr", "sql_to_tdplyr")
  .assign(".fam.tdplyrToSql", "tdplyr_to_sql")
  .assign(".fam.alternateTo", "alternate_to")
  .assign(".fam.tdplyrName", "tdplyr_name")
  .assign(".fam.tdplyrType", "tdplyr_type")
  .assign(".fam.usedInSequenceInputBy", "used_in_sequence_by")
  .assign(".fam.usedInFormula", "used_in_formula")
  .assign(".fam.inputs", "inputs")
  .assign(".fam.outputs", "outputs")
  .assign(".fam.arguments", "arguments")
  .assign(".fam.dependentAttr", "dependent")
  .assign(".fam.independentAttr", "independent")
  .assign(".fam.tdplyrFormulaName", "formula")
  .assign(".fam.defaultOuput", "__default_output__")
  .assign(".fam.defaultOutputTdplyrNameSingle", "result")
  .assign(".fam.defaultOutputTdplyrNameMultiple", "output")
  
  # JSON related
  .assign(".fam.allowsLists", "allowsLists")
  .assign(".fam.datatype", "datatype")
  .assign(".fam.boolType", "BOOLEAN")
  .assign(".fam.intType", "INTEGER")
  .assign(".fam.numericType", c("LONG", "DOUBLE", "DOUBLE PRECISION", "FLOAT"))
  .assign(".fam.inputTables", "input_tables")
  .assign(".fam.outputTables", "output_tables")
  .assign(".fam.argumentClauses", "argument_clauses")
  .assign(".fam.rName", "rName")
  .assign(".fam.name", "name")
  .assign(".fam.functionTdplyrName", "function_tdplyr_name")
  .assign(".fam.rFormulaUsage", "rFormulaUsage")
  .assign(".fam.rOrderNum", "rOrderNum")
  .assign(".fam.tdplyrSequenceColumnName", "sequence.column")
  
  .assign(".fam.tdplyrCharacterType", "character")
  .assign(".fam.tdplyrNumericType", "numeric")
  .assign(".fam.tdplyrBoolType", "logical")
  .assign(".fam.tdplyrIntegerType", "integer")
  .assign(".fam.tdplyrList", "list")
  
  # Custom output names - to hepl create the Function Argument map based
  # on the output names different from the generated name.
  .assign(".fam.customOuputNames", list(
    td_namedentity_finder_trainer_mle = list(result = "output"),
    td_sentiment_trainer_mle = list(result = "output"),
    td_lar_mle = list(output = "sql.stdout")
  ))
  
  # Adding constants for Model Cataloging
  .assign(".mc.modelCatalogDB", "TD_ModelCataloging")
  .assign(".mc.modelEngineML", "ML Engine")
  .assign(".mc.modelEngineAdvSQL", "Advanced SQL Engine")
  .assign(".mc.validEngines", list("MLE" = "ML Engine", "SQLE" = "Advanced SQL Engine"))

  # Stored Procedure Names
  .assign(".mc.saveModel", "SYSLIB.SaveModel")
  .assign(".mc.deleteModel", "SYSLIB.DeleteModel")
  .assign(".mc.publishModel", "SYSLIB.PublishModel")
  
  .assign(".mc.generatingClientTdplyr", "tdplyr")
  
  .assign(".mc.modelValidStatus", c("ACTIVE", "RETIRED", "CANDIDATE", "PRODUCTION", "IN-DEVELOPMENT"))
  .assign(".mc.defaultSaveStatus", "In-Development")
  .assign(".mc.defaultSaveAccess", "Private")
  .assign(".mc.publicAccess", "Public")
  
  .assign(".mc.models", "ModelsV")
  .assign(".mc.modelDetails", "ModelDetailsV")
  .assign(".mc.modelObjects", "ModelObjectsV")
  .assign(".mc.modelAttrs", "ModelAttributesV")
  .assign(".mc.modelPerf", "ModelPerformanceV")
  .assign(".mc.modelLoc", "ModelLocationV")
  .assign(".mc.modelListingList", c('ModelName','ModelAlgorithm','ModelGeneratingEngine',
                                    'ModelGeneratingClient','CreatedBy','CreatedDate'))
  
  .assign(".mc.modelsX", "ModelsVX")
  .assign(".mc.modelDetailsX", "ModelDetailsVX")
  .assign(".mc.modelInputsX", "ModelTrainingDataVX")
  
  .assign(".mc.modelName", "Name")
  .assign(".mc.modelId", "ModelId")
  .assign(".mc.modelDerivedName", "ModelName")
  .assign(".mc.modelDerivedAlgorithm", "ModelAlgorithm")
  .assign(".mc.modelDerivedGenClient", "ModelGeneratingClient")
  .assign(".mc.modelDerivedGenEng", "ModelGeneratingEngine")
  .assign(".mc.modelDerivedBuildTime", "ModelBuildTime")
  .assign(".mc.modelDerivedPredictionType", "ModelPredictionType")
  .assign(".mc.modelDerivedTargetColumn", "ModelTargetColumn")
  .assign(".mc.modelAccess", "ModelAccess")
  
  .assign(".mc.modelInputClientName", "ClientSpecificInputName")
  .assign(".mc.modelInputTableName", "TableName")
  .assign(".mc.modelInputRows", "NRows")
  .assign(".mc.modelInputCols", "NCols")
  
  .assign(".mc.modelObjName", "TableReferenceName")
  .assign(".mc.modelObjClientName", "ClientSpecificTableReferenceName")
  .assign(".mc.modelObjTableName", "TableName")
  
  .assign(".mc.modelClientClassKey", "__class_name__")
  .assign(".mc.modelAttrValue", "AttributeValue")
}

# Initialize the sql_translate_env implementations
# see sql-translation.R
# Note: Since we are re-using the Teradata S4 connection class and 
#       since sql_translate_env.Teradata is already defined in the dbplyr package, 
#       overriding sql_translate_env.Teradata in this package won't work unless we
#       assignInNamespace the dbplyr implementation.
# The sql_translate_env.Teradata in the dbplyr package shadows any other implementation
# of sql_translate_env.Teradata. Using a different S4 class name makes the assignInNamespace
# unecessary.
#
.initSQLMap <- function(){

  # We dynamically load the environments from dbplyr before assignInNamespace
  # so we can undo the assignInNamespace when unloading this package and to 
  # keep updates from dbplyr sql_translate_env.Teradata. We always override
  # the mappings from dbplyr.
  
  dbplyr_td_impl <- utils::getS3method("sql_translate_env", 
                                "Teradata", 
                                envir = asNamespace("dbplyr"))

   sqlVar <- list(dbplyr_td = dbplyr_td_impl(dbplyr::simulate_teradata()))
   
  .setSqlVariantDbplyr(sqlVar)
  
  suppressWarnings(
    utils::assignInNamespace('sql_translate_env.Teradata', 
                    sql_translate_env.Teradata, 
                    ns = "dbplyr")
  )
}

# Initialize list of alias definations for analytic functions for 
# supported engines into a global variable.Example : ml, sql etc
# Assumption is, the config files are created with details of the aliases for 
# analytic functions present in the tdplyr package.
#
.loadFunctionAliases <- function(){
  # List to store aliases for different supported engines.
  functionAliasMappings <- list()
  supportedVantageVersions <- .get("supportedVantageVersions")
  supportedEngines <- .get("supportedEngines")
  for (ver in names(supportedVantageVersions)) {
    functionAliasMappingsByVantageVersions <- list()
    for (cnt in 1:length(supportedEngines)) {
      # Read aliases for mlengine functions.
      aliasconfName <- paste0(supportedEngines[[cnt]]$file, "_", supportedVantageVersions[[ver]])
      fullAliasConfName <- system.file("config", aliasconfName, package="tdplyr")
      aliases_df <- read.csv(fullAliasConfName, header = TRUE, sep = ":", stringsAsFactors = FALSE)
      aliases_mapping <- lapply(aliases_df$aliasName, function(x) {trimws(x)})
      names(aliases_mapping) <- tolower(aliases_df$functionName)

      # Check if any duplicate entry it added for any function.
      duplicate_functions <- names(aliases_mapping)[duplicated(names(aliases_mapping))]
      if (length(duplicate_functions) > 0)
        .ta.stop("TDR_E3105", duplicate_functions, fullAliasConfName)

      # Store aliases for mlengine functions.
      functionAliasMappingsByVantageVersions[[supportedEngines[[cnt]]$name]] <- aliases_mapping
    }
    functionAliasMappings[[ver]] <- functionAliasMappingsByVantageVersions
  }
  
  # Store the list
  .assign("functionAliasMappings", functionAliasMappings)
}

# Check if a variable exists in the envirionment .TAEnv
# Args:
#   s: The variable name to check
# Returns:
#   TRUE if s exists in the package environment
.exists <- function(s) {
  exists(s, envir = get(".TAEnv"))
}

# Get the value of a variable in the environment .TAEnv
# Args:
#   s: The variable name to check
# Returns:
#   The value corresponding to s if it exists in the package environment
.get <- function(s) {
  tryCatch({
    get(s, envir = get(".TAEnv"))
  },
  error = function(...) NULL)
}

# Assign and attach a variable to the environment .TAEnv
# Args:
#   s: The variable name to check
#   value: Value to be assigned to the variable s
# Returns:
#   None
.assign <- function(s, value) {
  assign(s, value, envir = get(".TAEnv"))
}

# Remove a variable that is present in the environment .TAEnv
# Args:
#   s: The variable name to check
# Returns:
#   None
.rm <- function(s, silent = TRUE) {
  # If silent is false and if a variable is not available this will a throw warning
  command <- quote(rm(list = s, envir = get(".TAEnv")))
  if (silent)
    suppressWarnings(eval(command))
  else
    eval(command)
}

# Get the sql original sql variants from dbplyr
# Returns:
#  named list of sql variants
.getSqlVariantDbplyr <- function() {
  .get(".sql__variant__dbplyr")
}

# Set the original sql variants from dbplyr
# Arguments:
#  names list of sql variants
.setSqlVariantDbplyr <- function(sqlVar = list()) {
  .assign(".sql__variant__dbplyr", sqlVar)
}

#
# Event for unload package
#
.onUnload <- function(libpath) {

  # Force to disconnect after unload the library
  # Invoke disconnect on all connections

  try(.ta.removeContext(), silent = TRUE)
  
  # Undo the assignInNamespace for dbplyr:::sql_translate_env
  sqlVar <- .getSqlVariantDbplyr()
  suppressWarnings(
    utils::assignInNamespace('sql_translate_env.Teradata', 
                             function(con) sqlVar$dbplyr_td, 
                             ns = "dbplyr")
  )

  try(library.dynam.unload("tdplyr", libpath),silent = TRUE)
}

