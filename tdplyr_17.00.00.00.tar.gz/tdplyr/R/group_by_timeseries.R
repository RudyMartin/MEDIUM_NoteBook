#
# Copyright 2019 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
#
# Primary Owner: Adithya Avvaru (adithya.avvaru@teradata.com)
# Secondary Owner:
#
###################################################################################

#' Group by Time for PTI and non-PTI tables
#'
#' This function takes an existing tbl_teradata and converts into a grouped tbl_teradata 
#' object that allows a set of aggregate functions to be computed on data grouped in terms of time. 
#' Although the grouping is optimized for objects of class "tbl_teradata" created using PTI tables, 
#' it is also supported on objects of class "tbl_teradata" created using non-PTI tables when the 
#' argument "timecode.column" is specified.\cr
#' Note: If consecutive groupings are performed, latest grouping operation is considered, i.e. if 
#' \code{groupby} is followed by \code{groupby_time}, \code{groupby_time} grouping is considered 
#' for aggregation. Similarly, if \code{groupby_time} is followed by \code{groupby}, \code{groupby} 
#' grouping is considered for aggregation. If consecutive \code{groupby_time} operations are 
#' performed, latest \code{groupby_time} is considered for aggregation.
#' 
#' @param df Required Argument.\cr
#'           Specifies the tbl_teradata on which grouping based on time is to be done.
#' @param timebucket.duration Required Argument.\cr
#'                            Specifies the duration of each timebucket for aggregation and is 
#'                            used to assign each potential timebucket a unique number. The 
#'                            timebucket number is shown as a column in the aggregated 
#'                            tbl_teradata.\cr
#'                            A time duration can be specified using any of the units of time
#'                            as shown below:
#'                            \tabular{lllll}{
#'                            ------------------------\tab-------------------------------\tab
#'                            ---------------------------------------------------------------------\cr
#'                            Time Unit \tab Formal Form Example \tab Shorthand Equivalents \cr
#'                            ------------------------\tab-------------------------------\tab
#'                            ---------------------------------------------------------------------\cr
#'                            Calendar Years \tab CAL_YEARS(N)\tab Ncy, Ncyear, Ncyears\cr
#'                            Calendar Months \tab CAL_MONTHS(N) \tab Ncm, Ncmonth, Ncmonths\cr
#'                            Calendar Days \tab CAL_DAYS(N) \tab Ncd, Ncday, Ncdays\cr
#'                            Weeks \tab WEEKS(N) \tab Nw, Nweek, Nweeks\cr
#'                            Days \tab DAYS(N) \tab Nd, Nday, Ndays\cr
#'                            Hours \tab HOURS(N) \tab Nh, Nhr, Nhrs, Nhour, Nhours\cr
#'                            Minutes \tab MINUTES(N) \tab Nm, Nmins, Nminute, Nminutes\cr
#'                            Seconds \tab SECONDS(N) \tab Ns, Nsec, Nsecs, Nsecond, 
#'                            Nseconds\cr
#'                            Milliseconds \tab MILLISECONDS(N) \tab Nms, Nmsec, Nmsecs, 
#'                            Nmillisecond, Nmilliseconds\cr
#'                            Microseconds \tab MICROSECONDS(N) \tab Nus, Nusec, Nusecs, 
#'                            Nmicrosecond, Nmicroseconds\cr
#'                            ------------------------\tab-------------------------------\tab
#'                            ---------------------------------------------------------------------
#'                            }
#'                            Where, N is a 16-bit positive integer with a maximum value of 
#'                            32767.\cr
#'                            When timebucket.duration is Calendar Days, columns are grouped
#'                            in 24-hour periods starting at 00:00:00.000000 and ending at 
#'                            23:59:59.999999 on the day identified by time zero.\cr
#'                            The time units do not store values such as the year or the month. 
#'                            For example, CAL_YEARS(2017) does not set the year to 2017. It sets 
#'                            the timebucket.duration to intervals of 2017 years. Similarly, 
#'                            CAL_MONTHS(7) does not set the month to July. It sets the 
#'                            timebucket.duration to intervals of 7 months.\cr
#'                            A DAYS time unit is a 24-hour span relative to any moment in time. 
#'                            For example, if time zero (while creating PTI tables in Teradata 
#'                            SQL Engine) is 2016-10-01 12:00:00, the day buckets are 
#'                            2016-10-01 12:00:00.000000 - 2016-10-02 11:59:59.999999. 
#'                            This spans multiple calendar days, 
#'                            but encompasses one 24-hour period representative of a day.\cr
#'                            Note: This argument can take unbounded timebucket duration ("*") that 
#'                            can only be used with \code{ts.delta_t} time series aggregate 
#'                            function.\cr
#'                            Types: str\cr
#'                            Examples: 
#'                            \enumerate{
#'                            \item MINUTES(23) which is equal to 23 minutes
#'                            \item CAL_MONTHS(5) which is equal to 5 calendar months
#'                            }
#' @param value.expression Optional Argument.\cr
#'                         Specifies a column or any expression involving columns. These 
#'                         expressions are used for grouping purposes not related to time. \cr
#'                         Note: 
#'                         \enumerate{
#'                         \item The value.expression must not be a column reference to a view 
#'                         column that is derived from a function and cannot contain any ordered 
#'                         analytical or aggregate functions. 
#'                         \item The value.expression cannot be a literal.
#'                         }
#'                         Default Value : c()\cr
#'                         Types: character OR vector of characters
#' @param timecode.column Optional Argument.\cr
#'                        Specifies a column that serves as the timecode for a tbl_teradata 
#'                        created of a non-PTI table. \cr
#'                        For tbl_teradata created using PTI table, this argument takes 
#'                        TD_TIMECODE implicitly, but it can also be specified explicitly by the 
#'                        user with this argument.\cr
#'                        For tbl_teradata created using non-PTI table, one must pass column 
#'                        name to this argument, otherwise an error is raised.\cr
#'                        Default Value : NULL\cr
#'                        Types: character
#' @param sequence.column Optional Argument.\cr
#'                        Specifies column expression that is the sequence number.\cr
#'                        For tbl_teradata created using PTI table, it can be TD_SEQNO or any 
#'                        other column that acts as a sequence number.\cr
#'                        For tbl_teradata created using non-PTI table, sequence.column is a 
#'                        column that plays the role of TD_SEQNO, because non-PTI tables do not 
#'                        have TD_SEQNO.\cr
#'                        Note: This argument can only be given when "timecode.column" is not NULL.
#'                        Default Value : NULL\cr
#'                        Types: character
#' @param fill Optional Argument.\cr
#'             Specifies the value to be used for missing timebucket values.\cr
#'             Below is the description of accepted values:
#'             \enumerate{
#'             \item NULLS: The missing timebuckets are returned to the user with a NULL value 
#'             for all aggregate results.
#'             \item numeric_constant: Any Teradata SQL Engine supported Numeric literal. The 
#'             missing timebuckets are returned to the user with the specified constant value 
#'             for all aggregate results. If the data type specified in this argument is 
#'             incompatible with the input data type for an aggregate function, an error is reported.
#'             \item PREVIOUS/PREV: The missing timebuckets are returned to the user with the aggregate 
#'             results populated by the value of the closest previous timebucket with a non-missing value. 
#'             If the immediate predecessor of a missing timebucket is also missing, both buckets, and 
#'             any other immediate predecessors with missing values, are loaded with the first preceding 
#'             non-missing value. If a missing timebucket has no predecessor with a result (for example, 
#'             if the timebucket is the first in the series or all the preceding timebuckets in the entire 
#'             series are missing), the missing timebuckets are returned to the user with a NULL value for 
#'             all aggregate results. The abbreviation PREV may be used instead of PREVIOUS.
#'             \item NEXT: The missing timebuckets are returned to the user with the aggregate results 
#'             populated by the value of the closest succeeding timebucket with a non-missing value. If 
#'             the immediate successor of a missing timebucket is also missing, both buckets, and any 
#'             other immediate successors with missing values, are loaded with the first succeeding 
#'             non-missing value. If a missing timebucket has no successor with a result (for example, 
#'             if the timebucket is the last in the series or all the succeeding timebuckets in the 
#'             entire series are missing), the missing timebuckets are returned to the user with a NULL 
#'             value for all aggregate results.
#'             }
#'             Default Value : NULL\cr
#'             Permitted Values : NULLS, PREVIOUS, PREV, NEXT and any numeric constant\cr
#'             Types: character or a numeric value
#' @param ...  Optional arguments for future purpose, if needed.
#' @return A `tbl_teradata` object.
#' @examples
#' \donttest{
#' 
#' # Get remote data source connection.
#' con <- td_get_context()$connection
#' 
#' # Load the required tables.
#' loadExampleData("time_series_example", "ocean_buoys_seq", "ocean_buoys_nonseq", "ocean_buoys_nonpti", "package_tracking_pti")
#' 
#' # Create objects of class "tbl_teradata".
#' df_seq <- tbl(con, "ocean_buoys_seq") # tbl of sequenced PTI table.
#' df_nonseq <- tbl(con, "ocean_buoys_nonseq") # tbl of non-sequenced PTI table.
#' df_nonpti <- tbl(con, "ocean_buoys_nonpti") # tbl of non-PTI table.
#' 
#' # Example 1: Grouping the sequenced PTI tables based on time with timebucket duration of 30 minutes and
#' #            the column 'buoyid' and ignoring the aggregation when there is no values in the group.
#' 
#' # Grouping by timebucket duration of 30 minutes and 'buoyid'.
#' # Note the use of shorthand notation for timebucket duration.
#' seq_group1 <- df_seq %>% group_by_time(timebucket.duration = "30m", value.expression = "buoyid")
#' 
#' # Applying min() aggregation on grouped tbl object.
#' seq_group1 %>% summarise(min_temp = min(temperature))
#' 
#' # Example 2: Grouping the non-PTI tables based on time with timebucket duration of 1 minute
#' #            and fills the missing timebuckets with previous values.
#' 
#' # Grouping by timebucket duration of 1 minute.
#' # Note the use of formal notation for timebucket duration.
#' # Note the use of timecode.column argument (mandatory for non-PTI table).
#' seq_group2 <- df_nonpti %>% group_by_time(timebucket.duration = "MINUTES(1)", timecode.column = "TIMECODE", fill = "PREV")
#' 
#' # Applying min() aggregation on grouped tbl object.
#' temp_grouped <- seq_group2 %>% summarise(min_temp = min(temperature))
#' 
#' # Displaying the rows in the increasing order to TIMECODE_RANGE or 'GROUP BY TIME(MINUTES(1))' column.
#' temp_grouped %>% arrange(`GROUP BY TIME(MINUTES(1))`)
#' 
#' # Example 3: Grouping the non-sequenced PTI tables based on time with timebucket duration of 
#' #            2 Calendar years. Note the use of timecode.column and sequence.column arguments.
#' 
#' # The next three grouping give a quick demo of the use of fill argument keeping all other arguments
#' # same.
#' # With fill = "PREVIOUS"
#' grp1 <- df_nonseq %>% group_by_time(timebucket.duration = "CAL_YEARS(1)", timecode.column = "TD_TIMECODE", sequence.column = "buoyid", fill = "PREVIOUS")
#' min_t <- grp1 %>% summarise(min_temp = min(temperature))
#' min_t %>% arrange(`GROUP BY TIME(CAL_YEARS(1))`)
#' 
#' # With fill = "NEXT"
#' grp1 <- df_nonseq %>% group_by_time(timebucket.duration = "CAL_YEARS(1)", timecode.column = "TD_TIMECODE", sequence.column = "buoyid", fill = "NEXT")
#' min_t <- grp1 %>% summarise(min_temp = min(temperature))
#' min_t %>% arrange(`GROUP BY TIME(CAL_YEARS(1))`)
#' 
#' # With fill = 10000 (some numeric constant)
#' grp1 <- df_nonseq %>% group_by_time(timebucket.duration = "CAL_YEARS(1)", timecode.column = "TD_TIMECODE", sequence.column = "buoyid", fill = 10000)
#' min_t <- grp1 %>% summarise(min_temp = min(temperature))
#' min_t %>% arrange(`GROUP BY TIME(CAL_YEARS(1))`)
#' 
#' # Example 4: Finding Time Elapsed between Shipping and Receiving an Item. Input data used for this 
#' #            example contains information about parcels sent by a delivery service. This example also
#' #            demonstrates the use of unbounded timebucket duration ('*') for 'ts.delta_t' time series
#' #            aggregate function.
#' df_pack_pti <- tbl(con, "package_tracking_pti")
#' df_grp <- df_pack_pti %>% group_by_time(timebucket.duration = "*", value.expression = "parcel_number")
#' df_out <- df_grp %>% summarise(delta_t = ts.delta_t("Status LIKE 'picked%up%customer'", "Status LIKE 'delivered%customer'"))
#' df_out %>% arrange(TIMECODE_RANGE, parcel_number)
#' }

#' @export
#' @importFrom rlang new_quosure
#' @importFrom rlang get_expr
#' @importFrom rlang get_env
#' @importFrom dbplyr partial_eval
#' @importFrom dbplyr add_op_single
group_by_time <- function (df, timebucket.duration, value.expression = c(), 
                            timecode.column = NULL, sequence.column = NULL, fill = NULL, ...) {
  
  # timebucket_duration_modified has the formal timebucket duration if shorthand timebucket duration is passed.
  # This is used in select clause variable name.
  timebucket_duration_modified <- .validateGroupByTimeArguments(df, timebucket.duration, value.expression, 
                                                       timecode.column, sequence.column, fill)
  
  group_by_time_exr <- .build_group_by_time_clause(timebucket.duration, 
                                                   value.expression, 
                                                   timecode.column, 
                                                   sequence.column, 
                                                   fill)
  
  arg_values <- list("group_by_time_expr" = group_by_time_exr,
                     "time_bucket_duration" = timebucket_duration_modified,
                     "value_expression" = value.expression)
  
  dots <- quos(...)
  dots <- partial_eval_dots(dots, vars = op_vars(df))
  
  add_op_single("group_by_time", df, dots = dots, args = arg_values)
}

#' @export
#' @importFrom dbplyr sql_build
sql_build.op_group_by_time <- function (op, con, ...) {
  sql_build(op$x, con, ...) # uses op_base_remote
}

#' @export
op_grps.op_group_by_time <- function(op) {
  # Grouping by TIMECODE_RANGE and columns given in value.expression.
  group_columns_time_series <- c("TIMECODE_RANGE", op$args$value_expression)
}

# The function builds the group by time clause to be used in the query.
# Parameters:
#   timebucket.duration : Specifies the duration of time bucket.
#   value.expression : Specifies the columns which are used for grouping apart from timecode column.
#   timecode.column : Specifies the column which contain timecode information.
#   sequence.column : Specifies the column which contain the sequence information.
#   fill : Specifies the value to be used for missing timebucket values.
#' @importFrom dplyr sql
.build_group_by_time_clause <- function (timebucket.duration, value.expression = c(), 
                                         timecode.column = NULL, sequence.column = NULL, fill = NULL) {
  
  # Creating group_by_time clause
  group_by_time_exr <- paste0("GROUP BY TIME(", timebucket.duration)
  if (length(value.expression) > 0) {
    value_expression_new <- sql(paste0(value.expression, collapse = ", "))
    group_by_time_exr <- paste0(group_by_time_exr, " AND ", value_expression_new)
  }
  group_by_time_exr <- paste0(group_by_time_exr, ")")
  
  # Adding timecode column clause
  if (! is.null(timecode.column)) {
    group_by_time_exr <- paste0(group_by_time_exr, " USING TIMECODE(", timecode.column)
    if(! is.null(sequence.column)) {
      group_by_time_exr <- paste0(group_by_time_exr, ", ", sequence.column)
    }
    group_by_time_exr <- paste0(group_by_time_exr, ")")
  }
  
  # Adding FILL clause
  if(! is.null(fill)) {
    group_by_time_exr <- paste0(group_by_time_exr, " FILL(", fill, ")")
  }
  group_by_time_exr <- sql(group_by_time_exr)
}

# The function which validates the arguments of group_by_time API.
# Parameters:
#   df  : Specifies the tbl_teradata which is used for grouping.
#   timebucket.duration : Specifies the duration of time bucket.
#   value.expression : Specifies the columns which are used for grouping apart from timecode column.
#   timecode.column : Specifies the column which contain timecode information.
#   sequence.column : Specifies the column which contain the sequence information.
#   fill : Specifies the value to be used for missing timebucket values.
.validateGroupByTimeArguments <- function(df, timebucket.duration, value.expression = c(), 
                                         timecode.column = NULL, sequence.column = NULL, fill = NULL) {
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("timebucket.duration", timebucket.duration, FALSE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("value.expression", value.expression, TRUE, c("character", "list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("timecode.column", timecode.column, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("sequence.column", sequence.column, TRUE, c("character", NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("fill", fill, TRUE, c("numeric", "character")))
  
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types is data frame type.
  .validateInputTableDataType(df, NULL)
  
  .validateInputColumnsNotEmpty(timebucket.duration)
  
  .validateInputColumnsNotEmpty(value.expression)
  .validateTblHasArgumentColumns(value.expression, "value.expression", df, "df")
  
  .validateInputColumnsNotEmpty(timecode.column)
  .validateTblHasArgumentColumns(timecode.column, "timecode.column", df, "df")
  
  .validateInputColumnsNotEmpty(sequence.column)
  .validateTblHasArgumentColumns(sequence.column, "sequence.column", df, "df")
  
  .validateInputColumnsNotEmpty(fill)
  
  if (is.null(timecode.column) && !is.null(sequence.column))
    .ta.stop("TDR_E3101", "sequence.column", 'timecode.column', "specified")
  
  fill.permitted.values <- list("PREV", "PREVIOUS", "NEXT", "NULLS", "any numeric constant")
  if (!is.null(fill) && !is.numeric(fill))
    .validatePermittedValues(fill, fill.permitted.values)
  
  if (!is.null(timecode.column) || !is.null(sequence.column)) {
    col_info = NULL
    if(!is.null(timecode.column)) {
      if(timecode.column %in% value.expression) {
        .ta.stop("TDR_E3104", "argument", "timecode.column", 
                 "the columns not used in the argument 'value.expression'")
      }
      
      # Check for type of the column given in 'timecode.column' argument.
      col_info <- .ta.describe.columns.wrapper(.taConnection(), remote_query(df))
      timecode_col_type <- col_info$types[[which(col_info$names == timecode.column)]]
      if (timecode_col_type != "timestamp" && timecode_col_type != "date") {
        .ta.stop("TDR_E3108", "timecode.column", toupper(timecode_col_type), "TIMESTAMP or DATE")
      }
    }
    if(!is.null(sequence.column)) {
      if(sequence.column %in% value.expression) {
        .ta.stop("TDR_E3104", "argument", "sequence.column", 
                 "the columns not used in the argument 'value.expression'")
      }
      # Check for type of the column given in 'sequence.column' argument.
      seq_col_type <- col_info$types[[which(col_info$names == sequence.column)]]
      integer_types <- c("int", "integer")
      if (! seq_col_type %in% integer_types) {
        .ta.stop("TDR_E3108", "sequence.column", toupper(seq_col_type), "INTEGER")
      }
    }
  }
  

  .validate_time_bucket_duration(timebucket.duration = timebucket.duration)
}