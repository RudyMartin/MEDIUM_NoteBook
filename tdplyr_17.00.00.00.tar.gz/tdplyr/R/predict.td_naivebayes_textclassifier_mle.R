# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' @export
predict.td_naivebayes_textclassifier_mle <- function(
                                      object = NULL,
                                      newdata = NULL,
                                      input.token.column = NULL,
                                      doc.id.columns = NULL,
                                      model.type = "MULTINOMIAL",
                                      top.k = NULL,
                                      model.token.column = NULL,
                                      model.category.column = NULL,
                                      model.prob.column = NULL,
                                      newdata.partition.column = NULL,
                                      newdata.order.column = NULL,
                                      object.order.column = NULL) {
  
  td_naivebayes_textclassifier_predict_sqle(object = object,
                                       newdata = newdata,
                                       input.token.column = input.token.column,
                                       doc.id.columns = doc.id.columns,
                                       model.type = model.type,
                                       top.k = top.k,
                                       model.token.column = model.token.column,
                                       model.category.column = model.category.column,
                                       model.prob.column = model.prob.column,
                                       newdata.partition.column = newdata.partition.column,
                                       newdata.order.column = newdata.order.column,
                                       object.order.column = object.order.column)
}
