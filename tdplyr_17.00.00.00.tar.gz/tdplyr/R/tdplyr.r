# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET

#' tdplyr: dplyr for Teradata Vantage
#'
#' tdplyr is focused on integrating and scaling dplyr with Teradata 
#' Vantage to solve challenges in data analysis.
#'
#' The main goals are to:
#'
#' \itemize{
#'   \item Enable data scientists to work effectively with the data in Teradata Vantage.
#'   \item Provide a growing list of analytic functions to leverage in-database analytics.
#' }
#'
#' To learn more about tdplyr, start with the vignettes:
#'
#' \code{browseVignettes(package = "tdplyr")}
#'
#' Use the help command to view the list of exported functions:
#'
#' \code{help(package = "tdplyr")}
#'
#' To learn more about dplyr, start with the vignettes:
#'
#' \code{browseVignettes(package = "dplyr")}
#'
#' @section Package options:
#' \describe{
#' \item{\code{td.db_desc.output}}{Sets the Database output when printing tbls}
#' }
#'
#' @section Package options for dplyr related packages:
#'
#' Options from the dplyr package
#' \describe{
#'   \item{\code{dplyr.strict_sql}}{Forces an error if dplyr doesn't know how to 
#'                             map a function when translating SQL if TRUE. 
#'                             FALSE by default.}
#' }
#' 
#' Options from the tibble package
#' \describe{
#' \item{\code{tibble.print_min}}{Sets minimum amount of rows to print by default}
#' }
#'
#' @section Glossary of Terms:
#'
#' Teradata tbl object: Refers to the object created using the \code{tbl()} function of the "dplyr" package,
#' when the function is invoked with a Teradata connection.
#' Teradata tbl is an object of class "tbl_teradata".
#' For example, to create a Teradata tbl object from an existing table "TABLE1" with a connection "con",
#' use the command: \code{dplyr::tbl(con, "TABLE1")}.
#'
"_PACKAGE"

#' @importFrom magrittr extract2
#' @export
magrittr::extract2
