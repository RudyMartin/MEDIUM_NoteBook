# ################################################################## 
# 
# Copyright 2018 Teradata. All rights reserved.
# TERADATA CONFIDENTIAL AND TRADE SECRET
# 
# Primary Owner: Pankaj Purandare (pankajvinod.purandare@teradata.com)
# Secondary Owner: Trupti Purohit (trupti.purohit@teradata.com)
# 
# Version: 1.2
# Function Version: 1.9
# 
# ################################################################## 

# Description:
#   The SAX2 function transforms original time series data into symbolic
#   strings, which are more suitable for many additional types of manipulation,
#   because of their smaller size and the relative ease with which patterns can be
#   identified and compared. Input and output formats allow it to supply data to the Shapelet
#   Functions.
# 
# Args:
#   data -
#     Required Argument.\cr
#     Input table\cr
#   
#   data.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   data.order.column -
#     Required Argument.\cr
#     Specifies Order By columns for "data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   meanstats.data -
#     Optional Argument.\cr
#     meanstats tbl_teradata (optional) that contains the global means of 
#     each value_column of the input table.\cr
#   
#   meanstats.data.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "meanstats.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   meanstats.data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "meanstats.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   stdevstats.data -
#     Optional Argument.\cr
#     stdevstats tbl_teradata (optional) that contains the global standard 
#     deviations of each value_column of the input table.\cr
#   
#   stdevstats.data.partition.column -
#     Required Argument.\cr
#     Specifies Partition By columns for "stdevstats.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for partition.\cr
#     Types: character OR vector of Strings (character)
#   
#   stdevstats.data.order.column -
#     Optional Argument.\cr
#     Specifies Order By columns for "stdevstats.data".\cr
#     Values to this argument can be provided as a vector, if multiple 
#     columns are used for ordering.\cr
#     Types: character OR vector of Strings (character)
#   
#   value.columns -
#     Required Argument.\cr
#     Specifies the names of the input tbl_teradata columns that contain 
#     the time series data to be transformed.\cr
#     Types: character OR vector of Strings (character)
#   
#   time.column -
#     Optional Argument.\cr
#     Specifies the name of the input tbl_teradata column that contains the 
#     time axis of the data.\cr
#     Types: character
#   
#   window.type -
#     Optional Argument.\cr
#     Determines how much data the function processes at one time: "global" 
#     (default): The function computes the SAX code using a single mean and 
#     standard deviation for the entire data set."sliding": The function 
#     recomputes the mean and standard deviation for a sliding window of 
#     the data set.\cr
#     Default Value: "global"\cr
#     Permitted Values: sliding, global\cr
#     Types: character
#   
#   output -
#     Optional Argument.\cr
#     Determines how the function outputs the results:"string" (default): 
#     The function outputs a list of SAX codes for each window."bytes": The 
#     function outputs the list of SAX codes as compact byte arrays (which 
#     are not "human-readable")."bitmap": The function outputs a JSON 
#     representation of a SAX bitmap."characters": The function outputs one 
#     character for each line.\cr
#     Default Value: "string"\cr
#     Permitted Values: character, BITMAP, BYTES, CHARACTERS\cr
#     Types: character
#   
#   mean -
#     Optional Argument.\cr
#     Specifies the global mean values that the function uses to calculate 
#     the SAX code for every partition. A mean_value has the data type 
#     numeric. If mean specifies only one value and value.columns specifies 
#     multiple columns, then the specified value applies to every 
#     value_column. If mean specifies multiple values, then it must specify 
#     a value for each value_column. The nth mean_value corresponds to the 
#     nth value_column. Tip: To specify a different global mean value for 
#     each partition, use the multiple-input syntax and put the values in 
#     the meanstats table.\cr
#     Default Value: [null]\cr
#     Types: numeric OR vector of numerics
#   
#   st.dev -
#     Optional Argument.\cr
#     Specifies the global standard deviation values that the function uses 
#     to calculate the SAX code for every partition. A stdev_value has the 
#     data type numeric and its value must be greater than 0. If Stdev 
#     specifies only one value and value.columns specifies multiple 
#     columns, then the specified value applies to every value_column. If 
#     Stdev specifies multiple values, then it must specify a value for 
#     each value_column. The nth stdev_value corresponds to the nth 
#     value_column. Tip: To specify a different global standard deviation 
#     value for each partition, use the multiple-input syntax and put the 
#     values in the stdevstats table.\cr
#     Default Value: [null]\cr
#     Types: numeric OR vector of numerics
#   
#   window.size -
#     Optional Argument.\cr
#     Specifies the size of the sliding window. The value must be an 
#     integer greater than 0.\cr
#     Types: integer
#   
#   output.frequency -
#     Optional Argument.\cr
#     Specifies the number of data points that the window slides between 
#     successive outputs. The value must be an integer greater than 0. 
#     Note: window.type value must be "sliding" and Output value cannot be 
#     "characters". If window.type is "sliding" and Output value is 
#     "characters", then output.frequency is automatically set to the value 
#     of window.size, to ensure that a single character is assigned to each 
#     time point. If the number of data points in the time series is not an 
#     integer multiple of the window size, then the function ignores the 
#     leftover parts.\cr
#     Default Value: 1\cr
#     Types: integer
#   
#   points.persymbol -
#     Optional Argument.\cr
#     Specifies the number of data points to be converted into one SAX 
#     symbol. Each value must be an integer greater than 0. Note: 
#     window.type value must be "global".\cr
#     Default Value: [1]\cr
#     Types: integer
#   
#   symbols.perwindow -
#     Optional Argument.\cr
#     Specifies the number of SAX symbols to be generated for each window. 
#     Each value must be an integer greater than 0. The default value is 
#     the value of window.size. Note: window.type value must be 
#     "sliding".\cr
#     Types: integer
#   
#   alphabet.size -
#     Optional Argument.\cr
#     Specifies the number of symbols in the SAX alphabet. The value must 
#     be an integer in the range [2, 20]. \cr
#     Default Value: [4]\cr
#     Types: integer
#   
#   bitmap.level -
#     Optional Argument.\cr
#     Specifies the number of consecutive symbols to be converted to one 
#     symbol on a bitmap. For bitmap level 1, the bitmap contains the 
#     symbols "a", "b", "c", and so on; for bitmap level 2, the bitmap 
#     contains the symbols "aa", "ab", "ac", and so on. The input value 
#     must be an integer in the range [1, 4]. Note: Output value must be 
#     "bitmap".\cr
#     Default Value: [2]\cr
#     Types: integer
#   
#   print.stats -
#     Optional Argument.\cr
#     Specifies whether the function prints the mean and standard 
#     deviation. Note: Output value must be "string".\cr
#     Default Value: FALSE\cr
#     Types: logical
#   
#   accumulate -
#     Optional Argument.\cr
#     The names of the input tbl_teradata columns that are to appear in the 
#     output table. For each sequence in the input table, ta.sax2 choose 
#     the value corresponding to the first time point in the sequence to 
#     output as the accumulate value.\cr
#     Types: character OR vector of Strings (character)
#   
#   data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "data". The argument is used to ensure 
#     deterministic results for functions which produce results that vary 
#     from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   meanstats.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "meanstats.data". The argument is used to 
#     ensure deterministic results for functions which produce results that 
#     vary from run to run.\cr
#     Types: character OR vector of Strings (character)
#   
#   stdevstats.data.sequence.column -
#     Optional Argument.\cr
#     Specifies the vector of column(s) that uniquely identifies each row 
#     of the input argument "stdevstats.data". The argument is used to 
#     ensure deterministic results for functions which produce results that 
#     vary from run to run.\cr
#     Types: character OR vector of Strings (character)
# 
# Returns:
#   Function returns an object of class "td_sax_mle" which is a named 
#   list containing object of class "tbl_teradata".\cr
#   Named list member can be referenced directly with the "$" operator 
#   using the name: result.
# 
# 
#' @export
td_sax_mle <- function(
  data = NULL,
  data.partition.column = NULL,
  data.order.column = NULL,
  meanstats.data = NULL,
  stdevstats.data = NULL,
  value.columns = NULL,
  time.column = NULL,
  window.type = "global",
  output = "string",
  mean = NULL,
  st.dev = NULL,
  window.size = NULL,
  output.frequency = 1,
  points.persymbol = 1,
  symbols.perwindow = NULL,
  alphabet.size = 4,
  bitmap.level = 2,
  print.stats = FALSE,
  accumulate = NULL,
  data.sequence.column = NULL,
  meanstats.data.sequence.column = NULL,
  stdevstats.data.sequence.column = NULL,
  meanstats.data.partition.column = NULL,
  stdevstats.data.partition.column = NULL,
  meanstats.data.order.column = NULL,
  stdevstats.data.order.column = NULL
) {
  
  # Start the timer to get the build time
  startTime <- Sys.time()
  
  # Create argument information matrix to do parameter checking
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data, FALSE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.partition.column", data.partition.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.order.column", data.order.column, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("meanstats.data", meanstats.data, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("meanstats.data.partition.column", meanstats.data.partition.column, is.null(meanstats.data), c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("meanstats.data.order.column", meanstats.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("stdevstats.data", stdevstats.data, TRUE, c("ta.data.frame",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("stdevstats.data.partition.column", stdevstats.data.partition.column, is.null(stdevstats.data), c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("stdevstats.data.order.column", stdevstats.data.order.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("value.columns", value.columns, FALSE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("time.column", time.column, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("window.type", window.type, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("output", output, TRUE, c("character",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("mean", mean, TRUE, c("numeric","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("st.dev", st.dev, TRUE, c("numeric","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("window.size", window.size, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("output.frequency", output.frequency, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("points.persymbol", points.persymbol, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("symbols.perwindow", symbols.perwindow, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("alphabet.size", alphabet.size, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("bitmap.level", bitmap.level, TRUE, c("integer",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("print.stats", print.stats, TRUE, c("logical",NA)))
  argInfoMatrix <- rbind(argInfoMatrix, list("accumulate", accumulate, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("data.sequence.column", data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("meanstats.data.sequence.column", meanstats.data.sequence.column, TRUE, c("character","list")))
  argInfoMatrix <- rbind(argInfoMatrix, list("stdevstats.data.sequence.column", stdevstats.data.sequence.column, TRUE, c("character","list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  # meanstats.data.partition.column is reqd when meanstats.data is provided
  if(!is.null(meanstats.data) && is.null(meanstats.data.partition.column)){
    .ta.stop("TDR_E3001", paste("meanstats.data.partition.column"))
  }
  # stdevstats.data.partition.column is reqd when stdevstats.data is provided
  if(!is.null(stdevstats.data) && is.null(stdevstats.data.partition.column)){
    .ta.stop("TDR_E3001", paste("stdevstats.data.partition.column"))
  }
  
  # Make sure that a non-NULL value has been supplied for all mandatory arguments
  .validateMissingRequiredArguments(argInfoMatrix)
  
  # Make sure that a non-NULL value has been supplied correct type of argument
  .validateArgumentTypes(argInfoMatrix)
  
  # Check to make sure input table types are strings or data frame objects or of valid type.
  .validateInputTableDataType(data, NULL)
  .validateInputTableDataType(meanstats.data, NULL)
  .validateInputTableDataType(stdevstats.data, NULL)
  
  # Check for permitted values
  window.typePermittedValues <- list("SLIDING", "GLOBAL")
  .validatePermittedValues(window.type, window.typePermittedValues)
  
  outputPermittedValues <- list("STRING", "BITMAP", "BYTES", "CHARACTERS")
  .validatePermittedValues(output, outputPermittedValues)
  
  # Check whether the input columns passed to the argument are not empty.
  # Also check whether the input columns passed to the argument valid or not.
  .validateInputColumnsNotEmpty(value.columns)
  .validateTblHasArgumentColumns(value.columns, "value.columns", data, "data")
  
  .validateInputColumnsNotEmpty(time.column)
  .validateTblHasArgumentColumns(time.column, "time.column", data, "data")
  
  .validateInputColumnsNotEmpty(accumulate)
  .validateTblHasArgumentColumns(accumulate, "accumulate", data, "data")
  
  .validateInputColumnsNotEmpty(data.sequence.column)
  .validateTblHasArgumentColumns(data.sequence.column, "data.sequence.column", data, "data")
  
  .validateInputColumnsNotEmpty(meanstats.data.sequence.column)
  .validateTblHasArgumentColumns(meanstats.data.sequence.column, "meanstats.data.sequence.column", meanstats.data, "meanstats.data")
  
  .validateInputColumnsNotEmpty(stdevstats.data.sequence.column)
  .validateTblHasArgumentColumns(stdevstats.data.sequence.column, "stdevstats.data.sequence.column", stdevstats.data, "stdevstats.data")
  
  .validateInputColumnsNotEmpty(data.partition.column)
  .validateTblHasArgumentColumns(data.partition.column, "data.partition.column", data, "data")
  
  .validateInputColumnsNotEmpty(meanstats.data.partition.column)
  .validateTblHasArgumentColumns(meanstats.data.partition.column, "meanstats.data.partition.column", meanstats.data, "meanstats.data")
  
  .validateInputColumnsNotEmpty(stdevstats.data.partition.column)
  .validateTblHasArgumentColumns(stdevstats.data.partition.column, "stdevstats.data.partition.column", stdevstats.data, "stdevstats.data")
  
  .validateInputColumnsNotEmpty(data.order.column)
  .validateTblHasArgumentColumns(data.order.column, "data.order.column", data, "data")
  
  .validateInputColumnsNotEmpty(meanstats.data.order.column)
  .validateTblHasArgumentColumns(meanstats.data.order.column, "meanstats.data.order.column", meanstats.data, "meanstats.data")
  
  .validateInputColumnsNotEmpty(stdevstats.data.order.column)
  .validateTblHasArgumentColumns(stdevstats.data.order.column, "stdevstats.data.order.column", stdevstats.data, "stdevstats.data")
  
  
  # Create the arguments vector for the mapReduceObject.
  # We initilize the vector with all the mandatory args
  # and all the optional arguments to the SQLMR function invocation
  # are included only if a non-null value is supplied for the corresponding
  # argument to the user level R function.
  # Output table the arguments vector for the mapReduceObject
  funcOutputArgs <- NA
  
  # Model Cataloging related attributes.
  mc.sql.specific.attributes <- list()
  mc.target.column <- NULL
  mc.algorithm.name <- NULL
  
  # Generate lists for rest of the function arguments
  funcOtherArgSqlNames <- c()
  funcOtherArgs <- c()
  funcOtherArgJsonDatatypes <- c()
  
  funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TargetColumns")
  funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(value.columns,"\""), "'"))
  funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  
  if (!is.null(time.column)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "TimeColumn")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(time.column,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(accumulate)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Accumulate")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(.teradataQuoteArg(accumulate,"\""), "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "COLUMNS")
  }
  
  if (!is.null(window.type) && !missing(window.type)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "WindowType")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(window.type, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(output) && !missing(output)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputType")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
  }
  
  if (!is.null(mean)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "Mean")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(mean, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(st.dev)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "StDev")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(st.dev, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "DOUBLE")
  }
  
  if (!is.null(window.size)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "WindowSize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(window.size, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(output.frequency) && !missing(output.frequency)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputFrequency")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(output.frequency, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(points.persymbol) && !missing(points.persymbol)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "PointsPerSymbol")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(points.persymbol, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(symbols.perwindow)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SymbolsPerWindow")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(symbols.perwindow, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(alphabet.size) && !missing(alphabet.size)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "AlphabetSize")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(alphabet.size, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(bitmap.level) && !missing(bitmap.level)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "BitmapLevel")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(bitmap.level, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "INTEGER")
  }
  
  if (!is.null(print.stats) && !missing(print.stats)) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "OutputStats")
    funcOtherArgs <- c(funcOtherArgs, .teradataCollapseArgVector(print.stats, "'"))
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "BOOLEAN")
  }
  
  # Generate lists for rest of the function arguments
  sequenceInputByList <- c()
  if (!is.null(data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("input:", .teradataCollapseArgVector(data.sequence.column, "")))
  }
  
  if (!is.null(meanstats.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("meanstats:", .teradataCollapseArgVector(meanstats.data.sequence.column, "")))
  }
  
  if (!is.null(stdevstats.data.sequence.column)) {
    sequenceInputByList <- c(sequenceInputByList, paste0("stdevstats:", .teradataCollapseArgVector(stdevstats.data.sequence.column, "")))
  }
  
  if (length(sequenceInputByList) > 0) {
    funcOtherArgSqlNames <- c(funcOtherArgSqlNames, "SequenceInputBy")
    sequenceInputByArgValue <- .teradataCollapseArgVector(sequenceInputByList, "'")
    funcOtherArgs <- c(funcOtherArgs, sequenceInputByArgValue)
    funcOtherArgJsonDatatypes <- c(funcOtherArgJsonDatatypes, "STRING")
    mc.sql.specific.attributes[["SequenceInputBy"]] <- sequenceInputByArgValue
  }
  
  # Create a named vector for other arguments of function,
  names(funcOtherArgs) <- funcOtherArgSqlNames
  
  if (length(funcOtherArgs) == 0) {
    funcOtherArgs <- NA
  }
  
  
  # Declare empty lists to hold input table information.
  funcInputArgSqlNames <- c()
  funcInputTableViewQuery <- c()
  funcInputDataframeType <- c()
  funcInputDistribution <- c()
  funcInputPartitionByCols <- c()
  funcInputOrderByCols <- c()
  
  # Process data
  data.partition.column <- .teradataCollapseArgVector(data.partition.column, "\"")
  tableRef <- .teradataOnClauseFromDataFrame(data)
  funcInputDistribution <- c(funcInputDistribution, "FACT")
  funcInputArgSqlNames <- c(funcInputArgSqlNames, "input")
  funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
  funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
  funcInputPartitionByCols <- c(funcInputPartitionByCols, data.partition.column)
  funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(data.order.column, "\""))
  
  # Process meanstats.data
  meanstats.data.partition.column <- .teradataCollapseArgVector(meanstats.data.partition.column, "\"")
  if (!is.null(meanstats.data)) {
    tableRef <- .teradataOnClauseFromDataFrame(meanstats.data)
    funcInputDistribution <- c(funcInputDistribution, "FACT")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "meanstats")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, meanstats.data.partition.column)
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(meanstats.data.order.column, "\""))
  }
  
  # Process stdevstats.data
  stdevstats.data.partition.column <- .teradataCollapseArgVector(stdevstats.data.partition.column, "\"")
  if (!is.null(stdevstats.data)) {
    tableRef <- .teradataOnClauseFromDataFrame(stdevstats.data)
    funcInputDistribution <- c(funcInputDistribution, "FACT")
    funcInputArgSqlNames <- c(funcInputArgSqlNames, "stdevstats")
    funcInputTableViewQuery <- c(funcInputTableViewQuery, tableRef$ref)
    funcInputDataframeType <- c(funcInputDataframeType, tableRef$refType)
    funcInputPartitionByCols <- c(funcInputPartitionByCols, stdevstats.data.partition.column)
    funcInputOrderByCols <- c(funcInputOrderByCols, .teradataCollapseArgVector(stdevstats.data.order.column, "\""))
  }
  
  # create inputMatrix which will be used by .TeradataSqlmrQueryGenerator$new
  funcInputPartitionByCols <- type.convert(funcInputPartitionByCols, na.strings = "NA_character_", as.is = TRUE)
  funcInputOrderByCols <- type.convert(funcInputOrderByCols, na.strings = "NA_character_", as.is = TRUE)
  inputTableRefMatrix <- cbind(funcInputTableViewQuery, funcInputDataframeType, funcInputDistribution, funcInputPartitionByCols, funcInputOrderByCols, funcInputArgSqlNames)
  
  # Add column names to the matrix
  colnames(inputTableRefMatrix) <- c("tableRef", "tableRefType", "distribution", "column",
    "column_order", "alias")
  
  # create mapReduceObject
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "SAX2",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcOutputArgs,
    inputTableRefMatrix = inputTableRefMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML")
  )
  
  # Set the algorithm name for Model Cataloging.
  mc.algorithm.name <- .getAliasNameForFunction("SAX2", engine = .getEngineName("ENGINE_ML"), call.from.wrapper = TRUE)
  
  # Get the SQL code and print it if requested
  sqlmrQuery  <-  mapReduceObject$genSqlmrSelectStmtSql()
  .printSqlmrQuery(sqlmrQuery)
  
  # Check whether input has tbl object or not, based on the reference, we will return dataset.
  is_dplyr_input <- .hasTblInput(data, meanstats.data, stdevstats.data)
  
  # Return output table data frames.
  result <- list()
  result[["result"]] <- .createDataSetObject(sqlmrQuery, sourceType = "query", is_dplyr_input = is_dplyr_input)
  
  
  if (class(result) == "list" && length(result) == 1) {
    attr(result, "class") <- .getSQLMRClass("td_sax_mle", engine = .getEngineName("ENGINE_ML"))
  }
  
  result[["attributes"]] <- .ta.populateModelAttributes(as.list(match.call()))
  
  # Get the prediction type
  mc.prediction.type <- .getFunctionPredictionType(result)
  
  attr(result, "mc.prediction.type") <- mc.prediction.type
  attr(result, "mc.target.column") <- mc.target.column
  attr(result, "mc.sql.specific.attributes") <- mc.sql.specific.attributes
  attr(result, "mc.algorithm.name") <- mc.algorithm.name
  
  # End the timer to get the build time
  endTime <- Sys.time()
  
  
  # Calculate the build time
  mc.build.time <- as.integer(as.numeric(endTime - startTime, units="secs"))
  
  attr(result, "mc.build.time") <- mc.build.time
  return(result)
  
}
#' @export
td_sax <- td_sax_mle
