context("Unit tests for garbage collection related functions")


testInitSessionMetadata <- function() {
  .assign(".session_temp__objects__", as.environment(list(df = data.frame(stringsAsFactors=FALSE))))
  .assign(".temp_operations_count__", 0)
  options("td.tmpobject.sync.threshold" = 1)
}
testQuote <- function(obj) {
  q <- "\""
  paste0(q,obj,q)
}

tmpObjectsFile <- NULL
restoreBackup <- FALSE
suffix <- "__RTEST_BAK__"
backupFile <- NULL

testthat::setup(
  {
    # Take a backup of the session file if it exists and restore at the end of the test
    tmpObjectsFile <<- .ta.getSessionObjectsFileName(.ta.getSessionObjectsDirectory())
    if (file.exists(tmpObjectsFile)) {
      backupFile <<- paste0(tmpObjectsFile,suffix)
      #try to remove the backup file just in case it was present
      if (file.exists(backupFile))
        file.remove(backupFile)
      # we expect that unit test must have permission to rename this file
      restoreBackup <<- file.rename(tmpObjectsFile,backupFile)
      expect_true(restoreBackup)
    }
  }
)

test_that("session file created without errors or warnings", {
  #throws no error and warning
  expect_true(expect_warning(.ta.initSessionDataFile(), regexp = NA))
})

test_that("add / remove one object", {
  testInitSessionMetadata()

  expect_true(.ta.addTempObject("test_db.table1","table"))
  tmpObjects <- .get(".session_temp__objects__")
  expect_equal(nrow(tmpObjects$df), 1)
  expect_equal(tmpObjects$df[1,1], "test_db.table1")
  expect_equal(tmpObjects$df[1,2], "table")
  # The count should have been reset
  expect_equal(.get(".temp_operations_count__"),0)
  
  # check the file that we should have objects
  sessionFile <- .get(".session_temp_objects_file__")
  loadedSession <- .ta.loadObjectsFromFile(sessionFile)
  expect_type(loadedSession,"list")
  expect_equal(nrow(loadedSession),1)
  expect_equal(loadedSession[1,1], "test_db.table1")
  expect_equal(loadedSession[1,2], "table")
  
  # now remove the object
  expect_true(.ta.removeTempObject("test_db.table1","table"))
  expect_equal(nrow(tmpObjects$df), 0)
  expect_equal(.get(".temp_operations_count__"),0)
  # check the session file should be empty
  loadedSession <- .ta.loadObjectsFromFile(sessionFile)
  expect_null(loadedSession)

  # Try to remove an invalid object
  expect_false(.ta.removeTempObject("INVALID", "table"))
  expect_equal(nrow(tmpObjects$df), 0)
  expect_equal(.get(".temp_operations_count__"),0)
})

test_that("add / remove does not error on invalid object name", {
  testInitSessionMetadata()
  expect_false(.ta.addTempObject(NULL,"table"))
  tmpObjects <- .get(".session_temp__objects__")
  expect_equal(nrow(tmpObjects$df), 0)
  expect_false(.ta.addTempObject(NA,"table"))
  expect_equal(nrow(tmpObjects$df), 0)
  # add couple of empty strings
  expect_true(.ta.addTempObject("","table"))
  expect_equal(nrow(tmpObjects$df), 1)
  expect_true(.ta.addTempObject("","table"))
  expect_equal(nrow(tmpObjects$df), 2)
  # add a valid object
  expect_true(.ta.addTempObject("table1","table"))
  expect_equal(nrow(tmpObjects$df), 3)
  # add with invalid TYPEs
  # This should still add
  expect_true(.ta.addTempObject("table1","INVALID"))
  expect_equal(nrow(tmpObjects$df), 4)
  # NA and Null should not add
  expect_false(.ta.addTempObject("table1",NULL))
  expect_equal(nrow(tmpObjects$df), 4)
  expect_false(.ta.addTempObject("table1",NA))
  expect_equal(nrow(tmpObjects$df), 4)
  # Add with empty type
  expect_true(.ta.addTempObject("table1",""))
  expect_equal(nrow(tmpObjects$df), 5)
  # Add with both empty name empty type
  expect_true(.ta.addTempObject("",""))
  expect_true(.ta.addTempObject("",""))
  expect_equal(nrow(tmpObjects$df), 7)

  # remove objects in random order
  # this will remove two empty named objects
  expect_true(.ta.removeTempObject("","table"))
  expect_equal(nrow(tmpObjects$df), 5)
  # remove the valid object
  expect_true(.ta.removeTempObject("table1","table"))
  expect_equal(nrow(tmpObjects$df), 4)
  # remove invalid type object
  expect_true(.ta.removeTempObject("table1","invalid"))
  expect_equal(nrow(tmpObjects$df), 3)
  # remove 2 empty name and type object
  expect_true(.ta.removeTempObject("",""))
  expect_equal(nrow(tmpObjects$df), 1)
  # remove empty type object
  expect_true(.ta.removeTempObject("table1",""))
  expect_equal(nrow(tmpObjects$df), 0)

})

test_that("add / remove multiple objects", {
  testInitSessionMetadata()
  tmpObjects <- .get(".session_temp__objects__")
  # Add 4 objects
  expect_true(.ta.addTempObject("\"test_db\".\"table1\"","table"))
  # Add objects with quotes
  expect_true(.ta.addTempObject(testQuote("table1"),"table"))
  expect_true(.ta.addTempObject(testQuote("view1"),"view"))
  # Add with same name but as different type
  expect_true(.ta.addTempObject(testQuote("view1"), "table"))
  expect_equal(nrow(tmpObjects$df), 4)
  expect_equal(tmpObjects$df[1,1], "\"test_db\".\"table1\"")
  expect_equal(tmpObjects$df[1,2], "table")
  expect_equal(tmpObjects$df[2,1], testQuote("table1"))
  expect_equal(tmpObjects$df[2,2], "table")
  expect_equal(tmpObjects$df[3,1], testQuote("view1"))
  expect_equal(tmpObjects$df[3,2], "view")
  expect_equal(tmpObjects$df[4,1], testQuote("view1"))
  expect_equal(tmpObjects$df[4,2], "table")

  # check the file that we should have objects
  sessionFile <- .get(".session_temp_objects_file__")
  loadedSession <- .ta.loadObjectsFromFile(sessionFile)
  expect_type(loadedSession,"list")
  expect_equal(nrow(loadedSession),4)
  expect_equal(loadedSession[1,1], "\"test_db\".\"table1\"")
  expect_equal(loadedSession[1,2], "table")
  expect_equal(loadedSession[2,1], testQuote("table1"))
  expect_equal(loadedSession[2,2], "table")
  expect_equal(loadedSession[3,1], testQuote("view1"))
  expect_equal(loadedSession[3,2], "view")
  expect_equal(loadedSession[4,1], testQuote("view1"))
  expect_equal(loadedSession[4,2], "table")

  #remove one object
  expect_true(.ta.removeTempObject(testQuote("table1"), "table"))
  expect_equal(nrow(tmpObjects$df), 3)
  #remove invalid objects
  expect_false(.ta.removeTempObject("INVALID", "table"))
  expect_equal(nrow(tmpObjects$df), 3)

  #remove already removed object
  expect_false(.ta.removeTempObject(testQuote("table1"), "table"))
  expect_equal(nrow(tmpObjects$df), 3)

  loadedSession <- .ta.loadObjectsFromFile(sessionFile)
  expect_type(loadedSession,"list")
  expect_equal(nrow(loadedSession),3)
  #Add one more object
  expect_true(.ta.addTempObject("db2.table3","table"))
  expect_equal(nrow(tmpObjects$df), 4)

  loadedSession <- .ta.loadObjectsFromFile(sessionFile)
  expect_type(loadedSession,"list")
  expect_equal(nrow(loadedSession),4)

  #remove object with same name but different type
  expect_true(.ta.removeTempObject(testQuote("view1"), "view"))

  # check the file that we should have objects
  loadedSession <- .ta.loadObjectsFromFile(sessionFile)
  expect_type(loadedSession,"list")
  expect_equal(nrow(loadedSession),3)
  expect_equal(loadedSession[1,1], "\"test_db\".\"table1\"")
  expect_equal(loadedSession[1,2], "table")
  expect_equal(loadedSession[2,1], testQuote("view1"))
  expect_equal(loadedSession[2,2], "table")
  expect_equal(loadedSession[3,1], "db2.table3")
  expect_equal(loadedSession[3,2], "table")

  #remove all objects in different order
  expect_true(.ta.removeTempObject("db2.table3", "table"))
  expect_equal(nrow(tmpObjects$df), 2)
  loadedSession <- .ta.loadObjectsFromFile(sessionFile)
  expect_type(loadedSession,"list")
  expect_equal(nrow(loadedSession),2)

  expect_true(.ta.removeTempObject("\"test_db\".\"table1\"","table"))
  expect_equal(nrow(tmpObjects$df), 1)
  loadedSession <- .ta.loadObjectsFromFile(sessionFile)
  expect_type(loadedSession,"list")
  expect_equal(nrow(loadedSession),1)
  expect_equal(loadedSession[1,1], testQuote("view1"))
  expect_equal(loadedSession[1,2], "table")

  expect_true(.ta.removeTempObject(testQuote("view1"), "table"))
  expect_equal(nrow(tmpObjects$df), 0)
  loadedSession <- .ta.loadObjectsFromFile(sessionFile)
  expect_null(loadedSession,"list")
})

test_that("works with different threshold", {
  testInitSessionMetadata()
  #set threshold to 2
  options("td.tmpobject.sync.threshold" = 2)
  tmpObjects <- .get(".session_temp__objects__")

  # this should not get persisted since threshold is 2
  expect_false(.ta.addTempObject("test_db.table1","table"))
  expect_equal(nrow(tmpObjects$df), 1)
  expect_equal(tmpObjects$df[1,1], "test_db.table1")
  expect_equal(tmpObjects$df[1,2], "table")
  expect_equal(.get(".temp_operations_count__"),1)
  sessionFile <- .get(".session_temp_objects_file__")
  loadedSession <- .ta.loadObjectsFromFile(sessionFile)
  expect_null(loadedSession)


  # also testing with same name and type
  expect_true(.ta.addTempObject("test_db.table1","table"))
  expect_equal(nrow(tmpObjects$df), 2)
  expect_equal(tmpObjects$df[1,1], "test_db.table1")
  expect_equal(tmpObjects$df[1,2], "table")
  expect_equal(tmpObjects$df[2,1], "test_db.table1")
  expect_equal(tmpObjects$df[2,2], "table")
  # The count should have been reset
  expect_equal(.get(".temp_operations_count__"),0)
  
  loadedSession <- .ta.loadObjectsFromFile(sessionFile)
  expect_equal(nrow(loadedSession),2)
  expect_equal(loadedSession[1,1], "test_db.table1")
  expect_equal(loadedSession[1,2], "table")
  expect_equal(loadedSession[2,1], "test_db.table1")
  expect_equal(loadedSession[2,2], "table")
  
  #remove both objects with one command since they are the same
  expect_true(.ta.removeTempObject("test_db.table1", "table"))
  loadedSession <- .ta.loadObjectsFromFile(sessionFile)
  expect_null(loadedSession)
  # set back to 1
  options("td.tmpobject.sync.threshold" = 1)
})

test_that("load session can handle if session objects already exists", {
  testInitSessionMetadata()
  tmpObjects <- .get(".session_temp__objects__")
  # Add 2 objects
  expect_true(.ta.addTempObject("test_db.table1","table"))
  expect_true(.ta.addTempObject("table1","table"))
  # create a new data frame and add two entries
  tmpObjects$df <- data.frame(stringsAsFactors = FALSE)
  tmpObjects$df[1,1] <- "table1"
  tmpObjects$df[1,2] <- "table"
  # write extra entries and dont persist
  tmpObjects$df[2,1] <- "extraTable"
  tmpObjects$df[2,2] <- "table"
  #load the session
  .ta.loadSession()
  # check if the extra entry has been merged
  expect_equal(nrow(tmpObjects$df), 3)
  expect_equal(tmpObjects$df[1,1], "table1")
  expect_equal(tmpObjects$df[1,2], "table")
  expect_equal(tmpObjects$df[2,1], "extraTable")
  expect_equal(tmpObjects$df[2,2], "table")
  expect_equal(tmpObjects$df[3,1], "test_db.table1")
  expect_equal(tmpObjects$df[3,2], "table")

  #persist and load again and check
  .ta.persistSession()
  .ta.loadSession()

  expect_equal(nrow(tmpObjects$df), 3)
  expect_equal(tmpObjects$df[1,1], "table1")
  expect_equal(tmpObjects$df[1,2], "table")
  expect_equal(tmpObjects$df[2,1], "extraTable")
  expect_equal(tmpObjects$df[2,2], "table")
  expect_equal(tmpObjects$df[3,1], "test_db.table1")
  expect_equal(tmpObjects$df[3,2], "table")

  expect_true(.ta.removeTempObject("test_db.table1","table"))
  expect_true(.ta.removeTempObject("table1","table"))
  expect_true(.ta.removeTempObject("extraTable","table"))
  expect_equal(nrow(.get(".session_temp__objects__")$df), 0)

  sessionFile <- .get(".session_temp_objects_file__")
  loadedSession <- .ta.loadObjectsFromFile(sessionFile)
  expect_null(loadedSession)
})

# Adding a unit-test to verify if the way we get user name always works
test_that("Get User name works on the corresponding platform",  {
  user <- toupper(Sys.getenv("USER"))
  uname <- toupper(Sys.getenv("USERNAME"))
  if (nchar(user) > 0)
    expect_equal(.ta.getUserName(), user)
  else if (nchar(uname) > 0)
    expect_equal(.ta.getUserName(), uname)
  else
    fail("Neither USER nor USERNAME is set in the environment")
  })

testthat::teardown(
  {
    #reset the package variables
    testInitSessionMetadata()
    #restore the backup if it was reated
    if (restoreBackup)
      file.rename(backupFile, tmpObjectsFile)
  }
)
