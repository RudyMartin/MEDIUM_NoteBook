context("tests for dplyr joins")

cleanup <- function() {
  for( i in 1:6){
    tryCatch({
      DBI::dbExecute(con, paste0("drop table t",i))
    }, error=function(e) { 
      # DO Nothing
    })
  }
}
con <- NULL
testthat::setup({
  if(globalDTYPE == "odbc"){
    con <<- suppressWarnings(td_create_context(dsn = dsnName))
  } else {
    con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD))
  }
  
  #cleaning data base if tables are already exists.
  cleanup()
})

test_that("joins with same column in two different tables", {
  df1 <- data.frame(a = c(1,2,3,4,5,6), b = c('a','b','c','d','e','f'))
  df2 <- data.frame(a = c(1,2,3,7,8,9), b = c('a','b','c','g','h','i'))
  
  t1 <- copy_to(con,df1,"t1")
  t2 <- copy_to(con,df2,"t2")
  #inner join
  result <- as.data.frame(dplyr::inner_join(t1,t2,by = "a",suffix = c(".df1", ".df2")))
  expect_true(unique(result$a %in% c(1,2,3)))
  expect_true(unique(result$b.df1 %in% c('a','b','c')))
  expect_true(unique(result$b.df2 %in% c('a','b','c')))
  
    #full join
  result <- as.data.frame(dplyr::full_join(t1,t2,by = "a",suffix = c(".df1", ".df2")))
  expect_true(unique(result$a %in% c(1,2,3,4,5,6,7,8,9)))
  expect_true(unique(result$b.df1 %in% c('a','b','c','d','e','f',NA)))
  expect_true(unique(result$b.df2 %in% c('a','b','c','g','h','i',NA)))
  
  #left join
  result <- as.data.frame(dplyr::left_join(t1,t2,by = "a",suffix = c(".df1", ".df2")))
  expect_true(unique(result$a %in% c(1,2,3,4,5,6)))
  expect_true(unique(result$b.df1 %in% c('a','b','c','d','e','f')))
  expect_true(unique(result$b.df2 %in% c('a','b','c',NA)))
  
  #right join
  result <- as.data.frame(dplyr::right_join(t1,t2,by = "a",suffix = c(".df1", ".df2")))
  expect_true(unique(result$a %in% c(1,2,3,7,8,9)))
  expect_true(unique(result$b.df1 %in% c('a','b','c',NA)))
  expect_true(unique(result$b.df2 %in% c('a','b','c','g','h','i')))
  
  #semi join
  result <- as.data.frame(dplyr::semi_join(t1,t2,by = "a"))
  expect_true(unique(result$a %in% c(1,2,3)))
  expect_true(unique(result$b %in% c('a','b','c')))
  
  #anti join
  result <- as.data.frame(dplyr::anti_join(t1,t2,by = "a"))
  expect_true(unique(result$a %in% c(4,5,6)))
  expect_true(unique(result$b %in% c('d','e','f')))
})

test_that("joins with multiple same columns in two different tables", {
  df1 <- data.frame(a = c(1,2,3,4,5,6), b = c('a','b','a','d','e','f'),c = c(10,20,30,40,50,60))
  df2 <- data.frame(a = c(1,2,3,7,8,9), b = c('a','b','c','g','h','i'), c = c(15,25,35,45,55,65))
  
  t1 <- copy_to(con,df1,"t5")
  t2 <- copy_to(con,df2,"t6")
  #inner join
  result <- as.data.frame(dplyr::inner_join(t1,t2,by = c("a","b"),suffix = c(".df1", ".df2")))
  expect_true(unique(result$a %in% c(1,2)))
  expect_true(unique(result$b %in% c('a','b')))
  expect_true(unique(result$c.df1 %in% c(10,20)))
  expect_true(unique(result$c.df2 %in% c(15,25)))
  
  #full join
  result <- as.data.frame(dplyr::full_join(t1,t2,by = c("a","b"),suffix = c(".df1", ".df2")))
  expect_true(unique(result$a %in% c(1,2,3,4,5,6,7,8,9)))
  expect_true(unique(result$b %in% c('a','b','c','d','e','f','g','h','i')))
  expect_true(unique(result$c.df1 %in% c(10,20,30,40,50,60,NA)))
  expect_true(unique(result$c.df2 %in% c(15,25,35,45,55,65,NA)))
  
  #left join
  result <- as.data.frame(dplyr::left_join(t1,t2,by = c("a","b"),suffix = c(".df1", ".df2")))
  expect_true(unique(result$a %in% c(1,2,3,4,5,6)))
  expect_true(unique(result$b %in% c('a','b','c','d','e','f')))
  expect_true(unique(result$c.df1 %in% c(10,20,30,40,50,60)))
  expect_true(unique(result$c.df2 %in% c(15,25,NA)))
  
  #right join
  result <- as.data.frame(dplyr::right_join(t1,t2,by = c("a","b"),suffix = c(".df1", ".df2")))
  expect_true(unique(result$a %in% c(1,2,3,7,8,9)))
  expect_true(unique(result$b %in% c('a','b','c','g','h','i')))
  expect_true(unique(result$c.df1 %in% c(10,20,NA)))
  expect_true(unique(result$c.df2 %in% c(15,25,35,45,55,65)))
  
  #semi join
  result <- as.data.frame(dplyr::semi_join(t1,t2,by = c("a","b")))
  expect_true(unique(result$a %in% c(1,2)))
  expect_true(unique(result$b %in% c('a','b')))
  expect_true(unique(result$c %in% c(10,20)))
  
  #anti join
  result <- as.data.frame(dplyr::anti_join(t1,t2,by = c("a","b")))
  expect_true(unique(result$a %in% c(3,4,5,6)))
  expect_true(unique(result$b %in% c('a','d','e','f')))
  expect_true(unique(result$c %in% c(30,40,50,60)))
})

test_that("joins with different column in two different tables", {
  df1 <- data.frame(df1_a = c(1,2,3,4,5,6), df1_b = c('a','b','c','d','e','f'))
  df2 <- data.frame(df2_a = c(1,2,3,7,8,9), df2_b = c('a','b','c','g','h','i'))
  
  t1 <- copy_to(con,df1,"t3")
  t2 <- copy_to(con,df2,"t4")
  #inner join
  result <- as.data.frame(dplyr::inner_join(t1,t2,by = c("df1_a" = "df2_a")))
  expect_true(unique(result$df1_a %in% c(1,2,3)))
  expect_true(unique(result$df1_b %in% c('a','b','c')))
  expect_true(unique(result$df2_b %in% c('a','b','c')))
  
  #full join
  result <- as.data.frame(dplyr::full_join(t1,t2,by = c("df1_a" = "df2_a")))
  expect_true(unique(result$df1_a %in% c(1,2,3,4,5,6,7,8,9)))
  expect_true(unique(result$df1_b %in% c('a','b','c','d','e','f',NA)))
  expect_true(unique(result$df2_b %in% c('a','b','c','g','h','i',NA)))
  
  #left join
  result <- as.data.frame(dplyr::left_join(t1,t2,by = c("df1_a" = "df2_a")))
  expect_true(unique(result$df1_a %in% c(1,2,3,4,5,6)))
  expect_true(unique(result$df1_b %in% c('a','b','c','d','e','f')))
  expect_true(unique(result$df2_b %in% c('a','b','c',NA)))
  
  #right join
  result <- as.data.frame(dplyr::right_join(t1,t2,by = c("df1_a" = "df2_a")))
  expect_true(unique(result$df1_a %in% c(1,2,3,7,8,9)))
  expect_true(unique(result$df1_b %in% c('a','b','c',NA)))
  expect_true(unique(result$df2_b %in% c('a','b','c','g','h','i')))
  
  #semi join
  result <- as.data.frame(dplyr::semi_join(t1,t2,by = c("df1_a" = "df2_a")))
  expect_true(unique(result$df1_a %in% c(1,2,3)))
  expect_true(unique(result$df1_b %in% c('a','b','c')))
  
  #anti join
  result <- as.data.frame(dplyr::anti_join(t1,t2,by = c("df1_a" = "df2_a")))
  expect_true(unique(result$df1_a %in% c(4,5,6)))
  expect_true(unique(result$df1_b %in% c('d','e','f')))
})

test_that("joins with filters", {
  
  t1 <- tbl(con,"t3")
  t2 <- tbl(con,"t4")
  #inner join
  result <- dplyr::filter(t1,df1_a < 3) %>% dplyr::inner_join(t2,by = c("df1_a" = "df2_a"))
  result <- as.data.frame(result)
  
  expect_true(unique(result$df1_a %in% c(1,2)))
  expect_true(unique(result$df1_b %in% c('a','b')))
  expect_true(unique(result$df2_b %in% c('a','b')))
  
  #full join
  result <- dplyr::filter(t1,df1_a < 3)  %>% dplyr::full_join(t2,by = c("df1_a" = "df2_a"))
  result <- as.data.frame(result)
  
  expect_true(unique(result$df1_a %in% c(1,2,3,7,8,9)))
  expect_true(unique(result$df1_b %in% c('a','b',NA)))
  expect_true(unique(result$df2_b %in% c('a','b','c','g','h','i')))
  
  #left join
  result <- dplyr::filter(t1,df1_a < 3)  %>% dplyr::left_join(t2,by = c("df1_a" = "df2_a"))
  result <- as.data.frame(result)
  
  expect_true(unique(result$df1_a %in% c(1,2)))
  expect_true(unique(result$df1_b %in% c('a','b')))
  expect_true(unique(result$df2_b %in% c('a','b')))
  
  #right join
  result <- dplyr::filter(t1,df1_a < 3)  %>% dplyr::right_join(t2,by = c("df1_a" = "df2_a"))
  result <- as.data.frame(result)
  
  expect_true(unique(result$df1_a %in% c(1,2,3,7,8,9)))
  expect_true(unique(result$df1_b %in% c('a','b',NA)))
  expect_true(unique(result$df2_b %in% c('a','b','c','g','h','i')))
  
  #semi join
  result <- dplyr::filter(t1,df1_a < 3)  %>% dplyr::semi_join(t2,by = c("df1_a" = "df2_a"))
  result <- as.data.frame(result)
  
  expect_true(unique(result$df1_a %in% c(1,2)))
  expect_true(unique(result$df1_b %in% c('a','b')))
  
  #anti join
  result <- dplyr::filter(t1,df1_a < 3)  %>% dplyr::anti_join(t2,by = c("df1_a" = "df2_a"))
  result <- as.data.frame(result)
  
  expect_true(length(result$a) == 0)
  expect_true(length(result$b) == 0)
})

test_that("joins with mutate", {
  
  df1 <- data.frame(df1_a = c(1,2,3,4,5,6), df1_b = c('a','b','c','d','e','f'))
  df2 <- data.frame(df2_a = c(1,2,3,7,8,9), df2_b = c('a','b','c','g','h','i'))
  
  t1 <- tbl(con,"t3") %>% dplyr::mutate(df1_a1 = df1_a * 2)
  t2 <- tbl(con,"t4") %>% dplyr::mutate(df2_a1 = df2_a * 2)
  
  #inner join
  result <- dplyr::inner_join(t1, t2,by = c("df1_a1" = "df2_a1")) %>% as.data.frame()
  
  expect_true(unique(result$df1_a %in% c(1,2,3)))
  expect_true(unique(result$df1_a1 %in% c(2,4,6)))
  expect_true(unique(result$df1_b %in% c('a','b','c')))
  expect_true(unique(result$df2_a %in% c(1,2,3)))
  expect_true(unique(result$df2_b %in% c('a','b','c')))
  
  
  #full join
  result <- dplyr::full_join(t1,t2,by = c("df1_a1" = "df2_a1")) %>% as.data.frame()
  expect_true(unique(result$df1_a %in% c(1,2,3,4,5,6,NA)))
  expect_true(unique(result$df1_a1 %in% c(2,4,6,8,10,12,14,16,18)))
  expect_true(unique(result$df1_b %in% c('a','b','c','d','e','f',NA)))
  expect_true(unique(result$df2_a %in% c(1,2,3,7,8,9,NA)))
  expect_true(unique(result$df2_b %in% c('a','b','c','g','h','i',NA)))
  
  #left join
  result <- dplyr::left_join(t1,t2,by =  c("df1_a1" = "df2_a1")) %>% as.data.frame()
  expect_true(unique(result$df1_a %in% c(1,2,3,4,5,6)))
  expect_true(unique(result$df1_a1 %in% c(2,4,6,8,10,12)))
  expect_true(unique(result$df1_b %in% c('a','b','c','d','e','f')))
  expect_true(unique(result$df2_a %in% c(1,2,3,NA)))
  expect_true(unique(result$df2_b %in% c('a','b','c',NA)))
  
  #right join
  result <- dplyr::right_join(t1,t2,by = c("df1_a1" = "df2_a1"))  %>% as.data.frame()
  
  expect_true(unique(result$df1_a %in% c(1,2,3,NA)))
  expect_true(unique(result$df1_a1 %in% c(2,4,6,14,16,18)))
  expect_true(unique(result$df1_b %in% c('a','b','c',NA)))
  expect_true(unique(result$df2_a %in% c(1,2,3,7,8,9)))
  expect_true(unique(result$df2_b %in% c('a','b','c','g','h','i')))
  
  #semi join
  result <- dplyr::semi_join(t1,t2,by = c("df1_a1" = "df2_a1")) %>% as.data.frame()
  
  expect_true(unique(result$df1_a %in% c(1,2,3)))
  expect_true(unique(result$df1_a1 %in% c(2,4,6)))
  expect_true(unique(result$df1_b %in% c('a','b','c')))
  
  #anti join
  result <- dplyr::anti_join(t1, t2,by = c("df1_a1" = "df2_a1")) %>% as.data.frame()
  
  expect_true(unique(result$df1_a %in% c(4,5,6)))
  expect_true(unique(result$df1_a1 %in% c(8,10,12)))
  expect_true(unique(result$df1_b %in% c('d','e','f')))
})

testthat::teardown(
  {
    cleanup()
    td_remove_context()
  })