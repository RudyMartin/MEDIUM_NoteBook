context("Unit tests for functions in summarise")

.replace_column_name <- function(columns, to_be_replaced, replaced_with) {
  new_cols <-  unlist(lapply(columns, function(x) {
                gsub(to_be_replaced, replaced_with, x, fixed = TRUE)
              }))
  return(new_cols)
}

con <- NULL
seq_group1 <- NULL
testthat::setup({
  if(globalDTYPE == "odbc"){
    con <<- suppressWarnings(td_create_context(dsn = dsnName))
  } else {
    con <<- suppressWarnings(td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD))
  }

  # Loading necessary tables and creating required tbl_teradata objects.
  loadExampleData("time_series_example", "ocean_buoys_seq")
  df <- tbl(con, "ocean_buoys_seq")
  df1 <- df %>% mutate("new temp_var" = temperature)
  seq_group1 <<- df1 %>% group_by_time(timebucket.duration = "30m", timecode.column = "TD_TIMECODE")
})


context("Unit tests for the function `.get_column_names_summarise`")


test_that("Without using \"value.expression =\"", {
  ## With the use of distinct()
  expected_columns <- c("Maximum(Distinct(temperature))", 
                        "Minimum(Distinct(temperature))", 
                        "Average(Distinct(temperature))", 
                        "STDDEV_SAMP(Distinct(temperature))",
                        "MEDIAN(Distinct(temperature))",
                        "MODE(temperature)",
                        "PERCENTILE(Distinct(temperature, 25, LINEAR))",
                        "PERCENTILE(Distinct(temperature, 50, LINEAR))",
                        "PERCENTILE(Distinct(temperature, 75, LINEAR))")
  qq <- list()
  
  # With quotes to column name
  qq[["desc_temp"]] <- quo(ts.describe(distinct("temperature")))
  expect_equal(.get_column_names_summarise(qq), expected_columns)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe(distinct("temperature")))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", expected_columns), colnames(df2))
  
  # Without quotes to column name
  qq[["desc_temp"]] <- quo(ts.describe(distinct(temperature)))
  expect_equal(.get_column_names_summarise(qq), expected_columns)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe(distinct(temperature)))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", expected_columns), colnames(df2))
  
  # Using column name with spaces
  qq[["desc_temp"]] <- quo(ts.describe(distinct(`new temp_var`)))
  replaced_cols <- .replace_column_name(expected_columns, "temperature", "new temp_var")
  expect_equal(.get_column_names_summarise(qq), replaced_cols)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe(distinct(`new temp_var`)))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", replaced_cols), colnames(df2))
  
  ## Without the use of distinct()
  expected_columns <- c("Maximum(temperature)", 
                        "Minimum(temperature)", 
                        "Average(temperature)", 
                        "STDDEV_SAMP(temperature)",
                        "MEDIAN(temperature)",
                        "MODE(temperature)",
                        "PERCENTILE(temperature, 25, LINEAR)",
                        "PERCENTILE(temperature, 50, LINEAR)",
                        "PERCENTILE(temperature, 75, LINEAR)")
  
  # With quotes to column name
  qq[["desc_temp"]] <- quo(ts.describe("temperature"))
  expect_equal(.get_column_names_summarise(qq), expected_columns)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe("temperature"))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", expected_columns), colnames(df2))
  
  # Without quotes to column name
  qq[["desc_temp"]] <- quo(ts.describe(temperature))
  expect_equal(.get_column_names_summarise(qq), expected_columns)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe("temperature"))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", expected_columns), colnames(df2))
  
  # Using column name with spaces
  qq[["desc_temp"]] <- quo(ts.describe(`new temp_var`))
  replaced_cols <- .replace_column_name(expected_columns, "temperature", "new temp_var")
  expect_equal(.get_column_names_summarise(qq), replaced_cols)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe(`new temp_var`))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", replaced_cols), colnames(df2))
})


test_that("With using \"value.expression =\"", {
  ## With the use of distinct()
  expected_columns <- c("Maximum(Distinct(temperature))", 
                        "Minimum(Distinct(temperature))", 
                        "Average(Distinct(temperature))", 
                        "STDDEV_SAMP(Distinct(temperature))",
                        "MEDIAN(Distinct(temperature))",
                        "MODE(temperature)",
                        "PERCENTILE(Distinct(temperature, 25, LINEAR))",
                        "PERCENTILE(Distinct(temperature, 50, LINEAR))",
                        "PERCENTILE(Distinct(temperature, 75, LINEAR))")
  qq <- list()
  
  # With quotes to column name
  qq[["desc_temp"]] <- quo(ts.describe(value.expression = distinct("temperature")))
  expect_equal(.get_column_names_summarise(qq), expected_columns)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe(distinct("temperature")))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", expected_columns), colnames(df2))
  
  # Without quotes to column name
  qq[["desc_temp"]] <- quo(ts.describe(value.expression = distinct(temperature)))
  expect_equal(.get_column_names_summarise(qq), expected_columns)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe(distinct(temperature)))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", expected_columns), colnames(df2))
  
  # Using column name with spaces
  qq[["desc_temp"]] <- quo(ts.describe(value.expression = distinct(`new temp_var`)))
  replaced_cols <- .replace_column_name(expected_columns, "temperature", "new temp_var")
  expect_equal(.get_column_names_summarise(qq), replaced_cols)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe(distinct(`new temp_var`)))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", replaced_cols), colnames(df2))
  
  ## Without the use of distinct()
  expected_columns <- c("Maximum(temperature)", 
                        "Minimum(temperature)", 
                        "Average(temperature)", 
                        "STDDEV_SAMP(temperature)",
                        "MEDIAN(temperature)",
                        "MODE(temperature)",
                        "PERCENTILE(temperature, 25, LINEAR)",
                        "PERCENTILE(temperature, 50, LINEAR)",
                        "PERCENTILE(temperature, 75, LINEAR)")
  
  # With quotes to column name
  qq[["desc_temp"]] <- quo(ts.describe(value.expression = "temperature"))
  expect_equal(.get_column_names_summarise(qq), expected_columns)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe("temperature"))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", expected_columns), colnames(df2))
  
  # Without quotes to column name
  qq[["desc_temp"]] <- quo(ts.describe(value.expression = temperature))
  expect_equal(.get_column_names_summarise(qq), expected_columns)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe(temperature))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", expected_columns), colnames(df2))
  
  # Using column name with spaces
  qq[["desc_temp"]] <- quo(ts.describe(value.expression = `new temp_var`))
  replaced_cols <- .replace_column_name(expected_columns, "temperature", "new temp_var")
  expect_equal(.get_column_names_summarise(qq), replaced_cols)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe(`new temp_var`))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", replaced_cols), colnames(df2))
})


test_that("With using sql()", {
  ## With the use of distinct()
  expected_columns <- c("Maximum(Distinct(temperature))", 
                        "Minimum(Distinct(temperature))", 
                        "Average(Distinct(temperature))", 
                        "STDDEV_SAMP(Distinct(temperature))",
                        "MEDIAN(Distinct(temperature))",
                        "MODE(temperature)",
                        "PERCENTILE(Distinct(temperature, 25, LINEAR))",
                        "PERCENTILE(Distinct(temperature, 50, LINEAR))",
                        "PERCENTILE(Distinct(temperature, 75, LINEAR))")
  qq <- list()
  
  # With quotes to column name
  qq[["desc_temp"]] <- quo(ts.describe(distinct(sql("temperature"))))
  expect_equal(.get_column_names_summarise(qq), expected_columns)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe(distinct(sql("temperature"))))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", expected_columns), colnames(df2))
  
  # Without quotes to column name
  qq[["desc_temp"]] <- quo(ts.describe(distinct(sql(temperature))))
  expect_equal(.get_column_names_summarise(qq), expected_columns)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe(distinct(sql(temperature))))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", expected_columns), colnames(df2))
  
  # Using column name with spaces
  qq[["desc_temp"]] <- quo(ts.describe(distinct(sql(`new temp_var`))))
  replaced_cols <- .replace_column_name(expected_columns, "temperature", "new temp_var")
  expect_equal(.get_column_names_summarise(qq), replaced_cols)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe(distinct(sql(`new temp_var`))))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", replaced_cols), colnames(df2))
  
  ## Without the use of distinct()
  expected_columns <- c("Maximum(temperature)", 
                        "Minimum(temperature)", 
                        "Average(temperature)", 
                        "STDDEV_SAMP(temperature)",
                        "MEDIAN(temperature)",
                        "MODE(temperature)",
                        "PERCENTILE(temperature, 25, LINEAR)",
                        "PERCENTILE(temperature, 50, LINEAR)",
                        "PERCENTILE(temperature, 75, LINEAR)")
  
  # With quotes to column name
  qq[["desc_temp"]] <- quo(ts.describe(sql("temperature")))
  expect_equal(.get_column_names_summarise(qq), expected_columns)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe(sql("temperature")))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", expected_columns), colnames(df2))
  
  # Without quotes to column name
  qq[["desc_temp"]] <- quo(ts.describe(sql(temperature)))
  expect_equal(.get_column_names_summarise(qq), expected_columns)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe(sql(temperature)))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", expected_columns), colnames(df2))
  
  # Using column name with spaces
  qq[["desc_temp"]] <- quo(ts.describe(sql(`new temp_var`)))
  replaced_cols <- .replace_column_name(expected_columns, "temperature", "new temp_var")
  expect_equal(.get_column_names_summarise(qq), replaced_cols)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(ts.describe(sql(`new temp_var`)))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", replaced_cols), colnames(df2))
})


test_that("Using multiple describe operations", {
  qq <- list()
  
  qq[["last_t"]] <- quo(ts.last(temperature))
  qq[["desc1"]] <- quo(ts.describe("temperature"))
  qq[["bottom_t"]] <- quo(ts.bottom(temperature, 2))
  qq[["first_t"]] <- quo(ts.first(temperature))
  qq[["desc2"]] <- quo(ts.describe(distinct(salinity)))
  qq[["mad_t"]] <- quo(ts.mad(temperature))

  # Expected columns for the quosures above.
  expected_columns <- c("last_t", "Maximum(temperature)", "Minimum(temperature)", "Average(temperature)", 
                        "STDDEV_SAMP(temperature)", "MEDIAN(temperature)", "MODE(temperature)", 
                        "PERCENTILE(temperature, 25, LINEAR)", "PERCENTILE(temperature, 50, LINEAR)", 
                        "PERCENTILE(temperature, 75, LINEAR)", 
                        "bottom_t", "first_t", 
                        "Maximum(Distinct(salinity))", "Minimum(Distinct(salinity))", "Average(Distinct(salinity))", 
                        "STDDEV_SAMP(Distinct(salinity))", "MEDIAN(Distinct(salinity))", "MODE(salinity)", 
                        "PERCENTILE(Distinct(salinity, 25, LINEAR))", "PERCENTILE(Distinct(salinity, 50, LINEAR))", 
                        "PERCENTILE(Distinct(salinity, 75, LINEAR))", 
                        "mad_t")

  expect_equal(.get_column_names_summarise(qq), expected_columns)
  # Checking whether the column names after describe operation matches with names from internal function.
  df2 <- seq_group1 %>% summarise(last_t = ts.last(temperature), desc1 = ts.describe(temperature), 
                                  bottom_t = ts.bottom(temperature, 2), first_t = ts.first(temperature), 
                                  desc2 = ts.describe(distinct(salinity)),
                                  mad_t = ts.mad(temperature))
  expect_equal(c("TIMECODE_RANGE", "GROUP BY TIME(MINUTES(30))", expected_columns), colnames(df2))
})



context("Unit tests for the function `.validate_delta_t_conditions`")

test_that("Use of multiple ts.delta_t functions", {
  group_by_time_expr <- "GROUP BY TIME(HOURS(2) AND col1, col2)"
  timebucket_duration_modfied <- "HOURS(2)"
  value_expression <- c("col1", "col2")
  arg_values <- list("group_by_time_expr" = group_by_time_expr,
                     "time_bucket_duration" = timebucket_duration_modfied,
                     "value_expression" = value_expression)
  
  # Aggregate function expression as list of quosures
  qq <- list()
  qq[["delta_val1"]] <- quo(ts.delta_t(temperature == min_t, temperature == max_t))
  qq[["delta_val2"]] <- quo(ts.delta_t(temperature == min_t1, temperature == max_t2))
  
  expect_error(.validate_delta_t_conditions(arg_values, qq), 
               "The function 'ts.delta_t' cannot be combined with any other aggregate function, including itself.")
})

test_that("Use of ts.delta_t function with any other time series aggregate function", {
  group_by_time_expr <- "GROUP BY TIME(HOURS(2) AND col1, col2)"
  timebucket_duration_modfied <- "HOURS(2)"
  value_expression <- c("col1", "col2")
  arg_values <- list("group_by_time_expr" = group_by_time_expr,
                     "time_bucket_duration" = timebucket_duration_modfied,
                     "value_expression" = value_expression)
  
  # Aggregate function expression as list of quosures
  qq <- list()
  qq[["delta_val1"]] <- quo(ts.delta_t(temperature == min_t, temperature == max_t))
  qq[["delta_val2"]] <- quo(ts.min(temperature))
  
  expect_error(.validate_delta_t_conditions(arg_values, qq), 
               "The function 'ts.delta_t' cannot be combined with any other aggregate function, including itself.")
})

test_that("Use unbounded time bucket duration (*) for time series aggregate function other than ts.delta_t", {
  group_by_time_expr <- "GROUP BY TIME(HOURS(2) AND col1, col2)"
  timebucket_duration_modfied <- "*"
  value_expression <- c("col1", "col2")
  arg_values <- list("group_by_time_expr" = group_by_time_expr,
                     "time_bucket_duration" = timebucket_duration_modfied,
                     "value_expression" = value_expression)
  
  error_msg <- "Unbounded timebucket duration \\(\\*) can be used only with the 'ts.delta_t' function."
  
  # Aggregate function expression as list of quosures
  qq <- list()
  qq[["delta_val1"]] <- quo(ts.min(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.max(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.bottom(temperature, 2))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.top(temperature, 2))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.first(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.last(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.describe(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.sd(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.sdp(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.var(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.varp(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.sum(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.mean(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.mode(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.median(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.mad(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.percentile(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.kurtosis(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  qq[["delta_val1"]] <- quo(ts.skew(temperature))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
  
  # Using more than one quosure without ts.delta_t
  qq[["delta_val2"]] <- quo(ts.min(temperature))
  expect_equal(length(qq), 2)
  expect_equal(names(qq), c("delta_val1", "delta_val2"))
  expect_error(.validate_delta_t_conditions(arg_values, qq),  error_msg)
})

test_that("Using FILL clause along with ts.delta_t", {
  group_by_time_expr <- "GROUP BY TIME(HOURS(2) AND col1, col2) FILL(NULLS)"
  timebucket_duration_modfied <- "HOURS(2)"
  value_expression <- c("col1", "col2")
  arg_values <- list("group_by_time_expr" = group_by_time_expr,
                     "time_bucket_duration" = timebucket_duration_modfied,
                     "value_expression" = value_expression)
  
  # Aggregate function expression as list of quosures
  qq <- list()
  qq[["delta_val"]] <- quo(ts.delta_t(temperature == min_t, temperature == max_t))
  
  expect_error(.validate_delta_t_conditions(arg_values, qq), 
               "The function 'ts.delta_t' cannot be used with 'fill' argument of 'group_by_time' function.")
})

test_that("Positve test case for .validate_delta_t_conditions without ts.delta_t", {
  group_by_time_expr <- "GROUP BY TIME(HOURS(2) AND col1, col2) FILL(NULLS)"
  timebucket_duration_modfied <- "HOURS(2)"
  value_expression <- c("col1", "col2")
  arg_values <- list("group_by_time_expr" = group_by_time_expr,
                     "time_bucket_duration" = timebucket_duration_modfied,
                     "value_expression" = value_expression)
  
  # Aggregate function expression as list of quosures
  qq <- list()
  qq[["delta_val1"]] <- quo(ts.min(temperature))
  qq[["delta_val2"]] <- quo(ts.first(temperature))
  
  expect_true(.validate_delta_t_conditions(arg_values, qq))
})

test_that("Positve test case for .validate_delta_t_conditions with ts.delta_t", {
  group_by_time_expr <- "GROUP BY TIME(HOURS(2) AND col1, col2) USING TIMECODE(tc_col)"
  timebucket_duration_modfied <- "HOURS(2)"
  value_expression <- c("col1", "col2")
  arg_values <- list("group_by_time_expr" = group_by_time_expr,
                     "time_bucket_duration" = timebucket_duration_modfied,
                     "value_expression" = value_expression)
  
  # Aggregate function expression as list of quosures
  qq <- list()
  qq[["delta_val"]] <- quo(ts.delta_t(temperature == min_t, temperature == max_t))
  
  expect_true(.validate_delta_t_conditions(arg_values, qq))
})

testthat::teardown({    
  td_remove_context()
})