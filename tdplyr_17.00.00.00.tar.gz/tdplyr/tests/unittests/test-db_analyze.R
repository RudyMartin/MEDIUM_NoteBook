context("Unit tests for db_analyze function")

testthat::setup({
  if(globalDTYPE == "odbc"){
    con <<- suppressWarnings(td_create_context(dsn = dsnName))
  } else {
    con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD))
  }
  DBI::dbExecute(con,"create table table_defaultPI(a integer)")
  DBI::dbExecute(con,"create table table_PI(a integer, b integer) PRIMARY INDEX(b) ")
  DBI::dbExecute(con,"create table table_PI_2(a integer, \"b a\" integer, c integer) PRIMARY INDEX(a,c) ")
  DBI::dbExecute(con,"create table table_NOPI(a integer, b integer) NO PRIMARY INDEX ")
})

#Negative test cases
test_that("Throws error as required argument table is missing", {
  expect_error(db_analyze(con, table = NULL), 
               "'table' argument should be a valid table name.")
})

test_that("Throws error as required argument table is missing", {
  expect_error(db_analyze(con, table = NA), 
               "'table' argument should be a valid table name.")
})

test_that("Throws error as required argument column is missing", {
  expect_error(db_analyze(con, table = "table_exists", column = NULL), 
               "'column' argument should be a valid column.")
})

test_that("Throws error as required argument column is missing", {
  expect_error(db_analyze(con, table = "table_exists", column = NA), 
               "'column' argument should be a valid column.")
})

#Positive test cases
test_that("analyzes the PI table with default PRIMARY INDEX", {
  expect_error(DBI::dbExecute(con,"HELP statistics table_defaultPI"),"There are no statistics defined for the table.")
  expect_equal(db_analyze(con, table = "table_defaultPI", column = "a"),2)
  statsDf <- DBI::dbGetQuery(con,"HELP statistics table_defaultPI")
  expect_equal(nrow(statsDf),2)
  expect_true("a" %in% statsDf$`Column Names`)
})

test_that("analyzes the PI table with custom PRIMARY INDEX", {
  expect_error(DBI::dbExecute(con,"HELP statistics table_PI"),"There are no statistics defined for the table.")
  expect_equal(db_analyze(con, table = "table_PI", column = "b"),2)
  statsDf <- DBI::dbGetQuery(con,"HELP statistics table_PI")
  expect_equal(nrow(statsDf),2)
  expect_true("b" %in% statsDf$`Column Names`)
})

test_that("analyzes the PI table with custom multiple PRIMARY INDEX", {
  expect_error(DBI::dbExecute(con,"HELP statistics table_PI_2"),"There are no statistics defined for the table.")
  expect_equal(db_analyze(con, table = "table_PI_2", column = c("a","b a")),2)
  statsDf <- DBI::dbGetQuery(con,"HELP statistics table_PI_2")
  expect_equal(nrow(statsDf),2)
  expect_true("a,\"b a\"" %in% statsDf$`Column Names`)
})

test_that("analyzes the table with NO PRIMARY INDEX", {
  expect_error(DBI::dbExecute(con,"HELP statistics table_NOPI"),"There are no statistics defined for the table.")
  expect_equal(db_analyze(con, table = "table_NOPI", column = "a"),2)
  statsDf <- DBI::dbGetQuery(con,"HELP statistics table_NOPI")
  expect_equal(nrow(statsDf),2)
  expect_true("a" %in% statsDf$`Column Names`)
})

testthat::teardown(
  {
    DBI::dbExecute(con,"drop table table_defaultPI")
    DBI::dbExecute(con,"drop table table_PI")
    DBI::dbExecute(con,"drop table table_NOPI")
    DBI::dbExecute(con,"drop table table_PI_2")
    td_remove_context()
  }
)
