context("Tests for Teradata print and show")

# see also: test-db_desc-odbc
test_con <- NULL

testthat::setup(
  {
    if(globalDTYPE == "odbc"){
      test_con <<- suppressWarnings(td_create_context(dsn = dsnName))
    } else {
      test_con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD))
    }
    
    DBI::dbWriteTable(test_con, 'savings', as.data.frame(LifeCycleSavings))
    DBI::dbWriteTable(test_con, 'rock', rock)
  }
)

test_that('show and print works', {

  t <- tbl(test_con, 'savings')

  # show calls the default print
  show_output <- capture_output(show(t))
  lines <- unlist(strsplit(show_output, "\n"))

  header <- lines[1:3]
  cols <- Filter(function(x) x != "", unlist(strsplit(lines[4], " ")))
  typs <- Filter(function(x) x != "", unlist(strsplit(lines[5], " ")))
  rows <- lines[7 : length(lines) - 1L]

  # default print gets 10 rows
  expect_length(rows, 10L)
  expect_length(cols, length(colnames(t)))
  expect_length(typs, length(colnames(t)))
  expect_true(grepl('Source:', header[[1]]) == 1L)
  expect_true(grepl('Database:', header[[2]]) == 1L)

  # calling print should be roughly the same (except rows)
  print_output <- capture_output(print(t))
  lines <- unlist(strsplit(print_output, "\n"))

  header_p <- lines[1:3]
  cols_p <- Filter(function(x) x != "", unlist(strsplit(lines[4], " ")))
  typs_p <- Filter(function(x) x != "", unlist(strsplit(lines[5], " ")))
  rows_p <- lines[7 : length(lines) - 1L]

  expect_identical(header_p, header)
  expect_identical(cols_p, cols)
  expect_identical(typs_p, typs)

  # rows may be in another order
  expect_identical(length(rows_p), length(rows)) 

  # print takes n for limiting rows returned
  res <- capture_output(print(t, n=8L))
  lines <- unlist(strsplit(res, "\n"))

  header_p <- lines[1:3]
  cols_p <- Filter(function(x) x != "", unlist(strsplit(lines[4], " ")))
  typs_p <- Filter(function(x) x != "", unlist(strsplit(lines[5], " ")))
  rows_p <- lines[7 : length(lines) - 1L]

  # but everything is pretty much the same
  expect_length(rows_p, 8L)
  expect_length(cols_p, length(colnames(t)))
  expect_length(typs_p, length(colnames(t)))
  expect_true(grepl('Source:', header_p[[1]]) == 1L)
  expect_true(grepl('Database:', header_p[[2]]) == 1L)

  # show doesn't take other args
  expect_error(show(t, n=5L))

  # non-positive values of n for print
  expect_error(print(t, n = 0L))
  expect_error(print(t, n = -1L))
  expect_error(print(t, n = -Inf))
})

test_that('print and glimpse show different precision for <dbl>', {

 df <- tbl(test_con, 'rock')

 res <- df %>% 
        transmute(x = (floor(area) / 1000) ^ (floor(perm) / 1000)) %>% 
        arrange(x)

 b <- capture_output(glimpse(res))
 a <- capture_output(print(res))
 
  # column values for x
 glimpse_output <- unlist(strsplit(unlist(strsplit(b, "\n"))[[3]], ' '))[3:9]
 expect_identical(glimpse_output, c("<dbl>", "1.000000,", "1.009703,",
                                    "1.011744,", "1.012081,", "1.012243,", "1.035761,"))
 print_output <- Filter(function(x) nchar(x) >= 4,
                        unlist(strsplit(unlist(strsplit(a, "\n"))[6:13], ' ')))
 expect_identical(print_output, c("<dbl>", "1.01", "1.01", "1.01", "1.01", "1.04", "1.04"))

 expect_equal(length(print_output), length(glimpse_output))

})

testthat::teardown(
  {
    dplyr::db_drop_table(test_con, 'savings')
    dplyr::db_drop_table(test_con, 'rock')
    td_remove_context()
  }
)
