context("Error handling unit tests")

# Test Plan:
#   - First part test stop and warning With / without error code
#       and with /without formatting arguments
#   - Second part, test call stack
#   - Third part, testing with an external error code.

test_that(".ta.stop WITH error codes ", {
  msg <- "TDR_E2000"
  # verify it has the error code set
  expect_error(.ta.stop(msg), paste0("(",msg,")"))
  # verify it contains the package name prefix
  expect_error(.ta.stop(msg), paste0("\\[",.ta.getPackageName()))
})

test_that(".ta.stop works WITHOUT error codes", {
  msg <- "My error"
  # verify it has the default error code set
  expect_error(.ta.stop(msg), paste0("(",.getDefaultErrorCode(),")"))
  # verify it contains the package name prefix
  expect_error(.ta.stop(msg), paste0("\\[",.ta.getPackageName()))
  # verify if it has the actual message
  expect_error(.ta.stop(msg), msg)
})

test_that(".ta.stop with formatting strings WITH error code", {
  # set a error code that has format strings
  msg <- "TDR_E1002"
  arg1 <- "MYARG_1"
  # verify it has the error code set
  expect_error(.ta.stop(msg, arg1), paste0("(",msg,")"))
  # verify that the message is formatted correctly
  expect_error(.ta.stop(msg, arg1), gettextf(.global__error__list__[[msg]],arg1))
  expect_error(.ta.stop(msg), paste0("\\[",.ta.getPackageName()))
  #pass argument explicitly
  expect_error(.ta.stop(msg, "XYZ"), paste0("(",msg,")"))
  expect_error(.ta.stop(msg, "XYZ"), gettextf(.global__error__list__[[msg]],"XYZ"))
  expect_error(.ta.stop(msg), paste0("\\[",.ta.getPackageName()))
  # pass argument with a name
  expect_error(.ta.stop(msg, x = arg1), paste0("(",msg,")"))
  # verify that the message is formatted correctly
  expect_error(.ta.stop(msg, x = arg1), gettextf(.global__error__list__[[msg]],arg1))

  # Msg with two arguments
  msg <- "TDR_E1003"
  arg1 <- "MYARG_1"
  arg2 <- "MYARG_2"
  
  expect_error(.ta.stop(msg, arg1, arg2), paste0("(",msg,")"))
  expect_error(.ta.stop(msg, arg1, arg2), gettextf(.global__error__list__[[msg]],arg1,arg2))
  expect_error(.ta.stop(msg, arg1, arg2), paste0("\\[",.ta.getPackageName()))
  
  # pass one argument explicitly and other as a variable
  expect_error(.ta.stop(msg, arg1, "XYZ"), paste0("(",msg,")"))
  expect_error(.ta.stop(msg, arg1, "XYZ"), gettextf(.global__error__list__[[msg]],arg1, "XYZ"))
  expect_error(.ta.stop(msg, arg1, "XYZ"), paste0("\\[",.ta.getPackageName()))
  
  # pass one argument with name and other without
  expect_error(.ta.stop(msg, a = "ABC", "XYZ"), paste0("(",msg,")"))
  expect_error(.ta.stop(msg, a = "ABC", "XYZ"), gettextf(.global__error__list__[[msg]], "ABC", "XYZ"))
  expect_error(.ta.stop(msg, a = "ABC", "XYZ"), paste0("\\[",.ta.getPackageName()))
})


test_that(".ta.stop with formatting strings WITHOUT error code", {
  # set a error code that has format strings
  msg <- "This is %s error"
  arg1 <- "SOME"
  # verify it has the error code set
  expect_error(.ta.stop(msg, arg1), paste0("(",.getDefaultErrorCode(),")"))
  # verify that the message is formatted correctly
  expect_error(.ta.stop(msg, arg1), gettextf(msg,arg1))
  expect_error(.ta.stop(msg), paste0("\\[",.ta.getPackageName()))
  #pass argument explicitly
  expect_error(.ta.stop(msg, "XYZ"), paste0("(",.getDefaultErrorCode(),")"))
  expect_error(.ta.stop(msg, "XYZ"), gettextf(msg,"XYZ"))
  expect_error(.ta.stop(msg), paste0("\\[",.ta.getPackageName()))
  # pass argument with a name
  expect_error(.ta.stop(msg, x = arg1), paste0("(",.getDefaultErrorCode(),")"))
  # verify that the message is formatted correctly
  expect_error(.ta.stop(msg, x = arg1), gettextf(msg,arg1))

  # Msg with two arguments
  msg <- "This is %s error that %s."
  arg1 <- "SOME"
  arg2 <- "BUGS"
  
  expect_error(.ta.stop(msg, arg1, arg2), paste0("(",.getDefaultErrorCode(),")"))
  expect_error(.ta.stop(msg, arg1, arg2), gettextf(msg, arg1,arg2))
  expect_error(.ta.stop(msg, arg1, arg2), paste0("\\[",.ta.getPackageName()))
  
  # pass one argument explicitly and other as a variable
  expect_error(.ta.stop(msg, arg1, "XYZ"), paste0("(",.getDefaultErrorCode(),")"))
  expect_error(.ta.stop(msg, arg1, "XYZ"), gettextf(msg,arg1, "XYZ"))
  expect_error(.ta.stop(msg, arg1, "XYZ"), paste0("\\[",.ta.getPackageName()))
  
  # pass one argument with name and other without
  expect_error(.ta.stop(msg, a = "ABC", "XYZ"), paste0("(",.getDefaultErrorCode(),")"))
  expect_error(.ta.stop(msg, a = "ABC", "XYZ"), gettextf(msg, "ABC", "XYZ"))
  expect_error(.ta.stop(msg, a = "ABC", "XYZ"), paste0("\\[",.ta.getPackageName()))
})

#################################################
# Just repeat the above for .ta.warning()
##################################################

test_that(".ta.warning WITH error codes ", {
  msg <- "TDR_W1000"
  # verify it has the error code set
  expect_warning(.ta.warning(msg), paste0("(",msg,")"))
  # verify it contains the package name prefix
  expect_warning(.ta.warning(msg), paste0("\\[",.ta.getPackageName()))
})

test_that(".ta.warning works WITHOUT error codes", {
  msg <- "My error"
  # verify it has the default error code set
  expect_warning(.ta.warning(msg), paste0("(",.getDefaultErrorCode(),")"))
  # verify it contains the package name prefix
  expect_warning(.ta.warning(msg), paste0("\\[",.ta.getPackageName()))
  # verify if it has the actual message
  expect_warning(.ta.warning(msg), msg)
})

test_that(".ta.warning with formatting strings WITH error code", {
  # set a error code that has format strings
  msg <- "TDR_E1002"
  arg1 <- "MYARG_1"
  # verify it has the error code set
  expect_warning(.ta.warning(msg, arg1), paste0("(",msg,")"))
  # verify that the message is formatted correctly
  expect_warning(.ta.warning(msg, arg1), gettextf(.global__error__list__[[msg]],arg1))
  expect_warning(.ta.warning(msg), paste0("\\[",.ta.getPackageName()))
  #pass argument explicitly
  expect_warning(.ta.warning(msg, "XYZ"), paste0("(",msg,")"))
  expect_warning(.ta.warning(msg, "XYZ"), gettextf(.global__error__list__[[msg]],"XYZ"))
  expect_warning(.ta.warning(msg), paste0("\\[",.ta.getPackageName()))
  # pass argument with a name
  expect_warning(.ta.warning(msg, x = arg1), paste0("(",msg,")"))
  # verify that the message is formatted correctly
  expect_warning(.ta.warning(msg, x = arg1), gettextf(.global__error__list__[[msg]],arg1))

  # Msg with two arguments
  msg <- "TDR_E1003"
  arg1 <- "MYARG_1"
  arg2 <- "MYARG_2"
  
  expect_warning(.ta.warning(msg, arg1, arg2), paste0("(",msg,")"))
  expect_warning(.ta.warning(msg, arg1, arg2), gettextf(.global__error__list__[[msg]],arg1,arg2))
  expect_warning(.ta.warning(msg, arg1, arg2), paste0("\\[",.ta.getPackageName()))
  
  # pass one argument explicitly and other as a variable
  expect_warning(.ta.warning(msg, arg1, "XYZ"), paste0("(",msg,")"))
  expect_warning(.ta.warning(msg, arg1, "XYZ"), gettextf(.global__error__list__[[msg]],arg1, "XYZ"))
  expect_warning(.ta.warning(msg, arg1, "XYZ"), paste0("\\[",.ta.getPackageName()))
  
  # pass one argument with name and other without
  expect_warning(.ta.warning(msg, a = "ABC", "XYZ"), paste0("(",msg,")"))
  expect_warning(.ta.warning(msg, a = "ABC", "XYZ"), gettextf(.global__error__list__[[msg]], "ABC", "XYZ"))
  expect_warning(.ta.warning(msg, a = "ABC", "XYZ"), paste0("\\[",.ta.getPackageName()))
})


test_that(".ta.warning with formatting strings WITHOUT error code", {
  # set a error code that has format strings
  msg <- "This is %s error"
  arg1 <- "SOME"
  # verify it has the error code set
  expect_warning(.ta.warning(msg, arg1), paste0("(",.getDefaultErrorCode(),")"))
  # verify that the message is formatted correctly
  expect_warning(.ta.warning(msg, arg1), gettextf(msg,arg1))
  expect_warning(.ta.warning(msg), paste0("\\[",.ta.getPackageName()))
  #pass argument explicitly
  expect_warning(.ta.warning(msg, "XYZ"), paste0("(",.getDefaultErrorCode(),")"))
  expect_warning(.ta.warning(msg, "XYZ"), gettextf(msg,"XYZ"))
  expect_warning(.ta.warning(msg), paste0("\\[",.ta.getPackageName()))
  # pass argument with a name
  expect_warning(.ta.warning(msg, x = arg1), paste0("(",.getDefaultErrorCode(),")"))
  # verify that the message is formatted correctly
  expect_warning(.ta.warning(msg, x = arg1), gettextf(msg,arg1))

  # Msg with two arguments
  msg <- "This is %s error that %s."
  arg1 <- "SOME"
  arg2 <- "BUGS"
  
  expect_warning(.ta.warning(msg, arg1, arg2), paste0("(",.getDefaultErrorCode(),")"))
  expect_warning(.ta.warning(msg, arg1, arg2), gettextf(msg, arg1,arg2))
  expect_warning(.ta.warning(msg, arg1, arg2), paste0("\\[",.ta.getPackageName()))
  
  # pass one argument explicitly and other as a variable
  expect_warning(.ta.warning(msg, arg1, "XYZ"), paste0("(",.getDefaultErrorCode(),")"))
  expect_warning(.ta.warning(msg, arg1, "XYZ"), gettextf(msg,arg1, "XYZ"))
  expect_warning(.ta.warning(msg, arg1, "XYZ"), paste0("\\[",.ta.getPackageName()))
  
  # pass one argument with name and other without
  expect_warning(.ta.warning(msg, a = "ABC", "XYZ"), paste0("(",.getDefaultErrorCode(),")"))
  expect_warning(.ta.warning(msg, a = "ABC", "XYZ"), gettextf(msg, "ABC", "XYZ"))
  expect_warning(.ta.warning(msg, a = "ABC", "XYZ"), paste0("\\[",.ta.getPackageName()))
})

#############################################################################
# Test if ta.stop displays the function name and call stack properly
#############################################################################

callingFunc1 <- function() {
  msg <- "This is %s error"
  arg1 <- "SOME"
  .ta.stop(msg, arg1)
}
callingFuncWithArgs <- function(abc, val = 1) {
  .ta.stop("Test error")
}
callWithStackTrace <- function() {
  .ta.stop("Test error", showStackTrace = TRUE)
}

callWithStackTraceLevel2 <- function() {
  callWithStackTrace()
}

test_that(".ta.stop displays calling function name", {
  # check if the function call is present
  expect_error(callingFunc1(), "callingFunc1()")
  # check actual message
  expect_error(callingFunc1(), paste0("(",.getDefaultErrorCode(),")"))
  expect_error(callingFuncWithArgs("test"), "callingFuncWithArgs\\('test'\\)")
})
test_that(".ta.stop displays call stack trace: ", {
  # displays both levels
  expect_error(callWithStackTraceLevel2(), "In callWithStackTrace\\(\\):\ncallWithStackTraceLevel2\\(\\):")
})

#############################################################################
# Test if ta.warning displays the function name and call stack properly
#############################################################################


callingFunc1 <- function() {
  msg <- "This is %s error"
  arg1 <- "SOME"
  .ta.warning(msg, arg1)
}
callingFuncWithArgs <- function(abc, val = 1) {
  .ta.warning("Test error")
}
callWithStackTrace <- function() {
  .ta.warning("Test error", showStackTrace = TRUE)
}

callWithStackTraceLevel2 <- function() {
  callWithStackTrace()
}

test_that(".ta.warning displays calling function name", {
  # check if the function call is present
  expect_warning(callingFunc1(), "callingFunc1()")
  expect_warning(callingFunc1(), paste0("(",.getDefaultErrorCode(),")"))
  expect_warning(callingFuncWithArgs("test"), "callingFuncWithArgs\\('test'\\)")
})
test_that(".ta.warning displays call stack trace: ", {
  # displays both levels
  expect_warning(callWithStackTraceLevel2(), "In callWithStackTrace\\(\\):\ncallWithStackTraceLevel2\\(\\):")
})

# #############################################################################
# # Test if setting isExternal Error works as expected
# #############################################################################

test_that(".ta.stop works with isExternal", {
  msg <- "This is %s error"
  arg1 <- "SOME"
  
  expect_error(.ta.stop(msg, arg1, isExternal = TRUE),paste0("\\[",.ta.getPackageName()," - \\(",
                                        .getExternalErrorCode(),"\\)\\] ",.global__error__list__[[.getExternalErrorCode()]],
                                        gettextf(msg,arg1)))
})

test_that(".ta.warning works with isExternal", {
  msg <- "This is %s error"
  arg1 <- "SOME"

  expect_warning(.ta.warning(msg, arg1, isExternal = TRUE),paste0("\\[",.ta.getPackageName()," - \\(",
                                        .getExternalErrorCode(),"\\)\\] ",.global__error__list__[[.getExternalErrorCode()]],
                                        gettextf(msg,arg1)))
})

# #############################################################################
# # Test if multi line support works
# #############################################################################
test_that(".ta.stop works with multi line", {
    msg <- c("This is %s error.", "Line 2")
    arg1 <- "SOME"
    expect_error(.ta.stop(msg, arg1), gettextf("\\[%s - \\(TDR_E1001\\)\\] This is SOME error.\nLine 2", .ta.getPackageName()))
})

test_that(".ta.warning works with multi line", {
    msg <- c("This is %s error.", "Line 2")
    arg1 <- "SOME"
    expect_warning(.ta.warning(msg, arg1), gettextf("\\[%s - \\(TDR_E1001\\)\\] This is SOME error.\nLine 2", .ta.getPackageName()))

})

# #############################################################################
# # Basic Tests for ta.print
# #############################################################################

test_that(".ta.print without a code", {
  msg <- "My error"
  # verify it does not have any error code prefix set
  expect_false(grepl(paste0("(",.getDefaultErrorCode(),")"), capture_output(.ta.print(msg, addPrefix = FALSE)), fixed = TRUE))
  # verify it contains the package name prefix
  expect_false(grepl(paste0("[",.ta.getPackageName()), capture_output(.ta.print(msg, addPrefix = FALSE)), fixed = TRUE))

  # verify if it has the actual message
  expect_true(grepl(msg, capture_output(.ta.print(msg, addPrefix = FALSE)), fixed = TRUE))
  
  # Verify the above with addPrefix = TRUE
  # verify it does not have any error code prefix set
  expect_true(grepl(paste0("(",.getDefaultErrorCode(),")"), capture_output(.ta.print(msg, addPrefix = TRUE)), fixed = TRUE))
  # verify it contains the package name prefix
  expect_true(grepl(paste0("[",.ta.getPackageName()), capture_output(.ta.print(msg, addPrefix = TRUE)), fixed = TRUE))

  # verify if it has the actual message
  expect_true(grepl(msg, capture_output(.ta.print(msg, addPrefix = TRUE)), fixed = TRUE))
})

test_that(".ta.print with a code", {
  msg <- "TDR_W1000"
  val <- "Reserved: Exported functions API Warning"
  # verify it does not have any error code prefix set
  expect_false(grepl(paste0("(",msg,")"), capture_output(.ta.print(msg, addPrefix = FALSE)), fixed = TRUE))
  # verify it contains the package name prefix
  expect_false(grepl(paste0("[",.ta.getPackageName()), capture_output(.ta.print(msg, addPrefix = FALSE)), fixed = TRUE))

  # verify if it has the actual message
  expect_true(grepl(val, capture_output(.ta.print(msg, addPrefix = FALSE)), fixed = TRUE))
  
  # Verify the above with addPrefix = TRUE
  # verify it does not have any error code prefix set
  expect_true(grepl(paste0("(",msg,")"), capture_output(.ta.print(msg, addPrefix = TRUE)), fixed = TRUE))
  # verify it contains the package name prefix
  expect_true(grepl(paste0("[",.ta.getPackageName()), capture_output(.ta.print(msg, addPrefix = TRUE)), fixed = TRUE))

  # verify if it has the actual message
  expect_true(grepl(val, capture_output(.ta.print(msg, addPrefix = TRUE)), fixed = TRUE))
})
