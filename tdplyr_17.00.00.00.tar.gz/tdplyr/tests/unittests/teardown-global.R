cat("Initialize Global Teardown\n")

# Connect with basic dbConnect and odbc
# Do not use ta.connect here as this is only required to drop test tables and databases

# A switch to turn off teardown of database objects if needed
RUN_TEARDOWN <- TRUE

if (RUN_TEARDOWN) {
  con <- td_create_context(dsn = dsnName)

  # Just validate the connection
  expect_true(DBI::dbIsValid(con))

  # Drop any tables followed by databases / schemas here
  dplyr::db_drop_table(con, 'quakes')

  # Successfully disconnect all connections
  expect_warning(td_remove_context(), regexp = NA)
  expect_false(DBI::dbIsValid(con))
}
