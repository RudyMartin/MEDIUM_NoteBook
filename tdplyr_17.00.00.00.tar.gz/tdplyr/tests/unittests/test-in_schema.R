context ("Unit tests for in_schema related functions")

userName <-  toupper(.ta.getUserName())
tempDatabaseName <- toupper(paste0("RTEST_TMP_DATABASE_",userName))
db1 <- "DB.1"
# db with space
db2 <- "DB A 2"
getQuoted <- function (db) {
  dbplyr::sql_quote(db, '"')
}

# Helper function to check if a given table is in the db
# We do not use any APIs here but just raw sql query to very
isTableInDb <- function (con, db, table) {
  query <- gettextf("SELECT TableName FROM DBC.TABLESV
                       WHERE UPPER(databasename) = '%s'",
                        toupper(db))
    
  res <- DBI::dbGetQuery(con, query)
  return(toupper(table) %in% toupper(res$TableName))
}

dbObjects <- NULL
expectedDb <- NULL
expectedTable <- NULL

defaultDatabase <- ""
con <- NULL
testthat::setup({
  if(globalDTYPE == "odbc"){
    dcon <<- suppressWarnings(td_create_context(dsn = dsnName, uid = "dbc", pwd = "dbc"))
  } else {
    dcon <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = "dbc", pwd = "dbc"))
  }
  
  # Drop database, if exists, before creating it.
  try(DBI::dbExecute(dcon, paste0("DELETE DATABASE ",tempDatabaseName,";")), silent = TRUE)
  try(DBI::dbExecute(dcon, paste0("DROP DATABASE ",tempDatabaseName,";")), silent = TRUE)
  # Create database.
  DBI::dbExecute(dcon, paste0("CREATE DATABASE ",tempDatabaseName," AS PERM = 1e+06;" ))
  DBI::dbExecute(dcon, paste0("GRANT ALL ON ",tempDatabaseName," TO ", globalUID, ";" ))
  
  # Drop database, if exists, before creating it.
  try(DBI::dbExecute(dcon, paste0("DELETE DATABASE ",getQuoted(db1),";")), silent = TRUE)
  try(DBI::dbExecute(dcon, paste0("DROP DATABASE ",getQuoted(db1),";")), silent = TRUE)
  # Create database.
  DBI::dbExecute(dcon, paste0("CREATE DATABASE ",getQuoted(db1)," AS PERM = 1e+06;" ))
  DBI::dbExecute(dcon, paste0("GRANT ALL ON ",getQuoted(db1)," TO ", globalUID, ";" ))
  
  # Drop database, if exists, before creating it.
  try(DBI::dbExecute(dcon, paste0("DELETE DATABASE ",getQuoted(db2),";")), silent = TRUE)
  try(DBI::dbExecute(dcon, paste0("DROP DATABASE ",getQuoted(db2),";")), silent = TRUE)
  # Create database.
  DBI::dbExecute(dcon, paste0("CREATE DATABASE ",getQuoted(db2)," AS PERM = 1e+06;" ))
  DBI::dbExecute(dcon, paste0("GRANT ALL ON ",getQuoted(db2)," TO ", globalUID, ";" ))
  
  td_remove_context() # removes dcon
  
  if(globalDTYPE == "odbc"){
    con <<- suppressWarnings(td_create_context(dsn = dsnName, uid = globalUID, pwd = globalPWD))
  } else {
    con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, 
                                                uid = globalUID, pwd = globalPWD))
  }
  defaultDatabase <<- .get_dbname(con)

  # list of objects to test
  # basic ones with and without in_schema
  # rare cases where there is a dot in table name or database name
  # User must quote if the table name has special chars like dots
  # User can optionally quote their table name or db name using iin_schema
  dbObjects <<- list('r_tab1',
                dbplyr::in_schema(defaultDatabase,'r_tab11'),
                dbplyr::in_schema(defaultDatabase,'"r_tab1.1"'),
                dbplyr::in_schema(tempDatabaseName,"r_tab2"),
                dbplyr::in_schema(tempDatabaseName,'"r_tab3.1"'),
                # Create one with some upper case
                dbplyr::in_schema(tempDatabaseName,'R_Tab31'),
                dbplyr::in_schema(tempDatabaseName,'"r_tab.4.1"'),
                dbplyr::in_schema(getQuoted(db1),"r_tab6"),
                dbplyr::in_schema(getQuoted(db1),'"r_tab.7"'),
                dbplyr::in_schema(getQuoted(db1),'"r_tab8"'),
                # Test with spaces in names
                "r_tab 9",
                "r_tab.9 1 2",
                dbplyr::in_schema(tempDatabaseName,'"r_tab.10 1"'),
                dbplyr::in_schema(tempDatabaseName,'"r_tab.10.1 2 3"'),
                dbplyr::in_schema(getQuoted(db1),'"r_tab.11 1"'),
                dbplyr::in_schema(getQuoted(db1),'"r_tab.11.1 2 3"'),
                dbplyr::in_schema(getQuoted(db2),'r_tab12'),
                dbplyr::in_schema(getQuoted(db2),'"r_tab12.1"'),
                dbplyr::in_schema(getQuoted(db2),'"r_tab12.1.2 3 4"')
              )
  expectedDb <<- c(defaultDatabase,
                defaultDatabase,
                defaultDatabase,
                tempDatabaseName,
                tempDatabaseName,
                tempDatabaseName,
                tempDatabaseName,
                db1,
                db1,
                db1,
                # Test with spaces in names
                defaultDatabase,
                defaultDatabase,
                tempDatabaseName,
                tempDatabaseName,
                db1,
                db1,
                db2,
                db2,
                db2
              )
  expectedTable <<- c("r_tab1",
                'r_tab11',
                "r_tab1.1",
                "r_tab2",
                "r_tab3.1",
                "r_tab31",
                "r_tab.4.1",
                "r_tab6",
                "r_tab.7",
                "r_tab8",
                # Test with spaces in names
                "r_tab 9",
                "r_tab.9 1 2",
                "r_tab.10 1",
                "r_tab.10.1 2 3",
                "r_tab.11 1",
                "r_tab.11.1 2 3",
                "r_tab12",
                "r_tab12.1",
                "r_tab12.1.2 3 4"
              )
})

test_that("in_schema with copy_to, db_write_table, db_insert_into, db_has_table, dbExistsTable,
  dbRemoveTable, dbWriteTable, db_analyze works", {
  l <- length(dbObjects)
  data <- data.frame(aa = c(1:10), bb = rep("xyz",10))
  for (i in 1:l) {
    obj <- dbObjects[i][[1]]
    obj_id <- obj
    if(inherits(obj, "ident_q")){
      obj_id <- DBI::Id(schema = .extractDatabaseNameQuoted(obj), table = .extractTableNameQuoted(obj))
    }
    expectedDbName <- expectedDb[i]
    expectedTableName <- expectedTable[i]
    # precautionary cleanup
    tryCatch({
      dplyr::db_drop_table(con, obj)
    }, error=function(e) {   
      # DO Nothing
    })
    # Use copy_to that way we also test that with in_schema
    t1 <- expect_error(dplyr::copy_to(con, df = data, name = obj),
      regexp = NA)
    expect_equal(nrow(as.data.frame(t1)), nrow(data))
    # check has table and exists table
    expect_equal(as.character(dbplyr::remote_name(t1)), as.character(obj))
    # Verify with SQL if the table is indeed created in the database we want
    expect_true(isTableInDb(con, expectedDbName, expectedTableName))
    expect_true(DBI::dbExistsTable(con, obj))
    # Change the cases and try exists table
    expect_true(DBI::dbExistsTable(con, toupper(obj)))
    expect_true(DBI::dbExistsTable(con, tolower(obj)))
    # Test drop table
    expect_error(DBI::dbRemoveTable(con, obj_id),
      regexp = NA)
    # check table removed using our query
    expect_false(isTableInDb(con, expectedDbName, expectedTableName))
    expect_false(DBI::dbExistsTable(con, obj))
    expect_error(DBI::dbRemoveTable(con, obj_id), gettextf("'%s' does not exist", gsub("\"", "", obj)))

    expect_error(dplyr::db_write_table(con, table = obj_id,
        types = NULL, values = data, temporary = FALSE),
      regexp = NA)
    t1 <- dplyr::tbl(con, obj)
    expect_equal(nrow(as.data.frame(t1)), nrow(data))
    expect_equal(as.character(dbplyr::remote_name(t1)), as.character(obj))
    # insert 2 more rows
    expect_error(
      dplyr::db_insert_into(con, obj_id, data.frame(aa = c(11:12), bb = rep("abc", 2))),
      regexp = NA)
    expect_equal(nrow(as.data.frame(t1)), nrow(data)+2)
    expect_true(dplyr::db_has_table(con, obj))
    expect_error(dplyr::db_drop_table(con, obj),
      regexp = NA)
    expect_false(dplyr::db_has_table(con, obj))
    expect_error(dplyr::db_drop_table(con, obj), gettextf("'%s' does not exist", gsub("\"", "", obj)))
    # do some tests with dbWriteTable 
    expect_error(DBI::dbWriteTable(con, name = obj_id,
        value = data, temporary = FALSE), regexp = NA)
    t1 <- dplyr::tbl(con, obj)
    expect_equal(nrow(as.data.frame(t1)), nrow(data))
    expect_equal(as.character(dbplyr::remote_name(t1)), as.character(obj))
    expect_equal(nrow(as.data.frame(t1)), nrow(data))
    expect_true(dplyr::db_has_table(con, obj))
    # overwrite the same table with copy_to
    expect_error(dplyr::copy_to(con, name = obj,
      df = data.frame(aa = c(11:12), bb = rep("abc", 2)),
      temporary = FALSE, overwrite = TRUE),
    regexp = NA)
    expect_equal(nrow(as.data.frame(t1)), 2)
    # Test db_analyze with in_schema
    dplyr::db_analyze(con, obj, column = "aa")
    statsDf <- DBI::dbGetQuery(con,gettextf(
      'HELP statistics "%s"."%s"',expectedDbName, expectedTableName))
    expect_equal(nrow(statsDf),2)
    expect_true("aa" %in% statsDf$`Column Names`)

    expect_error(dplyr::db_drop_table(con, obj),
      regexp = NA)
    expect_false(dplyr::db_has_table(con, obj))
    expect_error(dplyr::db_drop_table(con, obj), gettextf("'%s' does not exist", gsub("\"", "", obj)))
  }
})

# TODO test db_create_table(not working), db_analyze with in_schema

testthat::teardown({
  
  td_remove_context() # removes con
  
  if(globalDTYPE == "odbc"){
    dcon <<- suppressWarnings(td_create_context(dsn = dsnName, uid = "dbc", pwd = "dbc"))
  } else {
    dcon <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = "dbc", pwd = "dbc"))
  }
  
  expect_error(DBI::dbExecute(dcon, paste0("DELETE DATABASE ",tempDatabaseName,";" )), regexp = NA)
  expect_error(DBI::dbExecute(dcon, paste0("DROP DATABASE ",tempDatabaseName,";" )), regexp = NA)

  expect_error(DBI::dbExecute(dcon, paste0("DELETE DATABASE ",getQuoted(db1),";" )), regexp = NA)
  expect_error(DBI::dbExecute(dcon, paste0("DROP DATABASE ",getQuoted(db1),";" )), regexp = NA)

  expect_error(DBI::dbExecute(dcon, paste0("DELETE DATABASE ",getQuoted(db2),";" )), regexp = NA)
  expect_error(DBI::dbExecute(dcon, paste0("DROP DATABASE ",getQuoted(db2),";" )), regexp = NA)

  td_remove_context() # removes dcon
})