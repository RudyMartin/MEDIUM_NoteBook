cat("Initializing Global Setup\n")

# Load all relevant libraries here as it gets painful to use qualifier for each
library(DBI)
library(dplyr)
library(dbplyr)

# Make sure to unload and load the tdplyr library again as many times
# if the library was already loaded then it wont update the new changes

# This will be a global setup for unit tests
# This will contain a few tables but the end2end
# is expected to have fledged setup

# Set the variables for connection
# default driver to run is ODBC as of now.
# set this to "native" to run the unittests using native driver.
globalDTYPE <- "odbc"
# DSN required for odbc
dsnName <- "TeradataDSN"
tdWalletString <- "pwd_for_test"
# Host, uid and password required for native driver tests
globalHost <- "tdap147t1.labs.teradata.com"
globalUID <- "alice"
globalPWD <- "alice"
globalLogMech <- NULL # default to TD2, other options : TD2, LDAP, TDNEGO, KRB5 for kerberos, and JWT.

# A switch to turn off creating the setup tables if needed
# If in case some setup tables exist, then this switch can be set to FALSE
# Then run the teardown-global file to remove the remaining tables
RUN_SETUP <- TRUE

 if (RUN_SETUP) {

  # Using create context here instead of dbConnect,
  # as it does not work on Mac right now with dsn
  con <- suppressWarnings(td_create_context(dsn = dsnName))

  # Just validate the connection
  expect_true(DBI::dbIsValid(con))

  # Cerate your sample tables / databases here here with meaningful names
  # We can reuse R datasets like iris and CO2
  DBI::dbWriteTable(con, 'quakes', quakes)

  expect_warning(td_remove_context(), regexp = NA)
  expect_false(DBI::dbIsValid(con))
 }
