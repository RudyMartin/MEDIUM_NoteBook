
# Note this test file must be launched from two different consoles simultaneously
# To test for multiple instances / sessions
context("Test garbage collection - this can be run in parallel to test multiple R instances")
library(dplyr)
library(DBI)
library(dbplyr)

getTempTablesUsingCopyTo <- function(con, n){
  ret <- list()
  for (i in 1:n) {
    df <- data.frame(aa = c(1:(1+i)), bb = c(101:(101+i)))
    t <- df %>% copy_to(con, df = .)
    expect_false(is.null(t)) #just a sanity check to verify if the tbl created
    ret[[i]] <- t
  }
  return(ret)
}

verifyTables <- function(con, tables, exists = TRUE) {
  for (t in tables) {
    expect_that(db_has_table(con, remote_name(t)), equals(exists))
  }
}

VerifyGarbageCollection <- function(on.remove.context = TRUE, num.tables = 2) {
  if(globalDTYPE == "native"){
    con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = globalDTYPE)
  }  else{
    con <- td_create_context(dsnName)
  }
  expect_true(dbIsValid(con))
  tables <- getTempTablesUsingCopyTo(con, num.tables)
  verifyTables(con, tables, exists = TRUE)
  if (on.remove.context) {
    td_remove_context()
    expect_false(dbIsValid(con))
  }
  if(globalDTYPE == "native"){
    con <- suppressWarnings(td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = globalDTYPE))
  }  else{
    con <- suppressWarnings(td_create_context(dsnName))
  }
  expect_true(dbIsValid(con))
  verifyTables(con, tables, exists = FALSE)
  td_remove_context()
  expect_false(dbIsValid(con))
}

iterateGarbageCollectionTest <- function(nIterations, on.remove.context = TRUE) {
  for (i in 1:nIterations) {
    VerifyGarbageCollection(on.remove.context = TRUE)
    # sleep for a random amount of time between 0.1 to 2 secs
    Sys.sleep(runif(1, min = 0.1, max = 2))
  }
}

test_that("Garbage collection works on remove context", {
  iterateGarbageCollectionTest(3, TRUE)
})

test_that("Garbage collection works on create context again", {
  iterateGarbageCollectionTest(3, FALSE)
})