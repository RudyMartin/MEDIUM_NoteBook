context ("Test package environment global variable support")

test_that("assign and create variables", {
    .assign("unitTestVarTAENv", 100)
    expect_true(.exists("unitTestVarTAENv"))
    expect_equal(.get("unitTestVarTAENv"), 100)
    .rm("unitTestVarTAENv")
    expect_false(.exists("unitTestVarTAENv"))
  })

test_that("assign does not create in global environment", {
    .assign("unitTestVarTAENv", 100)
    # check not in global env
    expect_false(exists("unitTestVarTAENv"))
    expect_true(.exists("unitTestVarTAENv"))
    .rm("unitTestVarTAENv")
    expect_false(.exists("unitTestVarTAENv"))
    # calling .rm with silent
    expect_warning(.rm("unitTestVarTAENv", silent = TRUE), regexp = NA)
    expect_warning(.rm("unitTestVarTAENv", silent = FALSE))
  })
