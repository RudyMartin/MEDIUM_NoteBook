context("Basic unit tests for to describe column types and names (.ta.describe.columns) for ODBC driver.")

if(tolower(globalDTYPE) == "native"){
  print("This test is supported only for ODBC driver.")
  return()
} 

dbccon <- suppressWarnings(DBI::dbConnect(odbc::odbc(), dsnName, uid = "dbc", pwd = "dbc"))
con <- suppressWarnings(td_create_context(dsnName, CharacterSet = "ASCII"))
conUTF8 <- suppressWarnings(DBI::dbConnect(odbc::odbc(), dsnName, CharacterSet = "UTF8"))

testthat::setup({
  # Initial Cleanup
  tryCatch({
    DBI::dbGetQuery(con, "drop table t_all_types_simple")
  }, error=function(e) {   
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(con, "drop table t_all_types_complex")
  }, error=function(e) {     
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(con, "drop table t_td_supported_types")
  }, error=function(e) { 
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(con, "drop table t_all_time_date_types")
  }, error=function(e) { 
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(con, "drop table t_pti_table_seq")
  }, error=function(e) {
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(con, "drop table t_pti_table_nonseq")
  }, error=function(e) {
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(dbccon, "DROP TYPE SYSUDTLIB.intarray")
  }, error=function(e) { 
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(dbccon, "DROP TYPE SYSUDTLIB.strarray")
  }, error=function(e) { 
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(con, "drop table t_number_supported")
  }, error=function(e) { 
    # DO Nothing
  })
  #
  # Create a table with all simple data types. 
  # Following table contains all regular widely used data types.
  #
  createQuery <- "Create Set table t_all_types_simple(
  C_ID INTEGER, 
  C_tint byteint, 
  C_sint smallint, 
  C_int int, 
  C_bint bigint, 
  C_decimal decimal(38,5), 
  C_double double PRECISION, 
  C_float float, 
  C_vbyte varbyte(10), 
  C_char char(128) CHARACTER SET UNICODE, 
  C_vchar varchar(128) CHARACTER SET UNICODE, 
  C_number number(18,3))"
  DBI::dbGetQuery(con, createQuery)
  
  #
  # Table containing time, timestamp and date datatypes.
  #
  createQuery <- "Create Set table t_all_time_date_types (
  C_ID  INTEGER, 
  C_date date, 
  C_time time, 
  C_timewtz time(3) with time zone, 
  C_timestamp timestamp(3), 
  C_timestampwtz timestamp(3) with time zone)"
  DBI::dbGetQuery(con, createQuery)
  
  #
  # PTI table - sequenced.
  #
  createQuery <- "CREATE TABLE t_pti_table_seq (
  buoyid INTEGER, 
  salinity INTEGER, 
  temperature INTEGER ) 
  PRIMARY TIME INDEX (TIMESTAMP(6), DATE '2012-01-01', HOURS(1), COLUMNS(buoyid), sequenced);"
  DBI::dbGetQuery(con, createQuery)
  
  #
  # PTI table - non_sequenced.
  #
  createQuery <- "CREATE TABLE t_pti_table_nonseq (
  buoyid INTEGER, 
  salinity INTEGER, 
  temperature INTEGER ) 
  PRIMARY TIME INDEX (TIMESTAMP(6), DATE '2012-01-01', HOURS(1), COLUMNS(buoyid), nonsequenced);"
  DBI::dbGetQuery(con, createQuery)
  
  #
  # Create a table with all complex data types. 
  # This includes following data types:
  #   1. User Defined Datatypes
  #   2. Complex Data Types like:
  #       a. JSON
  #       b. CLOB
  #       c. BLOB
  #       d. XML
  #
  testuser <- con@info$dbname
  # Let's create some user defined types, using superuser.
  DBI::dbGetQuery(dbccon, "CREATE TYPE SYSUDTLIB.intarray  AS INTEGER ARRAY [10]")
  DBI::dbGetQuery(dbccon, "CREATE TYPE SYSUDTLIB.strarray  AS VARCHAR(10) CHARACTER SET LATIN ARRAY [10]")
  DBI::dbGetQuery(dbccon, paste("grant UDTUSAGE on SYSUDTLIB to ", testuser))
  # Let's create a table.
  createQuery <- "Create Set table t_all_types_complex(
  C_ID  INTEGER, 
  C_intarray intarray, 
  C_strarray strarray, 
  C_json JSON(2048), 
  C_clob CLOB(2097088000),  
  C_blob BLOB(2097088000),  
  C_xml xml)"
  DBI::dbGetQuery(con, createQuery)
  
  #
  # Create a table with Teradata specific data types.
  # Here we have covered following types:
  #   1. byte
  #   2. All interval data types.
  #   3. All period data types.
  #
  createQuery <- "Create Set table t_td_supported_types(
  C_ID  INTEGER, 
  C_byte byte,  
  C_intvlyr interval year(2), 
  C_intvlyrmnth interval year(2) to month,  
  C_intvlmnth interval month(2),  
  C_intvldy interval day(2),  
  C_intvldyhr interval day(2) to hour,  
  C_intvldymin interval day(2) to minute,  
  C_intvldysec interval day(2) to second(0),  
  C_intvlhr interval hour(2),  
  C_intvlhrmin interval hour(2) to minute,  
  C_intvlhrsec interval hour(2) to second(0), 
  C_intvlmin interval minute(2),
  C_intvlminsec interval minute(2) to second(0),
  C_intvlsec interval second(2,0),
  C_perdate period(date),
  C_pertime period(time),
  C_pertimestamp period(timestamp),
  C_pertimewtz period(time with time zone),
  C_pertimestampwtz period(timestamp with time zone))"
  DBI::dbGetQuery(con, createQuery)
  
  createQuery <- "Create Set table t_number_supported(
  C_ID                        INTEGER,
  num_col_pres_scale      NUMBER(10,5),
  num_col_no_scale      NUMBER(10),
  num_col_max_pres            NUMBER(38,38),
  num_col_min_pres            NUMBER(1,0),
  num_col_18_pres             NUMBER(18,3),
  num_col_default      NUMBER)"
  DBI::dbGetQuery(con, createQuery)
})

# Test with both ASCII and utf8
conObjs <- c(con, conUTF8)

for (mycon in conObjs) {
  test_that("Unit Tests for Simple Data Types", {
    tblObj <- dplyr::tbl(con, "t_all_types_simple")
    columnInfo <- .ta.describe.columns(con, name = remote_name(tblObj))
    
    expected_col_names <- c("C_ID", "C_tint", "C_sint", "C_int", "C_bint", "C_decimal", "C_double", 
                            "C_float", "C_vbyte", "C_char", "C_vchar", "C_number")
    
    # Validate column names
    expect_equal(columnInfo$names, expected_col_names)
    
    # Validate Number of columns
    expect_equal(columnInfo$colnum, 12)
    
    # Validate types of the columns
    expect_equal(columnInfo$types[1], c("I"="int"))
    expect_equal(columnInfo$types[2], c("I1"="byteint"))
    expect_equal(columnInfo$types[3], c("I2"="smallint"))
    expect_equal(columnInfo$types[4], c("I"="int"))
    expect_equal(columnInfo$types[5], c("I8"="bigint"))
    expect_equal(columnInfo$types[6], c("D"="decimal"))
    expect_equal(columnInfo$types[7], c("F"="float"))
    expect_equal(columnInfo$types[8], c("F" ="float"))
    expect_equal(columnInfo$types[9], c("BV" = "varbyte"))
    expect_equal(columnInfo$types[10],c("CF" = "char"))
    expect_equal(columnInfo$types[11], c("CV" = "varchar"))
    expect_equal(columnInfo$types[12], c("N" = "number"))
    
    # No PTI table columns; Time Series Type for all columns will be NA
    expect_true(all(is.na(columnInfo$time_series_types)))
  })
  
  test_that("Unit Tests for Time/Date/Timestamp Data Types", {
    tblObj <- dplyr::tbl(mycon, dplyr::sql("select * from t_all_time_date_types"))
    columnInfo <- .ta.describe.columns.wrapper(con = con, from = remote_query(tblObj))
    
    expected_col_names <- c("C_ID", "C_date", "C_time", "C_timewtz", "C_timestamp", "C_timestampwtz")
    
    # Validate column names
    expect_equal(columnInfo$names, expected_col_names)
    
    # Validate Number of columns
    expect_equal(columnInfo$colnum, 6)
    
    # Validate types of the columns
    expect_equal(columnInfo$types[2], c("DA" ="date"))
    expect_equal(columnInfo$types[3], c("AT" = "time"))
    expect_equal(columnInfo$types[4], c("TZ"="time"))
    expect_equal(columnInfo$types[5], c("TS" = "timestamp"))
    expect_equal(columnInfo$types[6], c("SZ" = "timestamp"))
    
    # No PTI table columns; Time Series Type for all columns will be NA
    expect_true(all(is.na(columnInfo$time_series_types)))
  })
  
  test_that("Unit Tests for Complex Data Types", {
    tblObj <- dplyr::tbl(mycon, "t_all_types_complex")
    columnInfo <- .ta.describe.columns(con, remote_name(tblObj))
    
    expected_col_names <- c("C_ID", "C_intarray", "C_strarray", "C_json", "C_clob", "C_blob", "C_xml")
    
    # Validate column names
    expect_equal(columnInfo$names, expected_col_names)
    
    # Validate Number of columns
    expect_equal(columnInfo$colnum, 7)
    
    # Validate types of the columns
    expect_equal(columnInfo$types[1], c("I" = "int"))
    expect_equal(columnInfo$types[2], c("A1" = "array")) # Intarray
    expect_equal(columnInfo$types[3], c("A1" = "array")) # Strarray
    expect_equal(columnInfo$types[4], c("JN" = "json"))
    expect_equal(columnInfo$types[5], c("CO" = "clob"))
    expect_equal(columnInfo$types[6], c("BO" = "blob"))
    expect_equal(columnInfo$types[7], c("XM" = "xml"))
    
    # No PTI table columns; Time Series Type for all columns will be NA
    expect_true(all(is.na(columnInfo$time_series_types)))
  })
  
  test_that("Unit Tests for Teradata Specific Data Types", {
    tblObj <- dplyr::tbl(mycon, "t_td_supported_types")
    columnInfo <- .ta.describe.columns(con, remote_name(tblObj))
    
    expected_col_names <- c("C_ID", "C_byte", "C_intvlyr", "C_intvlyrmnth", "C_intvlmnth", 
                            "C_intvldy", "C_intvldyhr", "C_intvldymin", "C_intvldysec", "C_intvlhr",
                            "C_intvlhrmin", "C_intvlhrsec", "C_intvlmin", "C_intvlminsec", 
                            "C_intvlsec", "C_perdate", "C_pertime", "C_pertimestamp", 
                            "C_pertimewtz", "C_pertimestampwtz")
    
    # Validate column names
    expect_equal(columnInfo$names, expected_col_names)
    
    # Validate Number of columns
    expect_equal(columnInfo$colnum, 20)
    
    # Validate types of the columns
    expect_equal(columnInfo$types[1], c("I" = "int"))
    expect_equal(columnInfo$types[2], c("BF" = "byte"))
    expect_equal(columnInfo$types[3], c("YR" = "interval_year"))
    expect_equal(columnInfo$types[4], c("YM" = "interval_year_to_month")) 
    expect_equal(columnInfo$types[5], c("MO" = "interval_month")) 
    expect_equal(columnInfo$types[6], c("DY" = "interval_day")) 
    expect_equal(columnInfo$types[7], c("DH" = "interval_day_to_hour"))
    expect_equal(columnInfo$types[8], c("DM" = "interval_day_to_minute"))
    expect_equal(columnInfo$types[9], c("DS" = "interval_day_to_second"))
    expect_equal(columnInfo$types[10], c("HR" = "interval_hour"))
    expect_equal(columnInfo$types[11], c("HM" = "interval_hour_to_minute"))
    expect_equal(columnInfo$types[12], c("HS" = "interval_hour_to_second"))
    expect_equal(columnInfo$types[13], c("MI" = "interval_minute"))
    expect_equal(columnInfo$types[14], c("MS" = "interval_minute_to_second"))
    expect_equal(columnInfo$types[15], c("SC" = "interval_second"))
    expect_equal(columnInfo$types[16], c("PD" = "period_date"))
    expect_equal(columnInfo$types[17], c("PT" = "period_time"))
    expect_equal(columnInfo$types[18], c("PS" = "period_timestamp"))
    expect_equal(columnInfo$types[19], c("PZ" = "period_time_with_time_zone"))
    expect_equal(columnInfo$types[20], c("PM" = "period_timestamp_with_time_zone"))
    
    # No PTI table columns; Time Series Type for all columns will be NA
    expect_true(all(is.na(columnInfo$time_series_types)))
  })
  
  test_that("Unit Tests for Teradata Number type", {
    tblObj <- dplyr::tbl(mycon, "t_number_supported")
    columnInfo <- .ta.describe.columns(con, remote_name(tblObj))
    
    expected_col_names <- c("C_ID", "num_col_pres_scale", "num_col_no_scale", "num_col_max_pres",
                            "num_col_min_pres", "num_col_18_pres", "num_col_default")

    # Validate column names
    expect_equal(columnInfo$names, expected_col_names)
    
    # Validate Number of columns
    expect_equal(columnInfo$colnum, 7)
    
    # Validate types of the columns
    expect_equal(columnInfo$types[1], c("I" = "int"))
    expect_equal(columnInfo$types[2], c("N" = "number"))
    expect_equal(columnInfo$types[3], c("N" = "number"))
    expect_equal(columnInfo$types[4], c("N" = "number"))
    expect_equal(columnInfo$types[5], c("N" = "number"))
    expect_equal(columnInfo$types[6], c("N" = "number"))
    expect_equal(columnInfo$types[7], c("N" = "number"))
    
    # No PTI table columns; Time Series Type for all columns will be NA
    expect_true(all(is.na(columnInfo$time_series_types)))
  })
  
  test_that("Unit Tests for PTI tables", {
    
    ## PTI Sequenced table
    tblObj <- dplyr::tbl(con, "t_pti_table_seq")
    columnInfo <- .ta.describe.columns(con, remote_name(tblObj))
    
    expected_col_names <- c("TD_TIMECODE", "TD_SEQNO", "buoyid", "salinity", "temperature")
    
    # Validate column names
    expect_equal(columnInfo$names, expected_col_names)
    
    # Validate Number of columns
    expect_equal(columnInfo$colnum, 5)
    
    # Validate types of the columns
    expect_equal(columnInfo$types[1], c("TS" = "timestamp"))
    expect_equal(columnInfo$types[2], c("I" = "int"))
    expect_equal(columnInfo$types[3], c("I" = "int"))
    expect_equal(columnInfo$types[4], c("I" = "int"))
    expect_equal(columnInfo$types[5], c("I" = "int"))
    
    # PTI table columns 'TD_TIMECODE', 'TD_SEQNO' are present
    expect_true("TC" %in% columnInfo$time_series_types) # For TD_TIMECODE
    expect_true("TN" %in% columnInfo$time_series_types) # For TD_SEQ_NO
    
    ## PTI Non-sequenced table
    tblObj <- dplyr::tbl(con, "t_pti_table_nonseq")
    columnInfo <- .ta.describe.columns(con, remote_name(tblObj))
    
    expected_col_names <- c("TD_TIMECODE", "buoyid", "salinity", "temperature")
    
    # Validate column names
    expect_equal(columnInfo$names, expected_col_names)
    
    # Validate Number of columns
    expect_equal(columnInfo$colnum, 4)
    
    # Validate types of the columns
    expect_equal(columnInfo$types[1], c("TS" = "timestamp"))
    expect_equal(columnInfo$types[2], c("I" = "int"))
    expect_equal(columnInfo$types[3], c("I" = "int"))
    expect_equal(columnInfo$types[4], c("I" = "int"))
    
    # PTI table column 'TD_TIMECODE' is present; 'TD_SEQNO' is not present.
    expect_true("TC" %in% columnInfo$time_series_types) # For TD_TIMECODE
  })
}

testthat::teardown({
  tryCatch({
    DBI::dbGetQuery(con, "drop table t_all_types_simple")
  }, error=function(e) {   
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(con, "drop table t_all_types_complex")
  }, error=function(e) {     
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(con, "drop table t_td_supported_types")
  }, error=function(e) { 
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(con, "drop table t_pti_table_seq")
  }, error=function(e) {
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(con, "drop table t_pti_table_nonseq")
  }, error=function(e) {
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(con, "drop table t_all_time_date_types")
  }, error=function(e) { 
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(dbccon, "DROP TYPE SYSUDTLIB.intarray")
  }, error=function(e) { 
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(dbccon, "DROP TYPE SYSUDTLIB.strarray")
  }, error=function(e) { 
    # DO Nothing
  })
  tryCatch({
    DBI::dbGetQuery(con, "drop table t_number_supported")
  }, error=function(e) { 
    # DO Nothing
  })
  
  # Disconnect all the sessions.
  suppressWarnings(DBI::dbDisconnect(conUTF8))
  suppressWarnings(DBI::dbDisconnect(dbccon))
  suppressWarnings(td_remove_context())
})

