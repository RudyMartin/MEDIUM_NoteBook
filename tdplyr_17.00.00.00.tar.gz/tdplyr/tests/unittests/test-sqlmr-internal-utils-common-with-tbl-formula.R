################################################################################
# Following contains test cases for utility functions which will be accept tbl
# and process the results
################################################################################
context("Test tbl_teradata and Formula Processing Utility Functions.")

if(globalDTYPE == "odbc"){
  con <- suppressWarnings(DBI::dbConnect(odbc::odbc(), dsn = dsnName))
}else {
  con <- suppressWarnings(DBI::dbConnect(tdplyr::NativeDriver(), host = globalHost, uid = globalUID, pwd = globalPWD))
}

testthat::setup({
  # TEST SETUP - 
  tryCatch({
    DBI::dbGetQuery(con, "drop table validation_test_table")
  }, error=function(e) {     
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(con, "drop view validation_test_view")
  }, error=function(e) {     
    # DO Nothing
  })
  
  crtQuery <- "create multiset table validation_test_table (
  sn integer, 
  price real, 
  lotsize real, 
  bedrooms integer, 
  bathrms integer, 
  stories integer, 
  driveway varchar(10), 
  recroom varchar(10), 
  fullbase varchar(10), 
  gashw varchar(10), 
  airco varchar(10), 
  garagepl integer, 
  prefarea varchar(10), 
  homestyle varchar(20)
  )"
  DBI::dbGetQuery(con, crtQuery)
  DBI::dbGetQuery(con, "CREATE VIEW validation_test_view as select * from validation_test_table")
})

test_that("Unit test cases for '.teradataOnClauseFromDataFrame':", {
  # tbl with TABLE
  tbl_table <- dplyr::tbl(con, "validation_test_table")
  expect_equal(.teradataOnClauseFromDataFrame(tbl_table)$ref, gettextf("\"%s\".\"%s\"", .get_dbname(tbl_table), "validation_test_table"))
  expect_equal(.teradataOnClauseFromDataFrame(tbl_table)$refType, "TABLE")
  
  # tbl with VIEW
  tbl_view <- dplyr::tbl(con, "validation_test_view")
  expect_equal(.teradataOnClauseFromDataFrame(tbl_view)$ref, gettextf("\"%s\".\"%s\"", .get_dbname(tbl_table), "validation_test_view"))
  expect_equal(.teradataOnClauseFromDataFrame(tbl_view)$refType, "TABLE")
  
  # tbl with QUERY
  tbl_query <- dplyr::tbl(con, dplyr::sql("select * from validation_test_table"))
  expect_equal(.teradataOnClauseFromDataFrame(tbl_query)$ref, "select * from validation_test_table")
  expect_equal(.teradataOnClauseFromDataFrame(tbl_query)$refType, "QUERY")
})

test_that("Unit test cases for '.ta.parse.formula':", {
  tbl_table <- dplyr::tbl(con, "validation_test_table")
  tbl_view <- dplyr::tbl(con, "validation_test_view")
  tbl_query <- dplyr::tbl(con, dplyr::sql("select * from validation_test_table"))
  
  #### NEGATIVE CASES ####
  # Formula not empty
  formula <- ("")
  expect_error(.ta.parse.formula(formula, tbl_table), "Argument 'formula' should not contain empty string.")
  
  formula <- ""
  expect_error(.ta.parse.formula(formula, tbl_table), "Argument 'formula' should not contain empty string.")
  
  # Response variable is not provided or provided incorrectly.
  formula <- ( ~ price + lotsize + bedrooms + bathrms + stories + garagepl)
  expect_error(.ta.parse.formula(formula, tbl_table), "Response/Dependent variable is not specified correctly in the formula.")
  
  # Invalid term/dependent/response variable used.
  formula <- ("" ~ price + lotsize + bedrooms + bathrms + stories + garagepl)
  expect_error(.ta.parse.formula(formula, tbl_table), "invalid term in model formula")
  
  formula <- ("homestyle" ~ price + lotsize + bedrooms + bathrms + stories + garagepl)
  expect_error(.ta.parse.formula(formula, tbl_table), "invalid term in model formula")
  
  formula <- (x ~ price + lotsize + bedrooms + bathrms + stories + garagepl)
  expect_error(.ta.parse.formula(formula, tbl_table), "Response/Dependent variable x is not present in tbl_teradata")
  
  # Independent variables are not present.
  formula <- ( homestyle ~ x + y + z)
  expect_error(.ta.parse.formula(formula, tbl_table), "Independent variable x is not present in tbl_teradata")
  
  # Invalid variables used in formula.
  formula <- (homestyle ~ "price" + "lotsize")
  expect_error(.ta.parse.formula(formula, tbl_table), "invalid model formula in ExtractVars")
  
  #### POSITIVE CASES ####
  # tbl with table and formula containing numerics.
  formula.numeric <- (homestyle ~ price + lotsize + bedrooms + bathrms + stories + garagepl)
  expMatrix <- list()
  expMatrix <- rbind(expMatrix, list("homestyle", "price", "lotsize", "bedrooms", "bathrms", "stories", "garagepl"))
  expMatrix <- rbind(expMatrix, list("varchar", "float", "float", "int", "int", "int", "int"))
  colnames(expMatrix) <- c("homestyle", "price", "lotsize", "bedrooms", "bathrms", "stories", "garagepl")
  expect_equal(.ta.parse.formula(formula.numeric, tbl_table), expMatrix)
  
  # tbl with view and formula containing only categorical columns.
  formula.categorical <- (homestyle ~ driveway + recroom + fullbase + gashw + airco + prefarea)
  expMatrix <- list()
  expMatrix <- rbind(expMatrix, list("homestyle", "driveway", "recroom", "fullbase", "gashw", "airco", "prefarea"))
  expMatrix <- rbind(expMatrix, list("varchar", "varchar", "varchar", "varchar", "varchar", "varchar", "varchar"))
  colnames(expMatrix) <- c("homestyle", "driveway", "recroom", "fullbase", "gashw", "airco", "prefarea")
  expect_equal(.ta.parse.formula(formula.categorical, tbl_view), expMatrix)
  
  # tbl with query and formula containing all type of columns.
  formula.all <- (homestyle ~ driveway + recroom + fullbase + gashw + airco + prefarea + price + lotsize + bedrooms + bathrms + stories + garagepl)
  expMatrix <- list()
  expMatrix <- rbind(expMatrix, list("homestyle", "driveway", "recroom", "fullbase", "gashw", "airco", "prefarea", "price", "lotsize", "bedrooms", "bathrms", "stories", "garagepl"))
  expMatrix <- rbind(expMatrix, list("varchar", "varchar", "varchar", "varchar", "varchar", "varchar", "varchar", "float", "float", "int", "int", "int", "int"))
  colnames(expMatrix) <- c("homestyle", "driveway", "recroom", "fullbase", "gashw", "airco", "prefarea", "price", "lotsize", "bedrooms", "bathrms", "stories", "garagepl")
  expect_equal(.ta.parse.formula(formula.all, tbl_query), expMatrix)
})

test_that("Unit test cases for '.ta.getColumnsByType':", {
  # tbl with TABLE
  tbl_table <- dplyr::tbl(con, "validation_test_table")
  
  #### NEGATIVE CASES ####
  # Invalid type of variable is passed.
  # NULL is passed
  formula.term.matrix <- NULL
  expect_error(.ta.getColumnsByType(formula.term.matrix, tbl_table, "all"), "Argument 'formula.term.matrix' should be of matrix type")
  
  # NA is passed
  formula.term.matrix <- NA
  expect_error(.ta.getColumnsByType(formula.term.matrix, tbl_table, "all"), "Argument 'formula.term.matrix' should be of matrix type")
  
  # Character is passed
  formula.term.matrix <- "NULL"
  expect_error(.ta.getColumnsByType(formula.term.matrix, tbl_table, "all"), "Argument 'formula.term.matrix' should be of matrix type")
  
  # Invalid type is passed, type other than all, numeric, categorical
  formula.test <- (homestyle ~ price)
  formula.term.matrix <- .ta.parse.formula(formula.test, tbl_table)
  expect_null(.ta.getColumnsByType(formula.term.matrix, tbl_table, "invalid_arguments"))
  
  # Let's define some formula variables.
  formula.numeric <- (homestyle ~ price + lotsize + bedrooms + bathrms + stories + garagepl)
  formula.term.matrix <- .ta.parse.formula(formula.numeric, tbl_table)
  # Get 'categorical' columns.
  expect_equal(.ta.getColumnsByType(formula.term.matrix, tbl_table, "categorical"), character(0))
  # Get 'numerical' columns.
  expect_equal(.ta.getColumnsByType(formula.term.matrix, tbl_table, "numerical"), c("price", "lotsize", "bedrooms", "bathrms", "stories", "garagepl"))
  # Get all columns.
  expect_equal(.ta.getColumnsByType(formula.term.matrix, tbl_table, "all"), c("homestyle", "price", "lotsize", "bedrooms", "bathrms", "stories", "garagepl"))
  
  formula.categorical <- (homestyle ~ driveway + recroom + fullbase + gashw + airco + prefarea)
  formula.term.matrix <- .ta.parse.formula(formula.categorical, tbl_table)
  # Get 'categorical' columns.
  expect_equal(.ta.getColumnsByType(formula.term.matrix, tbl_table, "categorical"), c("driveway", "recroom", "fullbase", "gashw", "airco", "prefarea"))
  # Get 'numerical' columns.
  expect_equal(.ta.getColumnsByType(formula.term.matrix, tbl_table, "numerical"), character(0))
  # Get all columns.
  expect_equal(.ta.getColumnsByType(formula.term.matrix, tbl_table, "all"), c("homestyle", "driveway", "recroom", "fullbase", "gashw", "airco", "prefarea"))
  
  formula.all <- (homestyle ~ driveway + recroom + fullbase + gashw + airco + prefarea + price + lotsize + bedrooms + bathrms + stories + garagepl)
  formula.term.matrix <- .ta.parse.formula(formula.all, tbl_table)
  # Get 'categorical' columns.
  expect_equal(.ta.getColumnsByType(formula.term.matrix, tbl_table, "categorical"), c("driveway", "recroom", "fullbase", "gashw", "airco", "prefarea"))
  # Get 'numerical' columns.
  expect_equal(.ta.getColumnsByType(formula.term.matrix, tbl_table, "numerical"), c("price", "lotsize", "bedrooms", "bathrms", "stories", "garagepl"))
  # Get all columns.
  expect_equal(.ta.getColumnsByType(formula.term.matrix, tbl_table, "all"), c("homestyle", "driveway", "recroom", "fullbase", "gashw", "airco", "prefarea", "price", "lotsize", "bedrooms", "bathrms", "stories", "garagepl"))
})

testthat::teardown({
  # TEST SETUP - 
  tryCatch({
    DBI::dbGetQuery(con, "drop table validation_test_table")
  }, error=function(e) {     
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbGetQuery(con, "drop view validation_test_view")
  }, error=function(e) {     
    # DO Nothing
  })
})

suppressWarnings(DBI::dbDisconnect(con))
