context("Unit tests for copy_to with input as tbl object")

get_con_dbname <- function() {
  if(globalDTYPE == "odbc"){
    return(con@info$dbname)
  } else {
    return(.get_dbname(con))
  }
}

cleanup <- function() {
  for( i in 1:10){
    tryCatch({
      DBI::dbExecute(con, paste0("drop table t",i))
    }, error=function(e) { 
      # DO Nothing
    })
  }
  tryCatch({
    DBI::dbExecute(con, "drop table pi_table")
  }, error=function(e) { 
    # DO Nothing
  })
  tryCatch({
    DBI::dbExecute(con, "drop table nopi_table")
  }, error=function(e) { 
    # DO Nothing
  })
  tryCatch({
    DBI::dbExecute(con, "drop view view1")
  }, error=function(e) { 
    # DO Nothing
  })
}

testthat::setup({
  if(globalDTYPE == "odbc"){
    con <<- suppressWarnings(td_create_context(dsn = dsnName))
  } else {
    con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD, temp.database = "alice"))
  }
  #cleaning data base if tables are already exists
  cleanup()
  df <- data.frame(a = c('a','b','c'), b = c(1,2,3))
  copy_to(con,df,name = "pi_table",table.type = "PI", primary.index = "b", row.names = TRUE)
  copy_to(con,df,name = "nopi_table")
  DBI::dbExecute(con,"create view view1 as select * from pi_table")
})

#Negative test cases
test_that("creating a table from tbl which contains a PI table", {
  pi_table <- tbl(con,"pi_table")
  expect_error(copy_to(con,df = pi_table ,name = "t1", row.names = TRUE),
               "types and row.names argument\\(s) is/are not supported for tbl_teradata.")
  expect_error(copy_to(con,df = pi_table ,name = "t1", types = c("char(10)","int")),
               "types and row.names argument\\(s) is/are not supported for tbl_teradata.")
})
#df as tbl object test cases
test_that("creating a table from tbl which contains a PI table", {
  pi_table <- tbl(con,"pi_table")
  t1 <- copy_to(con,df = pi_table ,name = "t1")
  expect_equal(t1, tbl(con,"t1"))
  expect_true(unique(pull(t1,a) %in% pull(pi_table,a)))
  expect_true(unique(pull(t1,b) %in% pull(pi_table,b)))
  expect_true(unique(pull(t1,row_names) %in% pull(pi_table,row_names)))
  
  #passing query as input
  tblObj <- tbl(con,sql("select a from pi_table"))
  t2 <-copy_to(con,df = tblObj ,name = "t2")
  expect_equal(t2,tbl(con,"t2"))
  expect_true(unique(pull(t2,a) %in% pull(tblObj,a)))
})


test_that("creating a table from tbl which contains a NOPI table", {
  nopi_table <- tbl(con,"nopi_table")
  t3 <- copy_to(con,df = nopi_table ,name = "t3")
  expect_equal(t3, tbl(con,"t3"))
  expect_true(unique(pull(t3,a) %in% pull(nopi_table,a)))
  expect_true(unique(pull(t3,b) %in% pull(nopi_table,b)))
  
})

test_that("creating a table from tbl which contains a NOPI table", {
  nopi_table <- tbl(con,"nopi_table")
  t4 <- copy_to(con,df = nopi_table ,name = in_schema(get_con_dbname(), "t4"))
  expect_equal(t4, tbl(con,in_schema(get_con_dbname(),"t4")))
  expect_true(unique(pull(t4,a) %in% pull(nopi_table,a)))
  expect_true(unique(pull(t4,b) %in% pull(nopi_table,b)))
  
})

test_that("creating a PI table from tbl", {
  nopi_table <- tbl(con,"nopi_table")
  t5 <- copy_to(con,df = nopi_table ,name = "t5", table.type = "PI", primary.index = c("a","b"))
  expect_equal(t5, tbl(con,"t5"))
  expect_true(unique(pull(t5,a) %in% pull(nopi_table,a)))
  expect_true(unique(pull(t5,b) %in% pull(nopi_table,b)))
  
  #Checking primary index
  #Getting primary index columns from table
  primaryIndexDetails <- taQuery(paste0("select * from dbc.indicesx where UPPER(DatabaseName) = '",toupper(get_con_dbname()),
                                        "' and TableName = 't5'"))
  
  #Removing trailing spaces for column names
  primaryIndexColumns <- gsub("(^[[:space:]]+|[[:space:]]+$)", "",primaryIndexDetails$ColumnName)
  
  #Primary index should be on first column
  expect_true("b" %in% primaryIndexColumns)
  expect_true("a" %in% primaryIndexColumns)
  
})

test_that("creating a NOPI table from tbl", {
  nopi_table <- tbl(con,"nopi_table")
  t6 <- copy_to(con,df = nopi_table ,name = "t6", table.type = "NOPI")
  expect_equal(t6, tbl(con,"t6"))
  expect_true(unique(pull(t6,a) %in% pull(nopi_table,a)))
  expect_true(unique(pull(t6,b) %in% pull(nopi_table,b)))
  
  #Checking primary index
  expect_equal(grep("NO PRIMARY INDEX",paste0(DBI::dbGetQuery(con, "show table t6"),"")),1)
  
})

test_that("creating a PI table with magrittr from tbl", {
  nopi_table <- tbl(con,"nopi_table")
  t6 <- nopi_table %>% copy_to(con,df = .,table.type = "PI", primary.index = c("a","b"))
  tableName <- .get_source_definition(t6)
  expect_true(unique(pull(t6,a) %in% pull(nopi_table,a)))
  expect_true(unique(pull(t6,b) %in% pull(nopi_table,b)))
  
  #Checking primary index
  expect_equal(grep("PRIMARY INDEX \\( a ,b \\)",paste0(DBI::dbGetQuery(con, paste0("show table ",tableName)),"")),1)
  
  #table should be deleted after disconnection.
  expect_true(dbExistsTable(con,tableName))
  td_remove_context()
  if(globalDTYPE == "odbc"){
    con <<- suppressWarnings(td_create_context(dsn = dsnName))
  } else {
    con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD, temp.database = "alice"))
  }
  expect_false(dbExistsTable(con,tableName))
  
})

test_that("creating a NOPI table with magrittr from tbl", {
  nopi_table <- tbl(con,"nopi_table")
  t6 <- nopi_table %>% copy_to(con,df = .,table.type = "NOPI")
  tableName <- .get_source_definition(t6)
  expect_true(unique(pull(t6,a) %in% pull(nopi_table,a)))
  expect_true(unique(pull(t6,b) %in% pull(nopi_table,b)))
  
  #Checking primary index
  expect_equal(grep("NO PRIMARY INDEX",paste0(DBI::dbGetQuery(con, paste0("show table ",tableName)),"")),1)
  
  #table should be deleted after disconnection.
  expect_true(dbExistsTable(con,tableName))
  td_remove_context()
  if(globalDTYPE == "odbc"){
    con <<- suppressWarnings(td_create_context(dsn = dsnName))
  } else {
    con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD, temp.database = "alice"))
  }
  expect_false(dbExistsTable(con,tableName))
  
  
})

test_that("creating a table from tbl which contains a view", {

  view1 <- tbl(con,"view1")
  t7 <- copy_to(con,df = view1 ,name =  "t7")

  expect_equal(t7, tbl(con,"t7"))
  expect_true(unique(pull(t7,a) %in% pull(view1,a)))
  expect_true(unique(pull(t7,b) %in% pull(view1,b)))

})

test_that("creating a volatile table from tbl", {
  nopi_table <- tbl(con,"nopi_table")
  t8 <- copy_to(con,df = nopi_table ,name = "t8", temporary = TRUE)
  expect_equal(t8, tbl(con,"t8"))
  expect_true(unique(pull(t8,a) %in% pull(nopi_table,a)))
  expect_true(unique(pull(t8,b) %in% pull(nopi_table,b)))

  expect_true(dbExistsTable(con,"t8"))
  td_remove_context()
  if(globalDTYPE == "odbc"){
    con <<- suppressWarnings(td_create_context(dsn = dsnName))
  } else {
    con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD, temp.database = "alice"))
  }
  expect_false(dbExistsTable(con,"t8"))
})

test_that("creating a NOPI table with magrittr from tbl", {
  nopi_table <- tbl(con,"nopi_table")
  t6 <- nopi_table %>% copy_to(con,df = .,table.type = "NOPI")
  tableName <- .get_source_definition(t6)
  expect_true(unique(pull(t6,a) %in% pull(nopi_table,a)))
  expect_true(unique(pull(t6,b) %in% pull(nopi_table,b)))
})

test_that("creating a table with from tbl which is grouped by column", {
  df <- data.frame(a = c(1,2,1,2), b = c(3,4,3,4))
  t7 <- copy_to(con,df,"t8")
  t7 <- group_by(t7,b)
  t8 <- copy_to(con,t7,"t9")

  expect_equal(op_grps(t7), op_grps(t8))
})

test_that("throws error if tbl is from arrange", {
  df <- data.frame(a = c(1,2,1,2), b = c(3,4,3,4))
  t7 <- copy_to(con,df,"t10")
  t7 <- t7 %>% arrange(b)
  expect_error(copy_to(con,t7,"t11"),"Syntax error: ORDER BY is not allowed in subqueries")
})

testthat::teardown(
  {
    cleanup()
    td_remove_context()
  })
