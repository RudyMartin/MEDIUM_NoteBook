context ("Unit tests for Set Contexts")

userName <-  toupper(.ta.getUserName())
tempDatabaseName <- toupper(paste0("RTEST_TMP_DATABASE_",userName))

cleanup <- function() {
  # Drop database using the user 'dbc'
  dcon <- suppressWarnings(td_create_context(dsn = dsnName, uid = "dbc", pwd = "dbc"))
  DBI::dbExecute(dcon, paste0("DELETE DATABASE ",tempDatabaseName,";"))
  DBI::dbExecute(dcon, paste0("DROP DATABASE ",tempDatabaseName,";"))
  td_remove_context()
}

testthat::setup({
  # Create temporary database using the user 'dbc'.
  dcon <- suppressWarnings(td_create_context(dsn = dsnName, uid = "dbc", pwd = "dbc"))

  try(DBI::dbExecute(dcon, paste0("DELETE DATABASE ",tempDatabaseName,";")), silent = TRUE)
  try(DBI::dbExecute(dcon, paste0("DROP DATABASE ",tempDatabaseName,";")), silent = TRUE)

  DBI::dbExecute(dcon, paste0("CREATE DATABASE ",tempDatabaseName," AS PERM = 1e+06;" ))
  DBI::dbExecute(dcon, paste0("GRANT ALL ON ",tempDatabaseName," TO ", globalUID, ";" ))

  td_remove_context()
})

verifyConnection <- function(con) {
  expect_true(DBI::dbIsValid(con))
  expect_equal(as.character(class(con)), "Teradata")
  # check the entire class hierarchy
  hierarchy <- methods::getAllSuperClasses(methods::getClass(class(con)))
  expected_hierarchy <- c("OdbcConnection", "DBIConnection", "DBIObject")
  expect_equal(length(hierarchy), 3)
  expect_true(all.equal(hierarchy, expected_hierarchy))
  # check if the connection worked witha query
  expect_equal(nrow(DBI::dbGetQuery(con, "select user")), 1)
}
verifyRemoved <- function(con) {
  expect_false(DBI::dbIsValid(con))
  # Check if context is removed
  expect_true(is.null(.taConnection(silent = TRUE)))
  expect_true(is.null(.ta.getTempDatabase(silent = TRUE)))  
}

getDefaultDatabase <- function(con) {
  con@info$dbname
}

verifyContext <- function(con, defaultDB, tempDB) {
  expect_true(identical(con, .taConnection()))
  expect_equal(.ta.getDefaultDatabase(), defaultDB)
  expect_equal(.ta.getTempDatabase(), tempDB)
  context <- td_get_context()
  expect_true(identical(con, context$connection))
  expect_equal(.ta.getDefaultDatabase(), context$default.database)
  expect_equal(.ta.getTempDatabase(), context$temp.database)
}

test_that("set context with dbConnect connection", {
  con <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
  verifyConnection(con)
  # Context should not exist
  expect_false(.ta.contextExists())
  # Set context with a temp database and verify; ODBC deprecation warning.
  expect_warning(td_set_context(con, tempDatabaseName), "TDR_W1009")

  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, tempDatabaseName)
  # Successfully disconnect.
  td_remove_context()
})

test_that("set context with dbConnect connection - notifies user with deprecation warning", {
  con <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
  verifyConnection(con)

  # Context should not exist
  expect_false(.ta.contextExists())

  # Set context with a temp database and verify
  expect_warning(td_set_context(con),
    "ODBC Driver with tdplyr will be deprecated. Teradata recommends using Teradata SQL Driver for R when creating connection context.")

  # Context should exist now.
  expect_true(!is.null(td_get_context()))
  expect_true(.ta.contextExists())

  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)

  # Successfully disconnect.
  td_remove_context()
})

test_that("set context again with same connection", {
  con <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
  verifyConnection(con)
  # Context should not exist
  expect_false(.ta.contextExists())
  # Set context with a temp database and verify; ODBC deprecation warning
  expect_warning(td_set_context(con, tempDatabaseName), "TDR_W1009")
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, tempDatabaseName)

  # Set context again with same connection and different temp database should not disconnect.
  # ODBC deprecation warning
  expect_warning(td_set_context(con, defaultDB), "TDR_W1009")
  verifyConnection(con)

  # Set context again with same connection and same temp db.
  # ODBC deprecation warning
  expect_warning(td_set_context(con, defaultDB), "TDR_W1009")
  verifyConnection(con)
  verifyContext(con, defaultDB, defaultDB)

  # Calling multiple times makes no difference.
  # ODBC deprecation warning
  expect_warning(td_set_context(con, defaultDB), "TDR_W1009")
  verifyConnection(con)
  verifyContext(con, defaultDB, defaultDB)

  # Create another connection object with same info.
  con2 <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
  # ODBC deprecation warning
  expect_warning(td_set_context(con2, defaultDB), "TDR_W1009")
  verifyContext(con2, defaultDB, defaultDB)

  # Create another connection object with different con info should do GC
  # Due to the bug in odbc driver 16.20 use defaultDatabase param
  con3 <- DBI::dbConnect(odbc::odbc(), dsn = dsnName, DefaultDatabase = tempDatabaseName)
  expect_warning(td_set_context(con3, defaultDB),
    "Overwriting current context. Any non-persisted objects created using analytic functions will be removed")
  verifyConnection(con3)
  # Since the context and connection is overwritten, con2 is invalid.
  expect_true(!dbIsValid(con2))
  verifyConnection(con)
  verifyContext(con3, tempDatabaseName, defaultDB)

  td_remove_context()
  verifyRemoved(con3)
  # The other two connections must be valid
  expect_warning(DBI::dbDisconnect(con), regexp = NA)
})

test_that("set context again with different connection", {
  con <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
  verifyConnection(con)
  # Context should not exist
  expect_false(.ta.contextExists())
  # Set context with a temp database and verify; ODBC deprecation warning.
  expect_warning(td_set_context(con, tempDatabaseName), "TDR_W1009")
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, tempDatabaseName)

  # Create another connection con1
  con1 <- DBI::dbConnect(odbc::odbc(), dsn = dsnName, DefaultDatabase = tempDatabaseName)
  verifyConnection(con1)
  # Verify previous context
  verifyContext(con, defaultDB, tempDatabaseName)
  # Set context should throw warning
  expect_warning(td_set_context(con1, defaultDB),
    "Overwriting current context. Any non-persisted objects created using analytic functions will be removed")
  # The connection 'con' is overwritten and is not valid.
  expect_false(DBI::dbIsValid(con))
  expect_true(DBI::dbIsValid(con1))
  verifyContext(con1, tempDatabaseName, defaultDB)

  td_remove_context()
  verifyRemoved(con1)
})

test_that("set context after using create context", {
  expect_warning(con <- td_create_context(dsnName), "TDR_W1009")
  verifyConnection(con)
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)

  # Use set context after create context
  con1 <- DBI::dbConnect(odbc::odbc(), dsn = dsnName, DefaultDatabase = tempDatabaseName)
  verifyConnection(con)
  verifyConnection(con1)
  # Verify prev context
  verifyContext(con, defaultDB, defaultDB)
  defaultDB <- getDefaultDatabase(con1)
  # Context is overwritten because there is change in default database from "alice" to tempDatabase.
  expect_warning(td_set_context(con1, defaultDB), "TDR_W1002")
  con1 <- td_get_context()$connection

  # Prev connection is disconnected
  expect_false(DBI::dbIsValid(con))
  verifyConnection(con1)
  verifyContext(con1, tempDatabaseName, defaultDB)

  td_remove_context()
  verifyRemoved(con1)
  verifyRemoved(con)
})

test_that("set context after using create context but identical objects", {
  # Use set context with same con object does nothing
  expect_warning(con <- td_create_context(dsnName), "TDR_W1009")
  verifyConnection(con)
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)
  # Switch context without disconnecting
  # ODBC deprecation warning.
  expect_warning(td_set_context(con, tempDatabaseName), "TDR_W1009")
  # Connection is still active.
  verifyConnection(con)
  verifyContext(con, defaultDB, tempDatabaseName)

  td_remove_context()
  verifyRemoved(con)
})

test_that("Negative cases: set context with invalid inputs", {

  expect_error(td_set_context("INVALID_CON"), "Invalid type of arguments passed to following: \n\tArgument 'con' must be of 'Teradata or TeradataConnection' datatype. Multiple values are not supported.")
  # Same with error code
  expect_error(td_set_context("INVALID_CON"), "TDR_E3005")
  expect_error(td_set_context(NULL), "Following required arguments are missing: con")
  expect_error(td_set_context(NA), "Invalid type of arguments passed to following: \n\tArgument 'con' must be of 'Teradata or TeradataConnection' datatype. Multiple values are not supported.")

  # Create connection and disconnect and then set context
  con <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
  DBI::dbDisconnect(con)
  # Supressing ODBC deprecation warning.
  expect_error(suppressWarnings(td_set_context(con), "TDR_E1005"))
  expect_error(suppressWarnings(td_set_context(con), "Invalid connection object"))

  # Set context again with null / incorrect temp.database
 con <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
  verifyConnection(con)
  # Context should not exist.
  expect_false(.ta.contextExists())
  defaultDB <- getDefaultDatabase(con)
  # Set context with a incorrect temp database must ignore it; ODBC deprecation warning.
  expect_warning(td_set_context(con, "INVALID_DB_X"), "TDR_W1009")
  verifyContext(con, defaultDB, "INVALID_DB_X")
  td_remove_context()
  verifyRemoved(con)
})

testthat::teardown({
  cleanup()
})