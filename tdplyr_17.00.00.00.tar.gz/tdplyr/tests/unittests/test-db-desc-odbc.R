context("Tests for Teradata tbl output with ODBC driver")

test_con <- NULL

testthat::setup(
  {
    if(globalDTYPE == "odbc"){
      test_con <<- td_create_context(dsn = dsnName)
    } else {
      test_con <<- td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD)
    }
  }
)


test_that("td.db_desc.output option works", {

  # the td.db_desc.output option is a list of 3 elements (currently)
  # db - shows the Database version
  # driver - shows the tdodbc version
  # machine - shows the host name, servername, port, database
  opts <- getOption('td.db_desc.output')

  # by default, these should all be shown
  res <- db_desc(test_con)

  expect_true(grepl('Teradata+', res) == 1L)
  
  if(globalDTYPE == "odbc"){
    expect_true(grepl('(Teradata ODBC)+', res) == 1L)
  }else{
    expect_true(grepl('(Teradata Native Driver)+', res) == 1L)
  }
    
  expect_true(grepl('@', res) == 1L)

  # only show db
  opts <- list(db = TRUE, driver = FALSE, machine = FALSE)
  options(td.db_desc.output = opts)
  opts <- getOption('td.db_desc.output')
  res <- db_desc(test_con)

  expect_true(grepl('Teradata?', res) == 1L && grepl('Teradata+', res) == 1L)
  expect_false(grepl('(Teradata ODBC)+', res) == 1L)
  expect_false(grepl('@', res) == 1L)

  # only show driver
  opts <- list(db = FALSE, driver = TRUE, machine = FALSE)
  options(td.db_desc.output = opts)
  opts <- getOption('td.db_desc.output')
  res <- db_desc(test_con)

  expect_true(grepl('Teradata?', res) == 1L && grepl('Teradata+', res) == 1L)
  if(globalDTYPE == "odbc"){
    expect_true(grepl('(Teradata ODBC)+', res) == 1L)
  }else{
    expect_true(grepl('(Teradata Native)+', res) == 1L)
  }
  expect_false(grepl('@', res) == 1L)

  # only show machine
  opts <- list(db = FALSE, driver = FALSE, machine = TRUE)
  options(td.db_desc.output = opts)
  opts <- getOption('td.db_desc.output')
  res <- db_desc(test_con)

  expect_false(grepl('Teradata+', res) == 1L)
  expect_false(grepl('(Teradata ODBC)+', res) == 1L)
  expect_true(grepl('@', res) == 1L)

  # db, machine
  opts <- list(db = TRUE, driver = FALSE, machine = TRUE)
  options(td.db_desc.output = opts)
  opts <- getOption('td.db_desc.output')
  res <- db_desc(test_con)

  expect_true(grepl('Teradata+', res) == 1L)
  expect_false(grepl('(Teradata ODBC)+', res) == 1L)
  expect_true(grepl('@', res) == 1L)

  # db, driver
  opts <- list(db = TRUE, driver = TRUE, machine = FALSE)
  options(td.db_desc.output = opts)
  opts <- getOption('td.db_desc.output')
  res <- db_desc(test_con)

  expect_true(grepl('Teradata+', res) == 1L)
  if(globalDTYPE == "odbc"){
    expect_true(grepl('(Teradata ODBC)+', res) == 1L)
  }else{
    expect_true(grepl('(Teradata Native)+', res) == 1L)
  }
  expect_false(grepl('@', res) == 1L)

  # machine, driver
  opts <- list(db = FALSE, driver = TRUE, machine = TRUE)
  options(td.db_desc.output = opts)
  opts <- getOption('td.db_desc.output')
  res <- db_desc(test_con)

  expect_true(grepl('Teradata?', res) == 1L && grepl('Teradata+', res) == 1L)
  if(globalDTYPE == "odbc"){
    expect_true(grepl('(Teradata ODBC)+', res) == 1L)
  }else{
    expect_true(grepl('(Teradata Native)+', res) == 1L)
  }
  expect_true(grepl('@', res) == 1L)

  # show nothing will only show Teradata
  opts <- list(db = FALSE, driver = FALSE, machine = FALSE)
  options(td.db_desc.output = opts)
  opts <- getOption('td.db_desc.output')
  res <- db_desc(test_con)

  expect_true(grepl('Teradata?', res) == 1L && grepl('Teradata+', res) == 1L)
  expect_false(grepl('(Teradata ODBC)+', res) == 1L)
  expect_false(grepl('@', res) == 1L)

  # you can also set the option to NULL
  options(td.db_desc.output = NULL)
  res <- db_desc(test_con)

  expect_true(grepl('Teradata?', res) == 1L && grepl('Teradata+', res) == 1L)
  expect_false(grepl('(Teradata ODBC)+', res) == 1L)
  expect_false(grepl('@', res) == 1L)
})

testthat::teardown(
  {
    # set the option back to default
    options(td.db_desc.output = list(db  = TRUE, driver = TRUE, machine = TRUE))
    td_remove_context()
  }
)
