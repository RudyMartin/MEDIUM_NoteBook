context("Unit tests for loadExampleData")

create_db_context <- function(temp.database = NULL) {
  # Creating context based on the temp.database argument and driver type.
  if(globalDTYPE == "odbc"){
    if (!is.null(temp.database))
      con <<- suppressWarnings(td_create_context(dsn = dsnName, temp.database = temp.database))
    else
      con <<- suppressWarnings(td_create_context(dsn = dsnName))
  } else {
    if (!is.null(temp.database))
      con <<- suppressWarnings(td_create_context(dType = "native", host = globalHost, uid = globalUID, 
                                                 pwd = globalPWD, temp.database = temp.database))
    else
      con <<- suppressWarnings(td_create_context(dType = "native", host = globalHost, uid = globalUID, 
                                                 pwd = globalPWD))
  }
}

remove_db_context <- function() {
  # Dropping created tables and removing context.
  try(DBI::dbExecute(con, paste0("drop table \"", td_get_context()$temp.database, "\".\"strsimilarity_input\";")), 
      silent = TRUE)
  try(DBI::dbExecute(con, paste0("drop table \"", td_get_context()$temp.database, "\".\"antiselect_input\";")), 
      silent = TRUE)
  try(DBI::dbExecute(con, paste0("drop table \"", td_get_context()$temp.database, "\".\"attribution_sample_table1\";")),
      silent = TRUE)
  try(DBI::dbExecute(con, paste0("drop table \"", td_get_context()$temp.database, "\".\"model2_table\";")),
      silent = TRUE)
  try(DBI::dbExecute(con, paste0("drop table \"", td_get_context()$temp.database, "\".\"ocean_buoys_nonseq\";")),
      silent = TRUE)
  try(DBI::dbExecute(con, paste0("drop table \"", td_get_context()$temp.database, "\".\"ocean_buoys_seq\";")),
      silent = TRUE)
  try(DBI::dbExecute(con, paste0("drop table \"", td_get_context()$temp.database, "\".\"ocean_buoys_nonpti\";")),
      silent = TRUE)
  td_remove_context()
}

username <- toupper(Sys.getenv("USERNAME"))
tempDatabaseName <- paste0("R_LOAD_EX_", username)

cleanup <- function() {
  # Drop database using the user 'dbc'
  if(globalDTYPE == "native")
    dcon <<- suppressWarnings(td_create_context(dType = "native", host = globalHost, uid = "dbc", pwd = "dbc"))
  else
    dcon <<- suppressWarnings(td_create_context(dsn = dsnName, uid = "dbc", pwd = "dbc"))
  DBI::dbExecute(dcon, paste0("DELETE DATABASE ",tempDatabaseName,";"))
  DBI::dbExecute(dcon, paste0("DROP DATABASE ",tempDatabaseName,";"))
  td_remove_context()
}

testthat::setup({
  # Create temporary database using the user 'dbc'.
  if(globalDTYPE == "native")
    dcon <<- suppressWarnings(td_create_context(dType = "native", host = globalHost, uid = "dbc", pwd = "dbc"))
  else
    dcon <<- suppressWarnings(td_create_context(dsn = dsnName, uid = "dbc", pwd = "dbc"))
  try(DBI::dbExecute(dcon, paste0("DELETE DATABASE ",tempDatabaseName,";")), silent = TRUE)
  try(DBI::dbExecute(dcon, paste0("DROP DATABASE ",tempDatabaseName,";")), silent = TRUE)

  DBI::dbExecute(dcon, paste0("CREATE DATABASE ",tempDatabaseName," AS PERM = 1e+06;" ))
  DBI::dbExecute(dcon, paste0("GRANT ALL ON ",tempDatabaseName," TO ", globalUID, ";" ))
  
  td_remove_context()

  # Removing all the tables in intended connection.
  create_db_context()
  remove_db_context()
})


test_that("Negative test scenario where no test table is given", {
  # Missing required arguments check.
  expect_error(loadExampleData(), "argument \"fileName\" is missing, with no default")
  expect_error(loadExampleData("antiselect_example"), "Following required arguments are missing: ...")
  
  # Argument type check.
  expect_error(loadExampleData(123, "hello"), 
               "Argument 'fileName' must be of 'character' datatype. Multiple values are not supported.")
  expect_error(loadExampleData("antiselect_example", 123), 
               "Argument '...' must be of 'character' datatype or a vector of 'character' datatype\\(s).")
  expect_error(loadExampleData("antiselect_example", 123, TRUE), 
               "Argument '...' must be of 'character' datatype or a vector of 'character' datatype\\(s).")
  
  # Empty argument passed.
  expect_error(loadExampleData("  ", "csv_file_name"), 
               "Argument 'fileName' should not contain empty string.")
  expect_error(loadExampleData("antiselect_example", "hello", "   "), 
               "Argument '...' should not contain empty string.")
  
  # Invalid table name passed.
  expect_error(loadExampleData("antiselect_example", "hello", "abcd"), 
               "The example file 'antiselect_example' does not load the table\\(s) 'hello', 'abcd'.")
  expect_error(loadExampleData("antiselect_example", "hello"), 
               "The example file 'antiselect_example' does not load the table\\(s) 'hello'.")
})

test_that("Positive test scenario without temp.database argument", {
  # Creating context
  create_db_context()
  
  # td_antiselect_sqle uses load
  expect_error(suppressWarnings(tbl(con, "antiselect_input"), "Object 'antiselect_input' does not exist"))
  # td_string_similarity_mle uses loadByTypes
  expect_error(suppressWarnings(tbl(con,  "strsimilarity_input"), "Object 'strsimilarity_input' does not exist"))
  
  loadExampleData("antiselect_example", "antiselect_input")
  loadExampleData("stringsimilarity_example", "strsimilarity_input")
  # Loads multiple tables in one call.
  loadExampleData("attribution_example", "attribution_sample_table1", "model2_table")
  
  df <- tbl(con, "antiselect_input")
  expect_equal(td_nrow(df), bit64::as.integer64(7))
  
  df <- tbl(con, "strsimilarity_input")
  expect_equal(td_nrow(df), bit64::as.integer64(12))
  
  df <- tbl(con, "attribution_sample_table1")
  expect_equal(td_nrow(df), bit64::as.integer64(5))

  df <- tbl(con, "model2_table")
  expect_equal(td_nrow(df), bit64::as.integer64(4))
  
  # PTI tables (ocean_buoys)
  loadExampleData("time_series_example", "ocean_buoys_nonseq")
  loadExampleData("time_series_example", "ocean_buoys_seq")
  loadExampleData("time_series_example", "ocean_buoys_nonpti")
  
  df <- tbl(con, "ocean_buoys_nonseq")
  expect_equal(td_nrow(df), bit64::as.integer64(27))
  
  df <- tbl(con, "ocean_buoys_seq")
  expect_equal(td_nrow(df), bit64::as.integer64(28))
  
  df <- tbl(con, "ocean_buoys_nonpti")
  expect_equal(td_nrow(df), bit64::as.integer64(27))

  remove_db_context()
})


test_that("Positive test scenario with temp.database argument", {
  # Creating context
  create_db_context(temp.database = tempDatabaseName)
  
  # td_antiselect_sqle uses load
  expect_error(suppressWarnings(tbl(con, in_schema(tempDatabaseName, "antiselect_input")), 
                                paste0("Object '", tempDatabaseName,".antiselect_input' does not exist")))
  # td_string_similarity_mle uses loadByTypes
  expect_error(suppressWarnings(tbl(con,  in_schema(tempDatabaseName, "strsimilarity_input")), 
                                paste0("Object '", tempDatabaseName,".strsimilarity_input' does not exist")))
  
  loadExampleData("antiselect_example", "antiselect_input")
  loadExampleData("stringsimilarity_example", "strsimilarity_input")
  # Loads multiple tables in one call.
  loadExampleData("attribution_example", "attribution_sample_table1", "model2_table")

  df <- tbl(con, in_schema(tempDatabaseName, "antiselect_input"))
  expect_equal(td_nrow(df), bit64::as.integer64(7))
  
  df <- tbl(con, in_schema(tempDatabaseName, "strsimilarity_input"))
  expect_equal(td_nrow(df), bit64::as.integer64(12))
  
  df <- tbl(con, in_schema(tempDatabaseName, "attribution_sample_table1"))
  expect_equal(td_nrow(df), bit64::as.integer64(5))

  df <- tbl(con, in_schema(tempDatabaseName, "model2_table"))
  expect_equal(td_nrow(df), bit64::as.integer64(4))
  
  # PTI tables (ocean_buoys)
  loadExampleData("time_series_example", "ocean_buoys_nonseq")
  loadExampleData("time_series_example", "ocean_buoys_seq")
  loadExampleData("time_series_example", "ocean_buoys_nonpti")
  
  df <- tbl(con, in_schema(tempDatabaseName, "ocean_buoys_nonseq"))
  expect_equal(td_nrow(df), bit64::as.integer64(27))
  
  df <- tbl(con, in_schema(tempDatabaseName, "ocean_buoys_seq"))
  expect_equal(td_nrow(df), bit64::as.integer64(28))
  
  df <- tbl(con, in_schema(tempDatabaseName, "ocean_buoys_nonpti"))
  expect_equal(td_nrow(df), bit64::as.integer64(27))

  remove_db_context()
})

testthat::teardown (
  {
    cleanup()
  }
)