context("Unit tests for dplyr::db_drop_table and DBI::dbRemoveTable functions")

testthat::setup({
  if(globalDTYPE == "odbc"){
    con <<- suppressWarnings(td_create_context(dsn = dsnName))
  } else {
    con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD))
  }
  
  #Droping the tables if tables already exists otherwise test cases will fails.
  taQuery("drop table dropTableTest1", stopOnError = FALSE)
  taQuery("drop table dropTableTest2", stopOnError = FALSE)
  taQuery("drop table dropTableTest3", stopOnError = FALSE)
  taQuery("drop table dropTableTest4", stopOnError = FALSE)
  taQuery("create table dropTableTest1(a integer)")
  taQuery("create table dropTableTest2(a integer)")
  taQuery("create table dropTableTest3(a integer)")
  taQuery("create table dropTableTest4(a integer)")
})

test_that("drop the table using db_drop_table", {
  dplyr::db_drop_table(con,"dropTableTest1")
  expect_false(db_has_table(con,"dropTableTest1"))
})

test_that("drop the table using db_drop_table and in_schema", {
  if(globalDTYPE == "odbc"){
    expect_equal(dplyr::db_drop_table(con,dbplyr::in_schema(con@info$dbname,"dropTableTest2")),0)
  } else {
    dplyr::db_drop_table(con,dbplyr::in_schema(.get_dbname(con),"dropTableTest2"))
    expect_false(db_has_table(con,"dropTableTest2"))
  }
})

test_that("returns error as table does not exists using db_drop_table", {
  expect_error(dplyr::db_drop_table(con,force = FALSE,"dropTableTest1"),"Object 'dropTableTest1' does not exist")
})

test_that("with force using db_drop_table", {
  # Should not throw any error with force = TRUE
  expect_error(dplyr::db_drop_table(con, force = TRUE, "dropTableTest1"), regexp = NA)
})

test_that("drop the table using dbRemoveTable", {
  expect_silent(DBI::dbRemoveTable(con,"dropTableTest3"))
})

test_that("drop the table using dbRemoveTable and in_schema", {
  if(globalDTYPE == "odbc"){
    expect_error(DBI::dbRemoveTable(con,dbplyr::in_schema(con@info$dbname,"dropTableTest4")), regexp = NA)
  } else {
    expect_error(DBI::dbRemoveTable(con,dbplyr::in_schema(.get_dbname(con),"dropTableTest4")), regexp = NA)
  }
})

test_that("returns error as table does not exists using dbRemoveTable", {
  expect_error(DBI::dbRemoveTable(con,"dropTableTest2"),"Object 'dropTableTest2' does not exist")
})

test_that("returns error as table does not exists using dbRemoveTable", {
  expect_error(DBI::dbRemoveTable(con,"dropTableTest3"),"Object 'dropTableTest3' does not exist")
})

test_that("returns error as table does not exists using dbRemoveTable", {
  expect_error(DBI::dbRemoveTable(con,"dropTableTest4"),"Object 'dropTableTest4' does not exist")
})

testthat::teardown({
  taQuery("drop table dropTableTest1", stopOnError = FALSE)
  taQuery("drop table dropTableTest2", stopOnError = FALSE)
  taQuery("drop table dropTableTest3", stopOnError = FALSE)
  taQuery("drop table dropTableTest4", stopOnError = FALSE)
  td_remove_context()
})