context("Unit tests for dplyr::db_has_table and DBI::dbExistsTable functions")

get_con_dbname <- function() {
  if(globalDTYPE == "odbc"){
    return(con@info$dbname)
  } else {
    return(.get_dbname(con))
  }
}

testthat::setup({
  if(globalDTYPE == "odbc"){
    con <<- suppressWarnings(td_create_context(dsn = dsnName))
  }else {
    con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD))
  }
  
  taQuery("drop table table_exists", stopOnError = FALSE)
  taQuery("create table table_exists(a integer)")
})

test_that("table exists check using db_has_table", {
  expect_true(dplyr::db_has_table(con,"table_exists"))
})

test_that("table does not check exists  using db_has_table", {
  expect_false(dplyr::db_has_table(con,"table_does_not_exists"))
})

test_that("table exists check using db_has_table and in_schema", {
  expect_true(dplyr::db_has_table(con,dbplyr::in_schema(get_con_dbname(),"table_exists")))
})

test_that("table does not exists check using db_has_table and in_schema", {
  expect_false(dplyr::db_has_table(con,dbplyr::in_schema(get_con_dbname(),"table_does_not_exists")))
})

test_that("table exists using check dbExistsTable", {
  expect_true(DBI::dbExistsTable(con,"table_exists"))
})

test_that("table does not exists check using dbExistsTable", {
  expect_false(DBI::dbExistsTable(con,"table_does_not_exists"))
})

test_that("table exists using check dbExistsTable and in_schema", {
  expect_true(DBI::dbExistsTable(con,dbplyr::in_schema(get_con_dbname(),"table_exists")))
})

test_that("table does not exists check using dbExistsTable", {
  expect_false(DBI::dbExistsTable(con,dbplyr::in_schema(get_con_dbname(),"table_does_not_exists")))
})

testthat::teardown({
    taQuery("drop table table_exists")
    td_remove_context()
  })