context(".extractTableName tests")


test_that("get Table name from fully qualified name", {
  expect_that(
    .extractTableName("dbc.temp"), equals("temp")
  )
})

test_that("Object contains only table name", {
  expect_that(
    .extractTableName("temp"), equals("temp")
  )
})

test_that("database inside user default database ", {
  expect_that(
    .extractTableName("dbc.test.temp"), equals("test.temp")
  )
})

# Testing all possible combinations of schemaname.tablename specifications
# Without quoting, quoting both, quoting only dbname, quoting only tablename
# This will be useful for in_schema
objNames <- c("db1.tab1", "\"db.1\".tab.1","\"db.1\".tab1", "\"db.1\".\"tab.1\"", "db1.\"tab.1\"")

test_that("get table name name from fully qualified name", {
  expect_identical(
    .extractTableNameQuoted(objNames[1]), "tab1")
  expect_identical(
    .extractTableNameQuoted(objNames[2]), "tab.1")
  expect_identical(
    .extractTableNameQuoted(objNames[3]), "tab1")
  expect_identical(
    .extractTableNameQuoted(objNames[4]), "tab.1")
  expect_identical(
    .extractTableNameQuoted(objNames[5]), "tab.1")
})