context("tests for check types functions in taTypeChecks.R")

# functions included here:
# .CheckVirtualObject
# .checkPkg

test_that(".CheckVirtualObject gets the correct error message", {

  # mock a simple object
  df <- structure(list(), class = "not.a.tbl")

  expect_error(.CheckVirtualObject(df), 
               "df is not a class of tbl_teradata")

  # with error code
  expect_error(.CheckVirtualObject(df), 
               "TDR_E1006")

  df <- structure(list(), class = "tbl_teradata")

  expect_error(.CheckVirtualObject(df, type = "tbl_teradata"), 
               regexp = NA)

  expect_error(.CheckVirtualObject(df), 
               regexp = NA)

  expect_error(.CheckVirtualObject(df, type = c("x", "y", "z")), 
               "df is not a class of x or y or z.")

  expect_error(.CheckVirtualObject(df, type = c("x")), 
               "df is not a class of x.")
})

test_that(".checkPkg works", {
  expect_error(.checkPkg(.ta.getPackageName()), regexp = NA)
  expect_error(.checkPkg("INVALID_PKG"))
})
