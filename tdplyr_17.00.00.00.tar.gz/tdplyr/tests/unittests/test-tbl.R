context("Basic unit tests for tbl_teradata and attribute getters.")

userName <-  toupper(.ta.getUserName())
# Create database with username suffix to avoid issues when sharing same cluster
tempDatabaseName <- toupper(paste0("RTEST_TMP_DATABASE_",userName))

if(globalDTYPE == "odbc"){
  con <- suppressWarnings(td_create_context(dsn = dsnName))
} else {
  con <- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD, temp.database = "alice"))
}

get_con_dbname <- function() {
  if(globalDTYPE == "odbc"){
    return(con@info$dbname)
  } else {
    return(.get_dbname(con))
  }
}

cleanup <- function() {
  tryCatch({
      DBI::dbExecute(con, "drop table t1")
    }, error=function(e) { 
      # DO Nothing
    })
  
  tryCatch({
    DBI::dbExecute(con, "drop table t2")
  }, error=function(e) { 
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbExecute(con, "drop view v1")
  }, error=function(e) { 
    # DO Nothing
  })

  if(globalDTYPE == "odbc"){
    dcon <- DBI::dbConnect(odbc::odbc(), dsn = dsnName, uid = "dbc", pwd = "dbc")
  } else {
    dcon <- DBI::dbConnect(tdplyr::NativeDriver(), host = globalHost, uid = "dbc", pwd = "dbc", dType = "native")
  }
  # Delete database first, then drop
  tryCatch({
      DBI::dbExecute(dcon, paste0("DELETE DATABASE ",tempDatabaseName,";" ))
  }, error=function(e) { 
    # DO Nothing
  })
  tryCatch({
    DBI::dbExecute(dcon, paste0("DROP DATABASE ",tempDatabaseName,";" ))
  }, error=function(e) { 
    # DO Nothing
  })
  DBI::dbDisconnect(dcon)
}
testthat::setup({
  # Initial Cleanup
  cleanup()
  # create some tables 
  DBI::dbExecute(con, "create table t1(i int, j int) primary index(i, j)")
  DBI::dbExecute(con, "create table t2(i varchar(64), j timestamp(6)) no primary index")
  DBI::dbExecute(con, "create view v1 as (sel * from t2)")
  DBI::dbExecute(con, "insert into t1(i, j) values (1, 101)")
  DBI::dbExecute(con, "insert into t1(i, j) values (2, 102)")
  DBI::dbExecute(con, "insert into t1(i, j) values (3, 103)")
  DBI::dbExecute(con, "insert into t1(i, j) values (4, 104)")
  DBI::dbExecute(con, "insert into t1(i, j) values (5, 105)")
  
  if(globalDTYPE == "odbc"){
    dcon <- DBI::dbConnect(odbc::odbc(), dsn = dsnName, uid = "dbc", pwd = "dbc")
  } else {
    dcon <- DBI::dbConnect(tdplyr::NativeDriver(), host = globalHost, uid = "dbc", pwd = "dbc", dType = "native")
  }
  tryCatch({
    DBI::dbExecute(dcon, paste0("CREATE DATABASE ",tempDatabaseName," AS PERM = 1e+06;" ))
    DBI::dbExecute(dcon, paste0("GRANT ALL ON ",tempDatabaseName," TO ", globalUID, ";" ))
  }, error=function(e) { 
    print(e)
  })
  DBI::dbDisconnect(dcon)

  # Create tables in this new database
  expect_error(
  DBI::dbExecute(con, gettextf("create table %s.t1(i int, j int) primary index(i, j)", tempDatabaseName)),
  regexp = NA)
  expect_error(
  DBI::dbExecute(con, gettextf("insert into %s.t1(i, j) values (1, 2)", tempDatabaseName)),
  regexp = NA)

})  

verifyTblHierarchy <- function(t) {
  # check the entire class hierarchy
  hierarchy <- class(t)
  # we are inheriting from tbl_dbi sublass
  expected_hierarchy <- c("tbl_teradata", "tbl_dbi", "tbl_sql", "tbl_lazy", "tbl" )
  expect_equal(length(hierarchy), length(expected_hierarchy))
  expect_true(all.equal(hierarchy, expected_hierarchy))
}

test_that("tbl_teradata points to PI table", {
  res <- dplyr::tbl(con, "t1")
  verifyTblHierarchy(res)
  expect_match(res$ops$x, "t1")
  expect_is(res$ops$x, "ident")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  
  expect_equal(.get_source_type(res), "table")
  expect_equal(.get_source_definition(res), "t1")
  expect_equal(.get_object(res), gettextf("\"%s\".\"%s\"", .get_dbname(res), "t1"))
  expect_equal(.get_base_query(res), gettextf("SELECT * FROM %s", gettextf("\"%s\".\"%s\"", .get_dbname(res), "t1")))
  
  expect_equal(.get_column_datatypes(res), c("I"="int", "I"="int"))
  expect_equal(.get_colnames(res), c("i", "j"))
})

test_that("tbl_teradata points to NOPI table and wrap name as ident", {
  res <- dplyr::tbl(con, dplyr::ident("t2"))
  verifyTblHierarchy(res)
  expect_match(res$ops$x, "t2")
  expect_is(res$ops$x, "ident")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  expect_equal(.get_source_type(res), "table")
  expect_equal(.get_source_definition(res), "t2")
  expect_equal(.get_object(res), gettextf("\"%s\".\"%s\"", .get_dbname(res), "t2"))
  expect_equal(.get_base_query(res), gettextf("SELECT * FROM %s", gettextf("\"%s\".\"%s\"", .get_dbname(res), "t2")))
  expect_equal(.get_column_datatypes(res), c("CV"="varchar", "TS"="timestamp"))
  expect_equal(.get_colnames(res), c("i", "j"))
})

test_that("tbl_teradata points to a view", {
  res <- dplyr::tbl(con, "v1")
  verifyTblHierarchy(res)
  expect_match(res$ops$x, "v1")
  expect_is(res$ops$x, "ident")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)

  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  expect_equal(.get_source_type(res), "table")
  expect_equal(.get_source_definition(res), "v1")
  expect_equal(.get_object(res), gettextf("\"%s\".\"%s\"", .get_dbname(res), "v1"))
  expect_equal(.get_base_query(res), gettextf("SELECT * FROM %s", gettextf("\"%s\".\"%s\"", .get_dbname(res), "v1")))
  expect_equal(.get_column_datatypes(res), c("CV"="varchar", "TS"="timestamp"))
  expect_equal(.get_colnames(res), c("i", "j"))
})


test_that("tbl_teradata points to a query", {
  res <- dplyr::tbl(con, dplyr::sql("sel * from t2"))
  verifyTblHierarchy(res)
  expect_match(res$ops$x, "sel \\* from t2")
  expect_is(res$ops$x, "sql")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  expect_equal(.get_source_type(res), "query")
  expect_equal(.get_source_definition(res), "sel * from t2")
  expect_null(.get_object(res))
  expect_equal(.get_base_query(res), "sel * from t2")
  expect_equal(.get_column_datatypes(res), c("CV"="varchar", "TS"="timestamp"))
  expect_equal(.get_colnames(res), c("i", "j"))
})

test_that("tbl_teradata points to a complex nested query", {
  res1 <- dplyr::tbl(con, "t1")
  verifyTblHierarchy(res1)
  res1 <- res1 %>% dplyr::filter(i > 3) %>% dplyr::select(i, j) %>% dplyr::filter(j < 105) %>% dplyr::select(i)
  verifyTblHierarchy(res1)
  # should contain one row
  df <- as.data.frame(res1)
  expect_equal(nrow(df), 1)
  expect_equal(ncol(df), 1)
  expect_equal(df[[1]], 4)
  # get the query and create a tbl from complex query:
  q <- dbplyr::sql_render(res1)
  res <- dplyr::tbl(con, q)
  # should contain one row as well
  df <- as.data.frame(res)
  expect_equal(nrow(df), 1)
  expect_equal(ncol(df), 1)
  expect_equal(df[[1]], 4)
  expect_is(res$ops$x, "sql")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  expect_equal(.get_source_type(res), "query")
  # the subqueries have random aliases so not possible to check
#  expect_equal(.get_source_definition(res), "sel * from t2")
  expect_null(.get_object(res))
#  expect_equal(.get_base_query(res), "sel * from t2")
  expect_equal(.get_column_datatypes(res), c("I"="int"))
  expect_equal(.get_colnames(res), c("i"))
})

test_that("check attributes with lazy operations", {
  res <- dplyr::tbl(con, "t1")
  verifyTblHierarchy(res)
  expect_true(inherits(res$ops, "op"))
  expect_true(inherits(res$ops, "op_base_remote"))

  res <- res %>% dplyr::select(j)
  verifyTblHierarchy(res)
  expect_true(inherits(res$ops, "op"))
  # note this does not inherit op_base_remote
  expect_false(inherits(res$ops, "op_base_remote"))
  # get the column data types
  expect_equal(.get_column_datatypes(res), c("I"="int"))
  expect_equal(.get_colnames(res), c("j"))

  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  expect_equal(.get_source_type(res), "query")
  expect_null(.get_object(res))

  # NOTE the main difference is the remote name is not of class "sql"
  expect_true(all.equal(class(res$ops$x), c("op_base_remote", "op_base", "op")))
  expect_false(inherits(res$ops$x, "sql"))
  expect_equal(res$src$con, con)

  # repeat the same with mutate
  res <- dplyr::tbl(con, "t1")
  res <- res %>% dplyr::mutate(k = j*2) %>% dplyr::filter(i > 3) %>% mutate(l = i+2)
  verifyTblHierarchy(res)
  expect_true(inherits(res$ops, "op"))
  # note this does not inherit op_base_remote
  expect_false(inherits(res$ops, "op_base_remote"))
  expect_equal(.get_column_datatypes(res), c("I"="int", "I"="int","D"="decimal","D"="decimal"))
  expect_equal(.get_colnames(res), c("i", "j", "k", "l"))
  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  expect_equal(.get_source_type(res), "query")
  expect_null(.get_object(res))

  # NOTE the main difference is the remote name is not of class "sql"
  expect_true(inherits(res$ops$x, "op"))
  expect_false(inherits(res$ops$x, "sql"))
  expect_equal(res$src$con, con)

  # add a select on top of prev tbl
  res <- res %>% dplyr::select(k)
  expect_equal(.get_column_datatypes(res), c("D"="decimal"))
  expect_equal(.get_colnames(res), c("k"))
  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  expect_equal(.get_source_type(res), "query")
  expect_null(.get_object(res))

  # NOTE the main difference is the remote name is not of class "sql"
  expect_true(inherits(res$ops$x, "op"))
  expect_false(inherits(res$ops$x, "sql"))
  expect_equal(res$src$con, con)
})

test_that("Test .attach_attributes to tbl_teradata.", {
  tblObj <- dplyr::tbl(con, "t1")
  tblObj <- .attach_attributes(tblObj)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(attr(tblObj, "databaseName"), get_con_dbname())
  expect_equal(attr(tblObj, "sourceType"), "table")
  expect_equal(attr(tblObj, "sourceDefinition"), "t1")
  expect_equal(attr(tblObj, "object"), gettextf("\"%s\".\"%s\"", .get_dbname(tblObj), "t1"))
  expect_equal(attr(tblObj, "baseQuery"), gettextf("SELECT * FROM %s", gettextf("\"%s\".\"%s\"", .get_dbname(tblObj), "t1")))
  expect_equal(attr(tblObj, "columnDataType"), c("I"="int", "I"="int"))
  expect_equal(attr(tblObj, "columnNames"), c("i", "j"))
  
})

test_that("tbl with dbplyr::in_schema", {
  res <- dplyr::tbl(con, dbplyr::in_schema(tempDatabaseName,"t1"))
  verifyTblHierarchy(res)
  expect_match(res$ops$x, paste0(tempDatabaseName,".","t1"))
  expect_is(res$ops$x, "ident_q")
  expect_is(res$ops$x, "ident")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  # make suere the default database of the connection is different from temp database
  expect_false(identical(toupper(.get_dbname(con)), toupper(tempDatabaseName)))
  expect_equal(.get_dbname(res), tempDatabaseName)
  expect_equal(.get_source_type(res), "table")
  expect_equal(.get_source_definition(res), "t1")
  expect_equal(.get_object(res), gettextf("\"%s\".\"%s\"", tempDatabaseName, "t1"))
  expect_equal(.get_base_query(res), gettextf("SELECT * FROM %s", gettextf("\"%s\".\"%s\"", tempDatabaseName, "t1")))
  expect_equal(.get_column_datatypes(res), c("I"="int", "I"="int"))
  expect_equal(.get_colnames(res), c("i", "j"))
})

test_that("tbl with dbplyr::in_schema and names already quoted", {
  res <- dplyr::tbl(con, dbplyr::in_schema(.teradataQuoteArg(tempDatabaseName, "\""),.teradataQuoteArg("t1", "\"")))
  verifyTblHierarchy(res)
  expect_match(res$ops$x, gettextf("%s.%s", tempDatabaseName, "t1"))
  expect_is(res$ops$x, "ident_q")
  expect_is(res$ops$x, "ident")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  # make suere the default database of the connection is different from temp database
  expect_false(identical(toupper(.get_dbname(con)), toupper(tempDatabaseName)))
  expect_equal(.get_dbname(res), tempDatabaseName)
  expect_equal(.get_source_type(res), "table")
  expect_equal(.get_source_definition(res), "t1")
  expect_equal(.get_object(res), gettextf("\"%s\".\"%s\"", tempDatabaseName, "t1"))
  expect_equal(.get_base_query(res), gettextf("SELECT * FROM %s", gettextf("\"%s\".\"%s\"", tempDatabaseName, "t1")))
  expect_equal(.get_column_datatypes(res), c("I"="int", "I"="int"))
  expect_equal(.get_colnames(res), c("i", "j"))
})

# The .createDataSetObject internally creates a tbl object and hence these test cases are here
test_that(".createDataSetObject works with a query", {
  # Try query with a table in default database
  query <- "select * from t1"
  res <- .createDataSetObject(query, "query", databaseName = NULL)
  verifyTblHierarchy(res)
  expect_match(res$ops$x, gsub("\\*", "\\\\*", query))
  expect_is(res$ops$x, "sql")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  expect_equal(.get_source_type(res), "query")
  expect_equal(.get_source_definition(res), query)
  expect_null(.get_object(res))
  expect_equal(.get_base_query(res), query)
  expect_equal(.get_column_datatypes(res), c("I"="int", "I"="int"))
  expect_equal(.get_colnames(res), c("i", "j"))

  # Try query with a table in a different database
  # This shoud ignore the databaseName as of now with sourceType = query
  query <- gettextf("select * from %s.t1", tempDatabaseName)
  res <- .createDataSetObject(query, "query", databaseName = NULL)
  verifyTblHierarchy(res)
  expect_match(res$ops$x, gsub("\\*", "\\\\*", query))
  expect_is(res$ops$x, "sql")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  expect_equal(.get_source_type(res), "query")
  expect_equal(.get_source_definition(res), query)
  expect_null(.get_object(res))
  expect_equal(.get_base_query(res), query)
  expect_equal(.get_column_datatypes(res), c("I"="int", "I"="int"))
  expect_equal(.get_colnames(res), c("i", "j"))
})

# The .createDataSetObject internally creates a tbl object and hence these test cases are here
test_that(".createDataSetObject works with a query and ignore.metadata = TRUE", {
  # Try query with a table in default database
  query <- "select * from t1"
  res <- .createDataSetObject(query, "query", databaseName = NULL, ignore.metadata = TRUE)
  verifyTblHierarchy(res)
  expect_match(res$ops$x, gsub("\\*", "\\\\*", query))
  expect_is(res$ops$x, "sql")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  expect_equal(.get_source_type(res), "query")
  expect_equal(.get_source_definition(res), query)
  expect_null(.get_object(res))
  expect_equal(.get_base_query(res), query)
  expect_equal(.get_column_datatypes(res), c("I"="int", "I"="int"))
  expect_equal(.get_colnames(res), c("i", "j"))

  # Try query with a table in a different database
  # This shoud ignore the databaseName as of now with sourceType = query
  query <- gettextf("select * from %s.t1", tempDatabaseName)
  res <- .createDataSetObject(query, "query", databaseName = NULL, ignore.metadata = TRUE)
  verifyTblHierarchy(res)
  expect_match(res$ops$x, gsub("\\*", "\\\\*", query))
  expect_is(res$ops$x, "sql")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  expect_equal(.get_source_type(res), "query")
  expect_equal(.get_source_definition(res), query)
  expect_null(.get_object(res))
  expect_equal(.get_base_query(res), query)
  expect_equal(.get_column_datatypes(res), c("I"="int", "I"="int"))
  expect_equal(.get_colnames(res), c("i", "j"))
})

# The .createDataSetObject internally creates a tbl object and hence these test cases are here
test_that(".createDataSetObject works with a query and ignore.metadata = FALSE", {
  # Try query with a table in default database
  query <- "select * from t1"
  res <- .createDataSetObject(query, "query", databaseName = NULL, ignore.metadata = FALSE)
  verifyTblHierarchy(res)
  expect_match(res$ops$x, gsub("\\*", "\\\\*", query))
  expect_is(res$ops$x, "sql")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  expect_equal(.get_source_type(res), "query")
  expect_equal(.get_source_definition(res), query)
  expect_null(.get_object(res))
  expect_equal(.get_base_query(res), query)
  expect_equal(.get_column_datatypes(res), c("I"="int", "I"="int"))
  expect_equal(.get_colnames(res), c("i", "j"))

  # Try query with a table in a different database
  # This shoud ignore the databaseName as of now with sourceType = query
  query <- gettextf("select * from %s.t1", tempDatabaseName)
  res <- .createDataSetObject(query, "query", databaseName = NULL, ignore.metadata = FALSE)
  verifyTblHierarchy(res)
  expect_match(res$ops$x, gsub("\\*", "\\\\*", query))
  expect_is(res$ops$x, "sql")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  expect_equal(.get_source_type(res), "query")
  expect_equal(.get_source_definition(res), query)
  expect_null(.get_object(res))
  expect_equal(.get_base_query(res), query)
  expect_equal(.get_column_datatypes(res), c("I"="int", "I"="int"))
  expect_equal(.get_colnames(res), c("i", "j"))
})

test_that(".createDataSetObject works with table and with databaseName", {
  res <- .createDataSetObject("t1", "table", databaseName = tempDatabaseName)
  verifyTblHierarchy(res)
  expect_match(res$ops$x, "t1")
  expect_is(res$ops$x, "ident_q")
  expect_is(res$ops$x, "ident")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  # Note here the dbname is not the default connection database
  expect_equal(.get_dbname(res), tempDatabaseName)
  expect_equal(.get_source_type(res), "table")
  expect_equal(.get_source_definition(res), "t1")
  expect_equal(.get_object(res), gettextf("\"%s\".\"%s\"", tempDatabaseName, "t1"))
  expect_equal(.get_base_query(res), gettextf("SELECT * FROM %s", gettextf("\"%s\".\"%s\"", tempDatabaseName, "t1")))
  expect_equal(.get_column_datatypes(res), c("I"="int", "I"="int"))
  expect_equal(.get_colnames(res), c("i", "j"))

  # with default database
  res <- .createDataSetObject("t1", "table", databaseName = .get_dbname(con))
  verifyTblHierarchy(res)
  expect_match(res$ops$x, "t1")
  expect_is(res$ops$x, "ident_q")
  expect_is(res$ops$x, "ident")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  expect_equal(.get_source_type(res), "table")
  expect_equal(.get_source_definition(res), "t1")
  expect_equal(.get_object(res), gettextf("\"%s\".\"%s\"", .get_dbname(res), "t1"))
  expect_equal(.get_base_query(res), gettextf("SELECT * FROM %s", gettextf("\"%s\".\"%s\"", .get_dbname(res), "t1")))
  expect_equal(.get_column_datatypes(res), c("I"="int", "I"="int"))
  expect_equal(.get_colnames(res), c("i", "j"))
})

test_that(".createDataSetObject works with table and without databasename", {
  res <- .createDataSetObject("t1", "table", databaseName = NULL)
  verifyTblHierarchy(res)
  expect_match(res$ops$x, "t1")
  expect_is(res$ops$x, "ident")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  expect_equal(.get_source_type(res), "table")
  expect_equal(.get_source_definition(res), "t1")
  expect_equal(.get_object(res), gettextf("\"%s\".\"%s\"", .get_dbname(res), "t1"))
  expect_equal(.get_base_query(res), gettextf("SELECT * FROM %s", gettextf("\"%s\".\"%s\"", .get_dbname(res), "t1")))
  expect_equal(.get_column_datatypes(res), c("I"="int", "I"="int"))
  expect_equal(.get_colnames(res), c("i", "j"))
})

test_that("tbl_teradata is created using a src_teradata object", {
  res <- dplyr::tbl(con, "t2")
  verifyTblHierarchy(res)
  expect_match(res$ops$x, "t2")
  # verify the class hierarchy of src
  expect_true(all.equal(class(res$src),c("src_Teradata", "src_dbi", "src_sql", "src")))
  # create a tbl from the src object => to test tbl.src_Teradata
  # also change table name just to be sure it works
  # TODO this test needs to be added in DART
  res <- dplyr::tbl(res$src, "t1")
  verifyTblHierarchy(res)
  expect_true(all.equal(class(res$src),c("src_Teradata", "src_dbi", "src_sql", "src")))
  expect_match(res$ops$x, "t1")
  expect_is(res$ops$x, "ident")
  expect_is(res$ops$x, "character")
  expect_equal(res$src$con, con)
  
  #### Check tbl attributes i.e. test getters ####
  expect_equal(.get_tbl_connection(res), con)
  expect_equal(.get_dbname(res), get_con_dbname())
  expect_equal(.get_source_type(res), "table")
  expect_equal(.get_source_definition(res), "t1")
  expect_equal(.get_object(res), gettextf("\"%s\".\"%s\"", .get_dbname(res), "t1"))
  expect_equal(.get_base_query(res), gettextf("SELECT * FROM %s", gettextf("\"%s\".\"%s\"", .get_dbname(res), "t1")))
  expect_equal(.get_column_datatypes(res), c("I"="int", "I"="int"))
  expect_equal(.get_colnames(res), c("i", "j"))
})

test_that("tbl creation and subsequent retrieval of types only queries the backend once", {
  # store the original method in a variable
  if(globalDTYPE == "odbc"){
    dbSendQueryOrig <- methods::getMethod("dbSendQuery", c("OdbcConnection", "character"))
    # idea is to mock the dbSendQuery and then count the number of times it is invoked
    # Without the fix this will invoke dbSendQuery multiple times
    expect_that(
      with_mock(
        `DBI::dbSendQuery` = function(con,
                                     statement,
                                     ...) {
          invocations <<- invocations + 1
          dbSendQueryOrig(con, statement, ...)
        },
        {
          invocations <- 0
          t1 <- dplyr::tbl(con, "t1")
          types <- .get_column_datatypes(t1)
          # get column names
          cols <- .get_colnames(t1)
          # invoke again should still not go to backend
          types2 <- .get_column_datatypes(t1)
          
          invocations
        }
      ),
      equals(1))
  } #else TODO for native driver
})
test_that("tbl creation and retrieval of types queries the backend again for lazy ops", {
  # store the original method in a variable
  if(globalDTYPE == "odbc"){
    dbSendQueryOrig <- methods::getMethod("dbSendQuery", c("OdbcConnection", "character"))
    # idea is to mock the dbSendQuery and then count the number of times it is invoked
    # Without the fix this will invoke dbSendQuery multiple times
    expect_that(
      with_mock(
        `DBI::dbSendQuery` = function(con,
                                     statement,
                                     ...) {
          invocations <<- invocations + 1
          dbSendQueryOrig(con, statement, ...)
        },
        {
          invocations <- 0
          print(invocations)
          # even though we have multiple verbs this goes only once for once call to .get_column_datatypes
          t1 <- dplyr::tbl(con, "t1") %>% dplyr::mutate(k = j*2) %>% dplyr::filter(i > 3) %>% mutate(l = i+2)
          # this one goes to the backend once
          types <- .get_column_datatypes(t1)
          # get column names
          cols <- .get_colnames(t1)
          # invoke again should go to backend again
          types2 <- .get_column_datatypes(t1)
  
          invocations
        }
      ),
      equals(3))
  }
})
test_that("db_query_fields works when explicitly called", {
  query <- dplyr::sql("SELECT * from t1")
  if(globalDTYPE == "odbc"){
    #below check does not work with native driver.
    expect_equal(dplyr::db_query_fields(con, query), c("i", "j"))
  }
})
  
test_that("Invalid inputs", {
  # invalid sourceDefinition
  expect_error(dplyr::tbl(con, list()), 
               "no applicable method for 'as.sql' applied to an object of class")
  
  expect_error(dplyr::tbl(con, c()), 
               "no applicable method for 'as.sql' applied to an object of class")
  
  expect_error(dplyr::tbl(con, NaN), 
               "no applicable method for 'as.sql' applied to an object of class")
  
  expect_error(dplyr::tbl(con, NULL),
               "no applicable method for 'as.sql' applied to an object of class")
  
  # specify a non-existent table name
  expect_error(dplyr::tbl(con, "R_NON_EXISTENT_TABLE"),
               paste0("Failed to retrieve column info.*",
                "'R_NON_EXISTENT_TABLE' does not exist.*",
                "Exiting since failed to create tbl"))
  
})


testthat::teardown ({
  cleanup()
  # This should technically not throw any warning or error
  expect_warning(td_remove_context(), regexp = NA)
})
