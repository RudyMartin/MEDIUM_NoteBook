context(".extractDatabaseName tests")


test_that("get database name from table name", {
  expect_that(
    .extractDatabaseName("dbc.temp"), equals("dbc")
  )
})

test_that("Database name not present table name", {
  expect_that(
    .extractDatabaseName("temp"), equals(NULL)
  )
})

# Testing all possible combinations of schemaname.tablename specifications
# Without quoting, quoting both, quoting only dbname, quoting only tablename
# This will be useful for in_schema
objNames <- c("db1.tab1", "\"db.1\".tab.1","\"db.1\".tab1", "\"db.1\".\"tab.1\"", "db1.\"tab.1\"")

test_that("get database name from fully qualified name", {
  expect_identical(
    .extractDatabaseNameQuoted(objNames[1]), "db1")
  expect_identical(
    .extractDatabaseNameQuoted(objNames[2]), "db.1")
  expect_identical(
    .extractDatabaseNameQuoted(objNames[3]), "db.1")
  expect_identical(
    .extractDatabaseNameQuoted(objNames[4]), "db.1")
  expect_identical(
    .extractDatabaseNameQuoted(objNames[5]), "db1")
})
