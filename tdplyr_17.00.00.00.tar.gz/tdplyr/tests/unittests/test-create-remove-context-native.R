context ("Unit tests for Create, Get and Remove Contexts with Teradata Native driver")

verifyConnection <- function(con) {
  expect_equal(as.character(class(con)), "Teradata")
  # check the entire class hierarchy
  hierarchy <- methods::getAllSuperClasses(methods::getClass(class(con)))
  expected_hierarchy <- c("TeradataConnection", "DBIConnection", "DBIObject")
  expect_equal(length(hierarchy), 3)
  expect_true(all.equal(hierarchy, expected_hierarchy))
  # check if the connection worked witha query
  expect_equal(nrow(DBI::dbGetQuery(con, "select user")), 1)
}

getDefaultDatabase <- function(con) {
  # dont use the getter here as we want to test that as well
  toupper(DBI::dbGetQuery(con, "select database")[[1]])
}

verifyContext <- function(con, defaultDB, tempDB) {
  expect_true(identical(con, .taConnection()))
  expect_equal(.ta.getDefaultDatabase(), defaultDB)
  expect_equal(.ta.getTempDatabase(), tempDB)
}


queryNumTables <- function(con, dbToQuery) {
  nrow(DBI::dbGetQuery(con, paste0("help user ", dbToQuery, ";")))
}

# These functions taken from test-garbage-collection-backend.R
checkTableCount <- function(con, db, expected) {
  num <- queryNumTables(con, db)
  expect_equal(num, expected)
}

# just creates a dummy table with the given name in the db
addTempTable <- function(con, db, name) {
  object <- gettextf("\"%s\".\"%s\"", db, name)
  # create table
    try(DBI::dbExecute(con,
      gettextf("create table %s(a int, b float)", object)),
    silent = TRUE)
    # check if the table has been created
    expect_error(DBI::dbGetQuery(con, paste0("show table ", object)),
      regexp = NA)
    # add the table to a temp object
    .ta.addTempObject(object, "table")
}

cleanup <- function () {
  if (is.null(globalLogMech)){ 
    con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native")
  }
  else{
    con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", logmech = globalLogMech)
  }
  try(db_drop_table(con, "gc_table1"), silent = TRUE)
  try(db_drop_table(con, "gc_table2"), silent = TRUE)
  try(db_drop_table(con, "gc_table3"), silent = TRUE)
  try(db_drop_table(con, "gc_table4"), silent = TRUE)
  td_remove_context()
}

testthat::setup({
  cleanup()
})


userName <-  toupper(.ta.getUserName())
# just use dbc as a temp database since no tables will be created
tempDatabaseName <- "DBC"

test_that("td_create_context successfully connects with Teradata Native driver", {
  #skip_if(!.ta.isPlatformLinux(), "*** Running Native driver tests only on Linux")
  
  if (is.null(globalLogMech)){ 
    con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native")
  }
  else{
    con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", logmech = globalLogMech)
  }
  verifyConnection(con)
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)
  # successfully disconnect with warning that current context is being removed
  td_remove_context()
  # Check if context is removed
  expect_true(is.null(.taConnection(silent = TRUE)))
  expect_error(.taConnection())
  expect_true(is.null(.ta.getTempDatabase(silent = TRUE)))
})

test_that("Negative tests with native driver ", {
    #skip_if(!.ta.isPlatformLinux(), "*** Running Native driver tests only on Linux")
  if (is.null(globalLogMech)){ 
    expect_error(td_create_context(host = "INVALID_HOST", uid = "invalid", pwd = "INVALID", dType = "native"))
    # host missing
    expect_error(td_create_context(uid = globalUID,pwd = globalPWD, dType = "native"), "Following required arguments are missing: host")
    # Specify database param
    expect_error(
      td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", database = globalUID),
      "TDR_E1107")
    # Specify both dsn and Host works but it just prints a message
    out <- capture.output(con <-
      td_create_context(dsn = dsnName, host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native"))
    expect_true(grepl("TDR_P1108", out, fixed = TRUE))
    td_remove_context()
    
    # dsn but no host
    expect_error(td_create_context(dsn = dsnName, uid = globalUID,pwd = globalPWD, dType = "native"), "Following required arguments are missing: host")
  }
  else{
    expect_error(td_create_context(host = "INVALID_HOST", uid = "invalid", pwd = "INVALID", dType = "native", logmech = globalLogMech))
    # host missing
    expect_error(td_create_context(uid = globalUID, pwd = globalPWD, dType = "native", logmech = globalLogMech), "TDR_E3001")

    # Invalid logmech argument value passed
    expect_error(td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", logmech = "INVALID_LOGMECH"), "TDR_E3004")
    
    # Empty string passed to argument logmech
    expect_error(td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", logmech = ""), "TDR_E3004")
    
    # # Invalid logmech (type)
    expect_error(td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", logmech = 123), "TDR_E3005")
    
    # Multiple values passed to logmech argument
    expect_error(td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", logmech = c('TD2', 'LDAP')), "TDR_E3005")
    
    # Multiple values passed to logmech argument
    expect_error(td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", logmech = list('TD2', 'LDAP')), "TDR_E3005")
    
    # Specify database param
    expect_error(
      td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", database = globalUID, logmech = globalLogMech),
      "TDR_E1107")
    # Specify both dsn and Host works but it just prints a message
    out <- capture.output(con <-
      td_create_context(dsn = dsnName, host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", logmech = globalLogMech))

    expect_true(grepl("TDR_P1108", out, fixed = TRUE))
    td_remove_context()
    
    # dsn but no host
    expect_error(td_create_context(dsn = dsnName, uid = globalUID,pwd = globalPWD, dType = "native", logmech = globalLogMech), "Following required arguments are missing: host")
  }
    
})

#  create context multiple times
test_that("Call create context multiple times without remove context", {
  #skip_if(!.ta.isPlatformLinux(), "*** Running Native driver tests only on Linux")

  if (is.null(globalLogMech)){ 
    con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native")
  }
  else{
    con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", logmech = globalLogMech)
  }
  verifyConnection(con)
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)
  # gives warning if connect called again
  if (is.null(globalLogMech)){ 
    con2 <- expect_warning(
      td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native"))
  }
  else{
    con2 <- expect_warning(
      td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", logmech = globalLogMech))
  }
  verifyConnection(con2)
  defaultDB <- getDefaultDatabase(con2)
  verifyContext(con2, defaultDB, defaultDB)

  # Test if the previous connection is closed
  expect_error(dbDisconnect(con))

  # this removes con2
  td_remove_context()
  expect_false(identical(.taConnection(silent = TRUE), con2))

  # Retrieve the global connection should throw error
  expect_error(.taConnection())
  # Wont throw error with silent = TRUE
  expect_null(.taConnection(silent = TRUE))
})

test_that("call td_remove_context multiple times", {
  # skip_if(!.ta.isPlatformLinux(), "*** Running Native driver tests only on Linux")

  if (is.null(globalLogMech)){ 
    con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native")
  }
  else{
    con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", logmech = globalLogMech)
  }
  verifyConnection(con)
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)

  td_remove_context()
  expect_error(.taConnection())
  expect_null(.taConnection(silent = TRUE))
  # remove context again should throw error that context does not exist
  expect_error(td_remove_context(), "TDR_E1004")
})


test_that("Connect with a different temp database", {
  # skip_if(!.ta.isPlatformLinux(), "*** Running Native driver tests only on Linux")

  if (is.null(globalLogMech)){ 
    con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", 
                             temp.database = tempDatabaseName)
  }
  else{
    con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", 
                             temp.database = tempDatabaseName, logmech = globalLogMech)
  }
  verifyConnection(con)
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, tempDatabaseName)
  td_remove_context()

})

# test_that("Connect with a different default database", {
#   skip_if(!.ta.isPlatformLinux(), "*** Running Native driver tests only on Linux")
#   # Not supported with native driver. See negative tests
# })

test_that("Test get context", {
  # skip_if(!.ta.isPlatformLinux(), "*** Running Native driver tests only on Linux")

  if (is.null(globalLogMech)){ 
    con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", 
                             temp.database = tempDatabaseName)
  }
  else{
    con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", 
                             temp.database = tempDatabaseName, logmech = globalLogMech)
  }
  
  verifyConnection(con)
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, tempDatabaseName)

  context <- td_get_context()
  expect_true(identical(context$connection, .taConnection()))
  expect_equal(context$temp.database, tempDatabaseName)
  expect_equal(context$default.database, defaultDB)
  td_remove_context()

  # Call td_get_context after remove context should return null
  expect_true(is.null(td_get_context()))
})

test_that("Garbage collection works with native driver", {
  # skip_if(!.ta.isPlatformLinux(), "*** Running Native driver tests only on Linux")

  # This logic adapted from test-garbage-collection-backend.R
  if (is.null(globalLogMech)){ 
    con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native")
  }
  else{
    con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native", logmech = globalLogMech)
  }
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)
  countBefore <- queryNumTables(con, defaultDB)
  # Add bunch of temp tables
  addTempTable(con, defaultDB, "gc_table1")
  addTempTable(con, defaultDB, "gc_table2")
  addTempTable(con, defaultDB, "gc_table3")
  addTempTable(con, defaultDB, "gc_table4")

  # check the num of tables in the temp database are 4
  checkTableCount(con, defaultDB, countBefore + 4)

  # Remove context to trigger GC
  td_remove_context()
  expect_error(.taConnection())
  expect_null(.taConnection(silent = TRUE))

  # Connect again and see the objects were removed by the remove context call before
  if (is.null(globalLogMech)){ 
    con <- DBI::dbConnect(tdplyr::NativeDriver(), host = globalHost, uid = globalUID, pwd = globalPWD)
  }
  else{
    con <- DBI::dbConnect(tdplyr::NativeDriver(), host = globalHost, uid = globalUID, pwd = globalPWD, logmech = globalLogMech)
  }
  checkTableCount(con, defaultDB, countBefore)
  DBI::dbDisconnect(con)
})


testthat::teardown({
  cleanup()
})
