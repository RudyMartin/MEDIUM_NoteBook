context("Unit tests for checking garbage collection with multi sessions")

# First test all multi session related infrastructure functions
test_that("Get process ID works", {
  expect_error(.ta.getPID(), regexp = NA)
  # we can only check if the pid returned is greater than 0 as a validity check
  pid <- .ta.getPID()
  expect_gt(pid, 0)
})

test_that("Extract PID works with valid file name", {
  # 3 digit pid
  fileName <- ".td.objects.123.txt"
  expect_equal(.ta.extractPIDSuffix(fileName), 123L)

  # 1 digit pid
  fileName <- ".td.objects.8.txt"
  expect_equal(.ta.extractPIDSuffix(fileName), 8L)
  
  # No PID suffix
  fileName <- ".td.objects"
  expect_equal(.ta.extractPIDSuffix(fileName), .ta.getDefaultPID())
  
})

test_that("Extract PID works with invalid file name", {
  # without .txt suffix
  fileName <- ".td.objects.123"
  expect_equal(.ta.extractPIDSuffix(fileName), .ta.getDefaultPID())

  # without any pid integer
  fileName <- "xyz.12ab.txt"
  expect_equal(.ta.extractPIDSuffix(fileName), .ta.getDefaultPID())
  
  # file name without dots
  fileName <- "abc"
  expect_equal(.ta.extractPIDSuffix(fileName), .ta.getDefaultPID())

  # file name with one dot
  fileName <- "abc.txt"
  expect_equal(.ta.extractPIDSuffix(fileName), .ta.getDefaultPID())
  
})
test_that("Returns true on active process", {
  expect_true(.ta.isProcessActive(Sys.getpid()))
})

test_that("Returns false on invalid process", {
  expect_false(.ta.isProcessActive(-127))
})

removeFiles <- function(files, silent) {
  for (f in files) {
    try(suppressWarnings(file.remove(f)), silent = silent)
  }  
}
createFiles <- function(files) {
  # make sure to clean up in case
  # Test the remove files function in the package and it shoudl not throw any warnings
  expect_warning(.ta.removeFiles(files), regexp = NA)
  for (f in files) {
    expect_error(file.create(f), regexp = NA) # this should not throw error
  }
}

test_that("List all session files and remove files work", {
  # we are only creating files in this current directory so it wont touch the actual session directory
  dir <- getwd()
  actualFiles <-c(".td.objects.123.txt", ".td.objects.34.txt", ".td.objects.0.txt", ".td.objects")
  invalidFiles <- c(".td.objects.123", ".td.objects.txt", ".td.objects.bak",
        ".td.obj", ".td.obj.34", ".td.objects.123.bak", ".td.objects.bak", "td.objects")# invalid ones
  # get full path
  actualFiles <- sapply(actualFiles, function(x) {file.path(dir, x)}, USE.NAMES = FALSE)
  invalidFiles <- sapply(invalidFiles, function(x) {file.path(dir, x)}, USE.NAMES = FALSE)
  files <- append(actualFiles, invalidFiles)
  createFiles(files)
  sessionFiles <- .getAllSessionFiles(dir)
  expect_equal(length(sessionFiles), length(actualFiles))
  expect_true(all(actualFiles %in% sessionFiles))
  expect_warning(.ta.removeFiles(files), regexp = NA)
  # The sessionfiles must be empty
  expect_equal(length(.getAllSessionFiles(dir)), 0)
})

test_that("List Defunct session files work", {
  dir <- getwd()
  activeFiles <-c(".td.objects.123.txt", ".td.objects.34.txt")
  defunctFiles <- c(".td.objects.9.txt", ".td.objects.0.txt", ".td.objects")
  # get full path
  activeFiles <- sapply(activeFiles, function(x) {file.path(dir, x)}, USE.NAMES = FALSE)
  defunctFiles <- sapply(defunctFiles, function(x) {file.path(dir, x)}, USE.NAMES = FALSE)
  files <- append(activeFiles, defunctFiles)
  createFiles(files)
  expect_that(
    with_mock(
      `.ta.isProcessActive` = function(pid) {
        return(pid %in% c(123L, 34L))
      },
      `.getAllSessionFiles` = function(dir = NULL) {
        files
      },
      {
        defFiles <- .ta.getAllDefunctSessionFiles()
        expect_equal(length(defFiles), length(defunctFiles))
        expect_true(all(defFiles %in% defunctFiles))
        TRUE
      }
    ),
    equals(TRUE))
  expect_warning(.ta.removeFiles(files), regexp = NA)
  # The sessionfiles must be empty
  expect_equal(length(.getAllSessionFiles(dir)), 0)
})

test_that("Garbage collection does not remove objects from other ACTIVE sessions", {
  cur_pid <- .ta.getPID()
  # create a connection
  if(globalDTYPE == "odbc"){
    con <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
  }else {
    con <- DBI::dbConnect(tdplyr::NativeDriver(), host = globalHost, uid = globalUID, pwd = globalPWD)
  }
  
  expect_true(DBI::dbIsValid(con))
  td_set_context(con)
  df <- data.frame(c1 = c(1:3))
  
  # this will craete a temp table that will be GCed later
  t1 <- df %>% dplyr::copy_to(con, df = .)
  expect_false(is.null(t1))
  t1_name <- dbplyr::remote_name(t1)
  expect_true(dplyr::db_has_table(con, t1_name))
  # clear the internal structure simulating a session close
  .rm(".session_temp__objects__")
  # we simulate a new R instance using mocking here
  # the idea is that in this mocked R instance we create a temp table,
  # but when we end this mock instance the temp table created above should still exist
  expect_that(
    with_mock(
      `.ta.getPID` = function() {
        return(cur_pid + 1)
      },
      `.ta.isProcessActive` = function(pid) {
        return(pid %in% c(cur_pid, cur_pid + 1))
      },
      {
          if(globalDTYPE == "odbc"){
            con1 <- suppressWarnings(td_create_context(dsnName))
          }else {
            con1 <- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD))
          }
          
          expect_true(DBI::dbIsValid(con1))
          # this will craete a temp table that will be GCed
          t2 <- df %>% dplyr::copy_to(con1, df = .)
          expect_false(is.null(t2))
          t2_name <- dbplyr::remote_name(t2)
          # verify that the tbl is created
          expect_true(dplyr::db_has_table(con1, t2_name))
          # verify previous temp table still exists
          expect_true(dplyr::db_has_table(con, t1_name))
          # remove context
          td_remove_context()
          expect_false(DBI::dbIsValid(con1))
          # verify if the table has been removed
          if(globalDTYPE == "odbc"){
            con1 <- td_create_context(dsnName)
          }else {
            con1 <- td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD)
          }
          
          expect_true(DBI::dbIsValid(con1))
          expect_false(dplyr::db_has_table(con1, t2_name))
          # remove this context again
          td_remove_context()
          expect_false(DBI::dbIsValid(con1))
          TRUE
      }
      ),equals(TRUE))
  
  # Verify that the table created in previous session still exists.
  # and con should still be valid
  expect_true(DBI::dbIsValid(con))
  expect_true(dplyr::db_has_table(con, t1_name))
  DBI::dbDisconnect(con)
  expect_false(DBI::dbIsValid(con))
  # Calling create context here should garbage collect this object 
  if(globalDTYPE == "odbc"){
    con <- td_create_context(dsnName)
  }else {
    con <- td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD)
  }
  
  expect_true(DBI::dbIsValid(con))
  expect_false(dplyr::db_has_table(con, t1_name))
  td_remove_context()
})


test_that("Garbage collection REMOVES objects from other INACTIVE sessions", {
  cur_pid <- .ta.getPID()
  # create a connection
  if(globalDTYPE == "odbc"){
    con <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
  }else {
    con <- DBI::dbConnect(tdplyr::NativeDriver(), host = globalHost, uid = globalUID, pwd = globalPWD)
  }
  
  expect_true(DBI::dbIsValid(con))
  td_set_context(con)
  df <- data.frame(c1 = c(1:3))
  
  # this will craete a temp table that will be GCed later
  t1 <- df %>% dplyr::copy_to(con, df = .)
  expect_false(is.null(t1))
  t1_name <- dbplyr::remote_name(t1)
  expect_true(dplyr::db_has_table(con, t1_name))
  # clear the internal structure simulating a session close
  .rm(".session_temp__objects__")
  # we simulate a new R instance using mocking here
  # the idea is that in this mocked R instance we create a temp table,
  # but when we end this mock instance the temp table created above should still exist
  expect_that(
    with_mock(
      `.ta.getPID` = function() {
        return(cur_pid + 1)
      },
      `.ta.isProcessActive` = function(pid) {
        # mark previous session with cur_pid as inactive
        return(pid %in% c(cur_pid + 1))
      },
      {
          if(globalDTYPE == "odbc"){
            con1 <- suppressWarnings(td_create_context(dsnName))
          }else {
            con1 <- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD))
          }
          
          expect_true(DBI::dbIsValid(con1))
          # this will craete a temp table that will be GCed
          t2 <- df %>% dplyr::copy_to(con1, df = .)
          expect_false(is.null(t2))
          t2_name <- dbplyr::remote_name(t2)
          # verify that the tbl is created
          expect_true(dplyr::db_has_table(con1, t2_name))
          # verify previous temp table already GCed
          expect_false(dplyr::db_has_table(con, t1_name))
          # remove context
          td_remove_context()
          expect_false(DBI::dbIsValid(con1))
          # verify if the table has been removed
          if(globalDTYPE == "odbc"){
            con1 <- td_create_context(dsnName)
          }else {
            con1 <- td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD)
          }
          
          expect_true(DBI::dbIsValid(con1))
          expect_false(dplyr::db_has_table(con1, t2_name))
          # remove this context again
          td_remove_context()
          expect_false(DBI::dbIsValid(con1))
          TRUE
      }
      ),equals(TRUE))
  
  # Verify that the table created in previous session is GCed
  # and con should still be valid
  expect_true(DBI::dbIsValid(con))
  expect_false(dplyr::db_has_table(con, t1_name))
  DBI::dbDisconnect(con)
  expect_false(DBI::dbIsValid(con))
})
