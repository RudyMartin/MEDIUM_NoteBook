context ("Unit tests for Create, Get and Remove Contexts with Odbc")

# Only basic unit tests here, others in Dart

verifyConnection <- function(con) {
  expect_true(DBI::dbIsValid(con))
  expect_equal(as.character(class(con)), "Teradata")
  # check the entire class hierarchy
  hierarchy <- methods::getAllSuperClasses(methods::getClass(class(con)))
  expected_hierarchy <- c("OdbcConnection", "DBIConnection", "DBIObject")
  expect_equal(length(hierarchy), 3)
  expect_true(all.equal(hierarchy, expected_hierarchy))
  # check if the connection worked witha query
  expect_equal(nrow(DBI::dbGetQuery(con, "select user")), 1)
}

getDefaultDatabase <- function(con) {
  # dont use the getter here as we want to test that as well
  toupper(DBI::dbGetQuery(con, "select database")[[1]])
}

verifyContext <- function(con, defaultDB, tempDB) {
  expect_true(identical(con, .taConnection()))
  expect_equal(.ta.getDefaultDatabase(), defaultDB)
  expect_equal(.ta.getTempDatabase(), tempDB)
}

userName <-  toupper(.ta.getUserName())
tempDatabaseName <- toupper(paste0("RTEST_TMP_DATABASE_",userName))

cleanup <- function() {
  # Drop database using the user 'dbc'
  dcon <- DBI::dbConnect(odbc::odbc(), dsn = dsnName, uid = "dbc", pwd = "dbc")
  DBI::dbExecute(dcon, paste0("DELETE DATABASE ",tempDatabaseName,";"))
  DBI::dbExecute(dcon, paste0("DROP DATABASE ",tempDatabaseName,";"))
  td_remove_context()
}

testthat::setup({
  dcon <- suppressWarnings(td_create_context(dsn = dsnName, uid = "dbc", pwd = "dbc"))

  try(DBI::dbExecute(dcon, paste0("DELETE DATABASE ",tempDatabaseName,";")), silent = TRUE)
  try(DBI::dbExecute(dcon, paste0("DROP DATABASE ",tempDatabaseName,";")), silent = TRUE)

  DBI::dbExecute(dcon, paste0("CREATE DATABASE ",tempDatabaseName," AS PERM = 1e+06;" ))
  DBI::dbExecute(dcon, paste0("GRANT ALL ON ",tempDatabaseName," TO ", globalUID, ";" ))

  td_remove_context()
})

test_that("td_create_context successfully connects with odbc dsn", {
  con <- td_create_context(dsn = dsnName)
  verifyConnection(con)
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)
  # successfully disconnect with warning that current context is being removed
  td_remove_context()
  expect_false(DBI::dbIsValid(con))
  # Check if context is removed
  expect_true(is.null(.taConnection(silent = TRUE)))
  expect_true(is.null(.ta.getTempDatabase(silent = TRUE)))
})

test_that("Invalid DSN / credentials throws error", {
    expect_error(td_create_context(dsn = "INVALID_DSN"))
    expect_error(td_create_context(dsn = dsnName, pwd = "INVALID_PWD"))
})

#  create context multiple times
test_that("Call create context multiple times without remove context", {

  con1 <- td_create_context(dsn = dsnName)
  expect_identical(.taConnection(), con1)
  verifyConnection(con1)

  # gives warning if connect called again
  con2 <- expect_warning(td_create_context(dsn = dsnName), "TDR_W1002")
  # Verify if connection con1 is closed
  expect_false(DBI::dbIsValid(con1))

  # Check if the new connection set as global and old connection is not global
  expect_false(identical(.taConnection(), con1))
  expect_identical(.taConnection(), con2)
  verifyConnection(con2)

  td_remove_context()
  expect_false(DBI::dbIsValid(con2))
  expect_false(identical(.taConnection(silent = TRUE), con2))

  # Retrieve the global connection should throw error
  expect_error(.taConnection())
  # Wont throw error with silent = TRUE
  expect_null(.taConnection(silent = TRUE))

})

test_that("call td_remove_context multiple times", {

  con1 <- td_create_context(dsn = dsnName)
  expect_identical(.taConnection(), con1)
  verifyConnection(con1)

  td_remove_context()
  expect_false(DBI::dbIsValid(con1))
  expect_false(identical(.taConnection(silent = TRUE), con1))
  
  # remove context again should throw error that context does not exist
  expect_error(td_remove_context(), "TDR_E1004")
  expect_false(DBI::dbIsValid(con1))
  expect_false(identical(.taConnection(silent = TRUE), con1))
})

test_that("Test with tdWallet", {
  # TODO test tdWallet with more connection parameters
  con1 <- td_create_context(dsn = dsnName, tdWalletString = tdWalletString)
  verifyConnection(con1)
  defaultDB <- getDefaultDatabase(con1)
  verifyContext(con1, defaultDB, defaultDB)
  td_remove_context()
  expect_false(DBI::dbIsValid(con1))
  expect_false(identical(.taConnection(silent = TRUE), con1))
  
  # Connect with both pwd and tdWalletString should throw warning
  con1 <- expect_warning(
    td_create_context(dsn = dsnName, pwd = "UNUSED_PWD", tdWalletString = tdWalletString),
    "TDR_W1006")
  verifyConnection(con1)
  defaultDB <- getDefaultDatabase(con1)
  verifyContext(con1, defaultDB, defaultDB)
  td_remove_context()
  expect_false(DBI::dbIsValid(con1))
  expect_false(identical(.taConnection(silent = TRUE), con1))

})

test_that("Connect with a different temp database", {
  con1 <- td_create_context(dsn = dsnName, temp.database = tempDatabaseName)
  verifyConnection(con1)
  verifyContext(con1, getDefaultDatabase(con1), tempDatabaseName)
  td_remove_context()
  expect_false(DBI::dbIsValid(con1))
})

test_that("Connect with a different default database", {
  # database param must not be case sensitive
  con1 <- td_create_context(dsn = dsnName, dATaBase = tempDatabaseName)
  verifyConnection(con1)
  # Temp database is the default database and td_create_context sets default database as temp
  # database, if that argument is not specified.
  verifyContext(con1, tempDatabaseName, tempDatabaseName)
  td_remove_context()
  expect_false(DBI::dbIsValid(con1))
})

test_that("Connect with a different default database - TdWallet", {
  con1 <- td_create_context(dsn = dsnName, tdWalletString = tdWalletString, database = tempDatabaseName)
  verifyConnection(con1)
  # Temp database is the default database and vice versa
  verifyContext(con1, tempDatabaseName, getDefaultDatabase(con1))
  td_remove_context()
  expect_false(DBI::dbIsValid(con1))
})

test_that("database param in create context works", {
  # The odbc driver does not override if default database is present in odbc.ini
  # This issue must be resolved with ELE-645
  # There is no argument named DefaultDatabase for td_create_context and the argument
  # "DefaultDatabase" of dbConnect() is fetched using the 'database' argument of td_create_context.
  con1 <- td_create_context(dsn = dsnName, database = tempDatabaseName)
  verifyContext(con1, tempDatabaseName, tempDatabaseName)
  verifyConnection(con1)
  td_remove_context()
  expect_false(DBI::dbIsValid(con1))

  # set database param must not be case-sensitive
  con1 <- td_create_context(dsn = dsnName, DATABASE = tempDatabaseName)
  verifyContext(con1, tempDatabaseName, tempDatabaseName)
  verifyConnection(con1)
  td_remove_context()
  expect_false(DBI::dbIsValid(con1))
})

test_that("Test get context", {
  con1 <- td_create_context(dsn = dsnName)
  verifyConnection(con1)
  context <- td_get_context()
  expect_true(identical(context$connection, .taConnection()))
  defaultDB <- getDefaultDatabase(con1)
  expect_equal(context$temp.database, defaultDB)
  expect_equal(context$default.database, defaultDB)
  td_remove_context()
  expect_false(DBI::dbIsValid(con1))

  # Call td_get_context now should return null
  expect_true(is.null(td_get_context()))

  # same as above with different temp database
  con1 <- td_create_context(dsn = dsnName, temp.database = tempDatabaseName)
  verifyConnection(con1)
  context <- td_get_context()
  expect_true(identical(context$connection, .taConnection()))
  expect_equal(context$temp.database, tempDatabaseName)
  expect_equal(context$default.database, defaultDB)
  td_remove_context()
  expect_false(DBI::dbIsValid(con1))

  # Call td_get_context now should return null
  expect_true(is.null(td_get_context()))
})
# Test loadIODBC works as expected
test_that(".loadIODBC internal function works as expected", {
  prevOption <- getOption("td.load.IODBC")
  options("td.load.IODBC" = TRUE)
  # clear the variable
  .rm(".is__iodbc__loaded")
  # this will return true / false depending on the platform
  .loadIODBC()
  # NOTE: This test could fail on MAC if it did not have the tdplyr.so patch applied
  # Therefore, we have the null check here
  if (!is.null(.get(".is__iodbc__loaded")))
    expect_gt(.get(".is__iodbc__loaded"), 0)
  # try again to load and it should return false, irrespective of platform
  expect_false(.loadIODBC())
  options("td.load.IODBC" = prevOption)
})

test_that("Option td.load.IODBC works as expected", {
  optLoad <- getOption("td.load.IODBC")
  options("td.load.IODBC" = FALSE)
  # this should always return FALSE irrespective of platform
  expect_false(.loadIODBC())
  # try again to load and it should still return false
  expect_false(.loadIODBC())
  options("td.load.IODBC" = optLoad)
})

test_that("Option td.lib.IODBC is ignored when td.load.IODBC is unset", {
  optLib <- getOption("td.lib.IODBC")
  optLoad <- getOption("td.load.IODBC")
  options("td.load.IODBC" = FALSE)
  # set an invalid value should not throw error is  td.load.IODBC is set to false
  options("td.lib.IODBC" = "XYZ")
  # this should always return FALSE irrespective of platform
  expect_false(.loadIODBC())
  # try again to load and it should still return false
  expect_false(.loadIODBC())
  options("td.load.IODBC" = optLoad)
  options("td.lib.IODBC" = optLib)

})

testthat::teardown({
  cleanup()
})