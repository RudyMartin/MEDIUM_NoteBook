context("Unit tests for creating and dropping views")

create_db_context <- function() {
  if(globalDTYPE == "odbc"){
    con <<- suppressWarnings(td_create_context(dsn = dsnName))
  } else {
    con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD))
  }
}

cleanup <- function() {
  try(DBI::dbExecute(con, "DROP TABLE antiselect_input"), silent = TRUE)
}

testthat::setup({
  
  create_db_context()
  #cleaning data base if tables are already exists.
  cleanup()
  try(DBI::dbExecute(con, "DROP view my_view"), silent = TRUE)
  try(DBI::dbExecute(con, "DROP view view_tests"), silent = TRUE)
  loadExampleData("antiselect_example", "antiselect_input")
})

query <- dplyr::sql("select * from antiselect_input")

test_that("create view negative tests", {
  expect_error( .create.view(), "argument \"con\" is missing, with no default")
  expect_error( .create.view(con), "Following required arguments are missing: query, view_name")
  expect_error( .create.view(con, query), "Following required arguments are missing: view_name")
  expect_error( .create.view(con, view_name = "my_view"), "Following required arguments are missing: query")
  expect_error( .create.view(con, query = "", view_name = "my_view"), 
                "Argument 'query' should not contain empty string.")
  expect_error( .create.view(con, query = dplyr::sql(""), view_name = "my_view"), 
                "Argument 'query' should not contain empty string.")
  expect_error( .create.view(con, query = query, view_name = " "), 
                "Argument 'view_name' should not contain empty string.")
  expect_error( .create.view(con, query = 123, view_name = "my_view"), 
                "Argument 'query' must be of 'sql or character' datatype. Multiple values are not supported.")
  expect_error( .create.view(con, query = query, view_name = 123), 
                "Argument 'view_name' must be of 'character' datatype. Multiple values are not supported.")
  expect_error( .create.view(con, query = c(TRUE), view_name = "my_view"), 
                "Argument 'query' must be of 'sql or character' datatype. Multiple values are not supported.")
  expect_error( .create.view(con, query = query, view_name = c(2, 1)), 
                "Argument 'view_name' must be of 'character' datatype. Multiple values are not supported.")
  expect_error( .create.view(con, query = sql("select"), view_name = "my_view"), 
                "Table/View 'my_view' cannot be created")
})

test_that("drop view negative tests", {
  expect_error( .drop.view(), "argument \"con\" is missing, with no default")
  expect_error( .drop.view(con), "Following required arguments are missing: view_name")
  expect_error( .drop.view(con, view_name = " "), 
                "Argument 'view_name' should not contain empty string.")
  expect_error( .drop.view(con, view_name = 123), 
                "Argument 'view_name' must be of 'character' datatype. Multiple values are not supported.")
  expect_error( .drop.view(con, view_name = c(2, 1)), 
                "Argument 'view_name' must be of 'character' datatype. Multiple values are not supported.")
  expect_error( .drop.view(con, view_name = "view_tests"), 
                "Object 'view_tests' does not exist")
  expect_error( .drop.view(con, view_name = "view_tests"), 
                "Table/View 'view_tests' cannot be dropped")
})

test_that("create & drop view positive tests", {
  # .create.view returns view name on success
  expect_equal( .create.view(con, query = query, view_name = "my_view"), "my_view")
  .drop.view(con, "my_view")
})


testthat::teardown(
  {
    cleanup()
    td_remove_context()
  }
)