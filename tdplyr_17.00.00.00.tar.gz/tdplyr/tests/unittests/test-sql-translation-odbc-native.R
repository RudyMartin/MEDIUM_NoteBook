context('Tests for Teradata sql mapping')

map_con <- NULL
testthat::setup({
    if(globalDTYPE == "odbc"){
      map_con <<- suppressWarnings(td_create_context(dsn = dsnName))
    } else {
      map_con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD))
    }
  }
)
test_that("Math Operators mapped", {

  # Math ops

  # +
  q <-  translate_sql(c1 + c2, con = map_con) %>% as.character
  expect_identical(q, '"c1" + "c2"')

  q <-  translate_sql(c1 + 1L, con = map_con) %>% as.character
  expect_identical(q, '"c1" + 1')

  q <-  translate_sql(c1 + 1, con = map_con) %>% as.character
  expect_identical(q, '"c1" + 1.0')

  # - 
  q <- translate_sql(c1 - c2, con = map_con) %>% as.character
  expect_identical(q, '"c1" - "c2"')

  q <- translate_sql(c1 - 1L, con = map_con) %>% as.character
  expect_identical(q, '"c1" - 1')

  q <- translate_sql(c1 - 1, con = map_con) %>% as.character
  expect_identical(q, '"c1" - 1.0')

  # / 
  q <- translate_sql(c1 / c2, con = map_con) %>% as.character
  expect_identical(q, '"c1" / "c2"')

  q <- translate_sql(c1 / 1L, con = map_con) %>% as.character
  expect_identical(q, '"c1" / 1')

  q <- translate_sql(c1 / 1, con = map_con) %>% as.character
  expect_identical(q, '"c1" / 1.0')

  # * 
  q <- translate_sql(c1 * c2, con = map_con) %>% as.character
  expect_identical(q, '"c1" * "c2"')

  q <- translate_sql(c1 * 1L, con = map_con) %>% as.character
  expect_identical(q, '"c1" * 1')

  q <- translate_sql(c1 * 1, con = map_con) %>% as.character
  expect_identical(q, '"c1" * 1.0')

  # MOD 
  q <- translate_sql(c1 %% c2, con = map_con) %>% as.character
  expect_identical(q, '"c1" MOD "c2"')

  q <- translate_sql(c1 %% 1L, con = map_con) %>% as.character
  expect_identical(q, '"c1" MOD 1')

  q <- translate_sql(c1 %% 1, con = map_con) %>% as.character
  expect_identical(q, '"c1" MOD 1.0')

  # FLOOR
  q <- translate_sql(c1 %/% c2, con = map_con) %>% as.character
  expect_identical(q, 'FLOOR(("c1") / ("c2"))')

  q <- translate_sql(c1 %/% 1L, con = map_con) %>% as.character
  expect_identical(q, 'FLOOR(("c1") / (1))')

  q <- translate_sql(c1 %/% 1, con = map_con) %>% as.character
  expect_identical(q, 'FLOOR(("c1") / (1.0))')

  # POWER
  q <- translate_sql(c1^c2, con = map_con) %>% as.character
  expect_identical(q, 'POWER("c1", "c2")')

  q <- translate_sql(c1^1L, con = map_con) %>% as.character
  expect_identical(q, 'POWER("c1", 1)')

  q <- translate_sql(c1^1, con = map_con) %>% as.character
  expect_identical(q, 'POWER("c1", 1.0)')

})

test_that("Boolean Operators mapped", {

  # != 
  q <- translate_sql(c1 != c2, con = map_con) %>% as.character
  expect_identical(q, '"c1" <> "c2"')

  #  ==
  q <- translate_sql(c1 == c2, con = map_con) %>% as.character
  expect_identical(q, '"c1" = "c2"')

  # <, <=, >, >=, 
  q <- translate_sql(c1 < c2, con = map_con) %>% as.character
  expect_identical(q, '"c1" < "c2"')

  q <- translate_sql(c1 <= c2, con = map_con) %>% as.character
  expect_identical(q, '"c1" <= "c2"')

  q <- translate_sql(c1 > c2, con = map_con) %>% as.character
  expect_identical(q, '"c1" > "c2"')

  q <- translate_sql(c1 >= c2, con = map_con) %>% as.character
  expect_identical(q, '"c1" >= "c2"')
  
  #! Note the precedence
  q <- translate_sql(!(c1) >= c2, con = map_con) %>% as.character
  expect_identical(q, 'NOT(("c1") >= "c2")')

  q <- translate_sql(!c1 >= c2, con = map_con) %>% as.character
  expect_identical(q, 'NOT("c1" >= "c2")')

  q <- translate_sql(!(c1 >= c2), con = map_con) %>% as.character
  expect_identical(q, 'NOT(("c1" >= "c2"))')
  
  #& &&
  q <- translate_sql(c1 & c2, con = map_con) %>% as.character
  p <- translate_sql(c1 && c2, con = map_con) %>% as.character
  expect_identical(q, p)
  expect_identical(q, '"c1" AND "c2"')
  
  # |, ||
  q <- translate_sql(c1 | c2, con = map_con) %>% as.character
  p <- translate_sql(c1 || c2, con = map_con) %>% as.character
  expect_identical(q, p)
  expect_identical(q, '"c1" OR "c2"')

  #xor
  q <- translate_sql(xor(c1, c2), con = map_con) %>% as.character
  expect_identical(q, '"c1" OR "c2" AND NOT ("c1" AND "c2")')

  #is.null, is.na
  q <- translate_sql(is.null(c1), con = map_con) %>% as.character
  q <- translate_sql(is.a(c1), con = map_con) %>% as.character

  # if, if_else, if else
  q <- translate_sql(`if`(c1, 1), con = map_con) %>% as.character
  expect_identical('CASE WHEN ("c1") THEN (1.0) END', q)

  q <- translate_sql(if_else(c1, 1, 2), con = map_con) %>% as.character
  expect_identical('CASE WHEN ("c1") THEN (1.0) WHEN NOT("c1") THEN (2.0) END', q)

  p <- translate_sql(`if`(c1, 1, 2), con = map_con) %>% as.character
  expect_identical(p, q)

  p <- translate_sql(if(c1) 1 else 2, con = map_con) %>% as.character
  expect_identical(p, q)
})


test_that('character ops mapped', {

  # tolower
  q <- translate_sql(tolower(c1), con = map_con) %>% as.character
  expect_identical(q, 'LOWER("c1")')

  # toupper
  q <- translate_sql(toupper(c1), con = map_con) %>% as.character
  expect_identical(q, 'UPPER("c1")')

  # nchar
  q <- translate_sql(nchar(c1), con = map_con) %>% as.character
  expect_identical(q, 'CHARACTER_LENGTH("c1")')

  # single quote -> char vec literal
  q <- translate_sql(nchar('123'), con = map_con) %>% as.character
  expect_identical(q, "CHARACTER_LENGTH('123')")

  # str_length
  q <- translate_sql(str_length(c1), con = map_con) %>% as.character
  expect_identical(q, 'LENGTH("c1")')

  # double quote -> char vec literal
  q <- translate_sql(str_length("123"), con = map_con) %>% as.character
  expect_identical(q, "LENGTH('123')")

  # should allow columns to be used for start and stop as well
  # substr index starts at 1
  q <- translate_sql(substr(x, start, stop), con = map_con) %>% as.character
  expect_identical(q, 'SUBSTRING("x" FROM "start" FOR ("stop" - "start" + 1))')

  q <- translate_sql(substr(x, start), con = map_con) %>% as.character
  expect_identical(q, 'SUBSTRING("x" FROM "start")')

  q <- translate_sql(substr(x, 1L, 4L), con = map_con) %>% as.character
  expect_identical(q, 'SUBSTRING("x" FROM 1 FOR (4 - 1 + 1))')

  # dbl literals
  q <- translate_sql(substr(x, 1, 4), con = map_con) %>% as.character
  expect_identical(q, 'SUBSTRING("x" FROM 1.0 FOR (4.0 - 1.0 + 1))')

  # substring (aka substr)
  q <- translate_sql(substring(x, start, stop), con = map_con) %>% as.character
  expect_identical(q, 'SUBSTRING("x" FROM "start" FOR ("stop" - "start" + 1))')

  q <- translate_sql(substring(x, start), con = map_con) %>% as.character
  expect_identical(q, 'SUBSTRING("x" FROM "start")')

  q <- translate_sql(substring(x, 1L, 4L), con = map_con) %>% as.character
  expect_identical(q, 'SUBSTRING("x" FROM 1 FOR (4 - 1 + 1))')

  # dbl literals
  q <- translate_sql(substring(x, 1, 4), con = map_con) %>% as.character
  expect_identical(q, 'SUBSTRING("x" FROM 1.0 FOR (4.0 - 1.0 + 1))')

  # grep
  q <- translate_sql(grep(regexp, src , TRUE), con = map_con) %>% as.character
  expect_identical(q, 'REGEXP_SUBSTR("src", "regexp", 1, 1, \'i\')')

  q <- translate_sql(grep(regexp, src , FALSE), con = map_con) %>% as.character
  expect_identical(q, 'REGEXP_SUBSTR("src", "regexp", 1, 1, \'c\')')

  q <- translate_sql(grep('ch(i|o)p', 'mint chocolate chip'), con = map_con) %>% as.character
  expect_identical(q, "REGEXP_SUBSTR('mint chocolate chip', 'ch(i|o)p', 1, 1, 'c')")

  # str_extract
  q <- translate_sql(str_extract(string, pattern), con = map_con) %>% as.character
  expect_identical(q, 'REGEXP_SUBSTR("string", "pattern", 1, 1, \'c\')')

  q <- translate_sql(str_extract('mint chocolate chip', 'ch(i|o)p'), con = map_con) %>% as.character
  expect_identical(q, "REGEXP_SUBSTR('mint chocolate chip', 'ch(i|o)p', 1, 1, 'c')")

  # sub
  q <- translate_sql(sub(pattern, replacement, x, TRUE), con = map_con) %>% as.character
  expect_identical(q, 'REGEXP_REPLACE("x", "pattern", "replacement", 1, 1, \'i\')')

  q <- translate_sql(sub(pattern, replacement, x, FALSE), con = map_con) %>% as.character
  expect_identical(q, 'REGEXP_REPLACE("x", "pattern", "replacement", 1, 1, \'c\')')

  q <- translate_sql(sub('ch(i|o)p', 'chunk', x), con = map_con) %>% as.character
  expect_identical(q, 'REGEXP_REPLACE("x", \'ch(i|o)p\', \'chunk\', 1, 1, \'c\')')
  
  # gsub
  q <- translate_sql(gsub(pattern, replacement, x, TRUE), con = map_con) %>% as.character
  expect_identical(q, 'REGEXP_REPLACE("x", "pattern", "replacement", 1, 0, \'i\')')

  q <- translate_sql(gsub(pattern, replacement, x, FALSE), con = map_con) %>% as.character
  expect_identical(q, 'REGEXP_REPLACE("x", "pattern", "replacement", 1, 0, \'c\')')

  q <- translate_sql(gsub('ch(i|o)p', 'chunk', x), con = map_con) %>% as.character
  expect_identical(q, 'REGEXP_REPLACE("x", \'ch(i|o)p\', \'chunk\', 1, 0, \'c\')')
  
  # str_replace
  q <- translate_sql(str_replace(string, pattern, replacement), con = map_con) %>% as.character
  expect_identical(q, 'REGEXP_REPLACE("string", "pattern", "replacement", 1, 1, \'c\')')

  q <- translate_sql(str_replace(x, 'ch(i|o)p', 'chunk'), con = map_con) %>% as.character
  expect_identical(q, 'REGEXP_REPLACE("x", \'ch(i|o)p\', \'chunk\', 1, 1, \'c\')')
  
  # paste
  q <- translate_sql(paste(a, b, c), con = map_con) %>% as.character
  expect_identical(q, '"a" || \' \' || "b" || \' \' || "c"')

  q <- translate_sql(paste(a, b, c, sep = ''), con = map_con) %>% as.character
  expect_identical(q, '"a" || \'\' || "b" || \'\' || "c"')

  q <- translate_sql(paste(a, b, c, sep = ', '), con = map_con) %>% as.character
  expect_identical(q, '"a" || \', \' || "b" || \', \' || "c"')

  # paste0, like paste but sep = ''
  q <- translate_sql(paste0(a, b, c), con = map_con) %>% as.character
  expect_identical(q, '"a" || \'\' || "b" || \'\' || "c"')

  # str_join (alias of paste)
  q <- translate_sql(str_join(a, b, c), con = map_con) %>% as.character
  expect_identical(q, '"a" || \' \' || "b" || \' \' || "c"')

  q <- translate_sql(str_join(a, b, c, sep = ''), con = map_con) %>% as.character
  expect_identical(q, '"a" || \'\' || "b" || \'\' || "c"')

  q <- translate_sql(str_join(a, b, c, sep = ', '), con = map_con) %>% as.character
  expect_identical(q, '"a" || \', \' || "b" || \', \' || "c"')

  # str_trim
  expect_error(q <- translate_sql(str_trim(string), con = map_con), 
               'side must be one of "both", "left", or "right"')

  q <- translate_sql(str_trim(string, side = 'both'), con = map_con) %>% as.character
  expect_identical(q, 'RTRIM(LTRIM("string", \' \n\t\r\v\f\'), \' \n\t\r\v\f\')')

  q <- translate_sql(str_trim(string, side = 'left'), con = map_con) %>% as.character
  expect_identical(q, 'LTRIM("string", \' \n\t\r\v\f\')')

  q <- translate_sql(str_trim(string, side = 'right'), con = map_con) %>% as.character
  expect_identical(q, 'RTRIM("string", \' \n\t\r\v\f\')')

  q <- translate_sql(str_trim(' \n\tab \v\fc \r\t', side = 'right'), con = map_con) %>% as.character
  expect_identical(q, 'RTRIM(\' \n\tab \v\fc \r\t\', \' \n\t\r\v\f\')')

  q <- translate_sql(str_trim(' \n\tab \v\fc \r\t', side = 'left'), con = map_con) %>% as.character
  expect_identical(q, 'LTRIM(\' \n\tab \v\fc \r\t\', \' \n\t\r\v\f\')')

  # str_locate
  q <- translate_sql(str_locate(string, pattern), con = map_con) %>% as.character
  expect_identical(q, 'REGEXP_INSTR("string", "pattern", 1, 1, 0, \'c\')')

  q <- translate_sql(str_locate(string, pattern, return_opt = 0), con = map_con) %>% as.character
  expect_identical(q, 'REGEXP_INSTR("string", "pattern", 1, 1, 0, \'c\')')

  q <- translate_sql(str_locate(string, pattern, return_opt = 1), con = map_con) %>% as.character
  expect_identical(q, paste0("CASE WHEN (REGEXP_INSTR(\"string\", \"pattern\", 1, 1, 1, 'c') > 0)", 
                              " THEN (REGEXP_INSTR(\"string\", \"pattern\", 1, 1, 1, 'c') - 1)", 
                              " WHEN NOT(REGEXP_INSTR(\"string\", \"pattern\", 1, 1, 1, 'c') > 0)", 
                              " THEN (REGEXP_INSTR(\"string\", \"pattern\", 1, 1, 1, 'c'))",
                              " END"))

  q <- translate_sql(str_locate('a1 b2 c3', 'b2'), con = map_con) %>% as.character
  expect_identical(q, 'REGEXP_INSTR(\'a1 b2 c3\', \'b2\', 1, 1, 0, \'c\')')

  # strsplit
  q <- translate_sql(strsplit(x), con = map_con) %>% as.character
  expect_identical(q, 'STRTOK("x", \' \', 1)')

  q <- translate_sql(strsplit(x, split = '\n\t'), con = map_con) %>% as.character
  expect_identical(q, 'STRTOK("x", \'\n\t\', 1)')

  q <- translate_sql(strsplit(x, split = '\n\t', tokennum = 2L), con = map_con) %>% as.character
  expect_identical(q, 'STRTOK("x", \'\n\t\', 2)')

  q <- translate_sql(strsplit('abc\n\tdefg', split = '\n\t', tokennum = 2L), con = map_con) %>% as.character
  expect_identical(q, 'STRTOK(\'abc\n\tdefg\', \'\n\t\', 2)')
  
  # str_replace_all
  q <- translate_sql(str_replace_all(string, pattern, replacement), con = map_con) %>% as.character
  expect_identical(q, 'OREPLACE(\"string\", \"pattern\", \"replacement\")')
  
  q <- translate_sql(str_replace_all(x, 'ch(i|o)p', 'chunk'), con = map_con) %>% as.character
  expect_identical(q, 'OREPLACE(\"x\", \'ch(i|o)p\', \'chunk\')')
  
  # str_detect
  q <- translate_sql(str_detect(string, pattern), con = map_con) %>% as.character
  expect_identical(q, "INSTR(\"string\", \"pattern\") > 0")
  
  q <- translate_sql(str_detect(x, "chi"), con = map_con) %>% as.character
  expect_identical(q, 'INSTR(\"x\", \'chi\') > 0')
  
})

test_that('window functions are mapped correctly', {

  # ordered window functions

  # row_number()
  q <- translate_sql(row_number(), con = map_con) %>% as.character
  expect_identical(q, 'ROW_NUMBER() OVER ()')

  q <- translate_sql(row_number(x), con = map_con) %>% as.character
  expect_identical(q, 'ROW_NUMBER() OVER (ORDER BY "x")')

  q <- translate_sql(row_number(desc(x)), con = map_con) %>% as.character
  expect_identical(q, 'ROW_NUMBER() OVER (ORDER BY "x" DESC)')

  # function arg gets translated literally, doesn't compose
  # this makes sense since the parameters are column expressions
  q <- translate_sql(row_number(desc), vars_order = c('x'), con = map_con) %>% as.character
  expect_identical(q, 'ROW_NUMBER() OVER (ORDER BY "desc")')

  q <- translate_sql(row_number(), vars_group = c('y'), con = map_con) %>% as.character
  expect_identical(q, 'ROW_NUMBER() OVER (PARTITION BY "y")')

  q <- translate_sql(row_number(), vars_order = c('x'), vars_group = c('y'), con = map_con) %>% as.character
  expect_identical(q, 'ROW_NUMBER() OVER (PARTITION BY "y" ORDER BY "x")')

  # rank()
  q <- translate_sql(rank(), con = map_con) %>% as.character
  expect_identical(q, 'RANK() OVER ()')

  q <- translate_sql(rank(x), con = map_con) %>% as.character
  expect_identical(q, 'RANK() OVER (ORDER BY "x")')

  q <- translate_sql(rank(), vars_order = c('x'), con = map_con) %>% as.character
  expect_identical(q, 'RANK() OVER (ORDER BY "x")')

  q <- translate_sql(rank(c('x', 'y', 'z')), vars_order = c('x'), con = map_con) %>% as.character
  expect_identical(q, 'RANK() OVER (ORDER BY "x", "y", "z")')

  q <- translate_sql(rank(desc(x)), con = map_con) %>% as.character
  expect_identical(q, 'RANK() OVER (ORDER BY "x" DESC)')

  q <- translate_sql(rank(c(x, y, desc(z))), con = map_con) %>% as.character
  expect_identical(q, 'RANK() OVER (ORDER BY "x", "y", "z" DESC)')

  q <- translate_sql(rank(desc), vars_order = c('x'), con = map_con) %>% as.character
  expect_identical(q, 'RANK() OVER (ORDER BY "desc")')

  q <- translate_sql(rank(x), vars_group = c('y'), con = map_con) %>% as.character
  expect_identical(q, 'RANK() OVER (PARTITION BY "y" ORDER BY "x")')

  # dense_rank()
  q <- translate_sql(dense_rank(), con = map_con) %>% as.character
  expect_identical(q, 'DENSE_RANK() OVER ()')

  q <- translate_sql(dense_rank(x), con = map_con) %>% as.character
  expect_identical(q, 'DENSE_RANK() OVER (ORDER BY "x")')

  q <- translate_sql(dense_rank(), vars_order = c('x'), con = map_con) %>% as.character
  expect_identical(q, 'DENSE_RANK() OVER (ORDER BY "x")')

  q <- translate_sql(dense_rank(desc(x)), con = map_con) %>% as.character
  expect_identical(q, 'DENSE_RANK() OVER (ORDER BY "x" DESC)')

  q <- translate_sql(dense_rank(desc), vars_order = c('x'), con = map_con) %>% as.character
  expect_identical(q, 'DENSE_RANK() OVER (ORDER BY "desc")')

  q <- translate_sql(dense_rank(x), vars_group = c('y'), con = map_con) %>% as.character
  expect_identical(q, 'DENSE_RANK() OVER (PARTITION BY "y" ORDER BY "x")')

  # percent_rank()
  q <- translate_sql(percent_rank(), con = map_con) %>% as.character
  expect_identical(q, 'PERCENT_RANK() OVER ()')

  q <- translate_sql(percent_rank(x), con = map_con) %>% as.character
  expect_identical(q, 'PERCENT_RANK() OVER (ORDER BY "x")')

  q <- translate_sql(percent_rank(), vars_order = c('x'), con = map_con) %>% as.character
  expect_identical(q, 'PERCENT_RANK() OVER (ORDER BY "x")')

  q <- translate_sql(percent_rank(desc(x)), con = map_con) %>% as.character
  expect_identical(q, 'PERCENT_RANK() OVER (ORDER BY "x" DESC)')

  q <- translate_sql(percent_rank(desc), con = map_con) %>% as.character
  expect_identical(q, 'PERCENT_RANK() OVER (ORDER BY "desc")')

  q <- translate_sql(percent_rank(x), vars_group = c('y'), con = map_con) %>% as.character
  expect_identical(q, 'PERCENT_RANK() OVER (PARTITION BY "y" ORDER BY "x")')

  # cume_dist()
  q <- translate_sql(cume_dist(), con = map_con) %>% as.character
  expect_identical(q, 'CUME_DIST() OVER ()')

  q <- translate_sql(cume_dist(x), con = map_con) %>% as.character
  expect_identical(q, 'CUME_DIST() OVER (ORDER BY "x")')

  q <- translate_sql(cume_dist(), vars_order = c('x'), con = map_con) %>% as.character
  expect_identical(q, 'CUME_DIST() OVER (ORDER BY "x")')

  q <- translate_sql(cume_dist(desc(x)), con = map_con) %>% as.character
  expect_identical(q, 'CUME_DIST() OVER (ORDER BY "x" DESC)')

  q <- translate_sql(cume_dist(desc), con = map_con) %>% as.character
  expect_identical(q, 'CUME_DIST() OVER (ORDER BY "desc")')

  q <- translate_sql(cume_dist(x), vars_group = c('y'), con = map_con) %>% as.character
  expect_identical(q, 'CUME_DIST() OVER (PARTITION BY "y" ORDER BY "x")')

  
  # first()
  expect_error(translate_sql(first(), con = map_con) %>% as.character, 
               'argument "x" is missing, with no default')

  q <- translate_sql(first(x), con = map_con) %>% as.character
  expect_identical(q, 'first_value("x") OVER ()')

  # order_by param
  q <- translate_sql(first(x, order_by = a), con = map_con) %>% as.character
  expect_identical(q, 'first_value("x") OVER (ORDER BY "a")')

  # order_by()
  q <- translate_sql(order_by(a, first(x)), con = map_con) %>% as.character
  expect_identical(q, 'first_value("x") OVER (ORDER BY "a")')

  # mimic window_frame()
  q <- translate_sql(first(x), vars_order = c('a'), con = map_con) %>% as.character
  expect_identical(q, 'first_value("x") OVER (ORDER BY "a")')

  q <- translate_sql(first(x, ignore_nulls = TRUE), con = map_con) %>% as.character
  expect_identical(q, 'first_value("x" ignore nulls) OVER ()')

  q <- translate_sql(first(x), vars_group = c('b'), con = map_con) %>% as.character
  expect_identical(q, 'first_value("x") OVER (PARTITION BY "b")')

  q <- translate_sql(first(x, order_by = a, ignore_nulls = TRUE), 
                     vars_group = c('b'), 
                     con = map_con) %>% 
                     as.character

  expect_identical(q, 'first_value("x" ignore nulls) OVER (PARTITION BY "b" ORDER BY "a")')

  # last()
  expect_error(translate_sql(last(), con = map_con) %>% as.character,
               'argument "x" is missing, with no default')

  q <- translate_sql(last(x), con = map_con) %>% as.character
  expect_identical(q, 'last_value("x") OVER ()')

  q <- translate_sql(last(x, order_by = a), con = map_con) %>% as.character
  expect_identical(q, 'last_value("x") OVER (ORDER BY "a")')

  q <- translate_sql(order_by(a, last(x)), con = map_con) %>% as.character
  expect_identical(q, 'last_value("x") OVER (ORDER BY "a")')

  q <- translate_sql(last(x), vars_order = c('a'), con = map_con) %>% as.character
  expect_identical(q, 'last_value("x") OVER (ORDER BY "a")')

  q <- translate_sql(last(x, ignore_nulls = TRUE), con = map_con) %>% as.character
  expect_identical(q, 'last_value("x" ignore nulls) OVER ()')

  q <- translate_sql(last(x), vars_group = c('b'), con = map_con) %>% as.character
  expect_identical(q, 'last_value("x") OVER (PARTITION BY "b")')

  q <- translate_sql(last(x, order_by = a, ignore_nulls = TRUE), 
                     vars_group = c('b'), 
                     con = map_con) %>% 
                     as.character

  expect_identical(q, 'last_value("x" ignore nulls) OVER (PARTITION BY "b" ORDER BY "a")')

  # lag()
  expect_error(translate_sql(lag(), con = map_con) %>% as.character, 
               'argument "x" is missing, with no default')

  q <- translate_sql(lag(x), con = map_con) %>% as.character
  expect_identical(q, 'LAG("x", 1, NULL) OVER ()')

  q <- translate_sql(lag(x, n = 2L), con = map_con) %>% as.character
  expect_identical(q, 'LAG("x", 2, NULL) OVER ()')

  q <- translate_sql(lag(x, default = 0L), con = map_con) %>% as.character
  expect_identical(q, 'LAG("x", 1, 0) OVER ()')

  q <- translate_sql(lag(x, order_by = d), con = map_con) %>% as.character
  expect_identical(q, 'LAG("x", 1, NULL) OVER (ORDER BY "d")')

  q <- translate_sql(order_by(d, lag(x)), con = map_con) %>% as.character
  expect_identical(q, 'LAG("x", 1, NULL) OVER (ORDER BY "d")')

  q <- translate_sql(lag(x), vars_order = c('d'), con = map_con) %>% as.character
  expect_identical(q, 'LAG("x", 1, NULL) OVER (ORDER BY "d")')

  q <- translate_sql(lag(x, ignore_nulls = TRUE), con = map_con) %>% as.character
  expect_identical(q, 'LAG("x" ignore nulls, 1, NULL) OVER ()')

  q <- translate_sql(lag(x), vars_group = c('z'), con = map_con) %>% as.character
  expect_identical(q, 'LAG("x", 1, NULL) OVER (PARTITION BY "z")')

  q <- translate_sql(lag(x, n = 3L, default = 0L, order_by = d, ignore_nulls = TRUE), 
                     vars_group = c('z'), 
                     con = map_con) %>% 
                     as.character
  expect_identical(q, 'LAG("x" ignore nulls, 3, 0) OVER (PARTITION BY "z" ORDER BY "d")')

  # lead() 
  expect_error(translate_sql(lead(), con = map_con) %>% as.character, 
               'argument "x" is missing, with no default')

  q <- translate_sql(lead(x), con = map_con) %>% as.character
  expect_identical(q, 'LEAD("x", 1, NULL) OVER ()')

  q <- translate_sql(lead(x, n = 2L), con = map_con) %>% as.character
  expect_identical(q, 'LEAD("x", 2, NULL) OVER ()')

  q <- translate_sql(lead(x, default = 0L), con = map_con) %>% as.character
  expect_identical(q, 'LEAD("x", 1, 0) OVER ()')

  q <- translate_sql(lead(x, order_by = d), con = map_con) %>% as.character
  expect_identical(q, 'LEAD("x", 1, NULL) OVER (ORDER BY "d")')

  q <- translate_sql(order_by(d, lead(x)), con = map_con) %>% as.character
  expect_identical(q, 'LEAD("x", 1, NULL) OVER (ORDER BY "d")')

  q <- translate_sql(lead(x), vars_order = c('d'), con = map_con) %>% as.character
  expect_identical(q, 'LEAD("x", 1, NULL) OVER (ORDER BY "d")')

  q <- translate_sql(lead(x, ignore_nulls = TRUE), con = map_con) %>% as.character
  expect_identical(q, 'LEAD("x" ignore nulls, 1, NULL) OVER ()')

  q <- translate_sql(lead(x), vars_group = c('z'), con = map_con) %>% as.character
  expect_identical(q, 'LEAD("x", 1, NULL) OVER (PARTITION BY "z")')

  q <- translate_sql(lead(x, n = 3L, default = 0L, order_by = d, ignore_nulls = TRUE), 
                     vars_group = c('z'), 
                     con = map_con) %>% 
                     as.character
  expect_identical(q, 'LEAD("x" ignore nulls, 3, 0) OVER (PARTITION BY "z" ORDER BY "d")')

  ## nth() not supported
  expect_error(translate_sql(nth(), con = map_con) %>% as.character,
               'Window function `nth\\(\\)` is not supported by this database')

  ## ntile()

  q <- translate_sql(ntile(4, y), con = map_con) %>% as.character
  expect_identical('(RANK() OVER (ORDER BY "y") - 1) * 4.0 / COUNT(*) OVER ()', q)

  q <- translate_sql(ntile(4L, y), con = map_con) %>% as.character
  expect_identical('(RANK() OVER (ORDER BY "y") - 1) * 4 / COUNT(*) OVER ()', q)

  expect_error(translate_sql(ntile(x, y), con = map_con) %>% as.character,
               'n must be numeric when using ntile')

  q <- translate_sql(ntile(10, y), vars_group = c('z'), con = map_con) %>% as.character
  expect_identical('(RANK() OVER (PARTITION BY "z" ORDER BY "y") - 1) * 10.0 / COUNT(*) OVER (PARTITION BY "z")', q)

  # order by should be ignored
  q <- translate_sql(ntile(10, y), vars_order = c('h'), vars_group = c('z'), con = map_con) %>% as.character
  expect_identical('(RANK() OVER (PARTITION BY "z" ORDER BY "y") - 1) * 10.0 / COUNT(*) OVER (PARTITION BY "z")', q)

  q <- translate_sql(ntile(10, y), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('(RANK() OVER (ORDER BY "y") - 1) * 10.0 / COUNT(*) OVER ()', q)

  q <- translate_sql(order_by(h, ntile(10, y)), con = map_con) %>% as.character
  expect_identical('(RANK() OVER (ORDER BY "y") - 1) * 10.0 / COUNT(*) OVER ()', q)

  # order_by can be NULL, will look for arrange()
  expect_error(translate_sql(ntile(10), con = map_con), NA)

})

test_that('window aggregate functions are mapped correctly', {


  # varp (var_pop)
  q <-  translate_sql(varp(x, na.rm = TRUE), con = map_con) %>% as.character
  expect_identical('VAR_POP("x") OVER ()', q)

  # aggregates return results where order doesn't matter
  q <- translate_sql(varp(x, na.rm = TRUE), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('VAR_POP("x") OVER ()', q)

  q <- translate_sql(order_by(h, varp(x, na.rm = TRUE)), con = map_con) %>% as.character
  expect_identical('VAR_POP("x") OVER ()', q)

  # except when you specify a frame
  q <- translate_sql(varp(x, na.rm = TRUE), vars_frame = c(-10, 10), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('VAR_POP("x") OVER (ORDER BY "h" ROWS BETWEEN 10 PRECEDING AND 10 FOLLOWING)', q)

  q <- translate_sql(order_by(h, varp(x, na.rm = TRUE)), vars_frame = c(1, 10), con = map_con) %>% as.character
  expect_identical('VAR_POP("x") OVER (ORDER BY "h" ROWS BETWEEN 1 FOLLOWING AND 10 FOLLOWING)', q)

  # partition by
  q <- translate_sql(order_by(h, varp(x, na.rm = TRUE)), vars_group = c('y'), vars_frame = c(-10, -1), con = map_con) %>% as.character
  expect_identical('VAR_POP("x") OVER (PARTITION BY "y" ORDER BY "h" ROWS BETWEEN 10 PRECEDING AND 1 PRECEDING)', q)

  ## var (var_samp)

  q <-  translate_sql(var(x, na.rm = TRUE), con = map_con) %>% as.character
  expect_identical('VAR_SAMP("x") OVER ()', q)

  # aggregates return results where order doesn't matter
  q <- translate_sql(var(x, na.rm = TRUE), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('VAR_SAMP("x") OVER ()', q)

  q <- translate_sql(order_by(h, var(x, na.rm = TRUE)), con = map_con) %>% as.character
  expect_identical('VAR_SAMP("x") OVER ()', q)

  # except when you specify a frame
  q <- translate_sql(var(x, na.rm = TRUE), vars_frame = c(-10, 10), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('VAR_SAMP("x") OVER (ORDER BY "h" ROWS BETWEEN 10 PRECEDING AND 10 FOLLOWING)', q)

  q <- translate_sql(order_by(h, var(x, na.rm = TRUE)), vars_frame = c(1, 10), con = map_con) %>% as.character
  expect_identical('VAR_SAMP("x") OVER (ORDER BY "h" ROWS BETWEEN 1 FOLLOWING AND 10 FOLLOWING)', q)

  # partition by
  q <- translate_sql(order_by(h, var(x, na.rm = TRUE)), vars_group = c('y'), vars_frame = c(-10, -1), con = map_con) %>% as.character
  expect_identical('VAR_SAMP("x") OVER (PARTITION BY "y" ORDER BY "h" ROWS BETWEEN 10 PRECEDING AND 1 PRECEDING)', q)

  ## sdp (stddev_pop)

  q <-  translate_sql(sdp(x, na.rm = TRUE), con = map_con) %>% as.character
  expect_identical('STDDEV_POP("x") OVER ()', q)

  # aggregates return results where order doesn't matter
  q <- translate_sql(sdp(x, na.rm = TRUE), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('STDDEV_POP("x") OVER ()', q)

  q <- translate_sql(order_by(h, sdp(x, na.rm = TRUE)), con = map_con) %>% as.character
  expect_identical('STDDEV_POP("x") OVER ()', q)

  # except when you specify a frame
  q <- translate_sql(sdp(x, na.rm = TRUE), vars_frame = c(-1, 10), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('STDDEV_POP("x") OVER (ORDER BY "h" ROWS BETWEEN 1 PRECEDING AND 10 FOLLOWING)', q)

  q <- translate_sql(order_by(h, sdp(x, na.rm = TRUE)), vars_frame = c(-1, 10), con = map_con) %>% as.character
  expect_identical('STDDEV_POP("x") OVER (ORDER BY "h" ROWS BETWEEN 1 PRECEDING AND 10 FOLLOWING)', q)

  # partition by
  q <- translate_sql(order_by(h, sdp(x, na.rm = TRUE)), vars_group = c('y'), vars_frame = c(-1, 10), con = map_con) %>% as.character
  expect_identical('STDDEV_POP("x") OVER (PARTITION BY "y" ORDER BY "h" ROWS BETWEEN 1 PRECEDING AND 10 FOLLOWING)', q)

  ## sd (stddev_samp)

  q <-  translate_sql(sd(x, na.rm = TRUE), con = map_con) %>% as.character
  expect_identical('STDDEV_SAMP("x") OVER ()', q)

  # aggregates return results where order doesn't matter
  q <- translate_sql(sd(x, na.rm = TRUE), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('STDDEV_SAMP("x") OVER ()', q)

  q <- translate_sql(order_by(h, sd(x, na.rm = TRUE)), con = map_con) %>% as.character
  expect_identical('STDDEV_SAMP("x") OVER ()', q)

  # except when you specify a frame
  q <- translate_sql(sd(x, na.rm = TRUE), vars_frame = c(-1, 10), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('STDDEV_SAMP("x") OVER (ORDER BY "h" ROWS BETWEEN 1 PRECEDING AND 10 FOLLOWING)', q)

  q <- translate_sql(order_by(h, sd(x, na.rm = TRUE)), vars_frame = c(-1, 10), con = map_con) %>% as.character
  expect_identical('STDDEV_SAMP("x") OVER (ORDER BY "h" ROWS BETWEEN 1 PRECEDING AND 10 FOLLOWING)', q)

  # partition by
  q <- translate_sql(order_by(h, sd(x, na.rm = TRUE)), vars_group = c('y'), vars_frame = c(-1, 10), con = map_con) %>% as.character
  expect_identical('STDDEV_SAMP("x") OVER (PARTITION BY "y" ORDER BY "h" ROWS BETWEEN 1 PRECEDING AND 10 FOLLOWING)', q)

  ## min
  q <-  translate_sql(min(x, na.rm = TRUE), con = map_con) %>% as.character
  expect_identical('MIN("x") OVER ()', q)

  # aggregates return results where order doesn't matter
  q <- translate_sql(min(x, na.rm = TRUE), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('MIN("x") OVER ()', q)

  q <- translate_sql(order_by(h, min(x, na.rm = TRUE)), con = map_con) %>% as.character
  expect_identical('MIN("x") OVER ()', q)

  # except when you specify a frame
  q <- translate_sql(min(x, na.rm = TRUE), vars_frame = c(-Inf, Inf), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('MIN("x") OVER (ORDER BY "h" ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)', q)

  q <- translate_sql(order_by(h, min(x, na.rm = TRUE)), vars_frame = c(-Inf, Inf), con = map_con) %>% as.character
  expect_identical('MIN("x") OVER (ORDER BY "h" ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)', q)

  # partition by
  q <- translate_sql(order_by(h, min(x, na.rm = TRUE)), vars_group = c('y'), vars_frame = c(-Inf, Inf), con = map_con) %>% as.character
  expect_identical('MIN("x") OVER (PARTITION BY "y" ORDER BY "h" ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)', q)

  ## max
  q <-  translate_sql(max(x, na.rm = TRUE), con = map_con) %>% as.character
  expect_identical('MAX("x") OVER ()', q)

  # aggregates return results where order doesn't matter
  q <- translate_sql(max(x, na.rm = TRUE), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('MAX("x") OVER ()', q)

  q <- translate_sql(order_by(h, max(x, na.rm = TRUE)), con = map_con) %>% as.character
  expect_identical('MAX("x") OVER ()', q)

  # except when you specify a frame
  q <- translate_sql(max(x, na.rm = TRUE), vars_frame = c(-1, 0), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('MAX("x") OVER (ORDER BY "h" ROWS 1 PRECEDING)', q)

  q <- translate_sql(order_by(h, max(x, na.rm = TRUE)), vars_frame = c(0, 1), con = map_con) %>% as.character
  expect_identical('MAX("x") OVER (ORDER BY "h" ROWS BETWEEN CURRENT ROW AND 1 FOLLOWING)', q)

  ## mean()
  q <-  translate_sql(mean(x, na.rm = TRUE), con = map_con) %>% as.character
  expect_identical('AVG("x") OVER ()', q)

  # aggregates return results where order doesn't matter
  q <- translate_sql(mean(x, na.rm = TRUE), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('AVG("x") OVER ()', q)

  q <- translate_sql(order_by(h, mean(x, na.rm = TRUE)), con = map_con) %>% as.character
  expect_identical('AVG("x") OVER ()', q)

  # except when you specify a frame
  q <- translate_sql(mean(x, na.rm = TRUE), vars_frame = c(-Inf, 0), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('AVG("x") OVER (ORDER BY "h" ROWS UNBOUNDED PRECEDING)', q)

  q <- translate_sql(order_by(h, mean(x, na.rm = TRUE)), vars_frame = c(-Inf, 0), con = map_con) %>% as.character
  expect_identical('AVG("x") OVER (ORDER BY "h" ROWS UNBOUNDED PRECEDING)', q)

  ## sum()
  q <-  translate_sql(sum(x, na.rm = TRUE), con = map_con) %>% as.character
  expect_identical('SUM("x") OVER ()', q)

  # aggregates return results where order doesn't matter
  q <- translate_sql(sum(x, na.rm = TRUE), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('SUM("x") OVER ()', q)

  q <- translate_sql(order_by(h, sum(x, na.rm = TRUE)), con = map_con) %>% as.character
  expect_identical('SUM("x") OVER ()', q)

  # except when you specify a frame
  q <- translate_sql(sum(x, na.rm = TRUE), vars_frame = c(-Inf, 0), vars_order = c('h'), con = map_con) %>% as.character
  expect_identical('SUM("x") OVER (ORDER BY "h" ROWS UNBOUNDED PRECEDING)', q)

  q <- translate_sql(order_by(h, sum(x, na.rm = TRUE)), vars_frame = c(-Inf, 0), con = map_con) %>% as.character
  expect_identical('SUM("x") OVER (ORDER BY "h" ROWS UNBOUNDED PRECEDING)', q)

  ## n()
  q <- translate_sql(n(), con = map_con) %>% as.character
  expect_identical('CAST(COUNT(*) OVER () AS BIGINT)', q)

  # order by for count is not needed
  q <- translate_sql(n(), vars_order = c('x'), con = map_con) %>% as.character
  expect_identical('CAST(COUNT(*) OVER () AS BIGINT)', q)

  # takes groups
  q <- translate_sql(n(), vars_order = c('x'), vars_group = c('c'), con = map_con) %>% as.character
  expect_identical('CAST(COUNT(*) OVER (PARTITION BY "c") AS BIGINT)', q)

  # cumulative window aggregate functions
  # these have an implicit frame of ROWS UNBOUNDED PRECEDING (can't be overridden)

  # cumulative sum
  # Windowed expression 'sum("x")' does not have explicit order.
  # Please use arrange() or window_order() to make determinstic. 
  suppressWarnings(q <- translate_sql(cumsum(x), con = map_con) %>% as.character)
  expect_identical('SUM("x") OVER (ROWS UNBOUNDED PRECEDING)', q)

  q <- translate_sql(cumsum(x), vars_order = c('g'), con = map_con) %>% as.character 
  expect_identical('SUM("x") OVER (ORDER BY "g" ROWS UNBOUNDED PRECEDING)', q)

  q <- translate_sql(cumsum(x), vars_order = c('g'), vars_group = c('h'), con = map_con) %>% as.character 
  expect_identical('SUM("x") OVER (PARTITION BY "h" ORDER BY "g" ROWS UNBOUNDED PRECEDING)', q)

  # try to frame ...
  q <- translate_sql(cumsum(x), vars_frame = c(-1, 0), vars_order = c('g'), vars_group = c('h'), con = map_con) %>% as.character 
  expect_identical('SUM("x") OVER (PARTITION BY "h" ORDER BY "g" ROWS UNBOUNDED PRECEDING)', q)
  
  # cumulative min
  # Windowed expression 'min("x")' does not have explicit order.
  # Please use arrange() or window_order() to make determinstic. 
  suppressWarnings(q <- translate_sql(cummin(x), con = map_con) %>% as.character)
  expect_identical('MIN("x") OVER (ROWS UNBOUNDED PRECEDING)', q)

  q <- translate_sql(cummin(x), vars_order = c('g'), con = map_con) %>% as.character 
  expect_identical('MIN("x") OVER (ORDER BY "g" ROWS UNBOUNDED PRECEDING)', q)

  q <- translate_sql(cummin(x), vars_order = c('g'), vars_group = c('h'), con = map_con) %>% as.character 
  expect_identical('MIN("x") OVER (PARTITION BY "h" ORDER BY "g" ROWS UNBOUNDED PRECEDING)', q)

  # cumulative max
  # Windowed expression 'MAX("x")' does not have explicit order.
  # Please use arrange() or window_order() to make determinstic. 
  suppressWarnings(q <- translate_sql(cummax(x), con = map_con) %>% as.character)
  expect_identical('MAX("x") OVER (ROWS UNBOUNDED PRECEDING)', q)

  q <- translate_sql(cummax(x), vars_order = c('g'), con = map_con) %>% as.character 
  expect_identical('MAX("x") OVER (ORDER BY "g" ROWS UNBOUNDED PRECEDING)', q)

  q <- translate_sql(cummax(x), vars_order = c('g'), vars_group = c('h'), con = map_con) %>% as.character 
  expect_identical('MAX("x") OVER (PARTITION BY "h" ORDER BY "g" ROWS UNBOUNDED PRECEDING)', q)

  # cumulative mean
  # Windowed expression 'mean("x")' does not have explicit order.
  # Please use arrange() or window_order() to make determinstic. 
  suppressWarnings(q <- translate_sql(cummean(x), con = map_con) %>% as.character)
  expect_identical('avg("x") OVER (ROWS UNBOUNDED PRECEDING)', q)

  q <- translate_sql(cummean(x), vars_order = c('g'), con = map_con) %>% as.character 
  expect_identical('avg("x") OVER (ORDER BY "g" ROWS UNBOUNDED PRECEDING)', q)

  q <- translate_sql(cummean(x), vars_order = c('g'), vars_group = c('h'), con = map_con) %>% as.character 
  expect_identical('avg("x") OVER (PARTITION BY "h" ORDER BY "g" ROWS UNBOUNDED PRECEDING)', q)

})

test_that('Aggregate functions are mapped correctly', {

  q <- translate_sql(mean(x, na.rm = TRUE), window = FALSE, con = map_con) %>% as.character
  expect_identical('AVG("x")', q)

  q <- translate_sql(mean(distinct(x), na.rm = TRUE), window = FALSE, con = map_con) %>% as.character
  expect_identical('AVG(DISTINCT "x")', q)

  q <- translate_sql(sum(x, na.rm = TRUE), window = FALSE, con = map_con) %>% as.character
  expect_identical('SUM("x")', q)

  q <- translate_sql(sum(distinct(x), na.rm = TRUE), window = FALSE, con = map_con) %>% as.character
  expect_identical('SUM(DISTINCT "x")', q)

  q <- translate_sql(n(), window = FALSE, con = map_con) %>% as.character
  expect_identical('CAST(COUNT(*) AS BIGINT)', q)

  q <- translate_sql(n_distinct(x), window = FALSE, con = map_con) %>% as.character
  expect_identical('CAST(COUNT(DISTINCT "x") AS BIGINT)', q)


  # only takes 1 col expression
  expect_error(q <- translate_sql(n_distinct(x, y), window = FALSE, con = map_con),
               'unused argument')

  q <- translate_sql(var(x, na.rm = TRUE), window = FALSE, con = map_con) %>% as.character
  expect_identical('VAR_SAMP("x")', q)

  q <- translate_sql(var(distinct(x), na.rm = TRUE), window = FALSE, con = map_con) %>% as.character
  expect_identical('VAR_SAMP(DISTINCT "x")', q)

  q <- translate_sql(varp(x, na.rm = TRUE), window = FALSE, con = map_con) %>% as.character
  expect_identical('VAR_POP("x")', q)

  q <- translate_sql(varp(distinct(x), na.rm = TRUE), window = FALSE, con = map_con) %>% as.character
  expect_identical('VAR_POP(DISTINCT "x")', q)

  q <- translate_sql(sd(x, na.rm = TRUE), window = FALSE, con = map_con) %>% as.character
  expect_identical('STDDEV_SAMP("x")', q)

  q <- translate_sql(sd(distinct(x), na.rm = TRUE), window = FALSE, con = map_con) %>% as.character
  expect_identical('STDDEV_SAMP(DISTINCT "x")', q)

  q <- translate_sql(sdp(x, na.rm = TRUE), window = FALSE, con = map_con) %>% as.character
  expect_identical('STDDEV_POP("x")', q)

  q <- translate_sql(sdp(distinct(x), na.rm = TRUE), window = FALSE, con = map_con) %>% as.character
  expect_identical('STDDEV_POP(DISTINCT "x")', q)

  q <- translate_sql(min(x, na.rm = TRUE), window = FALSE, con = map_con) %>% as.character
  expect_identical('MIN("x")', q)

  q <- translate_sql(min(distinct(x), na.rm = TRUE), window = FALSE, con = map_con) %>% as.character
  expect_identical('MIN(DISTINCT "x")', q)

  q <- translate_sql(max(x, na.rm = TRUE), window = FALSE, con = map_con) %>% as.character
  expect_identical('MAX("x")', q)

  q <- translate_sql(max(distinct(x), na.rm = TRUE), window = FALSE, con = map_con) %>% as.character
  expect_identical('MAX(DISTINCT "x")', q)
  
})

test_that('math functions are mapped correctly', {

  q <- translate_sql(abs(x), con = map_con) %>% as.character
  expect_identical('ABS("x")', q)

  q <- translate_sql(acos(x), con = map_con) %>% as.character
  expect_identical('ACOS("x")', q)

  q <- translate_sql(acosh(x), con = map_con) %>% as.character
  expect_identical('acosh("x")', q)

  q <- translate_sql(asin(x), con = map_con) %>% as.character
  expect_identical('ASIN("x")', q)

  q <- translate_sql(asinh(x) , con = map_con) %>% as.character
  expect_identical('asinh("x")', q)

  q <- translate_sql(atan(x), con = map_con) %>% as.character
  expect_identical('ATAN("x")', q)

  q <- translate_sql(atan2(y, x), con = map_con) %>% as.character
  expect_identical('ATAN2("x", "y")', q)

  q <- translate_sql(atanh(x), con = map_con) %>% as.character
  expect_identical('atanh("x")', q)

  q <- translate_sql(ceil(x), con = map_con) %>% as.character
  expect_identical('CEILING("x")', q)

  q <- translate_sql(ceiling(x), con = map_con) %>% as.character
  expect_identical('CEILING("x")', q)

  q <- translate_sql(cos(x), con = map_con) %>% as.character
  expect_identical('COS("x")', q)

  q <- translate_sql(cosh(x), con = map_con) %>% as.character
  expect_identical('COSH("x")', q)

  q <- translate_sql(cot(x), con = map_con) %>% as.character
  expect_identical('1 / TAN("x")', q)

  q <- translate_sql(coth(x), con = map_con) %>% as.character
  expect_identical('(EXP(2 * (\"x\")) + 1) / (EXP(2 * (\"x\")) - 1)', q)

  q <- translate_sql(degrees(x), con = map_con) %>% as.character
  expect_identical('degrees("x")', q)

  q <- translate_sql(exp(x), con = map_con) %>% as.character
  expect_identical('EXP("x")', q)

  q <- translate_sql(floor(x), con = map_con) %>% as.character
  expect_identical('FLOOR("x")', q)

  q <- translate_sql(ln(x), con = map_con) %>% as.character
  expect_identical('LN("x")', q)

  q <- translate_sql(log(x), con = map_con) %>% as.character
  expect_identical('LN("x")', q)

  q <- translate_sql(log(x, y), con = map_con) %>% as.character
  expect_identical('LOG("x") / LOG("y")', q)

  q <- translate_sql(log10(x), con = map_con) %>% as.character
  expect_identical('LOG("x")', q)

  q <- translate_sql(radians(x), con = map_con) %>% as.character
  expect_identical('radians("x")', q)

  q <- translate_sql(round(x), con = map_con) %>% as.character
  expect_identical('ROUND("x", 0)', q)

  q <- translate_sql(round(x, 3), con = map_con) %>% as.character
  expect_identical('ROUND("x", 3)', q)

  q <- translate_sql(sign(x), con = map_con) %>% as.character
  expect_identical('SIGN("x")', q)

  q <- translate_sql(sin(x), con = map_con) %>% as.character
  expect_identical('SIN("x")', q)

  q <- translate_sql(sinh(x), con = map_con) %>% as.character
  expect_identical('SINH("x")', q)

  q <- translate_sql(sqrt(x), con = map_con) %>% as.character
  expect_identical('SQRT("x")', q)

  q <- translate_sql(tan(x), con = map_con) %>% as.character
  expect_identical('TAN("x")', q)

})

test_that('conversion functions work', {
  
  # as.integer
  q <- translate_sql(as.integer(x), con = map_con) %>% as.character
  expect_identical('CAST("x" AS INTEGER)', q)
  
  q <- translate_sql(as.integer((x)), con = map_con) %>% as.character
  expect_identical('CAST(("x") AS INTEGER)', q)
  
  q <- translate_sql(as.integer(2.99), con = map_con) %>% as.character
  expect_identical('CAST(2.99 AS INTEGER)', q)
  
  q <- translate_sql(as.integer((2.99)), con = map_con) %>% as.character
  expect_identical('CAST((2.99) AS INTEGER)', q)
  
  q <- translate_sql(as.integer(2L), con = map_con) %>% as.character
  expect_identical('CAST(2 AS INTEGER)', q)
  
  q <- translate_sql(as.integer((2L)), con = map_con) %>% as.character
  expect_identical('CAST((2) AS INTEGER)', q)
  
  # as.numeric
  q <- translate_sql(as.numeric((x)), con = map_con) %>% as.character
  expect_identical('CAST(("x") AS NUMERIC(5, 0))', q)
  
  q <- translate_sql(as.numeric((3.99)), con = map_con) %>% as.character
  expect_identical('CAST((3.99) AS NUMERIC(5, 0))', q)
  
  q <- translate_sql(as.numeric((3L)), con = map_con) %>% as.character
  expect_identical('CAST((3) AS NUMERIC(5, 0))', q)
  
  q <- translate_sql(as.numeric((x), precision = 2L), con = map_con) %>% as.character
  expect_identical('CAST(("x") AS NUMERIC(2, 0))', q)
  
  q <- translate_sql(as.numeric((x), precision = 2L, scale = 3L), con = map_con) %>% as.character
  expect_identical('CAST(("x") AS NUMERIC(2, 3))', q)
  
  # as.character
  q <- translate_sql(as.character(x), con = map_con) %>% as.character
  N <- Sys.getenv("TD_VARCHAR_COLUMN_SIZE")
  expect_identical(paste0('CAST(("x") AS VARCHAR(', N, '))'), q)
  
  q <- translate_sql(as.character(x, n = 10), con = map_con) %>% as.character
  expect_identical('CAST(("x") AS VARCHAR(10))', q)
  
  q <- translate_sql(as.character(x, n = 10, charset = 'UNICODE'), con = map_con) %>% as.character
  expect_identical('CAST(("x") AS VARCHAR(10) CHARACTER SET UNICODE)', q)
  
  q <- translate_sql(as(x, 'y'), con = map_con) %>% as.character
  expect_identical('CAST("x" AS y)', q)
  
  q <- translate_sql(as(x, 'varchar(10)'), con = map_con) %>% as.character
  expect_identical('CAST("x" AS varchar(10))', q)
  
  # as.Date
  q <- translate_sql(as.Date(x,format), con = map_con) %>% as.character
  expect_identical("CAST(\"x\" AS DATE FORMAT '\"format\"')", q)
  
  q <- translate_sql(as.Date(date,"yyyy-mm-dd"), con = map_con) %>% as.character
  expect_identical("CAST(\"date\" AS DATE FORMAT 'yyyy-mm-dd')", q)
  
})

test_that('bit functions work', {

  q <- translate_sql(bitwAnd(a,b), con = map_con) %>% as.character
  expect_identical('BITAND(CAST("a" AS INTEGER), CAST("b" AS INTEGER))', q)

  q <- translate_sql(bitwAnd(a, 2), con = map_con) %>% as.character
  expect_identical('BITAND(CAST("a" AS INTEGER), CAST(2 AS INTEGER))', q)

  q <- translate_sql(bitwAnd(10, 3), con = map_con) %>% as.character
  expect_identical('BITAND(CAST(10 AS INTEGER), CAST(3 AS INTEGER))', q)

  q <- translate_sql(bitwAnd(10L, 3L), con = map_con) %>% as.character
  expect_identical('BITAND(CAST(10 AS INTEGER), CAST(3 AS INTEGER))', q)

  q <- translate_sql(bitwAnd(10.999, 3.3), con = map_con) %>% as.character
  expect_identical('BITAND(CAST(10.999 AS INTEGER), CAST(3.3 AS INTEGER))', q)

  q <- translate_sql(bitwAnd(a, 2.1), con = map_con) %>% as.character
  expect_identical('BITAND(CAST("a" AS INTEGER), CAST(2.1 AS INTEGER))', q)

  q <- translate_sql(bitwAnd(a, 2L), con = map_con) %>% as.character
  expect_identical('BITAND(CAST("a" AS INTEGER), CAST(2 AS INTEGER))', q)

  q <- translate_sql(bitwNot(a), con = map_con) %>% as.character
  expect_identical('BITNOT(CAST("a" AS INTEGER))', q)

  q <- translate_sql(bitwNot((a)), con = map_con) %>% as.character
  expect_identical('BITNOT(CAST(("a") AS INTEGER))', q)

  q <- translate_sql(bitwNot(1.99), con = map_con) %>% as.character
  expect_identical('BITNOT(CAST(1.99 AS INTEGER))', q)

  q <- translate_sql(bitwNot(1), con = map_con) %>% as.character
  expect_identical('BITNOT(CAST(1 AS INTEGER))', q)

  q <- translate_sql(bitwNot(1L), con = map_con) %>% as.character
  expect_identical('BITNOT(CAST(1 AS INTEGER))', q)

  q <- translate_sql(bitwOr(a,b), con = map_con) %>% as.character
  expect_identical('BITOR(CAST("a" AS INTEGER), CAST("b" AS INTEGER))', q)

  q <- translate_sql(bitwXor(a,b), con = map_con) %>% as.character
  expect_identical('BITXOR(CAST("a" AS INTEGER), CAST("b" AS INTEGER))', q)

  q <- translate_sql(bitwShiftL(a,b), con = map_con) %>% as.character
  expect_identical('SHIFTLEFT(CAST("a" AS INTEGER), CAST("b" AS INTEGER))', q)

  q <- translate_sql(bitwShiftR(a,b), con = map_con) %>% as.character
  expect_identical('SHIFTRIGHT(CAST("a" AS INTEGER), CAST("b" AS INTEGER))', q)

})

testthat::teardown(
  {
    td_remove_context()
  }
)
