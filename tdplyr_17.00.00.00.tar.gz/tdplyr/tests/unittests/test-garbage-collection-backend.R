context("Test garbage collection basic scenarios")

# Goal of this is to test garbage collection with all of the scenarios
##############################################################################
###  The following are the places where garbage collection could be called
### 1) [Manual Test] R session Exit
### 2) Calling td_create_context / dbConnect / td_set_context first time in the session
### 3) Re-connecting / Overwriting existing context (Calling td_create_context / td_set_context or dbConnect second time with change in connection parameters)
### 4) On Package Unload (If user explicitly unloads the package)
### 5) On remove context. Note: if user used dbDisconnect then the GC WILL NOT fire.
### 6) [Not MVP-1] Explicitly calling clear temp objects API (clear_context) : NOT MVP-1
##############################################################################

## Helper functions
# Function to get the number of tables in a DB
queryNumTables <- function(con, dbToQuery) {
  nrow(DBI::dbGetQuery(con, paste0("help user ", dbToQuery, ";")))
}

verifyRemoved <- function(con) {
  expect_false(DBI::dbIsValid(con))
  # Check if context is removed
  if (!is.null(td_get_context()))
    expect_false(identical(con, td_get_context()$connection))
}

verifyContext <- function(con, defaultDB, tempDB) {
  context <- td_get_context()
  expect_true(identical(con, context$connection))
  expect_equal(context$default.database, defaultDB)
  expect_equal(context$temp.database, tempDB)
}

checkTableCount <- function(con, db, expected) {
  num <- queryNumTables(con, db)
  expect_equal(num, expected)
}

# just creates a dummy table with the given name in the db
addTempTable <- function(con, db, name) {
  object <- gettextf("\"%s\".\"%s\"", db, name)
  # create table
    expect_equal(DBI::dbExecute(con,
      gettextf("create table %s(a int, b float)", object)),
    0)
    # check if the table has been created
    expect_error(DBI::dbExecute(con, paste0("help table ", object)),
      regexp = NA)
    # add the table to a temp object
    .ta.addTempObject(object, "table")
}

# Create a temp database on setup
userName <-  toupper(.ta.getUserName())
tempDatabaseName <- toupper(paste0("RTEST_TMP_DATABASE_",userName))

defaultDatabase <- ""

testthat::setup({
  # Create connection using dbc to create tempDatabase and grant access to user globalUID.
  if (globalDTYPE == "odbc") {
    dcon <<- suppressWarnings(td_create_context(dsn = dsnName, uid = "dbc", pwd = "dbc"))
  } else {
    dcon <<- suppressWarnings(td_create_context(dType = "native", host = globalHost, uid = "dbc", pwd = "dbc"))
  }

  # Drop database, if exists, before creating it.
  try(DBI::dbExecute(dcon, paste0("DELETE DATABASE ",tempDatabaseName,";")), silent = TRUE)
  try(DBI::dbExecute(dcon, paste0("DROP DATABASE ",tempDatabaseName,";")), silent = TRUE)

  # Create database.
  DBI::dbExecute(dcon, paste0("CREATE DATABASE ",tempDatabaseName," AS PERM = 1e+06;" ))
  DBI::dbExecute(dcon, paste0("GRANT ALL ON ",tempDatabaseName," TO ", globalUID, ";" ))

  td_remove_context()

  # Now connecting using globalUID.
  if (globalDTYPE == "odbc") {
    con <<- suppressWarnings(td_create_context(dsn = dsnName))
  } else {
    con <<- suppressWarnings(td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD))
  }

  defaultDatabase <<- .get_dbname(con)
  # should not throw any error
  expect_warning(td_remove_context(), regexp = NA)
})

testset <- function(tempDatabaseName) {

  test_that("Garbage collection on remove context", {
    # create context
    if (globalDTYPE == "odbc") {
      con <- td_create_context(dsnName, temp.database = tempDatabaseName)
    } else {
      con <- td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD, temp.database = tempDatabaseName)
    }

    verifyContext(con, .get_dbname(con), tempDatabaseName)
    countBefore <- queryNumTables(con, tempDatabaseName)
    addTempTable(con, tempDatabaseName, "gc_table1")
    addTempTable(con, tempDatabaseName, "gc_table2")
    addTempTable(con, tempDatabaseName, "gc_table3")

    # check the num of tables in the temp database
    checkTableCount(con, tempDatabaseName, countBefore + 3)

    # remove context and check count again
    # The option td.debug.enable, if set, prints the error messages that resulted in failure of GC
    # of some tables.
    options(td.debug.enable = TRUE)
    debug_output <- capture.output(td_remove_context())
    options(td.debug.enable = FALSE)
    # Successful GC and no error messages.
    expect_true(identical(debug_output, character(0)))
    verifyRemoved(con)

    if (globalDTYPE == "odbc") {
      con <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
    } else {
      con <- DBI::dbConnect(tdplyr::NativeDriver(), host = globalHost, uid = globalUID, pwd = globalPWD)
    }

    checkTableCount(con, tempDatabaseName, countBefore)
    expect_warning(DBI::dbDisconnect(con), regexp = NA)
  })

  test_that("Garbage collection on create context twice", {
    # create context

    if (globalDTYPE == "odbc") {
      con <- td_create_context(dsnName, temp.database = tempDatabaseName)
    } else {
      con <- td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD, temp.database = tempDatabaseName)
    }

    verifyContext(con, .get_dbname(con), tempDatabaseName)
    countBefore <- queryNumTables(con, tempDatabaseName)
    addTempTable(con, tempDatabaseName, "gc_table1")
    addTempTable(con, tempDatabaseName, "gc_table2")
    addTempTable(con, tempDatabaseName, "gc_table3")
    addTempTable(con, tempDatabaseName, "gc_table4")

    # check the num of tables in the temp database
    checkTableCount(con, tempDatabaseName, countBefore + 4)

    # DO not remove context but create context again with a default temp db and check


    if (globalDTYPE == "odbc") {
      con <- expect_warning(td_create_context(dsnName, temp.database = tempDatabaseName),
                            "TDR_W1002")
    } else {
      con <- expect_warning(td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD,
                                                temp.database = tempDatabaseName),"TDR_W1002")
    }

    checkTableCount(con, tempDatabaseName, countBefore)
    td_remove_context()
    verifyRemoved(con)
  })

  test_that("Garbage collection using set context (TeradataDriver) and remove context", {

    if (globalDTYPE == "odbc") {
      con <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
    } else {
      con <- DBI::dbConnect(teradatasql::TeradataDriver(), host = globalHost, user = globalUID,
                            password = globalPWD)
    }

    td_set_context(con, tempDatabaseName)
    # td_set_context does not return the Teradata connection object; con is still
    # driver's TeradataConnection object.
    con <- td_get_context()$connection
    verifyContext(con, .get_dbname(con), tempDatabaseName)
    countBefore <- queryNumTables(con, tempDatabaseName)
    addTempTable(con, tempDatabaseName, "gc_table1")
    addTempTable(con, tempDatabaseName, "gc_table2")

    # check the num of tables in the temp database
    checkTableCount(con, tempDatabaseName, countBefore + 2)

    # Removing context; this should do GC.
    td_remove_context()
    verifyRemoved(con)

    if (globalDTYPE == "odbc") {
      con <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
    } else {
      con <- DBI::dbConnect(teradatasql::TeradataDriver(), host = globalHost, user = globalUID,
                            password = globalPWD)
    }
    checkTableCount(con, tempDatabaseName, countBefore)
    # Disconnecting the connection.
    DBI::dbDisconnect(con)
  })

  test_that("Garbage collection when using set context then create context", {
    if (globalDTYPE == "odbc") {
      con <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
    } else {
      con <- DBI::dbConnect(teradatasql::TeradataDriver(), host = globalHost, user = globalUID,
                            password = globalPWD)
    }
    td_set_context(con, tempDatabaseName)
    con <- td_get_context()$connection
    verifyContext(con, .get_dbname(con), tempDatabaseName)
    countBefore <- queryNumTables(con, tempDatabaseName)
    addTempTable(con, tempDatabaseName, "gc_table1")
    addTempTable(con, tempDatabaseName, "gc_table2")

    # Check the num of tables in the temp database
    checkTableCount(con, tempDatabaseName, countBefore + 2)
    # Create context remove prev context and does GC with new connection

    # Not removing context and calling td_create_context; td_create_context always overwrite
    # existing context and do GC.
    if (globalDTYPE == "odbc") {
      con2 <- expect_warning(td_create_context(dsnName, temp.database = tempDatabaseName), "TDR_W1002")
    } else {
      con2 <- expect_warning(td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD
                                           ,temp.database = tempDatabaseName), "TDR_W1002")
    }
    verifyContext(con2, .get_dbname(con2), tempDatabaseName)
    checkTableCount(con2, tempDatabaseName, countBefore)

    td_remove_context()
    verifyRemoved(con2)
    # 'con' is already disconnected while it is overwritten.
    expect_true(!DBI::dbIsValid(con))
  })
}

testset(tempDatabaseName)
# Repeat Above tests with temp database as default database
testset(defaultDatabase)

test_that("Garbage collection when using create context then set context", {
 # Create context
 if (globalDTYPE == "odbc") {
   # Here warning is ODBC deprecation warning
   con <- suppressWarnings(td_create_context(dsnName, temp.database = tempDatabaseName))
 } else {
   con <- td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD, temp.database = tempDatabaseName)
 }

 verifyContext(con, .get_dbname(con), tempDatabaseName)
 countBefore <- queryNumTables(con, tempDatabaseName)

 addTempTable(con, tempDatabaseName, "gc_table1")
 addTempTable(con, tempDatabaseName, "gc_table2")
 addTempTable(con, tempDatabaseName, "gc_table3")
 addTempTable(con, tempDatabaseName, "gc_table4")

 checkTableCount(con, tempDatabaseName, countBefore + 4)

 if (globalDTYPE == "odbc") {
   con2 <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)

   # This will just switch the temp database
   # No overwriting warning as the connection parameters are same td_get_context()$connection.
   expect_warning(td_set_context(con, defaultDatabase), "TDR_W1009") # ODBC deprecation warning only.

   # This should also not do any GC because it is the same con params
   expect_warning(td_set_context(con2), "TDR_W1009") # ODBC deprecation warning only.
 } else {
   con2 <- DBI::dbConnect(teradatasql::TeradataDriver(), host = globalHost, user = globalUID,
                          password = globalPWD)

   # This will just switch the temp database
   # No overwriting warning as the connection parameters are same td_get_context()$connection.
   expect_silent(td_set_context(con, defaultDatabase))

   # This should also not do any GC because it is the same con params
   expect_silent(td_set_context(con2))
   con2 <- td_get_context()$connection
 }

 verifyContext(con2, .get_dbname(con2), .get_dbname(con2))
 checkTableCount(con2, tempDatabaseName, countBefore + 4)

 # Note con is NOT disconnected
 expect_true(DBI::dbIsValid(con))

 # Now if you call set context with different connection param.
 # This should do garbage collection.

 if (globalDTYPE == "odbc") {
   con3 <- DBI::dbConnect(odbc::odbc(), dsn = dsnName, database = tempDatabaseName, defaultDatabase = tempDatabaseName)
   # this should do garbage collection because database changed but con2 is still active
   expect_warning(td_set_context(con3), "TDR_W1002")
   verifyContext(con3, .get_dbname(con3), .get_dbname(con3))
   checkTableCount(con3, tempDatabaseName, countBefore)
 } else {
   con3 <- DBI::dbConnect(teradatasql::TeradataDriver(), host = globalHost, user = globalUID,
                          password = globalPWD, database = tempDatabaseName)
   # TeradataDriver() is with new default database; td_set_context will overwrite the connection
   # and do GC.
   expect_warning(td_set_context(con3), "TDR_W1002")
   con3 <- td_get_context()$connection
 }

 verifyContext(con3, .get_dbname(con3), .get_dbname(con3))
 checkTableCount(con3, tempDatabaseName, countBefore)

 # Note con2 is disconnected when the context is overwritten.
 expect_true(!DBI::dbIsValid(con2))

 # remove context.
 td_remove_context()
 verifyRemoved(con3)
 verifyRemoved(con2)

 # Note con is NOT disconnected.
 expect_true(DBI::dbIsValid(con))
 # Disconnect con now.
 expect_warning(DBI::dbDisconnect(con), regexp = NA)

 verifyRemoved(con)
})

test_that("Garbage collection on set context twice", {
 if (globalDTYPE == "odbc") {
   con <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
 } else {
   con <- DBI::dbConnect(teradatasql::TeradataDriver(), host = globalHost, user = globalUID,
                         password = globalPWD)
 }
 suppressWarnings(td_set_context(con, tempDatabaseName)) # ODBC deprecation warning only.
 con <- td_get_context()$connection

 verifyContext(con, .get_dbname(con), tempDatabaseName)
 countBefore <- queryNumTables(con, tempDatabaseName)

 addTempTable(con, tempDatabaseName, "gc_table1")
 addTempTable(con, tempDatabaseName, "gc_table2")
 addTempTable(con, tempDatabaseName, "gc_table3")
 # Check the num of tables in the temp database
 checkTableCount(con, tempDatabaseName, countBefore + 3)

 # Set context again with default database
 capture_output(td_set_context(con))
 con <- td_get_context()$connection

 checkTableCount(con, tempDatabaseName, countBefore + 3)
 # Add two more temp tables to default database which is the new temp database

 defaultDB <- .get_dbname(con)
 countBeforeDefault <- queryNumTables(con, defaultDB)

 addTempTable(con, defaultDB, "gc_table11")
 addTempTable(con, defaultDB, "gc_table12")
 checkTableCount(con, defaultDB, countBeforeDefault + 2)

 # Set context with a new connection
 if (globalDTYPE == "odbc") {
   con2 <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
 } else {
   con2 <- DBI::dbConnect(teradatasql::TeradataDriver(), host = globalHost, user = globalUID,
                         password = globalPWD)
 }

 # This should still not do garbage collect because connection params are same
 capture_output(td_set_context(con2))
 con2 <- td_get_context()$connection

 checkTableCount(con2, tempDatabaseName, countBefore + 3)
 checkTableCount(con2, defaultDB, countBeforeDefault + 2)

 # Now try to do set context with a different default database
 # and this time it should clear all the temp tables

 if (globalDTYPE == "odbc") {
   con3 <- DBI::dbConnect(odbc::odbc(), dsn = dsnName, database = tempDatabaseName, defaultDatabase = tempDatabaseName)
   # td_set_context overwrites existing context and do GC as default datbase is changed now.
   expect_warning(td_set_context(con3), "TDR_W1002") # It will also generate ODBC deprecation warning.

 } else {
   con3 <- DBI::dbConnect(teradatasql::TeradataDriver(), host = globalHost, user = globalUID, password = globalPWD, database = tempDatabaseName)
   # td_set_context overwrites existing context and do GC as default datbase is changed now.
   expect_warning(td_set_context(con3), "TDR_W1002")
   con3 <- td_get_context()$connection
 }
 
 # Note con2 is disconnected
 verifyRemoved(con2)
 checkTableCount(con3, tempDatabaseName, countBefore)
 checkTableCount(con3, defaultDB, countBeforeDefault)

 td_remove_context()
 verifyRemoved(con3)
 # Note con is still alive
 expect_warning(DBI::dbDisconnect(con), regexp = NA)
 
 # Closing con2 and con3 should cause warnings
 if (globalDTYPE == "odbc") {
   expect_warning(DBI::dbDisconnect(con2))
   expect_warning(DBI::dbDisconnect(con3))
 }  else{
   expect_error(DBI::dbDisconnect(con2), regexp = NULL)
   expect_error(DBI::dbDisconnect(con3), regexp = NULL)
 }
})

context("Test garbage collection when user has no drop permissions")
# This is an important test case as it makes sure that if a user does not have permissions
# to drop the table the first time, he can connect again and drop tables

### This test is failing for both drivers
test_that("garbage collection handles when user has no permissions", {
  # connect using globalUID
  if (globalDTYPE == "odbc") {
    con <- td_create_context(dsnName, temp.database = tempDatabaseName)
  } else {
    con <- td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD,
                             temp.database = tempDatabaseName)
  }

  verifyContext(con, .get_dbname(con), tempDatabaseName)
  countBefore <- queryNumTables(con, tempDatabaseName)
  addTempTable(con, tempDatabaseName, "gc_table1")
  addTempTable(con, tempDatabaseName, "gc_table2")
  addTempTable(con, tempDatabaseName, "gc_table3")

  checkTableCount(con, tempDatabaseName, countBefore + 3)

  # connect using the user 'dbc' to revoke drop table permission to globalUID.
  # When globalDTYPE is odbc, make sure dsnName connects through the user 'dbc'.
  if (globalDTYPE == "odbc") {
    dbcon <- DBI::dbConnect(odbc::odbc(), dsn = dsnName, uid = "dbc", pwd = "dbc")
  } else {
    dbcon <- DBI::dbConnect(teradatasql::TeradataDriver(), host = globalHost, user = "dbc",
                            password = "dbc")
  }

  # revoke drop permissions for that database for globalUID, using 'dbc'.
  DBI::dbExecute(dbcon, gettextf("REVOKE DROP TABLE on %s from %s;", tempDatabaseName, globalUID))
  DBI::dbExecute(dbcon, gettextf("REVOKE DROP VIEW on %s from %s;", tempDatabaseName, globalUID))

  # td_remove_context() and see if that the tables have NOT been collected.
  # The option td.debug.enable, if set, prints the error messages that resulted in failure of GC
  # of some tables.
  options(td.debug.enable = TRUE)
  debug_output <- capture.output(td_remove_context())
  options(td.debug.enable = FALSE)
  debug_output <- paste0(debug_output, collapse = " ")
  table_names <- c("gc_table1", "gc_table2", "gc_table3")
  error_stmts <- paste0("The user does not have DROP TABLE access to ", tempDatabaseName, ".",
                        table_names)
  for (error in error_stmts) {
    expect_true(grepl(error, debug_output, fixed = TRUE))
  }
  verifyRemoved(con)

  if (globalDTYPE == "odbc") {
    conT <- DBI::dbConnect(odbc::odbc(), dsn = dsnName, database = tempDatabaseName)
  } else {
    conT <- DBI::dbConnect(teradatasql::TeradataDriver(), host = globalHost, user = globalUID,
                            password = globalPWD, database = tempDatabaseName)
  }

  # The tables were not removed
  checkTableCount(conT, tempDatabaseName, countBefore + 3)

  # grant permissions again and try to garbage collect
  DBI::dbExecute(dbcon, gettextf("GRANT DROP TABLE on %s TO %s;", tempDatabaseName, globalUID))
  DBI::dbExecute(dbcon, gettextf("GRANT DROP VIEW on %s TO %s;", tempDatabaseName, globalUID))
  # Check again to make sure the tables were not removed
  checkTableCount(conT, tempDatabaseName, countBefore + 3)
  expect_warning(DBI::dbDisconnect(conT), regexp = NA) # Connected using dbConnect(TeradataDriver())

 # Connect again and it should GC successfuly
  if (globalDTYPE == "odbc") {
    con <- td_create_context(dsnName)
  } else {
    con <- td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD)
  }

  verifyContext(con, .get_dbname(con), .get_dbname(con))
  checkTableCount(con, tempDatabaseName, countBefore)

  td_remove_context()
  verifyRemoved(con)

  # Removes dbc connection
  DBI::dbDisconnect(dbcon)
})

context("Test garbage collection when table already dropped")
# This is an important test case to handle scenario when table could be already dropped
# but when user logs in again garbage collection should just ignore and continue

test_that("garbage collection handles table already dropped", {
  # Connect
  if (globalDTYPE == "odbc") {
    con <- suppressWarnings(td_create_context(dsnName, temp.database = tempDatabaseName)) # ODBC deprecation warning.
  } else {
    con <- td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD, temp.database = tempDatabaseName)
  }

  verifyContext(con, .get_dbname(con), tempDatabaseName)
  countBefore <- queryNumTables(con, tempDatabaseName)
  addTempTable(con, tempDatabaseName, "gc_table1")
  addTempTable(con, tempDatabaseName, "gc_table2")
  addTempTable(con, tempDatabaseName, "gc_table3")

  checkTableCount(con, tempDatabaseName, countBefore + 3)

  # Drop two tables manually
  DBI::dbExecute(con,gettextf("drop table %s.%s;",tempDatabaseName,"gc_table1"))
  DBI::dbExecute(con,gettextf("drop table %s.%s;",tempDatabaseName,"gc_table3"))
  checkTableCount(con, tempDatabaseName, countBefore + 1)

  # Remove context and see if the tables were removed without any error
  # The option td.debug.enable, if set, prints the error messages that resulted in failure of GC
  # of some tables.
  options(td.debug.enable = TRUE)
  debug_output <- capture.output(td_remove_context())
  options(td.debug.enable = FALSE)
  debug_output <- paste0(debug_output, collapse = " ")
  table_names <- c("gc_table1", "gc_table3")
  error_stmts <- paste0("Object '", tolower(tempDatabaseName), ".", table_names, "' does not exist.")
  for (error in error_stmts) {
    expect_true(grepl(error, debug_output, fixed = TRUE))
  }
  verifyRemoved(con)

  if (globalDTYPE == "odbc") {
    conT <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
  } else {
    conT <- DBI::dbConnect(teradatasql::TeradataDriver(), host = globalHost, user = globalUID,
                           password = globalPWD)
  }

  # The tables were removed
  checkTableCount(conT, tempDatabaseName, countBefore)
  expect_warning(DBI::dbDisconnect(conT), regexp = NA)
})

context("Test garbage collection negative scenarios")

test_that("Garbage collection on package unload", {
 # Create context
 if (globalDTYPE == "odbc") {
   con <- suppressWarnings(td_create_context(dsnName, temp.database = tempDatabaseName)) # ODBC deprecation warning.
 } else {
   con <- td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD, temp.database = tempDatabaseName)
 }

 verifyContext(con, .get_dbname(con), tempDatabaseName)
 countBefore <- queryNumTables(con, tempDatabaseName)
 addTempTable(con, tempDatabaseName, "gc_table1")
 addTempTable(con, tempDatabaseName, "gc_table2")
 addTempTable(con, tempDatabaseName, "gc_table3")

 # Check the num of tables in the temp database
 checkTableCount(con, tempDatabaseName, countBefore + 3)

 # Do not remove context but just unload the package and reload it
 detach("package:tdplyr", unload=TRUE)
 devtools::load_all()

 # Create context again and check
 # First check the context was already removed
 verifyRemoved(con)

 if (globalDTYPE == "odbc") {
   con <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
 } else {
 con <- DBI::dbConnect(teradatasql::TeradataDriver(), host = globalHost, user = globalUID,
                       password = globalPWD)
 }

 checkTableCount(con, tempDatabaseName, countBefore)
 expect_warning(DBI::dbDisconnect(con), regexp = NA)
})

test_that("dbDisconnect (TeradataDriver) should not trigger garbage collection", {
 # Create context
 if (globalDTYPE == "odbc") {
   con <- suppressWarnings(td_create_context(dsnName, temp.database = tempDatabaseName)) # ODBC deprecation warning.
 } else {
   con <- td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD, temp.database = tempDatabaseName)
 }

 verifyContext(con, .get_dbname(con), tempDatabaseName)
 countBefore <- queryNumTables(con, tempDatabaseName)
 addTempTable(con, tempDatabaseName, "gc_table1")
 addTempTable(con, tempDatabaseName, "gc_table2")
 addTempTable(con, tempDatabaseName, "gc_table3")
 # check the num of tables in the temp database
 checkTableCount(con, tempDatabaseName, countBefore + 3)

 # Disconnect con with dbDisconnect
 expect_warning(DBI::dbDisconnect(con), regexp = NA)

 # Check the tables should still exist - no gc triggered
 if (globalDTYPE == "odbc") {
   conT <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
 } else {
   conT <- DBI::dbConnect(teradatasql::TeradataDriver(), host = globalHost, user = globalUID,
                          password = globalPWD)
 }

 checkTableCount(conT, tempDatabaseName, countBefore + 3)
 expect_warning(DBI::dbDisconnect(conT), regexp = NA)

 # Do create context again and it should do garbage collection
 # Note this also simulates system crash and reconnect
 if (globalDTYPE == "odbc") {
   con2 <- td_create_context(dsnName)
 } else {
   con2 <- td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD)
 }

 verifyContext(con2, .get_dbname(con2), .get_dbname(con2))

 # All garbage collected in the call to 'td_create_context' function.
 checkTableCount(con2, tempDatabaseName, countBefore)

 if (globalDTYPE == "odbc") {
   expect_warning(DBI::dbDisconnect(con)) # Already disconnected
 } else {
   expect_error(DBI::dbDisconnect(con)) # Already disconnected
 }

 td_remove_context()
 verifyRemoved(con2)
})

test_that("garbage collection happens when session is crashed", {
 # create context
 if (globalDTYPE == "odbc") {
   con <- suppressWarnings(td_create_context(dsnName, temp.database = tempDatabaseName)) # ODBC deprecation warning.
 } else {
   con <- td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD, temp.database = tempDatabaseName)
 }

 verifyContext(con, .get_dbname(con), tempDatabaseName)
 countBefore <- queryNumTables(con, tempDatabaseName)
 addTempTable(con, tempDatabaseName, "gc_table1")
 addTempTable(con, tempDatabaseName, "gc_table2")
 addTempTable(con, tempDatabaseName, "gc_table3")

 checkTableCount(con, tempDatabaseName, countBefore + 3)

 # simulate session kill by just invalidating the memory
 .rm(".session_temp__objects__")
 # Now connect to different default database and gc works

 if (globalDTYPE == "odbc") {
   con2 <- expect_warning(td_create_context(dsnName, database = tempDatabaseName),
                          "TDR_W1002")
   } else {
   con2 <- expect_warning(td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD, temp.database = tempDatabaseName),
                          "TDR_W1002")
 }

 #check if tables have been garbage collected
 checkTableCount(con2, tempDatabaseName, countBefore)
 td_remove_context()
 verifyRemoved(con2)
 verifyRemoved(con)
})

test_that("Add temp object fails if context is not initialized", {
 .rm(".session_temp__objects__")
 if (globalDTYPE == "odbc") {
   con <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
 } else {
   con <- DBI::dbConnect(teradatasql::TeradataDriver(), host = globalHost, user = globalUID,
                         password = globalPWD)
 }
 expect_error(addTempTable(con, tempDatabaseName, "gc_table1"), "TDR_E1004")
 DBI::dbDisconnect(con)
 verifyRemoved(con)
})

testthat::teardown({
  if (globalDTYPE == "odbc") {
    con <- DBI::dbConnect(odbc::odbc(), dsn = dsnName, uid = "dbc", pwd = "dbc")
  } else {
    con <- DBI::dbConnect(tdplyr::NativeDriver(), host = globalHost, uid = "dbc", pwd = "dbc")
  }
  
  DBI::dbExecute(con, paste0("DELETE DATABASE ",tempDatabaseName,";" ))
  DBI::dbExecute(con, paste0("DROP DATABASE ",tempDatabaseName,";" ))
  DBI::dbDisconnect(con)
})
