context("Unit tests for copy_to with different data types present in R data frame")

cleanup <- function() {
  for( i in 1:9){
    tryCatch({
      DBI::dbExecute(con, paste0("drop table t",i))
    }, error=function(e) { 
      # DO Nothing
    })
  }
}


testthat::setup({
  if(globalDTYPE == "odbc"){
    con <<- suppressWarnings(td_create_context(dsn = dsnName))
  } else {
    con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD))
  }
  cleanup()
})

test_that("creating a table with different data types", {
  df <-  data.frame(dt_date      = c(as.Date('1915-06-16'),as.Date('1916-06-16'),as.Date('1917-06-16')),
                    dt_posixct   = c(as.POSIXct('1915-06-16'),as.POSIXct('1916-06-16'),as.POSIXct(Sys.time())),
                    dt_posixlt   = c(as.POSIXlt('1915-06-16'),as.POSIXlt('1916-06-16'),as.POSIXlt(Sys.time())),
                    dt_logical   = c(TRUE, FALSE, TRUE),
                    dt_integer   = c(2L,3L,4L),
                    dt_character = c('a' , "good", "TRUE"),
                    dt_double    = c(1, 2.5, 4.5),
                    dt_raw       = as.raw(c(21,34,53)),
                    dt_complex   = c(1+2i, 3+4i, 6+7i)
  )
  expect_equal(copy_to(con, df, name = "t1"), tbl(con,"t1"))
  datatypes <- .ta.describe.columns.wrapper(con, sql("select * from t1"))$types
  expect_true(datatypes[[1]] == "date")
  expect_true(tolower(datatypes[[2]]) == "timestamp")
  expect_true(tolower(datatypes[[3]]) == "timestamp")
  expect_true(datatypes[[4]] == "byteint")
  expect_true(datatypes[[5]] == "int")
  expect_true(datatypes[[6]] == "varchar")
  expect_true(datatypes[[7]] == "float")
  expect_true(datatypes[[8]] == "byte")
  expect_true(datatypes[[9]] == "varchar")

  #verifying the datatype
  t1 <- collect(tbl(con,"t1"))
  t2 <- as.data.frame(tbl(con,"t1"))
  
  expect_equal(class(t1$dt_date), "Date")
  expect_true(unique(class(t1$dt_posixct) %in% c("POSIXct","POSIXt")))
  expect_true(unique(class(t1$dt_posixlt) %in% c("POSIXct","POSIXt")))
  expect_equal(typeof(t1$dt_integer),"integer")
  expect_equal(typeof(t1$dt_character),"character")
  expect_equal(typeof(t1$dt_double),"double")
  expect_equal(typeof(t1$dt_complex),"character")
  expect_equal(typeof(t1$dt_logical),"integer")

  #Verifying data
  expect_true(unique(df$dt_date %in% t1$dt_date))
  expect_true(unique(df$dt_logical %in% t1$dt_logical))
  expect_true(unique(df$dt_integer %in% t1$dt_integer))
  expect_true(unique(df$dt_character %in% t1$dt_character))
  expect_true(unique(df$dt_double %in% t1$dt_double))
  expect_true(unique(df$dt_date %in% t1$dt_date))
  expect_true(unique(df$dt_complex %in% as.complex(t1$dt_complex)))
  expect_true(unique(df$dt_logical %in% as.logical(t1$dt_logical)))
  if(td_get_context()$driver.type != "Teradata Native Driver")
    expect_true(unique(c(df$dt_raw[[1]],df$dt_raw[[2]],df$dt_raw[[3]])
              %in% c(t1$dt_raw[[1]],t1$dt_raw[[2]],t1$dt_raw[[3]])))
  
  expect_true(unique(df$dt_date %in% t2$dt_date))
  expect_true(unique(df$dt_logical %in% t2$dt_logical))
  expect_true(unique(df$dt_integer %in% t2$dt_integer))
  expect_true(unique(df$dt_character %in% t2$dt_character))
  expect_true(unique(df$dt_double %in% t2$dt_double))
  expect_true(unique(df$dt_date %in% t2$dt_date))
  expect_true(unique(df$dt_complex %in% as.complex(t2$dt_complex)))
  expect_true(unique(df$dt_logical %in% as.logical(t2$dt_logical)))
  if(td_get_context()$driver.type != "Teradata Native Driver")
    expect_true(unique(c(df$dt_raw[[1]],df$dt_raw[[2]],df$dt_raw[[3]])
                     %in% c(t2$dt_raw[[1]],t2$dt_raw[[2]],t2$dt_raw[[3]])))
})

#Overwrite TRUE
test_that("creating a table with different data types", {
  df <-  data.frame(dt_date      = c(as.Date('1915-06-16'),as.Date('1916-06-16'),as.Date('1917-06-16')),
                    dt_posixct   = c(as.POSIXct('1915-06-16'),as.POSIXct('1916-06-16'),as.POSIXct('1917-06-16')),
                    dt_posixlt   = c(as.POSIXlt('1915-06-16'),as.POSIXlt('1916-06-16'),as.POSIXlt('1917-06-16')),
                    dt_logical   = c(TRUE, FALSE, TRUE),
                    dt_integer   = c(2L,3L,4L),
                    dt_character = c('a' , "good", "TRUE"),
                    dt_double    = c(1, 2.5, 4.5),
                    dt_raw       = as.raw(c(21,34,53)),
                    dt_complex   = c(1+2i, 3+4i, 6+7i)
  )
  expect_equal(copy_to(con, df, name = "t1", overwrite = TRUE), tbl(con,"t1"))
  datatypes <- .ta.describe.columns.wrapper(con, sql("select * from t1"))$types
  expect_true(datatypes[[1]] == "date")
  expect_true(datatypes[[2]] == "timestamp")
  expect_true(datatypes[[3]] == "timestamp")
  expect_true(datatypes[[4]] == "byteint")
  expect_true(datatypes[[5]] == "int")
  expect_true(datatypes[[6]] == "varchar")
  expect_true(datatypes[[7]] == "float")
  expect_true(datatypes[[8]] == "byte")
  expect_true(datatypes[[9]] == "varchar")
})

#passing coltypes
test_that("creating a table with different data types", {
  df <-  data.frame(dt_date      = c(as.Date('1915-06-16'),as.Date('1916-06-16'),as.Date('1917-06-16')),
                    dt_posixct   = c(as.POSIXct('1915-06-16'),as.POSIXct('1916-06-16'),as.POSIXct('1917-06-16')),
                    dt_posixlt   = c(as.POSIXlt('1915-06-16'),as.POSIXlt('1916-06-16'),as.POSIXlt('1917-06-16')),
                    dt_logical   = c(TRUE, FALSE, TRUE),
                    dt_integer   = c(2L,3L,4L),
                    dt_character = c('a' , "good", "TRUE"),
                    dt_double    = c(1, 2.5, 4.5),
                    dt_raw       = as.raw(c(21,34,53)),
                    dt_complex   = c(1+2i, 3+4i, 6+7i)
  )
  expect_equal(copy_to(con, df, name = "t6",
                       types=c("date","timestamp","timestamp", "byteint", "int",
                               "varchar(10)", "float", "byte", "varchar(10)" )),
               tbl(con,"t6"))
  datatypes <- .ta.describe.columns.wrapper(con, sql("select * from t6"))$types
  expect_true(datatypes[[1]] == "date")
  expect_true(datatypes[[2]] == "timestamp")
  expect_true(datatypes[[3]] == "timestamp")
  expect_true(datatypes[[4]] == "byteint")
  expect_true(datatypes[[5]] == "int")
  expect_true(datatypes[[6]] == "varchar")
  expect_true(datatypes[[7]] == "float")
  expect_true(datatypes[[8]] == "byte")
  expect_true(datatypes[[9]] == "varchar")
})

test_that("creating a table with list", {
  df <-  data.frame(a = list(1,2,3))
  expect_equal(copy_to(con, df, name = "t2"), tbl(con,"t2"))
})

test_that("creating a table with factor", {
  df <-  data.frame(a = factor(c(1,2,3,3,4,2,1)),
                    b = c(as.POSIXct('1915-06-16'),as.POSIXct('1916-06-16'),
                          as.POSIXct('1916-06-16'),as.POSIXct('1917-06-16'),
                          as.POSIXct('1916-06-16'),as.POSIXct('1917-06-16'),
                          as.POSIXct('1916-06-16')))
  expect_equal(copy_to(con, df, name = "t3"), tbl(con,"t3"))
  datatypes <- .ta.describe.columns.wrapper(con, sql("select * from t3"))$types
  expect_true(datatypes[[1]] == "varchar")
  expect_true(datatypes[[2]] == "timestamp")

  #Verifying data
  t1 <- collect(tbl(con,"t3"))
  t2 <- as.data.frame(tbl(con,"t3"))
  
  expect_true(unique(df$a %in% t1$a))
  expect_true(unique(df$a %in% t2$a))

})

if(td_get_context()$driver.type != 'Teradata Native Driver'){
  test_that("creating a table with difftime", {
    df <-  data.frame(a = as.difftime(c("0:3:20", "11:23:15")), b = c(3+4i,6+7i))
    expect_equal(copy_to(con, df, name = "t4"), tbl(con,"t4"))
    datatypes <- .ta.describe.columns.wrapper(con, sql("select * from t4"))$types
    expect_true(datatypes[[1]] == "time")
    expect_true(datatypes[[2]] == "varchar")
  }) 
}

test_that("creating a table with blob", {
  b = blob::as.blob(c("hello", "how", "are", "you", "Good evening"))
  df = data.frame(a = c(1:5), b = b)
  expect_equal(copy_to(con, df, name = "t5"), tbl(con,"t5"))
  datatypes <- .ta.describe.columns.wrapper(con, sql("select * from t5"))$types
  expect_true(datatypes[[1]] == "int")
  expect_true(datatypes[[2]] == "blob")

  #verify data
  t1 <- collect(tbl(con,"t5"))
  t2 <- as.data.frame(tbl(con,"t5"))
  
  expect_true(unique(t1$b %in% df$b))
  expect_true(unique(t2$b %in% df$b))
})

if(td_get_context()$driver.type != 'Teradata Native Driver'){
  test_that("creating a table with raw data", {
    df = data.frame(a = c(0:255), b = as.raw(0:255))
    expect_equal(copy_to(con, df, name = "t7"), tbl(con,"t7"))
    datatypes <- .ta.describe.columns.wrapper(con, sql("select * from t7"))$types
    expect_true(datatypes[[1]] == "int")
    expect_true(datatypes[[2]] == "byte")
    
    #verify data
    t1 <- collect(tbl(con,"t7"))
    
    l1 = t1$a
    l2 = t1$b
    for (i in 1:length(l1)){
      expect_equal(l1[[i]], as.integer(l2[[i]]))
    }
  }) 
}

#Creating table with all the data types

test_that("creating a table with numeric data", {
  df = data.frame(dt_byteint  = c(-126,1,2,125),
                  dt_smallint = c(-32,-5,10,32),
                  dt_bigint   = c(-5,0,50,10),
                  dt_integer  = c(-50000,0,50000,100000),
                  dt_decimal  = c(13.1234,14.2312,15.3445,43.2412),
                  dt_float    = c(1.12,4.23,5.34,4.24),
                  dt_number   = c(3.35,23.42,51.00,6.40),
                  dt_number_def = c(1L, 3L, 2L, 5L))
  
  expect_equal(copy_to(con, df, name = "t8", types = c("byteint","smallint","bigint",
                                                       "integer","decimal(6,4)","double precision",
                                                       "number(10,5)", "number")), tbl(con,"t8"))
  datatypes <- .ta.describe.columns.wrapper(con, sql("select * from t8"), return.vector = TRUE)$types
  expect_true(datatypes[[1]] == "byteint")
  expect_true(datatypes[[2]] == "smallint")
  expect_true(datatypes[[3]] == "bigint")
  expect_true("integer" %in% datatypes[[4]])
  expect_true("decimal" %in% datatypes[[5]])
  expect_true("double precision" %in% datatypes[[6]])
  expect_true("number" %in% datatypes[[7]])
  expect_true("number" %in% datatypes[[8]])
  
  #verify data
  t1 <- collect(tbl(con,"t8"))
  t2 <- as.data.frame(tbl(con,"t8"))
  
  expect_true(unique(df$dt_byteint %in% t1$dt_byteint))
  expect_true(unique(df$dt_smallint %in% t1$dt_smallint))
  expect_true(unique(df$dt_bigint %in% as.integer(t1$dt_bigint)))
  expect_true(unique(df$dt_integer %in% t1$dt_integer))
  expect_true(unique(df$dt_decimal %in% t1$dt_decimal))
  expect_true(unique(df$dt_float %in% t1$dt_float))
  expect_true(unique(df$dt_number %in% t1$dt_number))
  expect_true(unique(df$dt_number_def %in% t1$dt_number_def))
  
  expect_true(unique(df$dt_byteint %in% t2$dt_byteint))
  expect_true(unique(df$dt_smallint %in% t2$dt_smallint))
  expect_true(unique(df$dt_bigint %in% as.integer(t2$dt_bigint)))
  expect_true(unique(df$dt_integer %in% t2$dt_integer))
  expect_true(unique(df$dt_decimal %in% t2$dt_decimal))
  expect_true(unique(df$dt_float %in% t2$dt_float))
  expect_true(unique(df$dt_number %in% t2$dt_number))
  expect_true(unique(df$dt_number_def %in% t2$dt_number_def))
})

test_that("creating a table with null data", {
  df <- data.frame(a = c(1,NaN, 3, NA,4, -Inf,Inf), b = c('abc',NaN, 'xyz', NA, 'def', -Inf,Inf))
  expect_equal(copy_to(con, df, name = "t9"), tbl(con,"t9"))
  datatypes <- .ta.describe.columns.wrapper(con, sql("select * from t9"))$types
  expect_true(datatypes[[1]] == "float")
  expect_true(datatypes[[2]] == "varchar")
  
  #verify data
  t1 <- collect(tbl(con,"t9"))
  t2 <- as.data.frame(tbl(con,"t9"))
  
  expect_true(unique(df$a %in% t1$a))
  expect_true(unique(df$b %in% t1$b))
  
  expect_true(unique(df$a %in% t2$a))
  expect_true(unique(df$b %in% t2$b))
  
})

testthat::teardown(
  {
    cleanup()
    td_remove_context()
  })