context("Unittests for helper functions for sample")

testthat::setup({
  # Create connection.
  if(globalDTYPE == "odbc"){
    con <<- suppressWarnings(td_create_context(dsn = dsnName))
  } else {
    con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD))
  }
  # Cleaning data base if tables are already exists.
  try(DBI::dbExecute(con, "DROP TABLE sample_test_table"), silent = TRUE)
  
  # Writing new table in Vantage using copy_to.
  df <- data.frame(a = c(1,2,3), b = c(3,4,5))
  copy_to(con, df = df, name = "sample_test_table", overwrite = TRUE)
})

test_that("Unittests to test whether generate_sample_query generates queries correctly", {
  
  df <- tbl(con, "sample_test_table")
  df_query <- tbl(con, sql("select * from sample_test_table"))
  df_tbl <- df %>% filter(a < 3)
  
  # when_then containing only list/vector of integers/un-named vector/partial_named vector
  expect_error(td_sample(df, when_then = list(2,3), case_else = 2), 
          "Permitted values for the argument 'when_then' are: Named list of numbers or named list of vector of numbers.")
  expect_error(td_sample(df, when_then = c(2,3), case_else = 2), 
          "Permitted values for the argument 'when_then' are: Named list of numbers or named list of vector of numbers.") 
  expect_error(td_sample(df, when_then = list("a<2" = c(2, 2), 3), case_else = 2), 
          "Permitted values for the argument 'when_then' are: Named list of numbers or named list of vector of numbers.") 
  
  ### Using tbl formed from table
  
  # With n = 3
  query <- .generate_sample_query(df, 3)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM sample_test_table SAMPLE 3")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With replacement and n
  query <- .generate_sample_query(df, n = 3, with.replacement = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM sample_test_table SAMPLE WITH REPLACEMENT 3")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With randomized allocation and n
  query <- .generate_sample_query(df, n = 3, randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM sample_test_table SAMPLE RANDOMIZED ALLOCATION 3")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With replacement, randomized allocation and n
  query <- .generate_sample_query(df, n = 3, with.replacement = TRUE, randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM sample_test_table SAMPLE WITH REPLACEMENT RANDOMIZED ALLOCATION 3")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then argument
  query <- .generate_sample_query(df, when_then = list("a < 3" = 1))
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM sample_test_table SAMPLE \t WHEN a < 3 THEN 1 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))

  # With when_then and replacement
  query <- .generate_sample_query(df, when_then = list("a < 3" = 1), with.replacement = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM sample_test_table SAMPLE WITH REPLACEMENT \t WHEN a < 3 THEN 1 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then and randomization
  query <- .generate_sample_query(df, when_then = list("a < 3" = 1), randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM sample_test_table SAMPLE RANDOMIZED ALLOCATION \t WHEN a < 3 THEN 1 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then, replacement and randomization
  query <- .generate_sample_query(df, when_then = list("a < 3" = 1), with.replacement = TRUE, randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM sample_test_table SAMPLE WITH REPLACEMENT RANDOMIZED ALLOCATION \t WHEN a < 3 THEN 1 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))

  # With when_then and case_else arguments
  query <- .generate_sample_query(df, when_then = list("a < 3" = 1), case_else = 2)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM sample_test_table SAMPLE \t WHEN a < 3 THEN 1 \t ELSE 2 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then, case_else and replacement
  query <- .generate_sample_query(df, when_then = list("a < 3" = 1), case_else = 2, with.replacement = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM sample_test_table SAMPLE WITH REPLACEMENT \t WHEN a < 3 THEN 1 \t ELSE 2 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then, case_else and randomization
  query <- .generate_sample_query(df, when_then = list("a < 3" = 1), case_else = 2, randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM sample_test_table SAMPLE RANDOMIZED ALLOCATION \t WHEN a < 3 THEN 1 \t ELSE 2 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then, case_else, replacement and randomization
  query <- .generate_sample_query(df, when_then = list("a < 3" = 1), case_else = 2, with.replacement = TRUE, randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM sample_test_table SAMPLE WITH REPLACEMENT RANDOMIZED ALLOCATION \t WHEN a < 3 THEN 1 \t ELSE 2 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  ### Using tbl formed from Query
  
  # With n = 3
  query <- .generate_sample_query(df_query, 3)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (select * from sample_test_table) AS sample_alias SAMPLE 3")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With replacement and n
  query <- .generate_sample_query(df_query, n = 3, with.replacement = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (select * from sample_test_table) AS sample_alias SAMPLE WITH REPLACEMENT 3")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With randomized allocation and n
  query <- .generate_sample_query(df_query, n = 3, randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (select * from sample_test_table) AS sample_alias SAMPLE RANDOMIZED ALLOCATION 3")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With replacement, randomized allocation and n
  query <- .generate_sample_query(df_query, n = 3, with.replacement = TRUE, randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (select * from sample_test_table) AS sample_alias SAMPLE WITH REPLACEMENT RANDOMIZED ALLOCATION 3")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then argument
  query <- .generate_sample_query(df_query, when_then = list("a < 3" = 1))
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (select * from sample_test_table) AS sample_alias SAMPLE \t WHEN a < 3 THEN 1 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then and replacement
  query <- .generate_sample_query(df_query, when_then = list("a < 3" = 1), with.replacement = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (select * from sample_test_table) AS sample_alias SAMPLE WITH REPLACEMENT \t WHEN a < 3 THEN 1 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then and randomization
  query <- .generate_sample_query(df_query, when_then = list("a < 3" = 1), randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (select * from sample_test_table) AS sample_alias SAMPLE RANDOMIZED ALLOCATION \t WHEN a < 3 THEN 1 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then, replacement and randomization
  query <- .generate_sample_query(df_query, when_then = list("a < 3" = 1), with.replacement = TRUE, randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (select * from sample_test_table) AS sample_alias SAMPLE WITH REPLACEMENT RANDOMIZED ALLOCATION \t WHEN a < 3 THEN 1 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when, then and case_else arguments
  query <- .generate_sample_query(df_query, when_then = list("a < 3" = 1), case_else = 2)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (select * from sample_test_table) AS sample_alias SAMPLE \t WHEN a < 3 THEN 1 \t ELSE 2 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then, case_else and replacement
  query <- .generate_sample_query(df_query, when_then = list("a < 3" = 1), case_else = 2, with.replacement = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (select * from sample_test_table) AS sample_alias SAMPLE WITH REPLACEMENT \t WHEN a < 3 THEN 1 \t ELSE 2 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then, case_else and randomization
  query <- .generate_sample_query(df_query, when_then = list("a < 3" = 1), case_else = 2, randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (select * from sample_test_table) AS sample_alias SAMPLE RANDOMIZED ALLOCATION \t WHEN a < 3 THEN 1 \t ELSE 2 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then, case_else, replacement and randomization
  query <- .generate_sample_query(df_query, when_then = list("a < 3" = 1), case_else = 2, with.replacement = TRUE, randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (select * from sample_test_table) AS sample_alias SAMPLE WITH REPLACEMENT RANDOMIZED ALLOCATION \t WHEN a < 3 THEN 1 \t ELSE 2 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  
  ## Using tbl from nested_query
  
  # With n = 3
  query <- .generate_sample_query(df_tbl, 3)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (SELECT * FROM \"sample_test_table\" WHERE (\"a\" < 3.0)) AS sample_alias SAMPLE 3")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With replacement and n
  query <- .generate_sample_query(df_tbl, n = 3, with.replacement = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (SELECT * FROM \"sample_test_table\" WHERE (\"a\" < 3.0)) AS sample_alias SAMPLE WITH REPLACEMENT 3")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With randomized allocation and n
  query <- .generate_sample_query(df_tbl, n = 3, randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (SELECT * FROM \"sample_test_table\" WHERE (\"a\" < 3.0)) AS sample_alias SAMPLE RANDOMIZED ALLOCATION 3")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With replacement, randomized allocation and n
  query <- .generate_sample_query(df_tbl, n = 3, with.replacement = TRUE, randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (SELECT * FROM \"sample_test_table\" WHERE (\"a\" < 3.0)) AS sample_alias SAMPLE WITH REPLACEMENT RANDOMIZED ALLOCATION 3")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then argument
  query <- .generate_sample_query(df_tbl, when_then = list("a < 3" = 1))
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (SELECT * FROM \"sample_test_table\" WHERE (\"a\" < 3.0)) AS sample_alias SAMPLE \t WHEN a < 3 THEN 1 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then and replacement
  query <- .generate_sample_query(df_tbl, when_then = list("a < 3" = 1), with.replacement = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (SELECT * FROM \"sample_test_table\" WHERE (\"a\" < 3.0)) AS sample_alias SAMPLE WITH REPLACEMENT \t WHEN a < 3 THEN 1 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then and randomization
  query <- .generate_sample_query(df_tbl, when_then = list("a < 3" = 1), randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (SELECT * FROM \"sample_test_table\" WHERE (\"a\" < 3.0)) AS sample_alias SAMPLE RANDOMIZED ALLOCATION \t WHEN a < 3 THEN 1 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then, replacement and randomization
  query <- .generate_sample_query(df_tbl, when_then = list("a < 3" = 1), with.replacement = TRUE, randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (SELECT * FROM \"sample_test_table\" WHERE (\"a\" < 3.0)) AS sample_alias SAMPLE WITH REPLACEMENT RANDOMIZED ALLOCATION \t WHEN a < 3 THEN 1 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when, then and case_else arguments
  query <- .generate_sample_query(df_tbl, when_then = list("a < 3" = 1), case_else = 2)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (SELECT * FROM \"sample_test_table\" WHERE (\"a\" < 3.0)) AS sample_alias SAMPLE \t WHEN a < 3 THEN 1 \t ELSE 2 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then, case_else and replacement
  query <- .generate_sample_query(df_tbl, when_then = list("a < 3" = 1), case_else = 2, with.replacement = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (SELECT * FROM \"sample_test_table\" WHERE (\"a\" < 3.0)) AS sample_alias SAMPLE WITH REPLACEMENT \t WHEN a < 3 THEN 1 \t ELSE 2 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then, case_else and randomization
  query <- .generate_sample_query(df_tbl, when_then = list("a < 3" = 1), case_else = 2, randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (SELECT * FROM \"sample_test_table\" WHERE (\"a\" < 3.0)) AS sample_alias SAMPLE RANDOMIZED ALLOCATION \t WHEN a < 3 THEN 1 \t ELSE 2 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
  # With when_then, case_else, replacement and randomization
  query <- .generate_sample_query(df_tbl, when_then = list("a < 3" = 1), case_else = 2, with.replacement = TRUE, randomize = TRUE)
  expected_query <- sql("SELECT a, b, SAMPLEID AS \"sampleid\" FROM (SELECT * FROM \"sample_test_table\" WHERE (\"a\" < 3.0)) AS sample_alias SAMPLE WITH REPLACEMENT RANDOMIZED ALLOCATION \t WHEN a < 3 THEN 1 \t ELSE 2 \t END  ")
  expect_equal(expected_query, gsub("\n", replacement = " ", x = query))
  
})


test_that("Unittests for validateSampleEachListElement", {
  # Negative tests
  expect_error(.validateSampleEachListElement(-4, "n"), "Permitted values for the argument 'n' are: positive real numbers.")
  expect_error(.validateSampleEachListElement(c(3, -2), "n"), "Permitted values for the argument 'n' are: positive real numbers.")
  expect_error(.validateSampleEachListElement(c(3, 2, -4, 2), "n"), "Permitted values for the argument 'n' are: positive real numbers.")
  
  # Positive tests
  .validateSampleEachListElement(4, "n") # No Error
  .validateSampleEachListElement(c(4, 3, 2), "n") # No Error
})

test_that("Unittests for .validateSampleArguments", {
  # Negative tests
  expect_error(.validateSampleArguments(n = 3, when_then = list("orders < 100" = 4)), "Provide either n or when.")
  expect_error(.validateSampleArguments(n = NULL, when_then = list(), case_else = 4), "Provide either n or when.")
  expect_error(.validateSampleArguments(n = 3, when_then = list(), case_else = 3), 
               "'case_else' argument can only be used when 'when_then' argument is specified.")
  
  # Positive tests
  .validateSampleArguments(n = 3, when_then = list(), case_else = c())
  .validateSampleArguments(n = NULL, when_then = list("orders < 100" = c(4)), case_else = c())
  .validateSampleArguments(n = NULL, when_then = list("order < 10" = 3, "prior <> 'high'" = c(2, 1)), case_else = c(2,3))
})


testthat::teardown({
  DBI::dbExecute(con, "DROP TABLE sample_test_table")
  td_remove_context()
})