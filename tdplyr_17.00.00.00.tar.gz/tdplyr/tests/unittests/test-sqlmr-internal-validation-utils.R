################################################################################
# This contains test cases for utility functions which will be used in 
# wrapper argument checks. Functions dependent on checks to be done on arguments
# passed to any wrapper function.
# 
# Primary Owner: pankajvinod.purandare@teradata.com
# Secondary Owner:
#
################################################################################
library(dplyr)
library(dbplyr)

context("Test Wrapper Argument Validation Utility Functions.")

test_that("Test cases for empty string validation function 
          (.validateInputColumnsNotEmpty):", {
            # Negative cases.
            # Empty string
            var1 <- ""
            expect_error(.validateInputColumnsNotEmpty(var1), 
                         "Argument 'var1' should not contain empty string.")
            # String containg only space
            var2 <- " "
            expect_error(.validateInputColumnsNotEmpty(var2), 
                         "Argument 'var2' should not contain empty string.")
            # String containg only escaped space
            var3 <- "\ "
            expect_error(.validateInputColumnsNotEmpty(var3), 
                         "Argument 'var3' should not contain empty string.")
            # String containg only newline
            var4 <- "\n"
            expect_error(.validateInputColumnsNotEmpty(var4), 
                         "Argument 'var4' should not contain empty string.")
            # String containg only tab
            var5 <- "\t"
            expect_error(.validateInputColumnsNotEmpty(var5), 
                         "Argument 'var5' should not contain empty string.")
            
            # Case when NA is passed.
            var6 <- NA
            expect_true(.validateInputColumnsNotEmpty(var6))
            # Case when NULL is passed.
            var7 <- NULL
            expect_true(.validateInputColumnsNotEmpty(var7))
            var8 <- NaN
            expect_true(.validateInputColumnsNotEmpty(var8))
            # Case when non-empty string is passed.
            var9 <- "Non-empty-string"
            expect_true(.validateInputColumnsNotEmpty(var9))
            })

test_that("Test cases for Permitted values validation (.validatePermittedValues):", {
  
  testarg <- "CD"
  vec <- c("A", "B", "CD", "EFG")
  # Invalid value is passed to 'permittedValuesList'
  expect_error(.validatePermittedValues(testarg, 1), 
               "Argument 'permittedValuesList' should be of list type")
  
  # Invalid type of argument is passed for permitted value list.
  expect_error(.validatePermittedValues(testarg, vec))
  
  # Positive case
  vec <- list("A", "B", "CD", "EFG")
  expect_true(.validatePermittedValues(testarg, vec))
  
  # Negative case where argument value is not same as that of permitted value.
  testarg <- "CDE"
  expect_error(expect_failure(.validatePermittedValues(testarg, vec)))
})

test_that("Missing required arguments check is performed properly ()", {
  ##### Test cases for '.teradataReportMissingArg' #####
  # When argument type = Character 
  # Invalid list i.e. list without column names is passed.
  data1 <- NULL
  alist <- list("data", data1, FALSE, "ta.data.frame")
  expect_error(.teradataReportMissingArg(alist))
  
  # Valid case: When aregument is missing and is required.
  alist <- list(argName = "data", argValue = data1, isOptional = FALSE, argType = "character")
  expect_identical(.teradataReportMissingArg(alist), "data")
  # Valid case - When argument is missing and is optional. Must return NULL.
  alist <- list(argName = "data", argValue = data1, isOptional = TRUE, argType = "character")
  expect_null(.teradataReportMissingArg(alist))
  
  data1 <- "nonNULL"
  # Valid case - When argument is not missing and is required Must return NULL.
  alist <- list(argName = "data", argValue = data1, isOptional = FALSE, argType = "character")
  expect_null(.teradataReportMissingArg(alist))
  # Valid case - When argument is not missing and is optional. Must return NULL.
  alist <- list(argName = "data", argValue = data1, isOptional = TRUE, argType = "character")
  expect_null(.teradataReportMissingArg(alist))
  
  # Invalid list i.e. list without column names is passed.
  data1 <- NULL
  alist <- list("data", data1, FALSE, "ta.data.frame")
  expect_error(.teradataReportMissingArg(alist))
  
  # Valid case: When aregument is missing and is required.
  alist <- list(argName = "data", argValue = data1, isOptional = FALSE, argType = "ta.data.frame")
  expect_identical(.teradataReportMissingArg(alist), "data")
  # Valid case - When argument is missing and is optional. Must return NULL.
  alist <- list(argName = "data", argValue = data1, isOptional = TRUE, argType = "ta.data.frame")
  expect_null(.teradataReportMissingArg(alist))
  
  data1 <- "nonNULL"
  # Valid case - When argument is not missing and is required Must return NULL.
  alist <- list(argName = "data", argValue = data1, isOptional = FALSE, argType = "ta.data.frame")
  expect_null(.teradataReportMissingArg(alist))
  # Valid case - When argument is not missing and is optional. Must return NULL.
  alist <- list(argName = "data", argValue = data1, isOptional = TRUE, argType = "ta.data.frame")
  expect_null(.teradataReportMissingArg(alist))
  
  ##### Test cases for '.teradataAllMissingArgsVector' #####
  data1 <- "data"
  centers <- NULL
  iter.max <- 910
  
  # Create argInfoMatrix matrix
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data1, FALSE, "ta.data.frame"))
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "numeric"))
  argInfoMatrix <- rbind(argInfoMatrix, list("iter.max", iter.max, TRUE, "numeric"))
  # Case when proper argument matrix is not passed.
  expect_error(.teradataAllMissingArgsVector(argInfoMatrix))
  
  # Positive case.
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_null(.teradataAllMissingArgsVector(argInfoMatrix))
  
  # Case when required argument is missing.
  data1 <- NULL
  centers <- NULL
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data1, FALSE, "ta.data.frame"))
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, FALSE, "numeric"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_identical(.teradataAllMissingArgsVector(argInfoMatrix), c("data", "centers"))
  
  
  ##### Test Cases for '.validateMissingRequiredArguments' #####
  # Negative cases.
  # Required arguments are missing.
  # Data for the test cases.
  data1 <- NULL
  centers <- NULL
  iter.max <- 910
  
  # Create argInfoMatrix matrix
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data1, FALSE, "ta.data.frame"))
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, FALSE, "numeric"))
  argInfoMatrix <- rbind(argInfoMatrix, list("iter.max", iter.max, TRUE, "numeric"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_error(.validateMissingRequiredArguments(argInfoMatrix), 
               "Following required arguments are missing: data, centers")
  
  
  # Positive cases.
  # Required as well as optional arguments are provided 
  # (one as NULL and other with proper value).
  data1 <- "data-non-null"
  centers <- NULL
  iter.max <- 910
  
  # Create argInfoMatrix matrix
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data1, FALSE, "ta.data.frame"))
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "numeric"))
  argInfoMatrix <- rbind(argInfoMatrix, list("iter.max", iter.max, TRUE, "numeric"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateMissingRequiredArguments(argInfoMatrix))
  
  # Required argument provided and optional are NA.
  centers <- NA
  iter.max <- NA
  # Create argInfoMatrix matrix
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("data", data1, FALSE, "ta.data.frame"))
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "numeric"))
  argInfoMatrix <- rbind(argInfoMatrix, list("iter.max", iter.max, TRUE, "numeric"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateMissingRequiredArguments(argInfoMatrix))
  
  
})

test_that("Test cases for validating argument types functions (.validateArgumentTypes)", {
  ##### Invalid type of values passed ##### 
  data <- "tempData"
  centers <- "10.3"
  iter.max <- "TRUE"
  family <- 10
  formula <- "a ~ x + y"
  top.k <- "10"
  # Create argInfoMatrix matrix
  argInfoMatrix <- list()
  # Single type Single Value - Passed Single incorrect type value
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "numeric"))
  argInfoMatrix <- rbind(argInfoMatrix, list("iter.max", iter.max, TRUE, "logical"))
  argInfoMatrix <- rbind(argInfoMatrix, list("family", family, TRUE, "character"))
  argInfoMatrix <- rbind(argInfoMatrix, list("formula", formula, FALSE, "formula"))
  argInfoMatrix <- rbind(argInfoMatrix, list("top.k", top.k, FALSE, "integer"))
  
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  expect_error(.validateArgumentTypes(argInfoMatrix), 
               paste0("Argument '", argInfoMatrix[1,]$argName, "' must be of '",
                      argInfoMatrix[1,]$argType, "' datatype."))
  expect_error(.validateArgumentTypes(argInfoMatrix), 
               paste0("Argument '", argInfoMatrix[2,]$argName, "' must be of '",
                      argInfoMatrix[2,]$argType, "' datatype."))
  expect_error(.validateArgumentTypes(argInfoMatrix), 
               paste0("Argument '", argInfoMatrix[3,]$argName, "' must be of '",
                      argInfoMatrix[3,]$argType, "' datatype."))
  expect_error(.validateArgumentTypes(argInfoMatrix), 
               paste0("Argument '", argInfoMatrix[4,]$argName, "' must be of '",
                      argInfoMatrix[4,]$argType, "' datatype."))
  expect_error(.validateArgumentTypes(argInfoMatrix), 
               paste0("Argument '", argInfoMatrix[5,]$argName, "' must be of '",
                      argInfoMatrix[5,]$argType, "' datatype."))
  
  ##### Test another internal function of '.validateArgumentTypes'  ##### 
  expect_identical(.teradataReportIncorrectType(argInfoMatrix[2,]), 
                   argInfoMatrix[2,]$argName)
  expect_identical(.teradataReportIncorrectType(argInfoMatrix[3,]), 
                   argInfoMatrix[3,]$argName)
  expect_identical(.teradataReportIncorrectType(argInfoMatrix[4,]), 
                   argInfoMatrix[4,]$argName)
  expect_identical(.teradataReportIncorrectType(argInfoMatrix[1,]), 
                   argInfoMatrix[1,]$argName)
  expect_identical(.teradataReportIncorrectType(argInfoMatrix[5,]), 
                   argInfoMatrix[5,]$argName)
  
  ##### cases to test allowsList type of arguments
  argInfoMatrix <- list()
  # Single datatype supported - Pass Single incorrect type value.
  col1 <- 10.3
  argInfoMatrix <- rbind(argInfoMatrix, list("col1", col1, TRUE, c("character", NA)))
  
  # Single type Single Value - Passed a list of correct types. But argument does not except list value.
  col2 = c("col1", "col2", "col3")
  argInfoMatrix <- rbind(argInfoMatrix, list("col2", col2, TRUE, c("character",NA)))
  
  # Single type Single Value - Passed a list of incorrect types. Argument can accepts a str
  col3 = c(1, TRUE, 2.28)
  argInfoMatrix <- rbind(argInfoMatrix, list("col3", col3, TRUE, c("character",NA)))
  
  # Multiple datatypes supported, but No List supported - Passe Single incorrect type value.
  booleanArg = TRUE
  argInfoMatrix <- rbind(argInfoMatrix, list("booleanArg", booleanArg, TRUE, c("float", "integer", "character")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  expect_error(.validateArgumentTypes(argInfoMatrix), 
               paste0("Argument '", argInfoMatrix[1,]$argName, "' must be of '",
                      na.omit(argInfoMatrix[1,]$argType), "' datatype. Multiple values are not supported"))
  expect_error(.validateArgumentTypes(argInfoMatrix), 
               paste0("Argument '", argInfoMatrix[2,]$argName, "' must be of '",
                      na.omit(argInfoMatrix[2,]$argType), "' datatype. Multiple values are not supported"))
  expect_error(.validateArgumentTypes(argInfoMatrix), 
               paste0("Argument '", argInfoMatrix[3,]$argName, "' must be of '",
                      na.omit(argInfoMatrix[3,]$argType), "' datatype. Multiple values are not supported"))
  expect_error(.validateArgumentTypes(argInfoMatrix), 
               paste0("Argument '", argInfoMatrix[4,]$argName, "' must be of '",
                      paste(na.omit(argInfoMatrix[4,]$argType),collapse = " or "), "' datatype. ",
                      "Multiple values are not supported. Integer values range between -2147483647 and 2147483647, both bounds inclusive."))
  
  argInfoMatrix <- list()
  # Multiple datatypes supported but No List supported - Pass a list of correct type values.
  # Argument can accept a character or a numeric
  # Passed a list containing values of correct types
  # Must raise error
  col1 = c(10.5, 100, 2.28)
  argInfoMatrix <- rbind(argInfoMatrix, list("col1", col1, TRUE, c("numeric", "character")))
  
  # Multiple datatypes supported, but not List. - Passed a list of incorrect type values.
  # Passed a list containing values of incorrect types.
  col2 = c(TRUE,FALSE)
  argInfoMatrix <- rbind(argInfoMatrix, list("col2", col2, TRUE, c("character", "double")))

  # Only integers are supported but lists are not supported (case 1).
  col3 = c(100,200)
  argInfoMatrix <- rbind(argInfoMatrix, list("col3", col3, TRUE, c("integer", "character")))

  # Only integers are supported but lists are not supported (case 2).
  col4 = c(100,200)
  argInfoMatrix <- rbind(argInfoMatrix, list("col4", col4, TRUE, c("integer",NA)))
  
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_error(.validateArgumentTypes(argInfoMatrix), 
               paste0("Argument '", argInfoMatrix[1,]$argName, "' must be of '",
                      paste(argInfoMatrix[1,]$argType, collapse = " or "), "' datatype. Multiple values are not supported"))
  
  expect_error(.validateArgumentTypes(argInfoMatrix), 
               paste0("Argument '", argInfoMatrix[2,]$argName, "' must be of '",
                      paste(argInfoMatrix[2,]$argType, collapse = " or "), "' datatype. Multiple values are not supported"))
  
  expect_error(.validateArgumentTypes(argInfoMatrix), 
               paste0("Argument '", argInfoMatrix[3,]$argName, "' must be of '",
                      paste(argInfoMatrix[3,]$argType, collapse = " or "), "' datatype. ",
                      "Multiple values are not supported. Integer values range between -2147483647 and 2147483647, both bounds inclusive."))
  
  # Skipping NA values
  actual_arg_types <- unlist(lapply(argInfoMatrix[4,]$argType, function (x) {
                        if (!is.na(x))
                            return(x)
                      }))
  expect_error(.validateArgumentTypes(argInfoMatrix), 
               paste0("Argument '", argInfoMatrix[4,]$argName, "' must be of '",
                      paste(actual_arg_types, collapse = " or "), "' datatype. ",
                      "Multiple values are not supported. Integer values range between -2147483647 and 2147483647, both bounds inclusive."))

  # Multiple supported datatypes but not List - Pass Single correct type value.
  argInfoMatrix <- list()
  col1 = 2.28
  argInfoMatrix <- rbind(argInfoMatrix, list("col1", col1, TRUE, c("numeric", "integer", "character")))
  
  col2 = 200
  argInfoMatrix <- rbind(argInfoMatrix, list("col2", col2, TRUE, c("integer", "character")))
  
  col3 = "col1"
  argInfoMatrix <- rbind(argInfoMatrix, list("col3", col3, TRUE, c("numeric", "integer", "character")))
  
  # single datatype With List - Passed Single correct type value.
  # Argument can accept a list of str or a str.
  object.data.order.column = "col1"
  argInfoMatrix <- rbind(argInfoMatrix, list("object.data.order.column", object.data.order.column, TRUE, c("character", "list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  expect_true(.validateArgumentTypes(argInfoMatrix))
  
  # Multiple datatypes With List - Passed Single incorrect type value.
  # Argument can accept a list of str or a str.
  # Passed a float or a bool.
  argInfoMatrix <- list()
  object.data.order.column = 2.28
  argInfoMatrix <- rbind(argInfoMatrix, list("object.data.order.column", object.data.order.column, TRUE, c("character", "integer", "list")))

  # Multiple types and a list, as expected types.
  edges.data.order.column = TRUE
  argInfoMatrix <- rbind(argInfoMatrix, list("edges.data.order.column", edges.data.order.column, TRUE, c("character", "list","double")))
  
  object1.data.order.column = 200 # Integer values can be numeric. Hence, no error messsage for this.
  argInfoMatrix <- rbind(argInfoMatrix, list("object1.data.order.column", object1.data.order.column, TRUE, c("character", "numeric", "list")))
  
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  expect_error(.validateArgumentTypes(argInfoMatrix), 
               paste0("Argument '", argInfoMatrix[1,]$argName, "' must be of '",
                      paste(argInfoMatrix[1,]$argType[ argInfoMatrix[1,]$argType != 'list' ],collapse = " or "), 
                      "' datatype or a vector of '", paste0(argInfoMatrix[1,]$argType[ argInfoMatrix[1,]$argType != 'list' ], collapse = " or "),
                      "' datatype\\(s). Integer values range between -2147483647 and 2147483647, both bounds inclusive."))

  expect_error(.validateArgumentTypes(argInfoMatrix),
               paste0("Argument '", argInfoMatrix[2,]$argName, "' must be of '",
                      paste(argInfoMatrix[2,]$argType[ argInfoMatrix[2,]$argType != 'list' ],collapse = " or "), "' datatype or a vector of '", paste0(argInfoMatrix[2,]$argType[ argInfoMatrix[2,]$argType != 'list' ], collapse = " or "),"' datatype\\(s)."))
  
  # Multiple types With List - Passed a list of correct type values.
  # Argument can accept a list of str or a str.
  # Passed a list containing values of correct types.
  argInfoMatrix <- list()
  object.data.order.column = c("col1", "col2", "col3")
  argInfoMatrix <- rbind(argInfoMatrix, list("object.data.order.column", object.data.order.column, TRUE, c("character", "list")))
  
  edges.data.order.column = c(2.28, 1.23, 45.23)
  argInfoMatrix <- rbind(argInfoMatrix, list("edges.data.order.column", edges.data.order.column, TRUE, c("character", "list","numeric")))

  edges1.data.order.column = c(10, 20)
  argInfoMatrix <- rbind(argInfoMatrix, list("edges1.data.order.column", edges1.data.order.column, TRUE, c("integer", "list")))
  
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  expect_true(.validateArgumentTypes(argInfoMatrix))
  
  # Multiple types With List -.
  # pass incorrect datatypes values as list.
  argInfoMatrix <- list()
  
  object.data.order.column = c(TRUE, "col1", 10.5)
  argInfoMatrix <- rbind(argInfoMatrix, list("object.data.order.column", object.data.order.column, TRUE, c("logical", "list","numeric")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  
  expect_error(.validateArgumentTypes(argInfoMatrix), 
               paste0("Argument '", argInfoMatrix[1,]$argName, "' must be of '",
                      paste(argInfoMatrix[1,]$argType[ argInfoMatrix[1,]$argType != 'list' ], collapse = " or "), "' datatype or a vector of '", paste(argInfoMatrix[1,]$argType[ argInfoMatrix[1,]$argType != 'list' ], collapse = " or "),"' datatype\\(s)."))
  
  
  # Argument can accept a list of ta.data.frame.
  # Passed a list containing bool, str and float.
  argInfoMatrix <- list()
  # Boolean value is still a string here.
  object.data.order.column = c(TRUE, "col1", 2.28)
  argInfoMatrix <- rbind(argInfoMatrix, list("object.data.order.column", object.data.order.column, TRUE, c("ta.data.frame",NA)))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))
  
  ##### Correct values are passed.  ##### 
  #### Test Integer ####
  centers <- 10
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "integer"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))
  centers <- c(10, 20, 30, 40)
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "integer"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))
  centers <- c(10, 20, 30, 40)
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, c("integer", "list")))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))

  #### Test Numeric ####
  centers <- 10
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "numeric"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))
  centers <- 10.2345
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "numeric"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))
  centers <- c(10, 20, 30, 40)
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "numeric"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))
  
  #### Test Character ####
  centers <- "10"
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "character"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))
  centers <- "char_type"
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "character"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))
  centers <- c("10, 20, 30, 40", "a", "b", "c")
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "character"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))
  
  #### Test Logical ####
  centers <- TRUE
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "logical"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))
  centers <- FALSE
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "logical"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))
  centers <- c(TRUE, FALSE, FALSE)
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "logical"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))
  
  #### Test formula ####
  centers <- x ~ y + z
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "formula"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))
  centers <- (x ~ y + z)
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "formula"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))
  
  #### Test ta.data.frame - This should skip ta.data.frame objects from checking ####
  centers <- "ta.data.frame.object"
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "ta.data.frame"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))
  centers <- 10
  argInfoMatrix <- list()
  argInfoMatrix <- rbind(argInfoMatrix, list("centers", centers, TRUE, "ta.data.frame"))
  colnames(argInfoMatrix) <- c("argName", "argValue", "isOptional", "argType")
  expect_true(.validateArgumentTypes(argInfoMatrix))
  
})

test_that("Unit test cases for '.validateInputTableDataType':", {

  if (globalDTYPE == "odbc") {
    con <<- suppressWarnings(DBI::dbConnect(odbc::odbc(), dsn = dsnName))
    # tbl(con, "query") will not work unless context is created.
    td_set_context(con)
  } else {
    # dbConnect(NativeDriver(), ...) will not create context.
    con <<- suppressWarnings(DBI::dbConnect(tdplyr::NativeDriver(), host = globalHost, uid = globalUID, pwd = globalPWD))
  }
  
  # TEST SETUP - 
  tryCatch({
      DBI::dbGetQuery(con, "drop table validateInputTableDataType")
    }, error=function(e) {     
      # DO Nothing
    })
  DBI::dbGetQuery(con, "create table validateInputTableDataType(i int, j int) primary index(i, j)")
  
  #### Test cases for input objects without Reference function.  ####
  # ++++ Table tibble object is passed.
  tbl_table <- tbl(con, "validateInputTableDataType")
  expect_true(.validateInputTableDataType(tbl_table, NULL))
  
  # ++++  Query tbl object is passed.
  tbl_query <- tbl(con, sql("select * from validateInputTableDataType"))
  expect_true(.validateInputTableDataType(tbl_query, NULL))
  
  # ---- In-correct object is passed - not a tbl object
  invalid_tbl <- "character_type"
  expect_error(.validateInputTableDataType(invalid_tbl, NULL), gettextf("Argument 'invalid_tbl' should be of %s type", paste0(.getSupportedDatasetClasses(), collapse = ", ")))
  
  #### Test cases for input objects with Reference function. ####
  #
  # Let's create an object with reference class. And all objects are 
  # of tbl_teradata types.
  #
  ref_obj <- list("x"=tbl_table, "y"=tbl_query)
  attr(ref_obj, "class") <- "ta.glm"
  
  # ++++ Correct call is made, by passing reference function name.
  expect_true(.validateInputTableDataType(ref_obj, "ta.glm"))
  
  # ---- In-correct call is made i.e. without mentioning reference function.
  expect_error(.validateInputTableDataType(ref_obj, NULL), 
               gettextf("Argument 'ref_obj' should be of %s type", 
                        paste0(.getSupportedDatasetClasses(), collapse = ", ")))
  
  # ---- Correct call is made, but passing reference function name is different.
  expect_error(.validateInputTableDataType(ref_obj, "ref_function_name"), 
               gettextf("Argument 'ref_obj' should be of %s type", 
                        paste(paste0(.getSupportedDatasetClasses(), 
                                     collapse = ", "), "or ref_function_name")))
  
  #
  # Let's create an object with reference class. And first object is not of 
  # tbl_teradata types.
  # Negative cases all should fail.
  #
  ref_obj <- list("x"=invalid_tbl, "y"=tbl_query)
  attr(ref_obj, "class") <- "ta.glm"
  
  # Correct call is made, by passing reference function name.
  expect_error(.validateInputTableDataType(ref_obj, "ta.glm"), 
               gettextf("Argument 'ref_obj' should be of %s type", 
                        paste(paste0(.getSupportedDatasetClasses(), 
                                     collapse = ", "), "or ta.glm")))
  
  # In-correct call is made i.e. without mentioning reference function.
  expect_error(.validateInputTableDataType(ref_obj, NULL), 
               gettextf("Argument 'ref_obj' should be of %s type", 
                        paste0(.getSupportedDatasetClasses(), collapse = ", ")))
  
  #
  # Let's create an object with reference class. And first object of 
  # tbl_teradata type and second of different type.
  #
  ref_obj <- list("x"=tbl_table, "y"=invalid_tbl)
  attr(ref_obj, "class") <- "ta.glm"
  
  # ++++ Correct call is made, by passing reference function name.
  expect_true(.validateInputTableDataType(ref_obj, "ta.glm"))
  
  # ---- In-correct call is made i.e. without mentioning reference function.
  expect_error(.validateInputTableDataType(ref_obj, NULL), 
               gettextf("Argument 'ref_obj' should be of %s type", 
                        paste0(.getSupportedDatasetClasses(), collapse = ", ")))
  
  # Let's test input objects for null's.
  # ---- Case 1: First object in the list is NULL. But class of object is correct.
  ref_obj <- list("x"=NULL, "y"=invalid_tbl)
  attr(ref_obj, "class") <- "ta.glm"
  expect_error(.validateInputTableDataType(ref_obj, "ta.glm"), "TDR_E3008")
  
  # ---- Case 2: Second object in the list is NULL. But class of object is correct.
  ref_obj <- list("x"=tbl_table, "y"=NULL)
  attr(ref_obj, "class") <- "ta.glm"
  expect_true(.validateInputTableDataType(ref_obj, "ta.glm"))
  
  # TEST - Cleanup
  tryCatch({
    DBI::dbGetQuery(con, "drop table validateInputTableDataType")
  }, error=function(e) {     
    # DO Nothing
  })
  
  td_remove_context()
})

test_that("Test cases to check if column(s)are present in given input object or not(.validateTblHasArgumentColumns):", {
  if (globalDTYPE == "odbc") {
    con <<- suppressWarnings(DBI::dbConnect(odbc::odbc(), dsn = dsnName))
    # tbl(con, "query") will not work unless context is created.
    td_set_context(con)
  } else {
    # dbConnect(NativeDriver(), ...) will not create context.
    con <<- suppressWarnings(DBI::dbConnect(tdplyr::NativeDriver(), host = globalHost, uid = globalUID, pwd = globalPWD))
  }
  
  # TEST SETUP - 
  tryCatch({
    DBI::dbGetQuery(con, "drop table validateTblHasArgumentColumns")
  }, error=function(e) {     
    # DO Nothing
  })
  DBI::dbGetQuery(con, "create table validateTblHasArgumentColumns(i int, j int, Col3 int, COL4 int) primary index(i, j)")
  tbl_table <- dplyr::tbl(con, "validateTblHasArgumentColumns")
  
  # Column argument is passed without the input data argument
  expect_error(.validateTblHasArgumentColumns("i", "input.columns", NULL , "data"), 
               "'input.columns' argument can only be used when 'data' argument is specified")
  
  # Column argument is not specified but input data argument is specified.
  expect_true(.validateTblHasArgumentColumns(NULL, "input.columns", tbl_table , "data")) 
               
  # Invalid column specified as string.
  expect_error(.validateTblHasArgumentColumns("col1", "input.columns", tbl_table , "data"), 
               "Column\\(s) 'col1' provided in 'input.columns' argument does not exist in object specified in 'data' argument")
  
  # Invalid columns specified as list
  expect_error(.validateTblHasArgumentColumns(c("j","col1"), "input.columns", tbl_table , "data"), 
               "Column\\(s) 'col1' provided in 'input.columns' argument does not exist in object specified in 'data' argument")

  # Case sensitive column names
  expect_error(.validateTblHasArgumentColumns(c("j","I", "col3"), "input.columns", tbl_table , "data"), 
               "Column\\(s) 'I,col3' provided in 'input.columns' argument does not exist in object specified in 'data' argument")
  
  # Duplicate columns specified.
  expect_error(.validateTblHasArgumentColumns(c("j","col3","I", "col3"), "input.columns", tbl_table , "data"), 
               "Column\\(s) 'col3,I' provided in 'input.columns' argument does not exist in object specified in 'data' argument")
  
  
  # Positive case
  expect_true(.validateTblHasArgumentColumns("i", "input.columns", tbl_table , "data"))
  expect_true(.validateTblHasArgumentColumns(c("i","j"), "input.columns", tbl_table , "data"))
  expect_true(.validateTblHasArgumentColumns(c("COL4","Col3"), "input.columns", tbl_table , "data"))
  
  td_remove_context()
})

test_that("Tests for .isDefaultOrNot function to check default value for partition.column args", {
  # FALSE tests indicate it is the default value and .validateTblHasArgumentColumns will not be called.
  expect_false(.isDefaultOrNot(c("ANY"), "ANY"))
  expect_false(.isDefaultOrNot("ANY", "ANY"))
  expect_false(.isDefaultOrNot(c("1"), "1"))
  expect_false(.isDefaultOrNot("1", "1"))
  
  # TRUE indicates argument will end up being quoted and .validateTblHasArgumentColumns will also be called.
  expect_true(.isDefaultOrNot(c("col", "ANY"), "ANY"))
  expect_true(.isDefaultOrNot(c("ANY", "1"), "1"))
  
  # Incorrect default value other than 1 or ANY passed to function
  expect_error(.isDefaultOrNot("col", "xyz"), "Permitted values for argDefaultValue are '1' and 'ANY'")
})

test_that("Tests for .validateArgValueLength function to check for number of characters in arguments", {
  arg_name <- "hello"

  # Positive tests
  expect_true(.validateArgValueLength(argument = arg_name, arg.len = 6, "LT")) # Less than
  expect_true(.validateArgValueLength(argument = arg_name, arg.len = 5, "LE")) # Less than or equal to
  expect_true(.validateArgValueLength(argument = arg_name, arg.len = 6, "LE")) # Less than or equal to
  expect_true(.validateArgValueLength(argument = arg_name, arg.len = 5, "EQ")) # Equal to
  expect_true(.validateArgValueLength(argument = arg_name, arg.len = 4, "NE")) # Not equal to
  expect_true(.validateArgValueLength(argument = arg_name, arg.len = 6, "NE")) # Not equal to
  expect_true(.validateArgValueLength(argument = arg_name, arg.len = 4, "GT")) # Greater than
  expect_true(.validateArgValueLength(argument = arg_name, arg.len = 5, "GE")) # Greater than or equal to
  expect_true(.validateArgValueLength(argument = arg_name, arg.len = 4, "GE")) # Greater than or equal to

  expect_true(.validateArgValueLength(argument = NULL, arg.len = 4, "GE")) # Passing NULL value to argument.

  # Negative tests
  expect_error(.validateArgValueLength(argument = arg_name, arg.len = 5, "LT"),
                "Length of argument 'arg_name' must be less than 5 character\\(s).") # Less than
  expect_error(.validateArgValueLength(argument = arg_name, arg.len = 4, "LT"),
                "Length of argument 'arg_name' must be less than 4 character\\(s).") # Less than
  expect_error(.validateArgValueLength(argument = arg_name, arg.len = 4, "LE"),
                "Length of argument 'arg_name' must be less than or equal to 4 character\\(s).") # Less than or equal to
  expect_error(.validateArgValueLength(argument = arg_name, arg.len = 4, "EQ"),
                "Length of argument 'arg_name' must be equal to 4 character\\(s).") # Equal to
  expect_error(.validateArgValueLength(argument = arg_name, arg.len = 6, "EQ"),
                "Length of argument 'arg_name' must be equal to 6 character\\(s).") # Equal to
  expect_error(.validateArgValueLength(argument = arg_name, arg.len = 5, "NE"),
                "Length of argument 'arg_name' must not be equal to 5 character\\(s).") # Not equal to
  expect_error(.validateArgValueLength(argument = arg_name, arg.len = 5, "GT"),
                "Length of argument 'arg_name' must be greater than 5 character\\(s).") # Greater than
  expect_error(.validateArgValueLength(argument = arg_name, arg.len = 6, "GT"),
                "Length of argument 'arg_name' must be greater than 6 character\\(s).") # Greater than
  expect_error(.validateArgValueLength(argument = arg_name, arg.len = 6, "GE"),
                "Length of argument 'arg_name' must be greater than or equal to 6 character\\(s).") # Greater than or equal to

  expect_error(.validateArgValueLength(argument = arg_name, arg.len = 6, "INVALID_OP"),
                "Argument 'op' should be one of: \n\"LT\",\"LE\",\"GT\",\"GE\",\"EQ\",\"NE\"") # Passing Invalid operation

})
