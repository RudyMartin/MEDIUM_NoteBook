#### TEST SETUP ####
# Declare some variables to be used in the testing.
sqlmrFuncName = "kmeans"

# Create rest of the function arguments vector for the mapReduceObject
funcOtherArgs <- c(InitialSeeds = "'2249_51_408_8_14','2165_51_398_7_14.6','2182_51_404_7_14.6','2204_55_372_7.19_14.6'")
funcOtherArgs <- c(funcOtherArgs, NumClusters = "'9'")
funcOtherArgs <- c(funcOtherArgs, Threshold = "'0.0395'")
funcOtherArgs <- c(funcOtherArgs, MaxIterNum = "'10'")
funcOtherArgs <- c(funcOtherArgs, UnpackColumns = "'False'")
funcOtherArgs <- c(funcOtherArgs, Seed = "'10'")

sqlmrOutputTabArgs <- c(OutputTable = "kmeanssample_centroid1", ClusteredOutput = "kmeanssample_clusteredoutput")

# Input table matrix
inputMatrix <- list()
inputMatrix  <-  rbind(inputMatrix,
                       list("computers_train1", "TABLE", "NONE", NA_character_, NA_character_, "InputTable") )
inputMatrix  <-  rbind(inputMatrix,
                       list("kmeanssample_centroid", "TABLE", "NONE", NA_character_, NA_character_, "CentroidsTable") )
colnames(inputMatrix) <- c("tableRef", "tableRefType", "distribution",
                         "column", "column_order","alias")

#### .TeradataSqlmrQueryGenerator object instantiation tests ####
context(".TeradataSqlmrQueryGenerator object instantiation tests")

test_that(".TeradataSqlmrQueryGenerator object instantiation when arguments are missing/wrong values are passed:", {
  # Missing SQL-MR function name.
  expect_error(.TeradataSqlmrQueryGenerator$new(
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = sqlmrOutputTabArgs), "sqlmr function name must be provided"
  )

  # 'inputTableRefMatrix' Not provided.
  expect_error(.TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = sqlmrFuncName,
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = sqlmrOutputTabArgs), 
    "Input matrix is required for multi-input function"
  )
  
  # Expected columns are not provided in 'inputTableRefMatrix'
  inputMatrixNoCols <- list()
  inputMatrixNoCols  <-  rbind(inputMatrixNoCols,
                               list("computers_train1", "NONE", NA_character_, NA_character_, "InputTable") )
  expect_error(.TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = sqlmrFuncName,
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = sqlmrOutputTabArgs,
    inputTableRefMatrix = inputMatrixNoCols), 
    "Input matrix must have all the columns tableRef, tableRefType, distribution, column, column_order, alias"
  )
  
})

test_that(".TeradataSqlmrQueryGenerator object instantiation  when different values are passed to sqlmrOutputTabArgs:", {
  # Check behavior when c() i.e. empty vector is passed to sqlmrOutputTabArgs
  funcArgs <- c()
  expect_error(.TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = sqlmrFuncName,
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcArgs,
    inputTableRefMatrix = inputMatrix), 
    "sqlmrOutputTabArgs cannot be null. If empty please pass NA. It must always be a vector"
  )
  
  # Make sure that the arguments vector has names corresponding
  # to each of the output table arguments.
  funcArgs <- c("Threshold", 'Seed', "UnpackColumns")
  expect_error(.TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = sqlmrFuncName,
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcArgs), 
    "Name not supplied for following SQL-MR function output arguments:\nThreshold\nSeed\nUnpackColumns"
  )
  
  funcArgs <- c(Threshold = "Threshold", 'Seed', "UnpackColumns")
  expect_error(.TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = sqlmrFuncName,
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = funcArgs), 
    "Name not supplied for following SQL-MR function output arguments:\nSeed\nUnpackColumns"
  )
})

test_that(".TeradataSqlmrQueryGenerator object instantiation  when different values are passed to funcArgs:", {
  
  # Check behavior when c() i.e. empty vector is passed to sqlmrFuncArgs
  funcArgs <- c()
  expect_error(.TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = sqlmrFuncName,
    sqlmrFuncArgs = funcArgs,
    sqlmrOutputTabArgs = sqlmrOutputTabArgs,
    inputTableRefMatrix = inputMatrix), 
    "sqlmrFuncArgs cannot be null. If empty please pass NA. It must always be a vector"
  )
  
  # Make sure that the arguments vector has names corresponding
  # to each of the arguments.
  funcArgs <- c("Threshold", 'Seed', "UnpackColumns")
  expect_error(.TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = sqlmrFuncName,
    sqlmrFuncArgs = funcArgs,
    sqlmrOutputTabArgs = sqlmrOutputTabArgs), 
    "Name not supplied for following SQL-MR function arguments:\nThreshold\nSeed\nUnpackColumns"
  )
  
  funcArgs <- c(Threshold = "Threshold", 'Seed', "UnpackColumns")
  expect_error(.TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = sqlmrFuncName,
    sqlmrFuncArgs = funcArgs,
    sqlmrOutputTabArgs = sqlmrOutputTabArgs), 
    "Name not supplied for following SQL-MR function arguments:\nSeed\nUnpackColumns"
  )
})

test_that(".TeradataSqlmrQueryGenerator object instantiation  when sqlEngine argument is used:", {
  #Invalid engine value for the given analytic function Kmeans.
  expect_error(.TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = sqlmrFuncName,
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = sqlmrOutputTabArgs,
    inputTableRefMatrix = inputMatrix,
    sqlmrEngine = .getEngineName("ENGINE_SQL")), 
    "Alias not found for function 'kmeans' for engine 'sql'"
  )

  # Engine argument is empty.
  funcArgs <- c("Threshold", 'Seed', "UnpackColumns")
  expect_error(.TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = sqlmrFuncName,
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = sqlmrOutputTabArgs,
    inputTableRefMatrix = inputMatrix,
    sqlmrEngine = ""), 
    "Engine  specified is not valid"
  )
  
  # Case for ml engine analytic function.
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = sqlmrFuncName,
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = sqlmrOutputTabArgs,
    inputTableRefMatrix = inputMatrix,
    sqlmrEngine = .getEngineName("ENGINE_ML"))
  
  expect_identical(mapReduceObject$genSqlmrFuncArgSql(), 
                   "\n\tInitialSeeds('2249_51_408_8_14','2165_51_398_7_14.6','2182_51_404_7_14.6','2204_55_372_7.19_14.6') \n\tNumClusters('9') \n\t\"Threshold\"('0.0395') \n\tMaxIterNum('10') \n\tUnpackColumns('False') \n\tSeed('10')")
  
  # Case for native analytic function using sqlengine as the engine.
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "npath",
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = sqlmrOutputTabArgs,
    inputTableRefMatrix = inputMatrix,
    sqlmrEngine = .getEngineName("ENGINE_SQL"))
  
  expectedStmt <- paste0("SELECT * FROM NPath ( \n\tON computers_train1 as InputTable   \n\tON kmeanssample_centroid as CentroidsTable   \n\tOUT TABLE OutputTable(kmeanssample_centroid1) \n\tOUT TABLE ClusteredOutput(kmeanssample_clusteredoutput) \n\tUSING \n\tInitialSeeds('2249_51_408_8_14','2165_51_398_7_14.6','2182_51_404_7_14.6','2204_55_372_7.19_14.6') \n\tNumClusters('9') \n\t\"Threshold\"('0.0395') \n\tMaxIterNum('10') \n\tUnpackColumns('False') \n\tSeed('10') \n)  as sqlmr")
  expect_match(mapReduceObject$genSqlmrSelectStmtSql(), expectedStmt, fixed = TRUE)
  
  # change position of the sqlmrEngine argument.
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = "npath",
    sqlmrEngine = .getEngineName("ENGINE_SQL"),
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = sqlmrOutputTabArgs,
    inputTableRefMatrix = inputMatrix
    )
  expect_match(mapReduceObject$genSqlmrSelectStmtSql(), expectedStmt, fixed = TRUE)
})

#### .TeradataSqlmrQueryGenerator Class methods tests ####
context(".TeradataSqlmrQueryGenerator Class methods tests")

# Let's test some internal functions.
mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
  sqlmrFuncName = sqlmrFuncName,
  sqlmrFuncArgs = funcOtherArgs,
  sqlmrOutputTabArgs = sqlmrOutputTabArgs,
  inputTableRefMatrix = inputMatrix)

test_that("genSqlmrFuncArgSql Class methods returns correct results", {
  
  expect_identical(mapReduceObject$genSqlmrFuncArgSql(), 
                   "\n\tInitialSeeds('2249_51_408_8_14','2165_51_398_7_14.6','2182_51_404_7_14.6','2204_55_372_7.19_14.6') \n\tNumClusters('9') \n\t\"Threshold\"('0.0395') \n\tMaxIterNum('10') \n\tUnpackColumns('False') \n\tSeed('10')")
  
  funcArgs <- NA
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = sqlmrFuncName,
    sqlmrFuncArgs = funcArgs,
    sqlmrOutputTabArgs = funcArgs,
    inputTableRefMatrix = inputMatrix)
  expect_identical(mapReduceObject$genSqlmrFuncArgSql(), "")
})

test_that("'genSqlmrInputFuncArgSql' Class method returns correct results", {
  # Case for 'TABLE' reference type and alias
  expect_identical(mapReduceObject$genSqlmrInputFuncArgSql("TempTable", "TABLE", "inputtable"), "\n\tON TempTable as inputtable")
  # Case for 'QUERY' reference type and alias
  expect_identical(mapReduceObject$genSqlmrInputFuncArgSql("SELECT * FROM TempTable", "QUERY", "inputtable"), "\n\tON ( SELECT * FROM TempTable ) as inputtable")
  # Case for 'Query' reference type and no alias
  expect_identical(mapReduceObject$genSqlmrInputFuncArgSql("SELECT * FROM TempTable", "QUERY"), "\n\tON ( SELECT * FROM TempTable )")
  # Case for invalid reference type
  expect_error(mapReduceObject$genSqlmrInputFuncArgSql("TempTable", "InvalidRef"), "invalid tableRefType")
  # Case for 'TABLE' reference type and alias as NA
  expect_identical(mapReduceObject$genSqlmrInputFuncArgSql("TempTable", "TABLE", NA), "\n\tON TempTable")
  # Case for 'TABLE' reference type and alias as NULL
  expect_identical(mapReduceObject$genSqlmrInputFuncArgSql("TempTable", "TABLE", NULL), "\n\tON TempTable")
  # Case for 'TABLE' reference type and alias as empty string
  expect_identical(mapReduceObject$genSqlmrInputFuncArgSql("TempTable", "TABLE", ""), "\n\tON TempTable")
})

test_that("'genSqlmrOutputFuncArgSql' Class method returns correct results", {
  
  expect_identical(mapReduceObject$genSqlmrOutputFuncArgSql(), "\n\tOUT TABLE OutputTable(kmeanssample_centroid1) \n\tOUT TABLE ClusteredOutput(kmeanssample_clusteredoutput)")
  
  funcArgs <- NA
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = sqlmrFuncName,
    sqlmrFuncArgs = funcArgs,
    sqlmrOutputTabArgs = funcArgs,
    inputTableRefMatrix = inputMatrix)
  expect_identical(mapReduceObject$genSqlmrOutputFuncArgSql(), "")
})

test_that("'genSqlmrOutputFuncArgSql' Class method returns correct results", {
  expectedStmt <- paste0("SELECT * FROM KMeans ( \n\tON computers_train1 as InputTable   \n\tON kmeanssample_centroid as CentroidsTable   \n\tOUT TABLE OutputTable(kmeanssample_centroid1) \n\tOUT TABLE ClusteredOutput(kmeanssample_clusteredoutput) \n\tUSING \n\tInitialSeeds('2249_51_408_8_14','2165_51_398_7_14.6','2182_51_404_7_14.6','2204_55_372_7.19_14.6') \n\tNumClusters('9') \n\t\"Threshold\"('0.0395') \n\tMaxIterNum('10') \n\tUnpackColumns('False') \n\tSeed('10') \n)  as sqlmr")
  expect_match(mapReduceObject$genSqlmrSelectStmtSql(), expectedStmt, fixed = TRUE)
  
  # Input table matrix
  inputMatrix <- list()
  inputMatrix  <-  rbind(inputMatrix, list("computers_train1", "TABLE", "FACT", "partition.column", "order.column", "InputTable"))
  colnames(inputMatrix) <- c("tableRef", "tableRefType", "distribution",
                             "column", "column_order","alias")
  
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = sqlmrFuncName,
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = sqlmrOutputTabArgs,
    inputTableRefMatrix = inputMatrix)
  expect_match(mapReduceObject$genSqlmrSelectStmtSql(), 
               "SELECT * FROM KMeans ( \n\tON computers_train1 as InputTable \n\tPARTITION BY partition.column \n\tORDER BY order.column \n\tOUT TABLE OutputTable(kmeanssample_centroid1) \n\tOUT TABLE ClusteredOutput(kmeanssample_clusteredoutput) \n\tUSING \n\tInitialSeeds('2249_51_408_8_14','2165_51_398_7_14.6','2182_51_404_7_14.6','2204_55_372_7.19_14.6') \n\tNumClusters('9') \n\t\"Threshold\"('0.0395') \n\tMaxIterNum('10') \n\tUnpackColumns('False') \n\tSeed('10') \n)  as sqlmr",
               fixed = TRUE)
  
  
  # Input table matrix
  inputMatrix <- list()
  inputMatrix  <-  rbind(inputMatrix, list("computers_train1", "TABLE", "DIMENSION", NULL, "order.column", "InputTable"))
  colnames(inputMatrix) <- c("tableRef", "tableRefType", "distribution",
                             "column", "column_order","alias")
  
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = sqlmrFuncName,
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = sqlmrOutputTabArgs,
    inputTableRefMatrix = inputMatrix)
  expect_match(mapReduceObject$genSqlmrSelectStmtSql(), 
               "SELECT * FROM KMeans ( \n\tON computers_train1 as InputTable \n\tDIMENSION \n\tORDER BY order.column \n\tOUT TABLE OutputTable(kmeanssample_centroid1) \n\tOUT TABLE ClusteredOutput(kmeanssample_clusteredoutput) \n\tUSING \n\tInitialSeeds('2249_51_408_8_14','2165_51_398_7_14.6','2182_51_404_7_14.6','2204_55_372_7.19_14.6') \n\tNumClusters('9') \n\t\"Threshold\"('0.0395') \n\tMaxIterNum('10') \n\tUnpackColumns('False') \n\tSeed('10') \n)  as sqlmr",
               fixed = TRUE)
  
  # Input table matrix
  inputMatrix <- list()
  inputMatrix  <-  rbind(inputMatrix, list("computers_train1", "TABLE", "DIMENSION", NULL, NA, "InputTable"))
  colnames(inputMatrix) <- c("tableRef", "tableRefType", "distribution",
                             "column", "column_order","alias")
  
  mapReduceObject <- .TeradataSqlmrQueryGenerator$new(
    sqlmrFuncName = sqlmrFuncName,
    sqlmrFuncArgs = funcOtherArgs,
    sqlmrOutputTabArgs = sqlmrOutputTabArgs,
    inputTableRefMatrix = inputMatrix)
  expect_match(mapReduceObject$genSqlmrSelectStmtSql(), 
               "SELECT * FROM KMeans ( \n\tON computers_train1 as InputTable \n\tDIMENSION  \n\tOUT TABLE OutputTable(kmeanssample_centroid1) \n\tOUT TABLE ClusteredOutput(kmeanssample_clusteredoutput) \n\tUSING \n\tInitialSeeds('2249_51_408_8_14','2165_51_398_7_14.6','2182_51_404_7_14.6','2204_55_372_7.19_14.6') \n\tNumClusters('9') \n\t\"Threshold\"('0.0395') \n\tMaxIterNum('10') \n\tUnpackColumns('False') \n\tSeed('10') \n)  as sqlmr",
               fixed = TRUE)
  
  
})