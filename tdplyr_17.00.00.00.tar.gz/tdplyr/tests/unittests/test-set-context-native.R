context ("Unit tests for Set Contexts using native driver")

userName <-  toupper(.ta.getUserName())
tempDatabaseName <- toupper(paste0("RTEST_TMP_DATABASE_",userName))

cleanup <- function() {
  # Drop database using the user 'dbc'
  dcon <- suppressWarnings(td_create_context(host = globalHost, uid = "dbc", pwd = "dbc", dType = "native"))
  DBI::dbExecute(dcon, paste0("DELETE DATABASE ",tempDatabaseName,";"))
  DBI::dbExecute(dcon, paste0("DROP DATABASE ",tempDatabaseName,";"))
  td_remove_context()
}

testthat::setup({
  # Create temporary database using the user 'dbc'.
  dcon <- suppressWarnings(td_create_context(host = globalHost, uid = "dbc", pwd = "dbc", dType = "native"))

  try(DBI::dbExecute(dcon, paste0("DELETE DATABASE ",tempDatabaseName,";")), silent = TRUE)
  try(DBI::dbExecute(dcon, paste0("DROP DATABASE ",tempDatabaseName,";")), silent = TRUE)

  DBI::dbExecute(dcon, paste0("CREATE DATABASE ",tempDatabaseName," AS PERM = 1e+06;" ))
  DBI::dbExecute(dcon, paste0("GRANT ALL ON ",tempDatabaseName," TO ", globalUID, ";" ))

  td_remove_context()
})

# This function verifies the correctness of the class, class hierarchy, validity and user of the
# connection object. Raise exception if the values are not correct.
# Args:
#   con - Specifies the connection object (either of class Teradata (of tdplyr) or
#         TerdataConnection (of teradatasql driver).
#   is.driver.connection - Set to TRUE when the connection object is of TeradataConnection class.
#                          Otherwise set to FALSE.
verifyConnection <- function(con, is.driver.connection = FALSE) {
  if (isTRUE(is.driver.connection)) {
    con_class <- "TeradataConnection"
    expected_hierarchy <- c("DBIConnection", "DBIObject")
  } else {
    con_class <- "Teradata"
    expected_hierarchy <- c("TeradataConnection", "DBIConnection", "DBIObject")
  }
  expect_true(DBI::dbIsValid(con))
  expect_equal(as.character(class(con)), con_class)
  # check the entire class hierarchy
  hierarchy <- methods::getAllSuperClasses(methods::getClass(class(con)))
  expect_equal(length(hierarchy), length(expected_hierarchy))
  expect_true(all.equal(hierarchy, expected_hierarchy))
  # check if the connection worked witha query
  expect_equal(nrow(DBI::dbGetQuery(con, "select user")), 1)
}

# This function verifies whether the connection object is removed or not. Raise Exception if the
# connection is not removed.
# Args:
#   con - Specifies the connection object (either of class Teradata (of tdplyr) or
#         TerdataConnection (of teradatasql driver).
verifyRemoved <- function(con) {
  expect_false(DBI::dbIsValid(con))
  # Check if context is removed
  expect_true(is.null(.taConnection(silent = TRUE)))
  expect_true(is.null(.ta.getTempDatabase(silent = TRUE)))  
}

# This function returns the default database from the connection object.
# Args:
#   con - Specifies the connection object (either of class Teradata (of tdplyr) or
#         TerdataConnection (of teradatasql driver).
getDefaultDatabase <- function(con) {
  return(.get_dbname(con))
}

# This function verfies the context related parameters like connection, default and temporary
# databases.
# Args:
#   con - Specifies the connection object (either of class Teradata (of tdplyr) or
#         TerdataConnection (of teradatasql driver).
#   defaultDB - Specifies the database name against which the context default database is to
#               be compared.
#   tempDB - Specifies the database name against which the context temporary database is to
#            be compared.
verifyContext <- function(con, defaultDB, tempDB) {
  expect_true(identical(con, .taConnection()))
  expect_equal(.ta.getDefaultDatabase(), defaultDB)
  expect_equal(.ta.getTempDatabase(), tempDB)
  context <- td_get_context()
  expect_true(identical(con, context$connection))
  expect_equal(.ta.getDefaultDatabase(), context$default.database)
  expect_equal(.ta.getTempDatabase(), context$temp.database)
}

test_that("set context with dbConnect (NativeDriver) connection and disconnect using
td_remove_context", {
  ## dbConnect with NativeDriver()
  con <- DBI::dbConnect(tdplyr::NativeDriver(), host = globalHost, uid = globalUID, pwd = globalPWD)

  verifyConnection(con)
  # Context should exist - dbConnect(NativeDriver(), ...) will create context.
  expect_true(.ta.contextExists())
  # Set context with a temp database and verify
  expect_silent(td_set_context(con, tempDatabaseName))

  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, tempDatabaseName)

  td_remove_context()
  verifyRemoved(con)
})

test_that("set context with dbConnect (TeradataDriver) connection and disconnect using
td_remove_context", {
  ## dbConnect with TeradataDriver()
  jsonStr <- paste0('{"host":"', globalHost, '","user":"', globalUID, '", "password":"', globalPWD,
                 '"}')
  con <- DBI::dbConnect(teradatasql::TeradataDriver(), jsonStr)

  verifyConnection(con, is.driver.connection = TRUE)
  # Context should not exist.
  expect_false(.ta.contextExists())
  # Set context with a temp database and verify.
  # No overwrite warning as connection parameters are same.
  expect_silent(td_set_context(con, tempDatabaseName))

  # td_set_context does not return the connection unlike td_create_context.
  con <- td_get_context()$connection

  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, tempDatabaseName)

  td_remove_context()
  verifyRemoved(con)
})

test_that("set context again with same connection", {
  ## dbConnect with TeradataDriver()
  jsonStr <- paste0('{"host":"', globalHost, '","user":"', globalUID, '", "password":"', globalPWD,
                 '"}')
  con <- DBI::dbConnect(teradatasql::TeradataDriver(), jsonStr)

  verifyConnection(con, is.driver.connection = TRUE)
  # Context should not exist
  expect_false(.ta.contextExists())
  # Set context with a temp database and verify
  expect_silent(td_set_context(con, tempDatabaseName))
  # td_set_context() will not return the new connection.
  con1 <- td_get_context()$connection

  defaultDB <- getDefaultDatabase(con1)
  verifyContext(con1, defaultDB, tempDatabaseName)

  # Set context again with same connection and different temp database should not disconnect and
  # therefore no overwriting warning.
  expect_silent(td_set_context(con, defaultDB))
  # td_set_context() will not return the new connection.
  con1 <- td_get_context()$connection
  verifyConnection(con1)
  verifyContext(con1, defaultDB, defaultDB)

  # Set context again with same connection and same temp db
  expect_silent(td_set_context(con, defaultDB))
  # td_set_context() will not return the new connection.
  con1 <- td_get_context()$connection
  verifyConnection(con1)
  verifyContext(con1, defaultDB, defaultDB)

  # Calling multiple times makes no difference
  expect_silent(td_set_context(con, defaultDB))
  # td_set_context() will not return the new connection.
  con1 <- td_get_context()$connection
  verifyConnection(con1)
  verifyContext(con1, defaultDB, defaultDB)

  # Create another connection object with same info.
  ## dbConnect with TeradataDriver()
  con2 <- DBI::dbConnect(teradatasql::TeradataDriver(), jsonStr)
  expect_silent(td_set_context(con2, defaultDB))
  # td_set_context() will not return the new connection.
  con1 <- td_get_context()$connection
  verifyConnection(con1)
  verifyConnection(con, is.driver.connection = TRUE)
  verifyContext(con1, defaultDB, defaultDB)

  # Another way of using TeradataDriver() - passsing arguments instead of JSON string.
  # Using 'database' argument of TeradataDriver() to use another database to connect to.
  con3 <- DBI::dbConnect(teradatasql::TeradataDriver(), host = globalHost, user = globalUID,
                         password = globalPWD, database = tempDatabaseName)

  expect_equal(.get_dbname(con3), tempDatabaseName)

  # There is change in schema name; hence there is garbage collection and overwriting warning.
  # Using warning code instead of full warning text.
  expect_warning(td_set_context(con3, tempDatabaseName), "TDR_W1002")
  # td_set_context() will not return the new connection.
  con1 <- td_get_context()$connection

  verifyConnection(con1)
  # Context and connection overwritten.
  expect_false(DBI::dbIsValid(con2))
  verifyConnection(con, is.driver.connection = TRUE)
  verifyContext(con1, tempDatabaseName, tempDatabaseName)

  # Use of td_set_context with new username and database names.
  # Expects an overwriting warning as dbConnect(NativeDriver(), ...) initializes context.
  expect_warning(con3 <- DBI::dbConnect(tdplyr::NativeDriver(), host = globalHost, uid = "dbc", pwd = "dbc"),
                 "Overwriting current context. Any non-persisted objects created using analytic functions will be removed")
  td_set_context(con3, tempDatabaseName)

  verifyConnection(con3)
  # Context and connection overwritten.
  expect_false(DBI::dbIsValid(con2))
  verifyConnection(con, is.driver.connection = TRUE)
  verifyContext(con3, "DBC", tempDatabaseName)

  con3 <- DBI::dbConnect(teradatasql::TeradataDriver(), host = globalHost, user = globalUID,
                       password = globalPWD, database = "dbc")

  verifyConnection(con3, is.driver.connection = TRUE)

  # There is change in schema name; hence there is garbage collection and overwriting warning.
  # Using warning code instead of full warning text.
  expect_warning(td_set_context(con3, tempDatabaseName), "TDR_W1002")

  con3 <- td_get_context()$connection

  verifyConnection(con3)
  # Context and connection overwritten.
  expect_false(DBI::dbIsValid(con2))
  verifyConnection(con, is.driver.connection = TRUE)

  # Remove the connection and ensure the latest connection and context set using td_set_context
  # are removed.
  td_remove_context()
  verifyRemoved(con3)

  # The other connection must be valid and should be able to disconnect.
  expect_silent(DBI::dbDisconnect(con))
})

test_that("set context after using create context", {
  ### With the same connection parameters
  con <- td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD)

  verifyConnection(con)
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)

  # Use set context after create context.
  ## dbConnect with TeradataDriver()
  jsonStr <- paste0('{"host":"', globalHost, '","user":"', globalUID, '", "password":"', globalPWD,
                 '"}')
  con1 <- DBI::dbConnect(teradatasql::TeradataDriver(), jsonStr)

  verifyConnection(con)
  verifyConnection(con1, is.driver.connection = TRUE)
  # Verify prev context
  verifyContext(con, defaultDB, defaultDB)
  defaultDB <- getDefaultDatabase(con1)

  # No change in connection parameters; hence, no overwriting.
  td_set_context(con1, defaultDB)
  con1 <- td_get_context()$connection

  # Check to ensure previous connection is not disconnected.
  expect_true(DBI::dbIsValid(con))
  verifyConnection(con1)

  verifyContext(con1, defaultDB, defaultDB)

  td_remove_context()
  dbDisconnect(con)

  verifyRemoved(con1)
  verifyRemoved(con)

  ### With the different connection parameters
  con <- td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD)

  verifyConnection(con)
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)

  # Use set context after create context.
  ## dbConnect with TeradataDriver()
  jsonStr <- paste0('{"host":"', globalHost, '","user":"dbc", "password":"dbc"}')
  con1 <- DBI::dbConnect(teradatasql::TeradataDriver(), jsonStr)

  verifyConnection(con)
  verifyConnection(con1, is.driver.connection = TRUE)
  # Verify prev context
  verifyContext(con, defaultDB, defaultDB)
  defaultDB <- getDefaultDatabase(con1)

  # Change in connection parameters (Using dbc now); overwriting warning is produced.
  expect_warning(td_set_context(con1, defaultDB), "TDR_W1002")
  con1 <- td_get_context()$connection

  # Check to ensure previous connection is disconnected.
  expect_false(DBI::dbIsValid(con))
  verifyConnection(con1)

  verifyContext(con1, defaultDB, defaultDB)

  td_remove_context()
  verifyRemoved(con1)
  verifyRemoved(con)
})

test_that("set context after using create context but identical objects", {
  # Use set context with same con object does nothing
  con <- td_create_context(dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD)

  verifyConnection(con)
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)
  # Switch context without disconnecting
  expect_silent(td_set_context(con, tempDatabaseName))
  # Connection is still active
  verifyConnection(con)
  verifyContext(con, defaultDB, tempDatabaseName)

  td_remove_context()
  verifyRemoved(con)
})

test_that("Negative cases: set context with invalid inputs", {

  expect_error(td_set_context("INVALID_CON"), "Invalid type of arguments passed to following: \n\tArgument 'con' must be of 'Teradata or TeradataConnection' datatype. Multiple values are not supported.")
  # same with error code
  expect_error(td_set_context("INVALID_CON"), "TDR_E3005")
  expect_error(td_set_context(NULL), "Following required arguments are missing: con")
  expect_error(td_set_context(NA), "Invalid type of arguments passed to following: \n\tArgument 'con' must be of 'Teradata or TeradataConnection' datatype. Multiple values are not supported.")

  # Create connection with dbConnect and disconnect and then set context.
  jsonStr <- paste0('{"host":"', globalHost, '","user":"', globalUID, '", "password":"', globalPWD,
                    '"}')
  con <- DBI::dbConnect(teradatasql::TeradataDriver(), jsonStr)

  DBI::dbDisconnect(con)

  # Set context again with incorrect temp.database. It will ignore and set the temp database in
  # context to the incorrect database. The error is thrown only when that database is accessed.
  jsonStr <- paste0('{"host":"', globalHost, '","user":"', globalUID, '", "password":"', globalPWD,
                    '"}')
  con <- DBI::dbConnect(teradatasql::TeradataDriver(), jsonStr)

  verifyConnection(con, is.driver.connection = TRUE)

  # Context should not exist.
  expect_false(.ta.contextExists())
  defaultDB <- getDefaultDatabase(con)

  # Set context with a incorrect temp database must ignore it.
  expect_silent(td_set_context(con, "INVALID_DB_X"))

  # The object 'con' is still the connection object of class TeradataDriver() as td_set_context()
  # does not return the connection after initializing context.
  expect_false(identical(.taConnection(), con))
  con <- td_get_context()$connection

  verifyContext(con, defaultDB, "INVALID_DB_X")

  td_remove_context()
  verifyRemoved(con)

  # Set context again with NULL temp.database. It will set the default database to temp database.
  con <- DBI::dbConnect(tdplyr::NativeDriver(), host = globalHost, uid = globalUID, pwd = globalPWD)

  verifyConnection(con)
  # Context should exist because the driver object is tdplyr::NativeDriver().
  expect_true(.ta.contextExists())
  defaultDB <- getDefaultDatabase(con)

  expect_silent(td_set_context(con, NULL))

  # Verifying whether default database is set to both default and temp databases.
  verifyContext(con, defaultDB, defaultDB)
  td_remove_context()
  verifyRemoved(con)
})

testthat::teardown({
  cleanup()
})