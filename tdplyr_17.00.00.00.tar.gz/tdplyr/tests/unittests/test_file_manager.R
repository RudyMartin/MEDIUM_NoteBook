context("Unit tests for internal function in taFileManager.R")

test_that("Test install, replace operations when td.debug.enable option set to FALSE", {
  # Setting the option "td.debug.enable" to FALSE.
  options("td.debug.enable" = FALSE)
  
  ## Install operation
  func_out <- .generate_stored_proc_for_file_mgmt("install", "file_identifier", 
                                                   "filename.R", 
                                                   "path/to/file/filename.R", FALSE)
  # Only one output, which is returned by the function.
  expect_true(length(func_out) == 1)
  # Checking actual output returned by the function.
  expect_equal(func_out, "call SYSUIF.install_file('file_identifier', 'filename.R', 'path/to/file/filename.R')")
  
  ## Replace operation
  # Without setting the argument "force.operation".
  func_out <- .generate_stored_proc_for_file_mgmt("replace", "file_identifier", 
                                                  "filename.R", 
                                                  "path/to/file/filename.R", FALSE)
  # Only one output, which is returned by the function.
  expect_true(length(func_out) == 1)
  # Checking actual output returned by the function.
  expect_equal(func_out, "call SYSUIF.replace_file('file_identifier', 'filename.R', 'path/to/file/filename.R', 0)")
  
  # With setting the argument "force.operation".
  func_out <- .generate_stored_proc_for_file_mgmt("replace", "file_identifier", 
                                                  "filename.R", 
                                                  "path/to/file/filename.R", TRUE)
  # Only one output, which is returned by the function.
  expect_true(length(func_out) == 1)
  # Checking actual output returned by the function.
  expect_equal(func_out, "call SYSUIF.replace_file('file_identifier', 'filename.R', 'path/to/file/filename.R', 1)")
  
})

test_that("Test install, replace operations when td.debug.enable option set to TRUE", {
  # Setting the option "td.debug.enable" to TRUE.
  options("td.debug.enable" = TRUE)
  
  ## Install operation
  func_out <- capture.output(.generate_stored_proc_for_file_mgmt("install", "file_identifier", 
                                                                 "filename.R", 
                                                                 "path/to/file/filename.R", FALSE))
  opt_len <- length(func_out)
  
  # With this debug enable option, now traceback and precedure call query will be printed.
  expect_true(opt_len > 1)
  
  # The last line of the capture.output() is the actual value returned.
  expect_equal(func_out[[opt_len]], 
               "[1] \"call SYSUIF.install_file('file_identifier', 'filename.R', 'path/to/file/filename.R')\"")
  
  # The last but one line of the capture.output() is where the procedure call is printed due to
  # enabling of the option "td.debug.enable".
  expect_equal(func_out[[opt_len - 1]], 
               "[tdplyr - (TDR_P5002)] Procedure Call: call SYSUIF.install_file('file_identifier', 'filename.R', 'path/to/file/filename.R')")
  
  ### Replace operation
  ## Without setting the argument "force.operation".
  func_out <- capture.output(.generate_stored_proc_for_file_mgmt("replace", "file_identifier", 
                                                                 "filename.R", 
                                                                 "path/to/file/filename.R", FALSE))
  opt_len <- length(func_out)
  
  # With this debug enable option, now traceback and precedure call query will be printed.
  expect_true(opt_len > 1)
  
  # The last line of the capture.output() is the actual value returned.
  expect_equal(func_out[[opt_len]], 
               "[1] \"call SYSUIF.replace_file('file_identifier', 'filename.R', 'path/to/file/filename.R', 0)\"")
  
  # The last but one line of the capture.output() is where the procedure call is printed due to
  # enabling of the option "td.debug.enable".
  expect_equal(func_out[[opt_len - 1]], 
               "[tdplyr - (TDR_P5002)] Procedure Call: call SYSUIF.replace_file('file_identifier', 'filename.R', 'path/to/file/filename.R', 0)")
  
  ## With setting the argument "force.operation".
  func_out <- capture.output(.generate_stored_proc_for_file_mgmt("replace", "file_identifier", 
                                                                 "filename.R", 
                                                                 "path/to/file/filename.R", TRUE))
  opt_len <- length(func_out)
  
  # With this debug enable option, now traceback and precedure call query will be printed.
  expect_true(opt_len > 1)
  
  # The last line of the capture.output() is the actual value returned.
  expect_equal(func_out[[opt_len]], 
               "[1] \"call SYSUIF.replace_file('file_identifier', 'filename.R', 'path/to/file/filename.R', 1)\"")
  
  # The last but one line of the capture.output() is where the procedure call is printed due to
  # enabling of the option "td.debug.enable".
  expect_equal(func_out[[opt_len - 1]], 
               "[tdplyr - (TDR_P5002)] Procedure Call: call SYSUIF.replace_file('file_identifier', 'filename.R', 'path/to/file/filename.R', 1)")
  
  options("td.debug.enable" = FALSE)
})

