context("Unit tests for model management functionality")

library(dplyr)
library(dbplyr)
library(DBI)

model_table_name <- .ta.mm.getModelTableName()
model_objects_table_name <- .ta.mm.getModelOutputTableName()

cleanup <- function() {
  tryCatch({
    DBI::dbExecute(con, paste0("drop table ", model_objects_table_name))
    DBI::dbExecute(con, paste0("drop table ", model_table_name))
    DBI::dbExecute(con, "drop table milk_timeseries")
    DBI::dbExecute(con, "drop table bank_web_clicks2")
    DBI::dbExecute(con, "drop table scale_housing_test")
    DBI::dbExecute(con, "drop table scale_housing")
  }, error=function(e) { 
    # DO Nothing
  })
}


testthat::setup({
  if(globalDTYPE == "odbc"){
    con <<- suppressWarnings(td_create_context(dsn = dsnName))
  }
  else {
    con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD))
  }
  cleanup()
})

# Non-Driver Function
loadExampleData("scalemap_example", "scale_housing")
loadExampleData("scale_example", "scale_housing_test")

scale_housing <- tbl(con, "scale_housing")
scale_housing_test <- tbl(con, "scale_housing_test")

td_scale_map_out <- td_scale_map_mle(data = scale_housing,
                                     input.columns = colnames(scale_housing)[2:7],
                                     miss.value = "omit"
)

td_scale_out <- td_scale_mle(object = td_scale_map_out,
                             data = scale_housing_test,
                             method = c("midrange","mean","maxabs","range")
)

# Driver Function
loadExampleData("arima_example", "milk_timeseries")

milk_timeseries <- tbl(con, "milk_timeseries")

td_arima_out <- td_arima_mle(data = milk_timeseries,
                             timestamp.columns = c("period"),
                             value.column = "milkpound",
                             orders = "0,1,2",
                             seasonal.order.p = 0,
                             seasonal.order.d = 1,
                             seasonal.order.q = 1,
                             period = 12
)

# SQLE Function
loadExampleData("npath_example1", "bank_web_clicks2")

bank_web_clicks2 <- tbl(con, sql("SELECT customer_id, session_id, datestamp, page FROM bank_web_clicks2"))

npath_out <- td_npath_sqle(
  data1=bank_web_clicks2,
  data1.partition.column = c("customer_id", "session_id"),
  data1.order.column = "datestamp",
  mode = "nonoverlapping",
  pattern = "(DUP|A)*",
  symbols = c("true AS A",
              "page = LAG (page,1) AS DUP"),
  result = c("FIRST (customer_id OF any (A)) AS customer_id",
             "FIRST (session_id OF A) AS session_id",
             "FIRST (datestamp OF A) AS first_date",
             "LAST (datestamp OF ANY(A,DUP)) AS last_date",
             "ACCUMULATE (page OF A) AS page_path",
             "ACCUMULATE (page of DUP) AS dup_path")
)


test_that("General test suite for model management/persistence functionality", {
  
  expect_error(td_list_models(), "Models table does not exist. Please try saving a model first using td_save_model.")
  expect_error(td_delete_model(name = "dummy"), "Models table does not exist. Please try saving a model first using td_save_model.")
  expect_error(td_retrieve_model(name = "dummy"), "Models table does not exist. Please try saving a model first using td_save_model.")
  
  # Save a model without specifying the model
  expect_error(td_save_model(name = "dummy"), "Following required arguments are missing: model")
  
  # Specify an invalid data type for model to be saved
  m1 <- list(1:4)
  expect_error(td_save_model(m1, name = "dummy"), "Argument 'model' should be of td_analytics type")
  
  # Specify an empty string for 'name' argument while saving model
  expect_error(td_save_model(npath_out, name = ""), "Argument 'name' should not contain empty string.")
  
  # Specify invalid value/data type for argument 'name'
  expect_error(td_save_model(npath_out, name = 1), "Argument 'name' should be of character type")
  expect_error(td_save_model(npath_out, name = NA), "Argument 'name' should be of character type")
  
  # Specify invalid value for argument 'overwrite'.
  expect_error(td_save_model(npath_out, name = "npath_clicks", overwrite = 'abcd'), "Argument 'overwrite' should be of logical type")
  
  # Save npath model
  td_save_model(npath_out, name = "model_1")
  
  models <- td_list_models()
  expect_true(nrow(models %>% filter(model_name == "model_1")) == 1)
  expect_equal(nrow(models), 1)
  expect_equal(nrow(as.data.frame(tbl(con, model_table_name))), 1)
  expect_equal(nrow(as.data.frame(tbl(con, model_objects_table_name))), 8)
  
  # Save a new model with the same name. Should throw an error.
  expect_error(td_save_model(td_scale_map_out, name = "model_1"), "Model with the name 'model_1' already exists. Please use a different name.")
  
  # Overwrite the previously saved model.
  td_save_model(td_scale_map_out, name = "model_1", overwrite = TRUE)
  
  models <- td_list_models()
  expect_true(nrow(models %>% filter(model_name == "model_1")) == 1)
  expect_equal(nrow(models), 1)
  expect_equal(nrow(as.data.frame(tbl(con, model_table_name))), 1)
  expect_equal(nrow(as.data.frame(tbl(con, model_objects_table_name))), 4)
  
  # Save all the analytic function models
  td_save_model(td_arima_out, name = "model_2_arima_milkprice")
  td_save_model(td_scale_out, name = "model_3_scale_housing")
  td_save_model(npath_out, name = "model_4_npath_clicks", overwrite = TRUE)
  
  models <- td_list_models()
  expect_equal(nrow(models), 4)
  
  td_delete_model(name = "model_4_npath_clicks")
  models <- td_list_models()
  expect_equal(nrow(models), 3)
  
  models <- td_list_models(name = 'housing')
  expect_equal(nrow(models), 1)
  
  expect_error(td_list_models(name = 1), "Argument 'name' should be of character type")
  expect_error(td_list_models(function_name = TRUE), "Argument 'function_name' should be of character type")
  expect_error(td_list_models(name = NA), "Argument 'name' should be of character type")
  expect_error(td_list_models(function_name = NA), "Argument 'function_name' should be of character type")
  expect_error(td_list_models(name = "random"), "No models found with the given search criteria.")
  
  models <- td_list_models(function_name = 'scale')
  expect_equal(nrow(models), 2)
  
  models <- td_list_models(name = 'milk', function_name = 'arima')
  expect_equal(nrow(models), 1)
  
  expect_error(td_delete_model(), "Following required arguments are missing: name")
  expect_error(td_delete_model(name = ''), "Argument 'name' should not contain empty string.")
  expect_error(td_delete_model(name = 2.34), "Argument 'name' should be of character type")
  expect_error(td_delete_model(name = NA), "Argument 'name' should be of character type")
  
  expect_error(td_delete_model(name = 'xyz'), "Model 'xyz' does not exist.")
  
  td_delete_model(name = "model_2_arima_milkprice")
  # Should expect an error trying to list a deleted model
  expect_error(td_list_models('model_2_arima_milkprice'), "No models found with the given search criteria.")
  
  # Error cases for restoring model
  expect_error(td_retrieve_model(), "Following required arguments are missing: name")
  expect_error(td_retrieve_model(name = ''), "Argument 'name' should not contain empty string.")
  expect_error(td_retrieve_model(name = 2.34), "Argument 'name' should be of character type")
  expect_error(td_retrieve_model(name = NA), "Argument 'name' should be of character type")
  
  expect_error(td_retrieve_model(name = 'model_2_arima_milkprice'), "Model 'model_2_arima_milkprice' does not exist.")
  
  scalemap_housing_model <- td_retrieve_model(name = 'model_1')
  expect_true(inherits(scalemap_housing_model$result, "tbl_sql"))
  expect_true(inherits(scalemap_housing_model$attributes, "data.frame"))
  expect_equal(nrow(scalemap_housing_model$attributes), 3)
  
  # Build new model using a restored model
  scaled_housing_model <- td_scale_mle(object = scalemap_housing_model,
                                       data = scale_housing_test,
                                       method = c("midrange","mean","maxabs","range")
  )
  # Save the model
  td_save_model(scaled_housing_model, name = "scaled_housing_model", overwrite = TRUE)
  expect_equal(nrow(td_list_models(function_name = 'scale')), 3)
  
  for(name in td_list_models()$model_name){
    td_delete_model(name)
  }
  
  expect_error(td_list_models(), "No models saved by the user were found.")
})

test_that("Save same model twice and try restoring one of them after deleting other - driver fn", {
  # Need to regenerate ARIMA model as it was previously deleted and output tables would have been dropped.
  td_arima_out <- td_arima_mle(data = milk_timeseries,
                               timestamp.columns = c("period"),
                               value.column = "milkpound",
                               orders = "0,1,2",
                               seasonal.order.p = 0,
                               seasonal.order.d = 1,
                               seasonal.order.q = 1,
                               period = 12
  )
  # Save the same model twice with two unique names
  td_save_model(td_arima_out, "a1")
  td_save_model(td_arima_out, "a2")
  
  # Restore the first model
  expect_output(td_retrieve_model("a1"), "Successfully retrieved model 'a1'.")
  # Delete the second model
  td_delete_model("a2")
  # When you try restoring the first model again, should expect error for driver functions
  expect_error(td_retrieve_model("a1"))
})

test_that("Save model twice and try restoring one of them after deleting other - non driver fn", {
  # Non-driver function
  td_save_model(npath_out, "n1")
  td_save_model(npath_out, "n2")
  
  npath_model1 <- td_retrieve_model("n1")
  npath_model2 <- td_retrieve_model("n2")
  
  td_delete_model("n1")
  # One should not expect any error here for a non-driver function
  expect_output(td_retrieve_model("n2"), "Successfully retrieved model 'n2'.")
})

test_that("Unit tests for td_describe_model", {
  expect_error(td_describe_model(), "Following required arguments are missing: name")
  expect_error(td_describe_model(''), "Argument 'name' should not contain empty string.")
  expect_error(td_describe_model(1), "Argument 'name' should be of character type")
  expect_error(td_describe_model('dummy_model'), "Model 'dummy_model' does not exist.")
  
  expect_output(td_describe_model('n2'), "ENGINE_SQL td_npath_sqle")
  expect_output(td_describe_model('n2'), 'result \"ALICE\".r_')
})

testthat::teardown(
  {
    cleanup()
    td_remove_context()
  }
)