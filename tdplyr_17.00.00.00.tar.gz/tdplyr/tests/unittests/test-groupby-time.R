context("Unit tests for the functions used for group_by_time")

con <- NULL
testthat::setup({
  if(globalDTYPE == "odbc"){
    con <<- suppressWarnings(td_create_context(dsn = dsnName))
  } else {
    con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD))
  }
  
  tryCatch({
    DBI::dbExecute(con, "drop table t_pti_table_seq")
  }, error=function(e) { 
    # DO Nothing
  })
  
  tryCatch({
    DBI::dbExecute(con, "drop table t_pti_table_nonseq")
  }, error=function(e) { 
    # DO Nothing
  })
  
  #
  # PTI table - sequenced.
  #
  createQuery <- "CREATE TABLE t_pti_table_seq (
                      buoyid INTEGER, 
                      salinity INTEGER, 
                      temperature INTEGER ) 
                  PRIMARY TIME INDEX (TIMESTAMP(6), DATE '2012-01-01', HOURS(1), COLUMNS(buoyid), sequenced);"
  DBI::dbGetQuery(con, createQuery)
  
  #
  # PTI table - non_sequenced.
  #
  createQuery <- "CREATE TABLE t_pti_table_nonseq (
                      buoyid INTEGER, 
                      salinity INTEGER, 
                      temperature INTEGER ) 
                  PRIMARY TIME INDEX (TIMESTAMP(6), DATE '2012-01-01', HOURS(1), COLUMNS(buoyid), nonsequenced);"
  DBI::dbGetQuery(con, createQuery)
})

test_that("Test .validateGroupByTimeArguments", {
  
  tables <- c("t_pti_table_seq", "t_pti_table_nonseq")
  
  for (table in tables) {
    df <- tbl(con, table)
    
    #######################
    #   Negative Tests   ##
    #######################
    
    if (table == "t_pti_table_seq") {
      seq_col <- "TD_SEQNO"
    } else {
      seq_col <- "buoyid"
    }
    
    # Tests for timebucket.duration argument
    expect_error(.validateGroupByTimeArguments(df, timecode.column = "TD_TIMECODE"), 
                 "argument \"timebucket.duration\" is missing, with no default")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = 2), 
                 "Argument 'timebucket.duration' must be of 'character' datatype. Multiple values are not supported.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = c(TRUE, 2)), 
                 "Argument 'timebucket.duration' must be of 'character' datatype. Multiple values are not supported.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = ""), 
                 "Argument 'timebucket.duration' should not contain empty string.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "3cys"), 
                 "Argument \"timebucket.duration\" has an invalid value: 3cys. Please check documentation.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "CAL_YEARSS(3)"), 
                 "Argument \"timebucket.duration\" has an invalid value: CAL_YEARSS\\(3). Please check documentation.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "invalid_tbd"), 
                 "Argument \"timebucket.duration\" has an invalid value: invalid_tbd. Please check documentation.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2ROSECOND"), 
                 "Argument \"timebucket.duration\" has an invalid value: 2ROSECOND. Please check documentation.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "ROSECOND(3)"), 
                 "Argument \"timebucket.duration\" has an invalid value: ROSECOND\\(3). Please check documentation.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "CAL_MONTHS(-4)"), 
                 "Argument \"timebucket.duration\" has an invalid value: CAL_MONTHS\\(-4). The numeric part in the argument should have positive integer with a maximum value of 32767.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "0cy"), 
                 "Argument \"timebucket.duration\" has an invalid value: 0cy. The numeric part in the argument should have positive integer with a maximum value of 32767.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "222222cy"), 
                 "Argument \"timebucket.duration\" has an invalid value: 222222cy. The numeric part in the argument should have positive integer with a maximum value of 32767.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "CAL_YEARS(0)"), 
                 "Argument \"timebucket.duration\" has an invalid value: CAL_YEARS\\(0). The numeric part in the argument should have positive integer with a maximum value of 32767.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "CAL_YEARS(222222)"), 
                 "Argument \"timebucket.duration\" has an invalid value: CAL_YEARS\\(222222). The numeric part in the argument should have positive integer with a maximum value of 32767.")
    
    # Tests for value.expression argument
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = ""),
                 "Argument 'value.expression' should not contain empty string.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = 2),
                 "Argument 'value.expression' must be of 'character' datatype or a vector of 'character' datatype\\(s)")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = c(2, TRUE)),
                 "Argument 'value.expression' must be of 'character' datatype or a vector of 'character' datatype\\(s)")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = c("buoyid", "invalid_column")),
                 "Column\\(s) 'invalid_column' provided in 'value.expression' argument does not exist in object specified in 'df' argument")
    
    # Tests for timecode.column argument
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = "buoyid", timecode.column = ""),
                 "Argument 'timecode.column' should not contain empty string.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", timecode.column = 2),
                 "Argument 'timecode.column' must be of 'character' datatype. Multiple values are not supported.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = "buoyid", timecode.column = c(2, TRUE), fill = "PREV"),
                 "Argument 'timecode.column' must be of 'character' datatype. Multiple values are not supported.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", timecode.column = c("TD_TIMECODE", "buoyid")),
                 "Argument 'timecode.column' must be of 'character' datatype. Multiple values are not supported.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", timecode.column = "buoyids"),
                 "Column\\(s) 'buoyids' provided in 'timecode.column' argument does not exist in object specified in 'df' argument")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", timecode.column = "2"),
                 "Column\\(s) '2' provided in 'timecode.column' argument does not exist in object specified in 'df' argument")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", timecode.column = "buoyid", fill = 2),
                 "Column\\(s) in the argument 'timecode.column' is\\(are) of unsupported datatype : INT. Should be TIMESTAMP or DATE.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = c("TD_TIMECODE", "salinity"), timecode.column = "TD_TIMECODE"),
                 "Permitted values for the argument 'timecode.column' are: the columns not used in the argument 'value.expression'.")
    
    # Tests for sequence.column argument
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = "buoyid", timecode.column = "TD_TIMECODE", sequence.column = ""),
                 "Argument 'sequence.column' should not contain empty string.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", timecode.column = "TD_TIMECODE", sequence.column = 2),
                 "Argument 'sequence.column' must be of 'character' datatype. Multiple values are not supported.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = "buoyid", timecode.column = "TD_TIMECODE", sequence.column = c(2, TRUE), fill = "PREV"),
                 "Argument 'sequence.column' must be of 'character' datatype. Multiple values are not supported.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", timecode.column = "TD_TIMECODE", sequence.column = c("salinity", "temperature")),
                 "Argument 'sequence.column' must be of 'character' datatype. Multiple values are not supported.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", timecode.column = "TD_TIMECODE", sequence.column = "buoyids"),
                 "Column\\(s) 'buoyids' provided in 'sequence.column' argument does not exist in object specified in 'df' argument")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", timecode.column = "TD_TIMECODE", sequence.column = "2"),
                 "Column\\(s) '2' provided in 'sequence.column' argument does not exist in object specified in 'df' argument")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = "buoyid", sequence.column = "salinity"),
                 "'sequence.column' argument can only be used when 'timecode.column' argument is specified.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", timecode.column = "TD_TIMECODE", sequence.column = "TD_TIMECODE"),
                 "Column\\(s) in the argument 'sequence.column' is\\(are) of unsupported datatype : TIMESTAMP. Should be INTEGER.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = c("buoyid", "salinity"), timecode.column = "TD_TIMECODE", sequence.column = "buoyid"),
                 "Permitted values for the argument 'sequence.column' are: the columns not used in the argument 'value.expression'.")
    
    # Tests for fill argument
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = "buoyid", timecode.column = "TD_TIMECODE", fill = ""),
                 "Argument 'fill' should not contain empty string.")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", timecode.column = "TD_TIMECODE", sequence.column = seq_col, fill = "2"),
                 "Argument 'fill' should be one of: \n\"PREV\",\"PREVIOUS\",\"NEXT\",\"NULLS\",\"any numeric constant\"")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = "buoyid", timecode.column = "TD_TIMECODE", sequence.column = seq_col, fill = "INVALID_VALUE"),
                 "Argument 'fill' should be one of: \n\"PREV\",\"PREVIOUS\",\"NEXT\",\"NULLS\",\"any numeric constant\"")
    expect_error(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", fill = TRUE),
                 "Argument 'fill' must be of 'numeric or character' datatype. Multiple values are not supported.")
    
    #######################
    #   Positive Tests   ##
    #######################
    # The function .validateGroupByTimeArguments validates the arguments and return the formal notation of timebucket duration, 
    # if it is given in shorthand notation.
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "CAL_YEARS(2)")
    expect_equal(gbt_clause, "CAL_YEARS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2cyear")
    expect_equal(gbt_clause, "CAL_YEARS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2cyears")
    expect_equal(gbt_clause, "CAL_YEARS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "CAL_MONTHS(2)")
    expect_equal(gbt_clause, "CAL_MONTHS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2cm")
    expect_equal(gbt_clause, "CAL_MONTHS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2cmonth")
    expect_equal(gbt_clause, "CAL_MONTHS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2cmonths")
    expect_equal(gbt_clause, "CAL_MONTHS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "CAL_DAYS(2)")
    expect_equal(gbt_clause, "CAL_DAYS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2cd")
    expect_equal(gbt_clause, "CAL_DAYS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2cday")
    expect_equal(gbt_clause, "CAL_DAYS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2cdays")
    expect_equal(gbt_clause, "CAL_DAYS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "WEEKS(2)")
    expect_equal(gbt_clause, "WEEKS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2w")
    expect_equal(gbt_clause, "WEEKS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2week")
    expect_equal(gbt_clause, "WEEKS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2weeks")
    expect_equal(gbt_clause, "WEEKS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "DAYS(2)")
    expect_equal(gbt_clause, "DAYS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2d")
    expect_equal(gbt_clause, "DAYS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2day")
    expect_equal(gbt_clause, "DAYS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2days")
    expect_equal(gbt_clause, "DAYS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "HOURS(2)")
    expect_equal(gbt_clause, "HOURS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2h")
    expect_equal(gbt_clause, "HOURS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2hr")
    expect_equal(gbt_clause, "HOURS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2hrs")
    expect_equal(gbt_clause, "HOURS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2hour")
    expect_equal(gbt_clause, "HOURS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2hours")
    expect_equal(gbt_clause, "HOURS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "MINUTES(2)")
    expect_equal(gbt_clause, "MINUTES(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2m")
    expect_equal(gbt_clause, "MINUTES(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2mins")
    expect_equal(gbt_clause, "MINUTES(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2minute")
    expect_equal(gbt_clause, "MINUTES(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2minutes")
    expect_equal(gbt_clause, "MINUTES(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "SECONDS(2)")
    expect_equal(gbt_clause, "SECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2s")
    expect_equal(gbt_clause, "SECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2sec")
    expect_equal(gbt_clause, "SECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2secs")
    expect_equal(gbt_clause, "SECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2second")
    expect_equal(gbt_clause, "SECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2seconds")
    expect_equal(gbt_clause, "SECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "MILLISECONDS(2)")
    expect_equal(gbt_clause, "MILLISECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2ms")
    expect_equal(gbt_clause, "MILLISECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2msec")
    expect_equal(gbt_clause, "MILLISECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2msecs")
    expect_equal(gbt_clause, "MILLISECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2millisecond")
    expect_equal(gbt_clause, "MILLISECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2milliseconds")
    expect_equal(gbt_clause, "MILLISECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "MICROSECONDS(2)")
    expect_equal(gbt_clause, "MICROSECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2us")
    expect_equal(gbt_clause, "MICROSECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2usec")
    expect_equal(gbt_clause, "MICROSECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2usecs")
    expect_equal(gbt_clause, "MICROSECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2microsecond")
    expect_equal(gbt_clause, "MICROSECONDS(2)")
    gbt_clause <- .validateGroupByTimeArguments(df, timebucket.duration = "2microseconds")
    expect_equal(gbt_clause, "MICROSECONDS(2)")
    
    expect_silent(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = "buoyid"))
    expect_silent(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = c("buoyid", "salinity")))
    expect_silent(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = "buoyid", timecode.column = "TD_TIMECODE"))
    expect_silent(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", timecode.column = "TD_TIMECODE"))
    expect_silent(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", timecode.column = "TD_TIMECODE", sequence.column = "buoyid"))
    expect_silent(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = "salinity", timecode.column = "TD_TIMECODE", sequence.column = seq_col))
    expect_silent(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", fill = "PREV"))
    expect_silent(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = "salinity", fill = "NEXT"))
    expect_silent(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", timecode.column = "TD_TIMECODE", fill = "PREVIOUS"))
    expect_silent(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = "buoyid", timecode.column = "TD_TIMECODE", fill = "NULLS"))
    expect_silent(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", value.expression = "salinity", timecode.column = "TD_TIMECODE", sequence.column = seq_col, fill = 4))
    expect_silent(.validateGroupByTimeArguments(df, timebucket.duration = "2cy", fill = 2.8))
  }
})

test_that("Test .build_group_by_time_clause", {
  #######################
  #   Positive Tests   ##
  #######################
  
  ## With only timebucket duration
  # Using formal notation
  gbt_clause <- .build_group_by_time_clause("CAL_YEARS(2)")
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(CAL_YEARS(2))")
  
  # Using shorthand notation : 28d
  gbt_clause <- .build_group_by_time_clause("28d")
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(28d)")
  
  ## With timebucket duration and one column in value.expression
  # Using formal notation
  gbt_clause <- .build_group_by_time_clause("CAL_MONTHS(2)", value.expression = "column_name")
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(CAL_MONTHS(2) AND column_name)")
  
  # Using shorthand notation : 8m
  gbt_clause <- .build_group_by_time_clause("8m", value.expression = "column_name")
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(8m AND column_name)")
  
  ## With timebucket duration and multiple column in value.expression
  # Using formal notation
  gbt_clause <- .build_group_by_time_clause("CAL_MONTHS(2)", value.expression = c("col1", "col2"))
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(CAL_MONTHS(2) AND col1, col2)")
  
  # Using shorthand notation : 8m
  gbt_clause <- .build_group_by_time_clause("8m", value.expression = c("col1", "col2"))
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(8m AND col1, col2)")
  
  ## With timebucket duration, value.expression and timecode column
  # Using formal notation
  gbt_clause <- .build_group_by_time_clause("CAL_DAYS(2)", value.expression = c("col1", "col2"), timecode.column = "timecode_col")
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(CAL_DAYS(2) AND col1, col2) USING TIMECODE(timecode_col)")
  
  # Using shorthand notation : 8s
  gbt_clause <- .build_group_by_time_clause("8s", value.expression = c("col1", "col2"), timecode.column = "timecode_col")
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(8s AND col1, col2) USING TIMECODE(timecode_col)")
  
  ## With timebucket duration, value.expression, timecode column and sequence.column
  # Using formal notation
  gbt_clause <- .build_group_by_time_clause("CAL_DAYS(2)", value.expression = c("col1", "col2"), timecode.column = "timecode_col", sequence.column = "seq_col")
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(CAL_DAYS(2) AND col1, col2) USING TIMECODE(timecode_col, seq_col)")
  
  # Using shorthand notation : 8s
  gbt_clause <- .build_group_by_time_clause("8s", value.expression = c("col1", "col2"), timecode.column = "timecode_col", sequence.column = "seq_col")
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(8s AND col1, col2) USING TIMECODE(timecode_col, seq_col)")
  
  ## With timebucket duration, value.expression, timecode column, sequence.column and fill (NULLS)
  # Using formal notation
  gbt_clause <- .build_group_by_time_clause("HOURS(2)", value.expression = c("col1", "col2"), timecode.column = "timecode_col", sequence.column = "seq_col", fill = "NULLS")
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(HOURS(2) AND col1, col2) USING TIMECODE(timecode_col, seq_col) FILL(NULLS)")
  
  # Using shorthand notation : 8msec
  gbt_clause <- .build_group_by_time_clause("8msec", value.expression = c("col1", "col2"), timecode.column = "timecode_col", sequence.column = "seq_col", fill = "NULLS")
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(8msec AND col1, col2) USING TIMECODE(timecode_col, seq_col) FILL(NULLS)")
  
  ## With timebucket duration, value.expression, and fill (PREV)
  # Using formal notation
  gbt_clause <- .build_group_by_time_clause("HOURS(2)", value.expression = c("col1", "col2"), fill = "PREV")
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(HOURS(2) AND col1, col2) FILL(PREV)")
  
  # Using shorthand notation : 8usec
  gbt_clause <- .build_group_by_time_clause("8usec", value.expression = c("col1", "col2"), fill = "PREV")
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(8usec AND col1, col2) FILL(PREV)")
  
  ## With timebucket duration and fill (NEXT)
  # Using formal notation
  gbt_clause <- .build_group_by_time_clause("WEEKS(2)", fill = "NEXT")
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(WEEKS(2)) FILL(NEXT)")
  
  # Using shorthand notation : 8usec
  gbt_clause <- .build_group_by_time_clause("8usec", fill = "NEXT")
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(8usec) FILL(NEXT)")
  
  ## With timebucket duration, value.expression, timecode column and fill (PREVIOUS)
  # Using formal notation
  gbt_clause <- .build_group_by_time_clause("HOURS(2)", value.expression = c("col1", "col2"), timecode.column = "timecode_col", fill = "PREVIOUS")
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(HOURS(2) AND col1, col2) USING TIMECODE(timecode_col) FILL(PREVIOUS)")
  
  # Using shorthand notation : 8msec
  gbt_clause <- .build_group_by_time_clause("8msec", value.expression = c("col1", "col2"), timecode.column = "timecode_col", fill = "PREVIOUS")
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(8msec AND col1, col2) USING TIMECODE(timecode_col) FILL(PREVIOUS)")
  
  ## With timebucket duration, timecode column and fill (numeric constant)
  # Using formal notation
  gbt_clause <- .build_group_by_time_clause("HOURS(2)", timecode.column = "timecode_col", fill = 28)
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(HOURS(2)) USING TIMECODE(timecode_col) FILL(28)")
  
  # Using shorthand notation : 8us
  gbt_clause <- .build_group_by_time_clause("8us", timecode.column = "timecode_col", fill = 4.28)
  expect_true(inherits(gbt_clause, "sql"))
  expect_equal(as.character(gbt_clause), "GROUP BY TIME(8us) USING TIMECODE(timecode_col) FILL(4.28)")
  
  
  
  #######################
  #   Negative Tests   ##
  #######################
  
  # Without any argument
  expect_error(.build_group_by_time_clause(), "argument \"timebucket.duration\" is missing, with no default")
  
})

test_that("Test .validate_time_bucket_duration", {
  #######################
  #   Positive Tests   ##
  #######################
  
  # The function .validate_time_bucket_duration return the timebucket duration as it is if it is in formal notation and 
  # returns the formal notation if it is in shorthand notation, irrespective of case.
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "CAL_YEARS(2)"), "CAL_YEARS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "CAL_MONTHS(2)"), "CAL_MONTHS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "CAL_DAYS(2)"), "CAL_DAYS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "WEEKS(2)"), "WEEKS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "DAYS(2)"), "DAYS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "HOURS(2)"), "HOURS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "MINUTES(2)"), "MINUTES(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "SECONDS(2)"), "SECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "MILLISECONDS(2)"), "MILLISECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "MICROSECONDS(2)"), "MICROSECONDS(2)")
  
  # Note the lower case for values in argument timebucket.duration
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "cal_years(2)"), "CAL_YEARS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "cal_months(2)"), "CAL_MONTHS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "cal_days(2)"), "CAL_DAYS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "weeks(2)"), "WEEKS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "days(2)"), "DAYS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "hours(2)"), "HOURS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "minutes(2)"), "MINUTES(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "seconds(2)"), "SECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "milliseconds(2)"), "MILLISECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "microseconds(2)"), "MICROSECONDS(2)")

  
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2cy"), "CAL_YEARS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2cyear"), "CAL_YEARS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2cyears"), "CAL_YEARS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2cm"), "CAL_MONTHS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2cmonth"), "CAL_MONTHS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2cmonths"), "CAL_MONTHS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2cd"), "CAL_DAYS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2cday"), "CAL_DAYS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2cdays"), "CAL_DAYS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2w"), "WEEKS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2week"), "WEEKS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2weeks"), "WEEKS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2d"), "DAYS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2day"), "DAYS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2days"), "DAYS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2h"), "HOURS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2hr"), "HOURS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2hrs"), "HOURS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2hour"), "HOURS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2hours"), "HOURS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "MINUTES(2)"), "MINUTES(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2mins"), "MINUTES(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2minute"), "MINUTES(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2minutes"), "MINUTES(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2s"), "SECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2sec"), "SECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2secs"), "SECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2second"), "SECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2seconds"), "SECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2ms"), "MILLISECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2msec"), "MILLISECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2msecs"), "MILLISECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2millisecond"), "MILLISECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2milliseconds"), "MILLISECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2us"), "MICROSECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2usec"), "MICROSECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2usecs"), "MICROSECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2microsecond"), "MICROSECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2microseconds"), "MICROSECONDS(2)")
  
  # Note the upper case for values in argument timebucket.duration
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2CY"), "CAL_YEARS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2CYEAR"), "CAL_YEARS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2CYEARS"), "CAL_YEARS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2CM"), "CAL_MONTHS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2CMONTH"), "CAL_MONTHS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2CMONTHS"), "CAL_MONTHS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2CD"), "CAL_DAYS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2CDAY"), "CAL_DAYS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2CDAYS"), "CAL_DAYS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2W"), "WEEKS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2WEEK"), "WEEKS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2WEEKS"), "WEEKS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2D"), "DAYS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2DAY"), "DAYS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2DAYS"), "DAYS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2H"), "HOURS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2HR"), "HOURS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2HRS"), "HOURS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2HOUR"), "HOURS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2HOURS"), "HOURS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2M"), "MINUTES(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2MINS"), "MINUTES(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2MINUTE"), "MINUTES(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2MINUTES"), "MINUTES(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2S"), "SECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2SEC"), "SECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2SECS"), "SECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2SECOND"), "SECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2SECONDS"), "SECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2MS"), "MILLISECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2MSEC"), "MILLISECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2MSECS"), "MILLISECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2MILLISECOND"), "MILLISECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2MILLISECONDS"), "MILLISECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2US"), "MICROSECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2USEC"), "MICROSECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2USECS"), "MICROSECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2MICROSECOND"), "MICROSECONDS(2)")
  expect_equal(.validate_time_bucket_duration(timebucket.duration = "2MICROSECONDS"), "MICROSECONDS(2)")

  #######################
  #   Negative Tests   ##
  #######################
  expect_error(.validate_time_bucket_duration(timebucket.duration = "invalid"), 
               "Argument \"timebucket.duration\" has an invalid value: invalid. Please check documentation.")
  expect_error(.validate_time_bucket_duration(timebucket.duration = "2ROSECOND"), 
               "Argument \"timebucket.duration\" has an invalid value: 2ROSECOND. Please check documentation.")
  expect_error(.validate_time_bucket_duration(timebucket.duration = "ROSECOND(3)"), 
               "Argument \"timebucket.duration\" has an invalid value: ROSECOND\\(3). Please check documentation.")
  expect_error(.validate_time_bucket_duration(timebucket.duration = "00cy"), 
               "Argument \"timebucket.duration\" has an invalid value: 00cy. The numeric part in the argument should have positive integer with a maximum value of 32767.")
  expect_error(.validate_time_bucket_duration(timebucket.duration = "222222cy"), 
               "Argument \"timebucket.duration\" has an invalid value: 222222cy. The numeric part in the argument should have positive integer with a maximum value of 32767.")
  expect_error(.validate_time_bucket_duration(timebucket.duration = "CAL_YEARS(0)"), 
               "Argument \"timebucket.duration\" has an invalid value: CAL_YEARS\\(0). The numeric part in the argument should have positive integer with a maximum value of 32767.")
  expect_error(.validate_time_bucket_duration(timebucket.duration = "CAL_YEARS(222222)"), 
               "Argument \"timebucket.duration\" has an invalid value: CAL_YEARS\\(222222). The numeric part in the argument should have positive integer with a maximum value of 32767.")
  
})

test_that("Test consecutive group_by_time and group_by", {
  # Latest grouping is considered
  tables <- c("t_pti_table_seq", "t_pti_table_nonseq")
  
  for (table in tables) {
    df <- tbl(con, table)
    
    # group_by_time followed by group_by
    df1 <- df %>% group_by(buoyid) %>% group_by_time(timebucket.duration = "2m")
    grouped_cols <- op_grps(df1)
    expect_equal(grouped_cols, "TIMECODE_RANGE")
    
    # group_by followed by group_by_time
    df1 <- df %>% group_by_time(timebucket.duration = "2m") %>% group_by(buoyid)
    grouped_cols <- op_grps(df1)
    expect_equal(grouped_cols, "buoyid")

    # Consecutive group_by_time operations
    df1 <- df %>% group_by_time(timebucket.duration = "2m") %>% 
      group_by_time(timebucket.duration = "2m", value.expression = "buoyid")
    grouped_cols <- op_grps(df1)
    expect_equal(grouped_cols, c("TIMECODE_RANGE", "buoyid"))
  }

})

testthat::teardown(
  {
    tryCatch({
      DBI::dbGetQuery(con, "drop table t_pti_table_seq")
    }, error=function(e) {
      # DO Nothing
    })
    
    tryCatch({
      DBI::dbGetQuery(con, "drop table t_pti_table_nonseq")
    }, error=function(e) {
      # DO Nothing
    })
    
    td_remove_context()
  })