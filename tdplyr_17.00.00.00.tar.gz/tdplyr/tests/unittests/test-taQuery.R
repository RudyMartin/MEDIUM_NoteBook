context("Tests for internal function taQuery")

test_con <- NULL

testthat::setup(
  {
    if(globalDTYPE == "odbc"){
      test_con <<- suppressWarnings(td_create_context(dsn = dsnName))
    }else {
      test_con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD, temp.database = "alice"))
    }
  }
)

test_that("taQuery doesn't stop with no connection given", {
  expect_error(taQuery("sel 1"), NA)
  
  # no error thrown when stopOnError is FALSE
  expect_error(taQuery("sel 1", stopOnError = FALSE), NA)
})

test_that("taQuery executes select queries", {
  
  # get a tbl on usersv 
  tbl_view <- tbl(test_con, in_schema('dbc', 'usersv'))
  
  # select query
  res <- taQuery("select username, defaultdatabase from dbc.usersv", test_con)
  expect_is(res, "data.frame")
  
  # expect attributes of data.frame
  expect_true(nrow(res) == pull(tally(tbl_view), 1L))
  expect_true("UserName" %in% colnames(res))
  expect_true("DefaultDataBase" %in% colnames(res))
  
  # test select *
  res <- taQuery("select * from dbc.usersv", test_con)
  expect_is(res, "data.frame")
  expect_true(nrow(res) == pull(tally(tbl_view), 1L))
  
})

test_that("taQuery executes valid DDL queries", {
  
  # successful DDL query execution returns empty data.frames 
  res <- taQuery("create table test_taQuery as (select * from dbc.usersv) with data", test_con)
  expect_is(res, "data.frame")
  expect_identical(nrow(res), 0L)
  expect_identical(ncol(res), 0L)
  
  res <- taQuery("drop table test_taQuery", test_con)
  expect_is(res, "data.frame")
  expect_identical(nrow(res), 0L)
  expect_identical(ncol(res), 0L)
  
  expect_error(tbl(test_con, 'test_taQuery'), 
               "Object 'test_taQuery' does not exist.")
})

test_that("taQuery executes DML queries", {
  
  # get the quakes tbl created in setup
  q <- tbl(test_con, 'quakes')
  
  # prepare an insert statement
  ins <- paste0("insert into quakes(",
                paste(sql_quote(colnames(q), quote = '"'), collapse = ","),
                ")",
                " values( ",
                paste(c(0.0, 0.0, 0, 0, 0), collapse = ","),
                ")")
  
  # get the row number from the quakes table
  original_nrow <- pull(tally(q), 1L)
  
  # do the insert
  res <- taQuery(ins)
  expect_is(res, "data.frame")
  # upon success, expect an empty data.frame
  expect_true(ncol(res) == nrow(res))
  
  # check that the row was inserted
  expect_true (pull(tally(q), 1L) == original_nrow + 1L)
  
  # check values before update statement
  res <- taQuery("sel * from quakes")
  expect_true(nrow(res) == original_nrow + 1L)
  expect_true(0 %in% res$lat && 0 %in% res$long)
  expect_true(0 %in% res$depth && 0 %in% res$mag)
  
  # do an update
  res <- taQuery("update quakes set mag=1.234 where mag=0")
  expect_is(res, "data.frame")
  # upon success, expect an empty data.frame
  expect_true(ncol(res) == nrow(res))
  
  # check update
  res <- taQuery("sel * from quakes")
  expect_true(1.234 %in% res$mag && !(0 %in% res$mag))
  
})

test_that("taQuery creates and changes databases", {

  # all test db users should have create db privileges on itself
  # create a new db ('schema')
  db_name <- "ele_148"
  ct_db_stmt <- paste0("create database ", db_name,            
                       " as perm=1e6 * (hashamp() + 1)")

  new_db <- taQuery(ct_db_stmt)
  expect_is(new_db, "data.frame")
  # upon success, expect an empty data.frame
  expect_equal(nrow(new_db), ncol(new_db))

  # switch default databases
  res <- taQuery(paste0("database ", db_name))
  # upon success, expect an empty data.frame
  expect_equal(nrow(res), ncol(res))
  
  # get current default database
  db <- taQuery("sel database")
  expect_identical(class(db), class(data.frame()))
  expect_true(nrow(db) == 1L && ncol(db) == 1L)
  db <- as.character(tolower(db[[1]]))
  
  expect_identical(db, db_name)

  # switch back to default db 
  user <- taQuery("sel user")
  user <- as.character(tolower(user[[1]]))
  res <- taQuery(paste0("database ", user))
  expect_equal(nrow(res), ncol(res))

  db <- taQuery("sel database")
  expect_identical(class(db), class(data.frame()))
  expect_true(nrow(db) == 1L && ncol(db) == 1L)
  db <- as.character(tolower(db[[1]]))
  
  expect_identical(db, user)
  
  # drop the database
  res <- taQuery(paste0("drop database ", db_name))
  # upon success, expect an empty data.frame
  expect_equal(nrow(res), ncol(res))

  # switch back
  res <- taQuery(paste0("database ", .get_dbname(test_con)))
})

test_that("taQuery executes help queries", {
  
  # get the current user
  user <- taQuery("sel user")
  expect_identical(class(user), class(data.frame()))
  expect_true(nrow(user) == 1L && ncol(user) == 1L)
  user <- as.character(user[[1]])
  
  # set default db. all test database users should have a default database
  expect_equal(taQuery(paste0("database ", user)), data.frame())
  
  # make sure the default database is set
  db <- taQuery("sel database")
  expect_identical(class(db), class(data.frame()))
  expect_true(nrow(db) == 1L && ncol(db) == 1L)
  db <- as.character(db[[1]])
  
  expect_identical(db, user)
  
  # get help info on user and default db
  # "help" gives back database objects (tables, views, etc.)
  res <- taQuery(paste0("help database ", user))
  expect_identical(class(res), class(data.frame()))
  # each release may add another column, so just expect that it has some cols
  expect_true(ncol(res) > 0L)
  # new tables may be added in the future so just expect that there are rows
  expect_true(nrow(res) > 0L)
  
  res <- taQuery(paste0("help user ", user))
  expect_identical(class(res), class(data.frame()))
  # each release may add another column, so just expect that it has some cols
  expect_true(ncol(res) > 0L)
  # new tables may be added in the future so just expect that there are rows
  expect_true(nrow(res) > 0L)

  # switch back
  res <- taQuery(paste0("database ", .get_dbname(test_con)))
})

test_that("taQuery behaves as expected for stopOnError", {
  
  # Error is thrown when stopOnError is TRUE
  expect_error(
    taQuery('sel * from non_existing_table'), 
    "Object 'non_existing_table' does not exist"
    )
  
  # -1L returned on error when stopOnError is FALSE
  invalid_stmt <- "insert into non_existing_table(id, val) values (1,1)"
  res <- taQuery(invalid_stmt, stopOnError = FALSE, con = test_con)
  
  expect_true(is.integer(res) && res == -1L)
})

test_that("taQuery behaves as expected for stopOnWarning", {

  # stopOnWarning is FALSE by default
  # if there is no error but there is a warning, 1L is returned
  expect_that(
    with_mock(
      # mock sqlQuery to return an error
      `DBI::dbGetQuery` = function(con,
                                   statement,
                                   ...) {
        warning("mock warning")
      },
      taQuery("mock statement", con=test_con)
    ),
    is_identical_to(1L))
  
  # stopOnWarning set to TRUE
  # if there is no error but there is a warning, stop with warning
  expect_that(
    with_mock(
      # mock sqlQuery to return an error
      `DBI::dbGetQuery` = function(con,
                                   statement,
                                   ...) {
        warning("mock warning")
      },
      taQuery(test_con, "mock statement", stopOnWarning = TRUE)
    ),
    throws_error("mock warning"))
})

test_that("taQuery throws warning when n passed to dbFetch", {

  res <- taQuery("select * from quakes", n=5L)
  if(globalDTYPE == "odbc"){
    expect_true(is.integer(res) && res == 1L)
    expect_error(taQuery("select * from quakes", n=5L, stopOnWarning = TRUE),
                 "Pending rows")
  } else {
    expect_equal(nrow(res), 1001)
  }
})

testthat::teardown(
  {
    td_remove_context()
  }
)
