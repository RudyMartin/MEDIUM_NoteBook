context("Unit tests for copy_to with input as data frame")

create_db_context <- function() {
  if(globalDTYPE == "odbc"){
    con <<- suppressWarnings(td_create_context(dsn = dsnName))
  } else {
    con <<- suppressWarnings(td_create_context( dType = "native", host = globalHost, uid = globalUID, pwd = globalPWD))
  }
}

get_con_dbname <- function(con) {
  if(globalDTYPE == "odbc"){
    return(con@info$dbname)
  } else {
    return(.get_dbname(con))
  }
}

cleanup <- function() {
  for( i in 1:27){
    tryCatch({
      DBI::dbExecute(con, paste0("drop table t",i))
    }, error=function(e) { 
      # DO Nothing
    })
  }
  
  tryCatch({
    DBI::dbExecute(con, "drop table table_exists")
    DBI::dbExecute(con, "drop table test_table_append")
    DBI::dbExecute(con, "drop table test_table_overwrite")
    DBI::dbExecute(con, "drop table test_df")
    DBI::dbExecute(con, "drop view test_view")
    DBI::dbExecute(con, "drop table tt1")
    DBI::dbExecute(con, "drop table employee")
  }, error=function(e) { 
    # DO Nothing
  })
}


testthat::setup({
  
  create_db_context()
  # Cleaning data base if tables are already exists.
  cleanup()
  taQuery("create table table_exists(a integer)")
})

test_that("Throws error as required argument df is missing", {
  expect_error(copy_to(con, name = "temp",table.type = "xyz"),
               "argument \"df\" is missing, with no default")
})

# More than 2048 columns check
test_that("throws column limit error if columns are more than 'maxNumberOfColumns' global value", {
  expect_error( copy_to(con, df = as.data.frame(matrix(1, ncol = 2049, nrow = 2)), name = "temp"),
                "Maximum number of columns in the dataframe should be 2048. Found 2049.")
})

test_that("Table type should be PI or noPi", {
  expect_error(copy_to(con, df = data.frame(a = c(1,2,3)), name = "temp",table.type = "xyz"),
               "Argument 'table.type' should be one of: \n\"NOPI\",\"PI\"")
})


test_that("data should be contain rows", {
  expect_error( copy_to(con, df =data.frame(), table = "temp",table.type = "pi", partitionKey = "a"),
                "Could not create table without any columns")
})

test_that("Throws error as table is already exists", {
  expect_error(copy_to(con, df = data.frame(a=c(1,2,3), b= c(3,4,5)),name = "table_exists"),
               paste0("Table 'table_exists' already exists.") )
})

# Checking table attributes and table type is PI
test_that("creates expected PI table", {
  data <- data.frame(a=c(1,2,3), b= c(3,4,5))
  df <- copy_to(con,df = data ,name = "t1", table.type = "pi",primary.index = c("a","b"),
                  row.names = FALSE,types = c('int','float'))

  t1 <- tbl(con,"t1")
  expect_equal( df, t1 )

  # Check if its tbl_teradata
  expect_is(df, "tbl_teradata")

  # Check number of rows
  expect_equal(td_nrow(df), bit64::as.integer64(nrow(data)))
  #Check column names
  expect_equal(c('a','b'), colnames(df))
  # Check row_names column present or not
  expect_false( "row_names" %in% names(df) )

  # Check datatypes
  dataTypes <- .get_column_datatypes(t1)
  expect_equal(c(dataTypes[[1]],dataTypes[[2]]), c("int","float"))

  # Getting primary index columns from table
  primaryIndexDetails <- taQuery(paste0("select * from dbc.indicesx where UPPER(DatabaseName) = '",toupper(get_con_dbname(con)),
                                        "' and TableName = 't1'"))

  # Removing trailing spaces for column names
  primaryIndexColumns <- gsub("(^[[:space:]]+|[[:space:]]+$)", "",primaryIndexDetails$ColumnName)

  # Check primary index column names are same or not
  expect_true("a" %in% primaryIndexColumns)
  expect_true("b" %in% primaryIndexColumns)

  # Comparing data
  dbData <- taQuery("select * from t1")
  # Returns TRUE only when enitre column present
  expect_true(unique(dbData$a %in% data$a))
  expect_true(unique(dbData$b %in% data$b))
})

# Without table.type argument
test_that("creates pi table as we did not mentioned tabeType", {
  expect_identical(copy_to(con,df = data.frame(a=c(1,2,3), b= c(3,4,5)),name = "t3",
                             row.names = FALSE), tbl(con,"t3"))

  # Table should contain primary Index on first column.
  # Getting primary index columns from table
  primaryIndexDetails <- taQuery(paste0("select * from dbc.indicesx where UPPER(DatabaseName) = '",toupper(get_con_dbname(con)),
                                        "' and TableName = 't3'"))

  # Removing trailing spaces for column names
  primaryIndexColumns <- gsub("(^[[:space:]]+|[[:space:]]+$)", "",primaryIndexDetails$ColumnName)

  # Primary index should be on first column
  expect_true("a" %in% primaryIndexColumns)
  expect_false("b" %in% primaryIndexColumns)

})

# Invalid values and types for row names
test_that("throws error as row.names is an invalid type", {
  data <- data.frame(a=c(1,2), b= c(3,4))
  expect_error(copy_to(con,df = data,name = "t4", table.type = "nopi",row.names = "xyz"),
               "Argument 'row.names' must be of 'logical' datatype. Multiple values are not supported.")
})

test_that("throws error as row.names is an invalid value", {
  data <- data.frame(a=c(1,2), b= c(3,4))
  expect_error(copy_to(con,df = data,name = "t4", table.type = "nopi",row.names = NA),
               "NULL/NA is not supported for the argument 'row.names'.")
})

test_that("throws error as row.names is an invalid type", {
  data <- data.frame(a=c(1,2), b= c(3,4))
  expect_error(copy_to(con,df = data,name = "t4", table.type = "nopi",row.names = 1),
               "Argument 'row.names' must be of 'logical' datatype. Multiple values are not supported.")
})


# With row.names = TRUE
test_that("creates table with row_names column as row.names is TRUE", {

  data <- data.frame(a=c(1,2), b= c(3,4))
  df <- copy_to(con,df = data,name = "t4", table.type = "nopi",row.names = TRUE)

  expect_identical(df, tbl(con,"t4"))
  expect_true("row_names" %in% colnames(df))
  # Comparing data
  # Checking data
  dbData <- taQuery("select * from t4")
  expect_true(unique(dbData$a %in% data$a))
  expect_true(unique(dbData$b %in% data$b))
  expect_true(unique(dbData$row_names %in% rownames(data)))
})

# With row.names = TRUE and data contains row_names
test_that("creates table with row_names as data contains row_names regardless of row.names option", {

  data <- data.frame(a=c(1,2), row_names = c(3,4))
  df <- expect_warning(copy_to(con,df = data,name = "t5", table.type = "nopi",row.names = TRUE),
               "'df' already has 'row_names' column, ignoring row names of dataframe.")
  expect_identical(df, tbl(con,"t5"))
  expect_true("row_names" %in% colnames(df))
  # Comparing data
  # Checking data
  dbData <- taQuery("select * from t5")
  expect_true(unique(dbData$a %in% data$a))
  expect_true(unique(dbData$row_names %in% data$row_names))
  expect_false(unique(dbData$row_names %in% rownames(data)))

})

# Custom row names
test_that("creates table with custom row_names column as row.names is TRUE", {

  data <- data.frame(a=c(1,2), b= c(3,4))
  # Changing row names to different values
  row.names(data) <- c(4:5)
  df <- copy_to(con,df = data,name = "t6", table.type = "nopi",row.names = TRUE)

  expect_identical(df, tbl(con,"t6"))
  expect_true("row_names" %in% colnames(df))
  # Checking data
  dbData <- taQuery("select * from t6")
  expect_true(unique(dbData$a %in% data$a))
  expect_true(unique(dbData$b %in% data$b))
  expect_true(unique(dbData$row_names %in% rownames(data)))
})

test_that("creates table with row_names are charecters", {

  data <- data.frame(a=c(1,2), b= c(3,4))
  # Changing row names to different values
  row.names(data) <- c('a','b')
  df <- copy_to(con,df = data,name = "t7", tableType = "nopi",row.names = TRUE)

  expect_identical(df, tbl(con,"t7"))
  expect_true("row_names" %in% colnames(df))
  # Checking data
  dbData <- taQuery("select * from t7")
  expect_true(unique(dbData$a %in% data$a))
  expect_true(unique(dbData$b %in% data$b))
  expect_true(unique(dbData$row_names %in% rownames(data)))
})

# With row.names = FALSE and data does not contains row_names column
test_that("creates table without row_names column", {

  data <- data.frame(a=c(1,2), b= c(3,4))
  df <- copy_to(con,df = data,name = "t8", table.type = "nopi",row.names = FALSE)

  expect_identical(df, tbl(con,"t8"))
  expect_false("row_names" %in% colnames(df))
  # Comparing data
  # Checking data
  dbData <- taQuery("select * from t8")
  expect_true(unique(dbData$a %in% data$a))
  expect_true(unique(dbData$b %in% data$b))
})

# With row.names = FALSE and data contains row_names
test_that("creates table with row_names as data contains row_names regardless of row.names option", {

  data <- data.frame(a=c(1,2), row_names = c(3,4))
  df <- copy_to(con,df = data,name = "t9", table.type = "nopi",row.names = FALSE)

  expect_identical(df, tbl(con,"t9"))
  expect_true("row_names" %in% colnames(df))
  # Comparing data
  # Checking data
  dbData <- taQuery("select * from t9")
  expect_true(unique(dbData$a %in% data$a))
  expect_true(unique(dbData$row_names %in% data$row_names))
  expect_false(unique(dbData$row_names %in% rownames(data)))

})

#row.names NULl and data does not contains row_names column
test_that("creates table without row_names column", {

  data <- data.frame(a = c(1,2), b = c(3,4))
  df <- copy_to(con,df = data,name = "t10", table.type = "nopi")

  expect_identical(df, tbl(con,"t10"))
  expect_false("row_names" %in% colnames(df))
  # Comparing data
  # Checking data
  dbData <- taQuery("select * from t10")
  expect_true(unique(dbData$a %in% data$a))
  expect_true(unique(dbData$b %in% data$b))
})

#row.names NULL and data contains row_names
test_that("creates table with row_names as data contains row_names regardless of row.names option", {

  data <- data.frame(a = c(1,2), row_names = c(3,4))
  df <- copy_to(con,df = data,name = "t11", table.type = "nopi")

  expect_identical(df, tbl(con,"t11"))
  expect_true("row_names" %in% colnames(df))
  # Comparing data
  # Checking data
  dbData <- taQuery("select * from t11")
  expect_true(unique(dbData$a %in% data$a))
  expect_true(unique(dbData$row_names %in% data$row_names))
  expect_false(unique(dbData$row_names %in% rownames(data)))
})

# Test cases for temporary argument
test_that("throws error as invalid value passed for temporary", {
  data <- data.frame(a=c(1,2), b= c(3,4))
  expect_error(copy_to(con,df = data,name = "t12", table.type = "nopi",temporary = "abc"),
               "Argument 'temporary' must be of 'logical' datatype. Multiple values are not supported.")
})

test_that("throws error as invalid value passed for temporary", {
  data <- data.frame(a=c(1,2), b= c(3,4))
  expect_error(copy_to(con,df = data,name = "t12", table.type = "nopi",temporary = NULL),
               "NULL/NA is not supported for the argument 'temporary'.")
})

test_that("throws error as invalid value passed for temporary", {
  data <- data.frame(a=c(1,2), b= c(3,4))
  expect_error(copy_to(con,df = data,name = "t12", table.type = "nopi",temporary = NA),
               "NULL/NA is not supported for the argument 'temporary'.")
})

# temporary = FALSE
test_that("creates permenant table as temporary FALSE", {

  data <- data.frame(a=c(1,2), row_names = c(3,4))
  df <- copy_to(con,df = data,name = "t12", table.type = "nopi",temporary = FALSE)

  expect_identical(df, tbl(con,"t12"))
  expect_true(dbExistsTable(con,"t12"))
  td_remove_context()
  create_db_context()
  # As it is a permanent table, table exists in database in any other session
  expect_true(dbExistsTable(con,"t12"))
})

# temporary = TRUE
test_that("creates volatile PI table as temporary TRUE and table.type is PI", {

  data <- data.frame(a=c(1,2), b = c(3,4))
  df <- copy_to(con,df = data,name = "t13", table.type = "pi",primary.index = c('a','b'), temporary = TRUE)

  expect_identical(df, tbl(con,"t13"))
  expect_true(dbExistsTable(con,"t13"))

  # As dbc.indices tables does not have information about primary indices for temporary tables,
  # So just checking show table query.
  expect_equal(grep("PRIMARY INDEX \\( a ,b \\)",paste0(DBI::dbGetQuery(con, "show table t13"),"")),1)
  td_remove_context()
  create_db_context()
  # As it is a volatile table, table does not exists in database after resetting connection
  expect_false(dbExistsTable(con,"t13"))
})

test_that("creates volatile NOPI table as temporary TRUE and table.type is NOPI", {

  data <- data.frame(a=c(1,2), row_names = c(3,4))
  df <- copy_to(con,df = data,name = "t14", table.type = "nopi",temporary = TRUE)

  expect_identical(df, tbl(con,"t14"))
  expect_true(dbExistsTable(con,"t14"))

  expect_equal(grep("NO PRIMARY INDEX",paste0(DBI::dbGetQuery(con, "show table t14"),"")),1)
  td_remove_context()
  create_db_context()
  # As it is a volatile table, table does not exists in database after resetting connection
  expect_false(dbExistsTable(con,"t14"))
})

#overWrite TRUE - Table does not exists
test_that("If table does not exists and overwrite is TRUE", {
  data <- data.frame(a=c(1,2,3), b= c(3,4,5))
  expect_identical(copy_to(con,df = data ,name = "t2", table.type = "pi",
                           primary.index = c("a","b"), overwrite = TRUE, row.names = FALSE),
                   tbl(con,"t2"))
})

# OverWrite TRUE - metadata different
test_that("No error thrown even if overwrite is TRUE and metadata is different between table and data frame", {
  data <- data.frame(a=c('a','b','c'), b= c(3,4,5))
  # t2 table contains float data type columns, but due to overwrite table should get overwritten.
  expect_equal(copy_to(con,df = data ,name = "t2", table.type = "pi",
                           primary.index = c("a","b"), overwrite = TRUE, row.names = FALSE),
                   tbl(con, "t2"))
})


test_that("No error thrown as overwrite is TRUE and metadata is different with regard to row.names", {
  data <- data.frame(a=c(1,2,3), b= c(3,4,5))
  # Create a table setting row.names = TRUE
  copy_to(con, df = data ,name = "t21", row.names = TRUE)
  # Now we try overwriting table setting the row.names parameter to FALSE
  expect_equal(copy_to(con,df = data, name = "t21", overwrite = TRUE, row.names = FALSE),
               tbl(con, "t21"))
})

test_that("overwrites existing table as metadata matches", {
  data <- data.frame(a=c(11,12,13), b= c(31,42,53))
  expect_equal(copy_to(con, df = data, name = "t21", overwrite = TRUE, row.names = TRUE),
               tbl(con,"t21"))
  dbData <- taQuery("select * from t21")
  expect_true(unique(dbData$a %in% data$a))
  expect_true(unique(dbData$b %in% data$b))
  expect_true(unique(dbData$row_names %in% rownames(data)))
})

test_that("No error thrown as overwrite is TRUE and metadata is different with regard to row.names", {
  data <- data.frame(a=c(1,2,3), b= c(3,4,5))
  # Create a table with row.names set to FALSE
  copy_to(con, df = data ,name = "t22", row.names = FALSE)
  # Try overwriting to same table with row.names set to TRUE. This should not throw an error.
  expect_equal(copy_to(con, df = data, name = "t22", overwrite = TRUE, row.names = TRUE),
               tbl(con, "t22"))
})

test_that("overwrites existing table as metadata matches", {
  data <- data.frame(a=c(12,21,32), b= c(13,14,15))
  expect_equal(copy_to(con,df = data ,name = "t22", overwrite = TRUE, row.names = FALSE),
               tbl(con,"t22"))
  dbData <- taQuery("select * from t22")
  expect_true(unique(dbData$a %in% data$a))
  expect_true(unique(dbData$b %in% data$b))
})

# Passing coltypes:
test_that("overwrites existing table as metadata matches", {
  data <- data.frame(a=c(12,21,32), b= c(13,14,15))
  copy_to(con,df = data ,name = "t26",types = c("integer","real"))
  expect_equal(copy_to(con,df = data ,name = "t26",types = c("integer","real"), overwrite = TRUE),
               tbl(con,"t26"))
  dbData <- taQuery("select * from t26")
  expect_true(unique(dbData$a %in% data$a))
  expect_true(unique(dbData$b %in% data$b))
  
  copy_to(con,df = data ,name = "t27",types = c("integer","int"))
  expect_equal(copy_to(con,df = data ,name = "t27",types = c("integer","int"), overwrite = TRUE),
               tbl(con,"t27"))
  dbData <- taQuery("select * from t27")
  expect_true(unique(dbData$a %in% data$a))
  expect_true(unique(dbData$b %in% data$b))
})

# analyze flag test cases
test_that("collect the statistics as analyze is TRUE and table type is NOPI", {

  data <- data.frame(a=c(1,2), b = c(3,4))
  df <- copy_to(con,df = data,name = "t15", table.type = "nopi",analyze = TRUE)
  statsDf <- DBI::dbGetQuery(con,"HELP statistics t15")
  expect_equal(nrow(statsDf),2)
  expect_true("a" %in% statsDf$`Column Names`)
})

test_that("collect the statistics as analyze is TRUE and table type is PI", {

  data <- data.frame(a=c(1,2), b = c(3,4))
  df <- copy_to(con,df = data,name = "t16", table.type = "pi",analyze = TRUE, primary.index = "b")
  statsDf <- DBI::dbGetQuery(con,"HELP statistics t16")
  expect_equal(nrow(statsDf),2)
  expect_true("b" %in% statsDf$`Column Names`)
})

test_that("collect the statistics as analyze is TRUE and table type is PI (default primary index)", {

  data <- data.frame(a=c(1,2), b = c(3,4))
  df <- copy_to(con,df = data,name = "t17", table.type = "pi",analyze = TRUE)
  statsDf <- DBI::dbGetQuery(con,"HELP statistics t17")
  expect_equal(nrow(statsDf),2)
  expect_true("a" %in% statsDf$`Column Names`)
})

test_that("Does not collect statistics as analyze is FALSE", {

  data <- data.frame(a=c(1,2), b = c(3,4))
  df <- copy_to(con,df = data,name = "t18", table.type = "nopi",analyze = FALSE)
  expect_error(DBI::dbExecute(con,"HELP statistics t18"),
               "There are no statistics defined for the table.")
})

test_that("collect the statistics as analyze is TRUE for temporary PI table", {

  data <- data.frame(a=c(1,2), b = c(3,4))
  df <- copy_to(con,df = data,name = "t19", table.type = "pi",analyze = TRUE,
                primary.index = "b", temporary = TRUE)
  statsDf <- DBI::dbGetQuery(con,"HELP statistics t19")
  expect_equal(nrow(statsDf),2)
  expect_true("b" %in% statsDf$`Column Names`)
})

test_that("collect the statistics as analyze is TRUE for temporary NOPI table", {

  data <- data.frame(a=c(1,2), b = c(3,4))
  df <- copy_to(con,df = data,name = "t20", table.type = "nopi",analyze = TRUE, temporary = TRUE)
  statsDf <- DBI::dbGetQuery(con,"HELP statistics t20")
  expect_equal(nrow(statsDf),2)
  expect_true("a" %in% statsDf$`Column Names`)
})
test_that("collect the statistics as analyze is TRUE, row.names is TRUE and table type is PI (default primary index) ", {

  data <- data.frame(a=c(1,2), b = c(3,4))
  df <- copy_to(con,df = data,name = "t23", table.type = "pi",analyze = TRUE, row.names = TRUE)
  statsDf <- DBI::dbGetQuery(con,"HELP statistics t23")
  expect_equal(nrow(statsDf),2)
  expect_true("row_names" %in% statsDf$`Column Names`)
})

test_that("collect the statistics as analyze is TRUE, table type is PI and column name contains spaces ", {

  data <- data.frame(a=c(1,2), "a b" = c(3,4), check.names = FALSE)
  df <- copy_to(con,df = data,name = "t25", table.type = "pi",analyze = TRUE, primary.index = "a b")
  statsDf <- DBI::dbGetQuery(con,"HELP statistics t25")
  expect_equal(nrow(statsDf),2)
  expect_true("\"a b\"" %in% statsDf$`Column Names`)
})

test_that("overwrites existing table as metadata matches", {
  data <- data.frame(a=c('abc','def','xyz'), b= c(13.12,14.23,15.34))
  expect_equal(copy_to(con,df = data ,name = "t24", types = c('char(3)','decimal(4,2)'), row.names = FALSE),
               tbl(con,"t24"))
  expect_equal(copy_to(con,df = data ,name = "t24", types = c('char(3)','decimal(4,2)'), row.names = FALSE, overwrite = TRUE),
               tbl(con,"t24"))
  dbData <- taQuery("select * from t24")
  if(td_get_context()$driver.type != "Teradata Native Driver")
    expect_true(unique(dbData$a %in% data$a))
  expect_true(unique(dbData$b %in% data$b))
})

test_that("creating a PI table with magrittr from tbl", {
  data <- data.frame(a=c(1,2), b = c(3,4))
  t6 <- data %>% copy_to(con,df = .,table.type = "PI")
  tableName <- .get_source_definition(t6)
  dbData <- taQuery(gettextf("select * from %s",tableName))
  expect_true(unique(dbData$a %in% data$a))
  expect_true(unique(dbData$b %in% data$b))

  # Checking primary index
  expect_equal(grep("PRIMARY INDEX \\( a \\)",paste0(DBI::dbGetQuery(con, paste0("show table ",tableName)),"")),1)

  # Table should be deleted after disconnection.
  expect_true(dbExistsTable(con,tableName))
  td_remove_context()
  create_db_context()
  expect_false(dbExistsTable(con,tableName))
})

test_that("creating a NOPI table with magrittr from tbl", {
  data <- data.frame(a=c(1,2), b = c(3,4))
  t6 <- data %>% copy_to(con,df = .,table.type = "NOPI")
  tableName <- .get_source_definition(t6)
  dbData <- taQuery(gettextf("select * from %s",tableName))
  expect_true(unique(dbData$a %in% data$a))
  expect_true(unique(dbData$b %in% data$b))

  # Checking primary index
  expect_equal(grep("NO PRIMARY INDEX",paste0(DBI::dbGetQuery(con, paste0("show table ",tableName)),"")),1)

  # Table should be deleted after disconnection.
  expect_true(dbExistsTable(con,tableName))
  td_remove_context()
  create_db_context()
  expect_false(dbExistsTable(con,tableName))
})

test_that("Test cases for append functionality", {
  fac <- sample(3, 10, replace = TRUE)
  df <- data.frame(x = "a", y = 1:10, z = 2.34, fac = fac)
  
  # Specify invalid datatype for append
  expect_error(copy_to(con, df, name = "test_table_append", append = "xyz"), "Argument 'append' must be of 'logical' datatype. Multiple values are not supported.")

  # Set overwrite tp TRUE along with another append operation
  expect_error(copy_to(con, df, name = "test_table_append", append = TRUE,
                       overwrite = TRUE), "'append' and 'overwrite' both cannot be set to TRUE")
  
  copy_to(con, df, name = "test_table_append")
  # Try copying to an already existing table without append or overwrite set to TRUE
  expect_error(copy_to(con, df, name = "test_table_append"), "Table 'test_table_append' already exists")
  
  # Try appending a table instead of a dataframe
  test_table_append <- tbl(con, "test_table_append")
  expect_error(copy_to(con, test_table_append, name = "test_table_append", append = TRUE),
               "A table cannot be appended to another table. Alternatively, use the as.data.frame\\() function to convert 'df' to an R data frame before appending.")
  
  # Try appending a dataframe which does not match with the table metadata/structure
  new_df <- data.frame(c(TRUE, 'b', 'L'))
  expect_error(copy_to(con, new_df, name = "test_table_append", append = TRUE), 
               "Cannot append to 'test_table_append', as table structure does not match 'df'.")
  
  df <- rbind(df, data.frame(list(x = '0', y = 5, z = 'a', fac = '04-04-2990')))
  expect_error(copy_to(con, new_df, name = "test_table_append", append = TRUE), 
               "Cannot append to 'test_table_append', as table structure does not match 'df'.")
})

test_that("Overwrite table with a table", {
  df <- data.frame(column1 = c(1,2,3), column2 = c('teradata','vantage','release'),
                   column3 = c(TRUE,FALSE,TRUE))
  
  # Overwrite to a non existent table. Should create a new table
  expect_equal(copy_to(con, df, name = "test_table_overwrite", overwrite = TRUE), tbl(con, "test_table_overwrite"))
  tt_overwrite <- tbl(con, "test_table_overwrite")
  expect_equal(nrow(as.data.frame(tt_overwrite)), 3)
  
  # Overwrite a table with itself. Should expect an error.
  expect_error(copy_to(con, tt_overwrite, name = "test_table_overwrite", overwrite = TRUE), "Cannot overwrite table with itself.")
  
  df <- data.frame(x = "a", y = 1:10, z = 2.34)
  copy_to(con, df, name = "test_df", append = TRUE)
  expect_equal(copy_to(con, df, name = "test_table_overwrite", overwrite = TRUE), tbl(con, "test_table_overwrite"))
  expect_equal(copy_to(con, tbl(con, "test_df"), name = "test_table_overwrite", overwrite = TRUE), tbl(con, "test_table_overwrite"))
  expect_equal(nrow(as.data.frame(tt_overwrite)), 10)

  DBI::dbExecute(con, dplyr::sql("create view test_view as select * from test_table_overwrite"))
  expect_error(copy_to(con, df, name = "test_view", overwrite = TRUE), "'test_view' is not a table.")
  expect_true(dbExistsTable(con,"test_view"))
})

test_that("Enhance types to support named character vector", {
  # Create sample data frames.
  df1 <- data.frame(name='a', age=21)
  df2 <- data.frame(name='b', age=25)
  
  copy_to(con, df1, name = "tt1", append = TRUE)
  # Specify a type for the column in data frame which does not match the one in database.
  expect_error(copy_to(con, df2, name = "tt1", append = TRUE, types = c("varchar", "integer")), 
               "Cannot append to 'tt1', as table structure does not match 'df'.")
  # Case where mix of named and unnamed cahracter vector is used for types.
  expect_error(copy_to(con, df2, name = "tt1", append = TRUE, types = c(name="varchar", "integer")),
               "Incorrect specification for argument 'types'. Cannot be a mix of named and unnamed character vector.")
  # Case where name specified in types vector does not match a column in the data frame.
  expect_error(copy_to(con, df2, name = "tt1", append = TRUE, types = c(fname="varchar", year="integer")),
               "Column\\(s) 'fname,year' provided in 'types' argument does not exist in object specified in 'df' argument")
  # Case where all the types of column are not specified in the unnamed vector.
  expect_error(copy_to(con, df2, name = "tt1", append = TRUE, types = c("integer")),
               "Length of 'types' argument does not match number of columns in data frame.")
  # Case where an item in types vector is empty string
  expect_error(copy_to(con, df2, name = "tt1", append = TRUE, types = c("", "double")),
               "Argument 'types' should not contain empty string.")
  expect_error(copy_to(con, df2, name = "tt1", append = TRUE, types = c(name="", age="double")),
               "Argument 'types' should not contain empty string.")
  
  # Case where data can be appended successfully with types not specified
  expect_equal(copy_to(con, df2, name = "tt1", append = TRUE), tbl(con, "tt1"))
  
  # Case where data can be appended successfully with types specified as unnamed vector.
  expect_equal(copy_to(con, df2, name = "tt1", append = TRUE, types = c("varchar(20)", "float")), tbl(con, "tt1"))
  
  # Case where data can be appended successfully with types specified as named character vector.
  expect_equal(copy_to(con, df2, name = "tt1", append = TRUE, types = c(name="varchar(20)", age="float")), tbl(con, "tt1"))
  
  emp.data <- data.frame(
    emp_id = c (1:5), 
    emp_name = c("Rick","Dan","Michelle","Ryan","Gary"),
    salary = c(623.3,515.2,611.0,729.0,843.25), 
    
    start_date = as.Date(c("2012-01-01", "2013-09-23", "2014-11-15", "2014-05-11",
                           "2015-03-27")),
    married = c(FALSE, TRUE, TRUE, FALSE, TRUE),
    stringsAsFactors = FALSE
  )
  tmp_emp <- emp.data[5,]
  emp.data <- emp.data[1:4,]
  copy_to(con, emp.data, name = "employee", overwrite = TRUE)
  # Data type of column emp_id is incorrect.
  expect_error(copy_to(con, tmp_emp, name = "employee", append = TRUE, types = c(emp_id="real", married="byteint")), 
               "Cannot append to 'employee', as table structure does not match 'df'.")
  # Data type for column start_date is wrong.
  expect_error(copy_to(con, tmp_emp, name = "employee", append = TRUE, types = c(start_date="time", emp_name="char")), 
               "Cannot append to 'employee', as table structure does not match 'df'.")
  # Specify datatype aliases for the columns.
  expect_equal(copy_to(con, tmp_emp, name = "employee", append = TRUE, types = c(emp_id="integer", salary="real")),
               tbl(con, "employee"))

  # Passing uppercase to column names in 'types' argument, whereas the column names in Vantage is lower case.
    expect_equal(copy_to(con, tmp_emp, name = "employee", append = TRUE, types = c(EMP_ID="integer", salary="real")),
               tbl(con, "employee"))
  
  # Passing mixed case to column names in 'types' argument, whereas the column names in Vantage is lower case.
    expect_equal(copy_to(con, tmp_emp, name = "employee", append = TRUE, types = c(EMP_ID="integer", sALArY="real")),
               tbl(con, "employee"))

  # Passing uppercase to SQL types in 'types' argument.
    expect_equal(copy_to(con, tmp_emp, name = "employee", append = TRUE, types = c(emp_id="INTEGER", salary="real")),
               tbl(con, "employee"))

  expect_error(copy_to(con, tbl(con, "employee"), name = "dummy_table", types = c(emp_id = "integer")), "types and row.names argument\\(s) is/are not supported for tbl_teradata")
})

testthat::teardown(
  {
    cleanup()
    td_remove_context()
  }
)

