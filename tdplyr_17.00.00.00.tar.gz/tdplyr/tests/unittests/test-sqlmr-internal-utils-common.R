################################################################################
# This contains test cases for utility functions which will be used to
#   1. Quote strings or list of strings/variables.
#   2. Generate temp table names.
# 
# Primary Owner: pankajvinod.purandare@teradata.com
# Secondary Owner:
#
################################################################################
context("Unit tests for SQL-MR utils.")

test_that("Unit test for .getFunctionPredictionType", {
  predictiontypes <- .get("predictiontypes")
  
  functionList <- list(
    td_adaboost_mle = predictionTypes$classification,
    td_adaboost_predict_mle = predictionTypes$classification,
    td_antiselect_mle = predictionTypes$other,
    td_antiselect_sqle = predictionTypes$other,
    td_arima_mle = predictionTypes$regression,
    td_arima_predict_mle = predictionTypes$regression,
    td_attribution_mle = predictionTypes$other,
    td_attribution_sqle = predictionTypes$other,
    td_burst_mle = predictionTypes$other,
    td_ccm_mle = predictionTypes$other,
    td_ccm_prepare_mle = predictionTypes$other,
    td_cfilter_mle = predictionTypes$other,
    td_changepoint_detection_mle = predictionTypes$other,
    td_changepoint_detection_rt_mle = predictionTypes$other,
    td_confusion_matrix_mle = predictionTypes$other,
    td_coxph_mle = predictionTypes$regression,
    td_cox_hazard_ratio_mle = predictionTypes$regression,
    td_cox_survival_mle = predictionTypes$regression,
    td_cumulative_mov_avg_mle = predictionTypes$other,
    td_decision_forest_evaluator_mle = predictionTypes$other,
    # Commenting the following function as it requires function
    # object with data and formula for evaluating the
    # prediction type, and will be covered in the Dart tests.
    #td_decision_forest_mle,
    td_decision_forest_predict_mle = predictionTypes$other,
    td_decision_forest_predict_sqle = predictionTypes$other,
    td_decision_tree_mle = predictionTypes$classification,
    td_decision_tree_predict_mle = predictionTypes$classification,
    td_decision_tree_predict_sqle = predictionTypes$classification,
    td_dtw_mle = predictionTypes$other,
    td_dwt2d_mle = predictionTypes$other,
    td_dwt_mle = predictionTypes$other,
    td_exponential_mov_avg_mle = predictionTypes$other,
    td_fpgrowth_mle = predictionTypes$other,
    td_glml1l2_mle = predictionTypes$regression,
    td_glml1l2_predict_mle = predictionTypes$regression,
    td_glm_mle = predictionTypes$regression,
    td_glm_predict_mle = predictionTypes$regression,
    td_glm_predict_sqle = predictionTypes$regression,
    td_histogram_mle = predictionTypes$other,
    td_hmm_decoder_mle = predictionTypes$other,
    td_hmm_evaluator_mle = predictionTypes$other,
    td_hmm_supervised_mle = predictionTypes$other,
    td_hmm_unsupervised_mle = predictionTypes$other,
    td_idwt2d_mle = predictionTypes$other,
    td_idwt_mle = predictionTypes$other,
    td_kmeans_mle = predictionTypes$clustering,
    td_knn_mle = predictionTypes$classification,
    td_knn_recommender_mle = predictionTypes$other,
    td_knn_recommender_predict_mle = predictionTypes$other,
    td_lar_mle = predictionTypes$regression,
    td_lar_predict_mle = predictionTypes$regression,
    td_lda_inference_mle = predictionTypes$classification,
    td_lda_mle = predictionTypes$classification,
    td_lda_topic_summary_mle = predictionTypes$classification,
    td_levenshtein_distance_mle = predictionTypes$other,
    td_linreg_predict_mle = predictionTypes$regression,
    td_lin_reg_mle = predictionTypes$regression,
    td_minhash_mle = predictionTypes$clustering,
    td_modularity_mle = predictionTypes$other,
    td_moving_average_sqle = predictionTypes$other,
    td_naivebayes_mle = predictionTypes$classification,
    td_naivebayes_predict_mle = predictionTypes$classification,
    td_naivebayes_predict_sqle = predictionTypes$classification,
    td_naivebayes_textclassifier_mle = predictionTypes$classification,
    td_naivebayes_textclassifier_predict_mle = predictionTypes$classification,
    td_naivebayes_textclassifier_predict_sqle = predictionTypes$classification,
    td_namedentity_finder_evaluator_mle = predictionTypes$other,
    td_namedentity_finder_mle = predictionTypes$other,
    td_namedentity_finder_trainer_mle = predictionTypes$other,
    td_ngramsplitter_mle = predictionTypes$other,
    td_ngramsplitter_sqle = predictionTypes$other,
    td_npath_mle = predictionTypes$other,
    td_npath_sqle = predictionTypes$other,
    td_ntree_mle = predictionTypes$other,
    td_pack_mle = predictionTypes$other,
    td_pack_sqle = predictionTypes$other,
    td_page_rank_mle = predictionTypes$other,
    td_path_analyzer_mle = predictionTypes$other,
    td_path_generator_mle = predictionTypes$other,
    td_path_start_mle = predictionTypes$other,
    td_path_summarizer_mle = predictionTypes$other,
    td_pivot_mle = predictionTypes$other,
    td_pos_tagger_mle = predictionTypes$other,
    td_random_sample_mle = predictionTypes$other,
    td_random_walk_sample_mle = predictionTypes$other,
    td_sampling_mle = predictionTypes$other,
    td_sax_mle = predictionTypes$other,
    td_scale_by_partition_mle = predictionTypes$other,
    td_scale_map_mle = predictionTypes$other,
    td_scale_mle = predictionTypes$other,
    td_scale_summary_mle = predictionTypes$other,
    td_sentence_extractor_mle = predictionTypes$other,
    td_sentiment_evaluator_mle = predictionTypes$other,
    td_sentiment_extractor_mle = predictionTypes$other,
    td_sentiment_trainer_mle = predictionTypes$other,
    td_series_splitter_mle = predictionTypes$other,
    td_sessionize_mle = predictionTypes$other,
    td_sessionize_sqle = predictionTypes$other,
    td_simple_mov_avg_mle = predictionTypes$other,
    td_string_similarity_mle = predictionTypes$other,
    td_string_similarity_sqle = predictionTypes$other,
    td_svm_dense_mle = predictionTypes$classification,
    td_svm_dense_predict_mle = predictionTypes$classification,
    td_svm_dense_summary_mle = predictionTypes$classification,
    td_svm_sparse_mle = predictionTypes$classification,
    td_svm_sparse_predict_mle = predictionTypes$classification,
    td_svm_sparse_predict_sqle = predictionTypes$classification,
    td_svm_sparse_summary_mle = predictionTypes$classification,
    td_text_chunker_mle = predictionTypes$other,
    td_text_classifier_evaluator_mle = predictionTypes$classification,
    td_text_classifier_mle = predictionTypes$classification,
    td_text_classifier_trainer_mle = predictionTypes$classification,
    td_text_morph_mle = predictionTypes$other,
    td_text_parser_mle = predictionTypes$other,
    td_text_tagger_mle = predictionTypes$other,
    td_text_tokenizer_mle = predictionTypes$other,
    td_tfidf_mle = predictionTypes$other,
    td_tf_mle = predictionTypes$other,
    td_unpack_mle = predictionTypes$other,
    td_unpack_sqle = predictionTypes$other,
    td_unpivot_mle = predictionTypes$other,
    td_varmax_mle = predictionTypes$regression,
    td_vector_distance_mle = predictionTypes$other,
    td_weighted_mov_avg_mle = predictionTypes$other,
    td_xgboost_mle = predictionTypes$classification,
    td_xgboost_predict_mle = predictionTypes$classification
  )
  
  ### Test that we get expected Prediction Type for given functions
  # Loop throught the list
  for (func in names(functionList)) {
    functionObj <- "dummy"
    functionEngine <- "ENGINE_ML"
    if (grepl("_sqle", func)) {
      functionEngine <- "ENGINE_SQL"
    }
    
    attr(functionObj, "class") <- .getSQLMRClass(func, engine = .getEngineName(
      functionEngine))
    
    # Compare the result of .getFunctionPredictionType() with the expected.
    # Note that the .getFunctionPredictionType() function has no second argument
    # as it is optional.
    expect_equal(.getFunctionPredictionType(functionObj),
                 functionList[[func]])
  }
  
  ### Test for errors on invalid inputs
  # Invalid required argument - analytic function object
  expect_error(.getFunctionPredictionType("dummy", "dummyDataFrame"),
               paste0("Argument 'analytic.function.object' should be of ",
                      "td_analytics type"))
  
  functionObj <- "dummy"
  attr(functionObj, "class") <- .getSQLMRClass("td_decision_forest_mle",
                                               engine = .getEngineName(
                                                 "ENGINE_ML"))
  
  # Invalid required argument - tbl_teradata for input dependent function
  expect_error(.getFunctionPredictionType(functionObj, "dummyDataFrame"),
               "Argument 'input.data' should be of tbl_teradata type")
  
  # Missing required argument - tbl_teradata for input dependent function
  expect_error(.getFunctionPredictionType(functionObj),
               "Following required arguments are missing: input.data")
  
  ### Test the internal function with invalid inputs
  # Invalid required argument - tbl_teradata for input dependent function
  expect_error(.getInputDependentPredictionType(functionObj, "dummyDataFrame"),
               "Argument 'input.data' should be of tbl_teradata type")
  
  # Missing required argument - tbl_teradata for input dependent function
  expect_error(.getInputDependentPredictionType(functionObj),
               "argument \"input.data\" is missing, with no default")
})

test_that("Unit test cases for .teradataGenerateTempTableName", {
  # Test prefix with other options set to default
  prefix <- NULL
  expect_match(.teradataGenerateTempTableName(prefix, gc.onQuit = FALSE), "r_t__")
  prefix <- NA
  expect_match(.teradataGenerateTempTableName(prefix, gc.onQuit = FALSE), "r_t__")
  prefix <- NaN
  expect_match(.teradataGenerateTempTableName(prefix, gc.onQuit = FALSE), "r_t__")
  prefix <- ""
  expect_error(.teradataGenerateTempTableName(prefix, gc.onQuit = FALSE), 
               "Prefix should not contain only spaces or tabs or newlines.")
  prefix <- " "
  expect_error(.teradataGenerateTempTableName(prefix, gc.onQuit = FALSE),
               "Prefix should not contain only spaces or tabs or newlines.")
  prefix <- "\t"
  expect_error(.teradataGenerateTempTableName(prefix, gc.onQuit = FALSE),
               "Prefix should not contain only spaces or tabs or newlines.")
  prefix <- "\n"
  expect_error(.teradataGenerateTempTableName(prefix, gc.onQuit = FALSE),
               "Prefix should not contain only spaces or tabs or newlines.")
  prefix <- "glm"
  expect_match(.teradataGenerateTempTableName(prefix, gc.onQuit = FALSE), "r_t__glm_")
  
  # Test use.default.database=TRUE
  # TODO: Needs to be run again, once '.ta.getTempDatabase()' is merged.
  #expect_match(
  #  with_mock(
  #    `tdplyr::.ta.getTempDatabase` = function () {
  #      return("dbname")
  #    }, 
  #    `tdplyr::.ta.getUserName` = function () {
  #      return("username")
  #    },
  #    .teradataGenerateTempTableName(prefix, use.default.database = TRUE, gc.onQuit = FALSE)), 
  #  "\"dbname\".r_username_t__glm")
  
  # Test gc.onQuit = TRUE
  # Move this test to gc file since it overwrites session file
  # expect_match(.teradataGenerateTempTableName(prefix, gc.onQuit = TRUE), "r_t__glm")
})

test_that("Unit Test cases for '.isRefFuncOutput':", {
  
  ##### Test cases for '.isRefFuncOutput' #####
  # Empty string 
  x <- ""
  expect_false(.isRefFuncOutput(x, "td_glm_mle")) 
  x <- NA
  expect_false(.isRefFuncOutput(x, "td_glm_mle")) 
  x <- NULL
  expect_false(.isRefFuncOutput(x, "td_glm_mle")) 
  x <- NaN
  expect_false(.isRefFuncOutput(x, "td_glm_mle")) 
  
  # Character string
  x <- "non-empty"
  expect_false(.isRefFuncOutput(x, "td_glm_mle")) 
  
  # Boolean i.e. logical element is passed.
  expect_false(.isRefFuncOutput(TRUE, "td_glm_mle")) 
  
  # Numeric is passed
  expect_false(.isRefFuncOutput(10, "td_glm_mle")) 
  
  # input is numeric
  x <- 10
  attr(x, "class") <- "td_glm_mle"
  expect_true(.isRefFuncOutput(x, "td_glm_mle")) 
})


################################################################################
# This contains test cases for utility functions which will be used to
# quote strings or list of strings/variables.
################################################################################

context("Test Quote Utility Functions.")
test_that("Unit Test cases for '.teradataQuoteArg':", {
  
  ##### Test cases for '.teradataQuoteArg' #####
  # Empty string quoting - Default quote.
  x <- ""
  expect_identical(.teradataQuoteArg(x), "''") 
  x <- NA
  expect_identical(.teradataQuoteArg(x), NA) 
  x <- NULL
  expect_equal(.teradataQuoteArg(x), "NA_character_") 
  x <- NaN
  expect_identical(.teradataQuoteArg(x), NA)
  
  # Non-empty string quoting - Default quote.
  x <- "non-empty"
  expect_identical(.teradataQuoteArg(x), "'non-empty'")
  
  # Non-Empty string quoting - double quote.
  expect_identical(.teradataQuoteArg(x, "\""), "\"non-empty\"") 
  
  # Non-Empty string quoting - ` as quote.
  expect_identical(.teradataQuoteArg(x, "`"), "`non-empty`") 
  
  # input is numeric
  x <- 10
  expect_identical(.teradataQuoteArg(x), "'10'")
})

test_that("Unit Test cases for '.teradataCollapseArgVector':", {
  ##### Test cases for '.teradataCollapseArgVector' #####
  # Empty string quoting - Default quote.
  vec <- c()
  expect_equal(.teradataCollapseArgVector(vec), "NA_character_") 
  vec <- NA
  expect_identical(.teradataCollapseArgVector(vec), NA)
  vec <- NaN
  expect_identical(.teradataCollapseArgVector(vec), NA)
  vec <- NULL
  expect_equal(.teradataCollapseArgVector(vec), "NA_character_") 
  
  # Non-empty string quoting - Default quote.
  vec <- c("str1", "str2", "str3")
  expect_identical(.teradataCollapseArgVector(vec), "'str1','str2','str3'")
  
  # Non-Empty string quoting - double quote.
  expect_identical(.teradataCollapseArgVector(vec, "\""), "\"str1\",\"str2\",\"str3\"") 
  
  # Non-Empty string quoting - ` as quote.
  expect_identical(.teradataCollapseArgVector(vec, "`"), "`str1`,`str2`,`str3`") 
  
  # input is numeric
  x <- c(10, 20, 30, 40)
  expect_identical(.teradataCollapseArgVector(x), "'10','20','30','40'")
})

test_that("Unit Test cases for '.getAliasNameForFunction':", {
  ##### Test cases for '.getAliasNameForFunction' #####

  expect_identical(.getAliasNameForFunction('pivot'),"Pivoting")
  expect_identical(.getAliasNameForFunction('CCMPrepare'),"CCMPrepare")
  expect_identical(.getAliasNameForFunction('confusionmatrix',"ml"),"ConfusionMatrix")
  expect_identical(.getAliasNameForFunction('NaiveBayesTextClassifierPredict',"sql"),"NaiveBayesTextClassifierPredict")
  
  #case insensitive cases
  #use default engine
  expect_identical(.getAliasNameForFunction('PivoT'),"Pivoting")
  #privide engine parameter.
  expect_identical(.getAliasNameForFunction('PivoT', "ML"),"Pivoting")
  #use sqlengine
  expect_identical(.getAliasNameForFunction('npath',"SQL"),"NPath")

  #Two aliases for attribution
  expect_identical(.getAliasNameForFunction('Attribution',"sql"),"Attribution")
  expect_identical(.getAliasNameForFunction('Attribution',"ml"),"attribution_coprocessor")
  
  #Error handling cases
  #invalid engine specified
  expect_error(.getAliasNameForFunction('npath',"noengine"), "Engine noengine specified is not valid")
  
  # function does not exist for given engine type.
  # we now have ml engine alias for npath function npath_MLE. So below check is not needed.
  # expect_error(.getAliasNameForFunction('npath',"ml"), "Alias not found for function 'npath' for engine 'ml'")
  
  # function does not exist for given engine type.
  expect_error(.getAliasNameForFunction('pivot',"sql"), "Alias not found for function 'pivot' for engine 'sql'")
  
  # default value mlengine so npath alias will not be returned.
  # we now have ml engine alias for npath function npath_MLE. So below check is not needed.
  # expect_error(.getAliasNameForFunction('npath'),"Alias not found for function 'npath' for engine 'ml'")
  
  #missing argument
  expect_error(.getAliasNameForFunction(),'argument "functionName" is missing, with no default')
  expect_error(.getAliasNameForFunction(engine = "sql"),'argument "functionName" is missing, with no default')
  
})

test_that("Unit Test cases for '.getSQLMRClass':", {
  getHierarchyML <- function(s) {
    c(s, "td_analytics_ml", "td_analytics", "list")
  }
  getHierarchySQL <- function(s) {
    c(s, "td_analytics_sql", "td_analytics", "list")
  }
  # with default engine
  expect_identical(.getSQLMRClass("td_glm_mle"), getHierarchyML("td_glm_mle"))
  # with engine
  expect_identical(.getSQLMRClass("td_glm_mle", engine = "ml"), getHierarchyML("td_glm_mle"))
  # with upper case engine
  expect_identical(.getSQLMRClass("td_glm_mle", engine = "ML"), getHierarchyML("td_glm_mle"))
  # with upper case sub class
  expect_identical(.getSQLMRClass("Td_GlM_mle", engine = "ml"), getHierarchyML("td_glm_mle"))
  # using .getEngineName
  expect_identical(.getSQLMRClass("td_glm_mLE", engine = .getEngineName("ENGINE_ML")), getHierarchyML("td_glm_mle"))

  # Do with engine = sql
  expect_identical(.getSQLMRClass("td_npath_sqle", engine = "sql"), getHierarchySQL("td_npath_sqle"))
  # with upper case engine
  expect_identical(.getSQLMRClass("td_npath_sqle", engine = "Sql"), getHierarchySQL("td_npath_sqle"))
  # with upper case sub class
  expect_identical(.getSQLMRClass("td_NpAth_Sqle", engine = "sql"), getHierarchySQL("td_npath_sqle"))

  # using .getEngineName
  expect_identical(.getSQLMRClass("td_npath_sqle", engine = .getEngineName("ENGINE_SQL")), getHierarchySQL("td_npath_sqle"))
})
