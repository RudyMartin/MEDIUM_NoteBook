context ("Unit tests to verify using both ODBC and Native driver in the same R session.")

# NOTE: This one has skip_if statements because the scenario of using both odbc and native,
# in same session does not work very well on mac.
verifyConnection <- function(con, parentClass) {
  expect_equal(as.character(class(con)), "Teradata")
  # check the entire class hierarchy
  hierarchy <- methods::getAllSuperClasses(methods::getClass(class(con)))
  expected_hierarchy <- c(parentClass, "DBIConnection", "DBIObject")
  expect_equal(length(hierarchy), 3)
  expect_true(all.equal(hierarchy, expected_hierarchy))
  # check if the connection worked witha query
  expect_equal(nrow(DBI::dbGetQuery(con, "select user")), 1)
}

getDefaultDatabase <- function(con) {
  # dont use the getter here as we want to test that as well
  toupper(DBI::dbGetQuery(con, "select database")[[1]])
}

verifyContext <- function(con, defaultDB, tempDB) {
  expect_true(identical(con, .taConnection()))
  expect_equal(.ta.getDefaultDatabase(), defaultDB)
  expect_equal(.ta.getTempDatabase(), tempDB)
}

verifyRemoved <- function(con) {
  expect_false(.ta.isConnectionValid(con))
  # Check if context is removed
  expect_true(is.null(.taConnection(silent = TRUE)))
  expect_error(.taConnection())
  expect_true(is.null(.ta.getTempDatabase(silent = TRUE)))
}

test_that("Create context using Native driver then ODBC and then Native driver again", {
  # skip_if(!.ta.isPlatformLinux(), "*** Running Native driver tests only on Linux")
  con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native")
  verifyConnection(con, "TeradataConnection")
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)

  td_remove_context()
  verifyRemoved(con)

  con <- td_create_context(dsn = dsnName)
  verifyConnection(con, "OdbcConnection")
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)

  # Now Create context without removing

  # Note this does not throw warning because of the change in driver
  con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native")
  verifyConnection(con, "TeradataConnection")
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)

  td_remove_context()
  verifyRemoved(con)

})


test_that("Create context using ODBC then Native driver and then ODBC again", {
  # skip_if(!.ta.isPlatformLinux(), "*** Running Native driver tests only on Linux")

  con <- td_create_context(dsn = dsnName)
  verifyConnection(con, "OdbcConnection")
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)
  
  td_remove_context()
  verifyRemoved(con)

  con <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native")
  verifyConnection(con, "TeradataConnection")
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)

  # Now Create context without removing
  # Note this does not throw warning because of the change in driver
  con <- td_create_context(dsn = dsnName)
  verifyConnection(con, "OdbcConnection")
  defaultDB <- getDefaultDatabase(con)
  verifyContext(con, defaultDB, defaultDB)

  td_remove_context()
  verifyRemoved(con)
})


test_that("Use Multiple simultaneous connections with dbConnect and both drivers ", {
  # skip_if(!.ta.isPlatformLinux(), "*** Running Native driver tests only on Linux")

  # Create 3 connections with odbc
  con1 <- td_create_context(dsn = dsnName)
  con2 <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
  con3 <- DBI::dbConnect(odbc::odbc(), dsn = dsnName)
  
  verifyConnection(con1, "OdbcConnection")
  defaultDB <- getDefaultDatabase(con1)
  verifyContext(con1, defaultDB, defaultDB)

  verifyConnection(con2, "OdbcConnection")
  defaultDB <- getDefaultDatabase(con2)
  
  verifyConnection(con3, "OdbcConnection")
  defaultDB <- getDefaultDatabase(con3)

  td_remove_context()
  DBI::dbDisconnect(con2)
  DBI::dbDisconnect(con3)
  verifyRemoved(con1)
  verifyRemoved(con2)
  verifyRemoved(con3)
  
  # Next create 3 connections with native
  con4 <- td_create_context(host = globalHost, uid = globalUID, pwd = globalPWD, dType = "native")
  con5 <- DBI::dbConnect(tdplyr::NativeDriver(), host = globalHost, uid = globalUID, pwd = globalPWD)
  con6 <- DBI::dbConnect(tdplyr::NativeDriver(), host = globalHost, uid = globalUID, pwd = globalPWD)
  
  verifyConnection(con4, "TeradataConnection")
  defaultDB <- getDefaultDatabase(con4)
  verifyContext(con4, defaultDB, defaultDB)

  verifyConnection(con5, "TeradataConnection")
  defaultDB <- getDefaultDatabase(con5)
  
  verifyConnection(con6, "TeradataConnection")
  defaultDB <- getDefaultDatabase(con6)

  td_remove_context()
  DBI::dbDisconnect(con5)
  DBI::dbDisconnect(con6)
  verifyRemoved(con4)
  verifyRemoved(con5)
  verifyRemoved(con6)

})
