# Testing
We should adopt the following approach for testing:

# Folder Structure:
* **unittests (in tdplyr repo):** This directory contains tests typically to validate internal functions. The test case May OR May not connect to the backend. We can run these tests with with *test_dir()* instead of *test()*. There doesn't seem to be any advantage in maintaining two separate set of unit tests - not connecting to the backend and others that connect to the backend. So, just combining them into a single folder is easier to manage.
  * Note: This does not mean you cannot call external APIs in unittests. You can but, if you see yourself calling an external API and then validating the output / error returned by that, then it might actually make sense to move it to the end2end folder as discussed below.
* **end2end (in dart repo):** This directory contains tests that will ONLY use **exposed APIs**. The test cases in this folder will test user scenarios (both positive and negative) for each API.
* **end2end-smoke ** (in dart, but optional for now): This directory can be considered as a subset of end2end but with a **few good positive** test cases go in here and may be one or two negative tests **for each API**. Developers can use this to do basic **build verification** before submitting Pull requests.

# Setup and Clean up:
So far we have been doing setup and cleanup within each test file. This is the main reason why our tests are taking so long. It makes sense to create a **common set of tables** that all test cases can use UNLESS any test case requires modifying or deleting or creating tables then the test case has to have its own setup. The global setup tables should be enough for most of our test cases.
The global setup should contain multiple tables: **With a Rich set of types and data.**
Testthat has support for setup-* and teardown-* files. But it may not be supported in DART so we can have the **setup** and **teardown** files in sub-folders.

Steps to submit PR and DART Test cases:
1. In tdplyr repo - do the code changes.
2. Add unit test cases, execute the same.
3. Run build() -- This will generate the tdplyr tar ball. Use the location of this file, as tar ball location.
4. Add end to end test cases to Dart folder structure.
5. Add TST files and Config files
6. Execute Dart tests.
7. Raise separate PR's
